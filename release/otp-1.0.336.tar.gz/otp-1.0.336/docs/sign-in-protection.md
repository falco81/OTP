# Sign-in protection

*Settings → Sign-in protection* (1.0.137). Two things, each switched and tuned
there (or with `otp --set`):

1. **Guessing from one place held back** - RADIUS, off by default.
2. **Changes that could cut the server off taken back** unless somebody keeps
   them - a node's new network, and the firewall and who may reach the pages;
   on by default.
3. **Wrong directory passwords per person capped** (1.0.230) - so guesses made
   here never lock the account in Active Directory; off by default. Per
   directory, with the domain's own lockout and password policy read and a cap
   recommended, since 1.0.232.

## 1. Guessing from one place (RADIUS)

Without it, only each token counts its own wrong codes (`rate_limit_tries`,
`lockout_after`). From one place somebody may still try every name a few times
a day, or lock everybody's token on purpose.

Switched on, the place each request comes from is counted too: the
`Calling-Station-Id` the VPN sends - the address the person connects to the VPN
from (a MAC address on Wi-Fi; IPv6 counted by its /64). A request without one
is not counted.

| Setting | Default | What it is |
|---|---|---|
| `radius_guard` | 0 (off) | the switch |
| `radius_guard_tries` | 20 | refusals from one place within the window - and it is blocked |
| `radius_guard_names` | 5 | different names refused from one place within the window - and it is blocked (0: not counted) |
| `radius_guard_window_min` | 15 | the window the refusals are counted over |
| `radius_guard_block_min` | 30 | how long a place stays blocked |
| `radius_guard_trusted` | (none) | addresses or networks never blocked: an office behind one address, a monitor |

Counted: wrong passwords, wrong codes, names nobody has. Not counted: refusals
that are the server's own trouble (a directory away, a realm not set up, a code
that could not be sent).

A blocked place is refused at once - nothing of its requests is checked (no
directory bind, no code), and **nobody's token counts them**, so a guesser can
no longer lock other people's tokens either. The refusal says why in the log
(*the step: sign-in protection*), and Events has a line when a place is blocked.

**Who is counted and who is blocked** is in the table under the settings, with
the tokens locked by wrong codes: how many refusals and names against the limit
(a bar that fills), how long a block still runs, the names tried. Type a name or
an address to see only those; *Clear* lets one in again at once, *Clear these* /
*Clear them all* the ones shown. The same rows are in *Accounts → Locked out*.

Each node counts what reaches it (in memory, as the pages' sign-ins are); both
nodes' lists are shown, and clearing reaches the other node within seconds.

```bash
otp --set radius_guard=1
otp --set radius_guard_tries=20
otp --set radius_guard_names=5
otp --set radius_guard_trusted='198.51.100.7 203.0.113.0/24'
```

## 1.1 Wrong directory passwords per person (1.0.230)

A directory password is tried against Active Directory at each sign-in to the
enrolment pages, at each new token there (*Replace it*), and at each sign-in of
an administrator from the directory. Until 1.0.230 each of these had a count of
its own, per address and per name, held in each node's memory: from many
addresses, and on two nodes, a name could get dozens of wrong passwords through
to the directory in a quarter of an hour - more than its lockout threshold
(typically 5 to 10), and the account was locked there: mail, the VPN, the PC.

| Setting | Default | |
|---------|---------|--|
| `dir_pw_tries` | `0` | Wrong directory passwords for one name, from anywhere and on any node, before the directory is no longer asked for it. **0 = no cap of its own, as until now.** |
| `dir_pw_window_min` | `30` | How long one counts. As long as the directory's *Reset account lockout counter after*, or longer. |

Set `dir_pw_tries` **below** the directory's lockout threshold - 3 for a
threshold of 5 to 10. Over the cap, the name gets *too many wrong passwords for
this name: try again in N min* and the directory is not asked at all - the
account in Active Directory stays unlocked; only these pages wait. A right
password does not count. The count is kept in the database: both nodes of an HA
pair and every node on one database count together; `DOMAIN\novak`,
`novak@corp.cz` and `Novak` are one name. *Locked out* (Accounts, and Sign-in
protection) shows the names counted and clears them one by one. RADIUS is not
affected - it has its own *Guessing from one place* above and the lockout of
tokens.

```
otp --set dir_pw_tries=3
otp --set dir_pw_window_min=30
```

## 1.2 Per directory, and the domain's own policy (1.0.232)

Under *Wrong directory passwords per person* every configured directory has a
card of its own: its servers, whether the link is encrypted, and how it is capped.

- **As the setting above** - `dir_pw_tries` and `dir_pw_window_min` (the default:
  as in 1.0.230).
- **Its own** - a cap and a window for this directory alone.
- **No cap** - this directory is never held back here, whatever the setting above
  says.

Each directory is counted on its own: `novak` of one domain and `novak` of
another are two names. **Counted by the account** (1.0.234): the person's entry in the
directory, whatever name was typed - `novakj` (sAMAccountName), `jan.novak@corp.cz` (UPN)
and the e-mail address are one count. *Locked out* shows it as the first part of the
account's DN and a short hash of it (`jan novak#3f2a9c1e|corp`). A name the directory does
not have is counted as typed, the same way - so the answer never tells which names exist.
A password refused before the directory is asked (empty, or with a control character) does
not count.

**Read the domain's policy** (full administrators) connects to the directory with
its own bind account and reads what the domain itself says: the *Account lockout*
(threshold, how long one counts, how long it locks), the *Password policy*
(length, complexity, history, the longest and shortest age) and every
*Fine-grained password policy* (PSO) in `CN=Password Settings Container,CN=System`
that the bind account may read. It recommends a cap: two under the lowest
threshold when that is over 3, else one under (at least 1), over the longest
window of them - so the person always has some tries left before the domain
locks them. *Use it* only fills it in on the card; nothing changes until **Save
the changes** at the bottom of the page (*Put them back* forgets it). A domain
that does not lock accounts at all (threshold 0) is said so; 10 in 30 minutes is
recommended then all the same - it still slows down guessing.

What was read is kept beside the caps and shown again the next time the page is
opened, with when it was read.

```bash
otp --dir-caps                   # the setting and each directory's own cap, and its policy as read
```
```bash
otp --dir-cap corp=3/30          # its own: 3 wrong passwords in 30 min; corp=setting, corp=none
```
```bash
otp --dir-policy corp            # read the domain's policy now, and the cap recommended
```
The console has them under *RADIUS clients, realms and directories*. `otp --dir-sample corp novak`
shows every attribute of one person (where the e-mail address and the mobile number are read).

## 2. Changes taken back unless kept

| Setting | Default | |
|---|---|---|
| `net_confirm_min` | 10 | a node's new network (Settings → Network) goes back unless kept within these minutes; 0: kept at once |
| `fw_confirm_min` | 5 | a change of the firewall or of who may reach the pages goes back unless kept within these minutes; 0: kept at once |

While a change waits, **every page shows a banner** with the time left,
*Keep it* and *Put the old back now*; `otp --status` and the console say so too.

```bash
otp --change-keep net --node otp2     # keep the new network of otp2
otp --change-back net --node otp2     # go back to the old one now
otp --change-keep fw                  # keep the firewall change
otp --change-back fw
```

In the console: *Cluster → Keep or put back a change on trial*.

**The network.** The node keeps what it had (its NetworkManager connection and
host name), puts the new one in, restarts - and waits. Not kept in time, or
come up without its new address at all, it asks itself for the old network:
the same job the other way round (a restart, the other node of a cluster told
the old address again). In a cluster the other node's `pg_hba.conf` lets both
addresses in while the new one is on trial, so it can still be told; kept, only
the new one stays. Only a network set by hand can be put back by itself - one
from DHCP is said so and kept at once.

**The firewall.** What was set before the first change of a trial (otp's rules,
your own, the automatic ones switched off, who may reach which page) is kept;
further changes within the trial move its deadline on. Not kept, one node puts
it all back and every node puts that in within seconds.

Keep a change only once you have checked that what it could have cut off still
answers: the node at its new address; SSH, the pages and RADIUS after a
firewall change.
