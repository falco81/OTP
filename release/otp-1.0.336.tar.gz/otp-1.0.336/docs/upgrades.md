# Upgrades and maintenance

Two ways to put in a new version. Both stay: use whichever suits you.

| | Command line | The pages |
|---|---|---|
| Where | on each node, as root | *Settings → Upgrades*, as a full administrator |
| How | `./install.sh --upgrade` | send the `.tar.gz`, press *Upgrade* |
| One server | out of service for a minute or two | the same |
| A cluster | node by node, by hand | every node in turn, by itself |

## From any version

Any older version - back to the first `opt` 1.0.0 - is upgraded straight to
this one, on SQLite, MariaDB and PostgreSQL: the tables are brought up to date
when the new version starts (columns added, nothing taken away), `opt` is
renamed to `otp` by install.sh, and copies made by any older version go back
into this one. Tested from every release 1.0.0 - 1.0.61 on SQLite and from
releases across that range on MariaDB and PostgreSQL (1.0.62). In a cluster the nodes are upgraded one after the other; while
one is new and the other old, what the new one writes into a table that gained
a column waits in its replication until the other is upgraded too, and then
goes over - nothing is lost.

## Maintenance

A node **in maintenance** answers no RADIUS request and its `/healthz` says
`503 maintenance`, so the VPN and the load balancer take it for down and use
the other node. Its pages go on working, so it can be looked at and brought
back.

```
otp --maintenance on --why "new disk"     # out of service
otp --maintenance status                  # which (exit 3 while in maintenance)
otp --maintenance off                     # back in service
otp --maintenance on --node otp2          # another node of the cluster
```

With the VIP address on ([tls-and-vip.md](tls-and-vip.md)), a node in
maintenance also gives the address up to the other node.

On the pages: *Settings → Upgrades → The nodes*, or the *Maintenance and
upgrades* card on the Overview. With a single server, maintenance means
nobody can sign in to the VPN.

## On the command line

```
tar xzf otp-X.Y.Z.tar.gz && cd otp-X.Y.Z
sudo ./install.sh --upgrade
```

From 1.0.37 on, `install.sh --upgrade` takes the node out of service before it
touches anything (and waits 20 s in a cluster, for the balancer and the VPN to
notice), and puts it back once the new version answers. A node that was in
maintenance already stays in it. In a cluster, upgrade one node, check it
(`otp --check`, `otp --ha-status`), then the other.

## From the pages

*Settings → Upgrades*:

1. **Send the package** - the `otp-X.Y.Z.tar.gz` as released. It is checked at
   once (below) and kept in the database, so every node of a cluster has it.
2. **Upgrade.** One server: it is put in and restarted. A cluster: one node at
   a time - the others first, the node the page came from last:
   1. the node goes into maintenance, and waits 20 s for the balancer;
   2. the package is handed to root (see below), which runs its
      `install.sh --upgrade`;
   3. the node comes back as the new version, checks that its database opens
      and RADIUS listens, reads the list of replicated tables again, and leaves
      maintenance;
   4. only then the next node begins.

   A node that fails stops the upgrade there, goes back into service as it
   runs, and the page shows what `install.sh` said. *Stop it* leaves the nodes
   not yet begun as they are.

`otp --upgrade-status` shows the same on the command line, and
`otp --upgrade-cancel` stops it.

### The pages while it runs (1.0.299)

Every page shows how far it is in a band under its header - the version, from
which, who started it, how long so far, a bar, the step (`step 7 of 9 · The
pages`) and, in a cluster, every node's state. The pages are served by the very
things an upgrade restarts (the daemon and its API, PHP, nginx), so:

- **This node's progress is in a file the pages read themselves**:
  `/var/www/otp/.upgrade.json`, root's (0644), written whole - `otp_upgrade.py`
  writes the first step (the package checked) and a refusal, `install.sh
  --upgrade` each of its steps, `done` at its end and `failed` from its EXIT
  trap (a signal too), with what runs then. nginx serves no dot name. PHP
  believes it while it runs for 30 min after its last word, `done` and
  `failed` for 10 min. An upgrade on the command line writes it too.
- **While the daemon is away**, every API call of the pages is answered 503
  with `upgrading` (how far it is) instead of "the daemon is not answering";
  `/admin/?api=upgrade-state` answers without the daemon at all. The page says
  *restarting* - never the red bar or a red toast - asks again every 2 s, and
  says so too while nginx and PHP restart and nothing answers it.
- **Behind the VIP address** the node answering is the other one while this
  one is upgraded: the band follows the cluster's plan from whichever node
  answers.
- **At the end** the page loads the pages of the version it was upgraded to by
  itself, once - as soon as that version answers (a VIP address moving to the
  node done already counts), never back to an older one. With unsaved changes
  it offers *Load it again* instead.
- **A failure** is a red band with the reason and a way to *Upgrades* (what
  `install.sh` said); × hides it for that upgrade.
- **Signed out** meanwhile, the sign-in page shows the same band from the file
  and loads again by itself when the daemon answers.
- **`/healthz`** says `503 maintenance NODE: being upgraded to X` while the
  daemon is away in an upgrade - a monitor sees maintenance, not down. The VIP
  address is not decided by it (`otp-vip-check`): unchanged.

### From the web (1.0.123)

*Settings → Upgrades → From the web* looks once a day (and when *Look now*
is pressed) at `upgrade_url` for `otp-X.Y.Z.tar.gz` packages:

| `upgrade_url` | how it is read |
|---|---|
| `https://github.com/OWNER/REPO/tree/BRANCH/FOLDER` (the default: `https://github.com/falco81/OTP/tree/main/release`, which keeps the last ten versions) | GitHub's API lists the folder; the packages come from `raw.githubusercontent.com`. When the API refuses (60 questions an hour without an account), the folder's own page is read for the names. |
| a web page or a folder listing (nginx, Apache autoindex) | every link to an `otp-X.Y.Z.tar.gz` |
| one package's address | that package |

HTTPS only. A proxy, if the server needs one, comes from `https_proxy` in the
service's environment (`systemctl edit otp`: `Environment=https_proxy=…`).
The node needs to reach the address (and `api.github.com`,
`raw.githubusercontent.com` for GitHub) - Settings → Firewall and access lets
everything out.

The newest one newer than what runs here is offered: **Upgrade to X now**
fetches it, checks it exactly as a package sent by hand (below - the signature
of a release key this server trusts, every file in it), keeps it in the
database and begins the upgrade; **Only fetch it** stops before the upgrade.
With more than one version there newer than this one (1.0.142), a list beside
the buttons lets you choose which to go to - the newest is chosen, and the
buttons follow the choice; with only one, the page is as before. An older one
than what runs here is never offered, nor taken.
Nothing is ever put in by itself. `upgrade_check` off stops the daily look;
*Look now* still asks.

*Hide this* takes a finished upgrade off the page.

On the command line (and in `otp --console` → Upgrades):

```bash
otp --upgrade-check              # what is at upgrade_url, and whether it is newer
otp --upgrade-online             # the newest: fetched, checked, every node upgraded
otp --upgrade-online 1.0.140 --yes
otp --upgrade-follow             # follow one going on, with its progress bars
```

### What makes it safe

The service runs as `otp`, which may not write a byte of the program. The
pages therefore never install anything themselves:

- The node lays the package and a request down in `/var/lib/otp/upgrade/`.
  systemd sees the request (`otp-upgrade.path`) and starts
  `otp-upgrade.service`, which runs `/usr/local/lib/otp/otp_upgrade.py` **as
  root**. It is the only thing that unit can do.
- Root copies the package to a folder of its own before reading it, so it
  cannot be changed under the check, and checks it again from the start:
  - **signed**: `MANIFEST` lists the SHA-256 of every file and `MANIFEST.sig`
    is its Ed25519 signature, by one of the keys in
    `/usr/local/lib/otp/release-keys/` - root's alone, put there only by
    `install.sh`;
  - every file is the one signed, and nothing else is in it: no link, no
    device, no path outside its one folder;
  - it is not older than what is installed (going back is done on the command
    line).
- Then it runs the package's own `install.sh --upgrade --yes`, exactly as
  somebody would by hand, and writes what it said to
  `/var/lib/otp/upgrade/last.log`.

A package that was changed, or signed by a key the server does not know, is
refused - put it in on the command line if you trust it. The first version
with this (1.0.37) has to be put in on the command line once: that installs the
units and the key.

## Going back to an older version (1.0.143)

Only to a version it is safe to go back to, and never by putting a database
back: the tables stay as they are - whatever their size - and the older
program runs on them. Every column a newer version added is one an older one
leaves alone (they are all added NULL).

**How far back.** Each version says the oldest one it may go back to
(`DOWNGRADE_FLOOR` in otp.py): one that reads what it writes into the
database and config.json the same, and has every security fix that matters.
Going back is refused below the highest of these

- of any version that ran on this database, on any node - each node keeps its
  own in the database (`downgrade:floor:NODE`), so a version that ran once
  still counts after going back from it;
- of any version installed on this machine - install.sh keeps it in
  `/usr/local/lib/otp/downgrade-floor`, root's alone. The otp account cannot
  lower it, so nobody who has only the pages (or the otp account) can take the
  server back to a version with a hole a later one fixed. An older version's
  install.sh leaves it as it is.

**The package against the database.** Fetched or given, the older package is
checked like an upgrade's (signed, every file) and then against this
database: a column the database has as NOT NULL with no default that the
older version does not know would make every row it writes there fail - such
a version is refused, naming the column.

**Then** it goes the road of an upgrade: one node at a time, each in
maintenance while it is done, checked and brought back. Root's helper puts an
older version in only when going back is asked for as such, and never below
its floor file.

- The pages, once *Settings → Upgrades → Offer going back to an older
  version* (`upgrade_downgrade`, off by default) is on: *Going back to an older
  version* - *Show the versions to go back to* lists the older versions at
  `upgrade_url`, each with what stands in its way and *What changed* (what
  came in it, and folded what going back to it gives up); *Go back to X*
  (asked twice). Off, the pages offer nothing of it and the API refuses it.
- The command line:

  ```bash
  otp --downgrade-check                  # the older versions there, and which are safe
  otp --downgrade 1.0.140                # from upgrade_url, every node, followed here
  otp --downgrade /root/otp-1.0.140.tar.gz
  ```

- The console: *Upgrades → Go back to an older version (only a safe one)*.
  *Upgrade this node from a package file* refuses an older package and points
  here.

What came in the newer versions is gone until you upgrade again; settings
that only a newer version knows stay in the database and are used again then.

## To be done by hand (1.0.258)

Some things an update cannot do itself: a step only root can take on the
command line, or what the installer had to leave to you. otp says each of them
until it is done - never only in a log line:

- **Settings → Upgrades → To be done by hand**, the first card of the pane: one
  band a thing and a node - what it is, why it matters, the command with a
  **Copy** button, and when it was first seen. **Look again** asks the node at
  once (the other node within a minute); **Done** is for what otp cannot check
  itself, and for one it can, marked by hand (written in the events). *Done
  lately* lists what was done, by whom, and what went by itself.
- A count beside **Upgrades** in the settings menu and on the **Settings**
  tab - red when one of them is bad, amber otherwise. Nothing else on the pages
  changes for it.
- The alerts mail them with the rest (*An upgrade of otp*, on by default).
- `otp --after` lists them with the commands (`--json` too) and looks at this
  node again first; `otp --after-done ID [--node NAME]` marks one done.
  `otp --status` and `otp --check` say how many (`--check` fails on a bad
  one), the console says them on its first screen, and `install.sh --upgrade`
  says those still to be done at its end.

What there is now:

| What | When | How it goes |
|---|---|---|
| otp is newer than the parts root installs | the program was put in without install.sh of its version (copied by hand, an install.sh --upgrade that stopped half way) | by itself, once `./install.sh --upgrade` of that version has run to its end |
| upgrades from the pages cannot be put in | otp_upgrade.py or otp-upgrade.path missing | by itself, after `install.sh --upgrade` |
| nginx did not take the additions / the guard for big uploads | `nginx -t` refused what install.sh put into otp.conf | by itself, once an upgrade gets them in |
| SELinux: otp's module is not the one this version needs | SELinux on, the module missing or older than the one beside the program | by itself, once it is in (`semodule -i /usr/local/lib/otp/otp_server.cil`, as install.sh) |
| SELinux refuses otp something | enforcing, and refusals counted | by itself when nothing is refused; Done holds until more is refused |
| PHP without the php2shell fix | the PHP here is not fixed | by itself, within the hour of the update |
| nothing opened the firewall | firewalld was not running at the install | Done, once the ports are open |

Each node looks at its own at the start, every ten minutes and when asked,
and keeps what it found in a row of its own (`after:NODE`); a Done is kept for
every node (`after:ack:ID:NODE`). What root found and the service cannot see
itself install.sh writes into `/usr/local/lib/otp/root-facts.json` (root's,
readable by all, no secret in it): which version put the root parts in, and
what nginx, SELinux and the firewall made of it. Never switch SELinux off for
any of this: what it refuses is put right by what otp needs.

A new version that needs something by hand adds one entry to the list in the
program (`after_entry(...)` in the part *after the update*): its words, its
commands and a check - the pages, the mails, the command line, the console and
install.sh then say it with nothing else changed.

## A cluster: what goes where

Settings, clients, realms, directories, tokens and accounts are the cluster's
and replicate. A few settings belong to one machine and each node has its own
(*Settings → High availability → Each node's own settings*): the address RADIUS
listens on, the port the pages ask the daemon on, the name it greets mail
servers with, the name isemon files it under, and the debug switches. The
database address and the cluster's wiring are in each node's
`/etc/otp/config.json` and never replicate. Maintenance, heartbeats and the
upgrade's progress are kept per node.

A new version may add a column. Between the upgrade of the first node and the
second, the older one takes nothing from the newer (the change waits in the
newer one's replication slot) and catches up as soon as it is upgraded - which
is why the upgrade goes straight on to the next node.

## The operating system

- **Ordinary updates** (`dnf upgrade`, a new kernel, a minor PostgreSQL):
  node by node - `otp --maintenance on`, update, reboot,
  `otp --ha-status` shows both directions running, `otp --maintenance off`,
  then the other node. The live node keeps what the other misses (up to 16 GB).
- **A new major release** (AlmaLinux 9 → 10, PostgreSQL 16 → 17): do not
  upgrade in place - `pg_upgrade` does not carry the replication slots. Make a
  bundle on the live node (`otp --ha-bundle FILE`), reinstall the other node
  from scratch, `otp --ha-join FILE` on it; then the same the other way round.
