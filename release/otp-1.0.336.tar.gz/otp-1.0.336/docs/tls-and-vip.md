# Certificates, TLS, and the VIP address

Certificates and TLS: *Settings → Certificates and TLS*. The VIP address:
*Settings → High availability → The VIP address*. A full
administrator, or the command line. From 1.0.47.

- **Certificates and TLS** for each node's own name, and for the web
  address's name: upload a certificate (PEM, PFX / PKCS#12, with or without a
  password), make a request (CSR) here, or make a self-signed one; choose the
  protocols, the ciphers, the DH parameters and HSTS.
- **Trusted roots of the system** (1.0.265): certificate authorities of your
  own put into the trust of the operating system of every node, beside the
  distribution's list (see below).
- **The VIP address**: in a cluster of two, one more IP address for
  the pages and the administration that is on one node at a time
  (active/standby) and moves to the other node by itself when the node
  holding it is not well. **RADIUS never uses it**: both nodes keep answering
  RADIUS on their own addresses, active/active, exactly as before.

With the VIP address off, everything works as before - including a load
balancer of your own ([load-balancers.md](load-balancers.md)).

---

## How it is put in place

The service runs as `otp` and may not change nginx, keepalived or the
firewall. What is asked on the pages is kept in the database (so both
nodes know it; keys are sealed with the tokens' key) and each node then asks
root for its own part: the daemon writes `/var/lib/otp/web/request.json`,
systemd (`otp-web.path`) starts `otp-web.service`, which runs
`/usr/local/lib/otp/otp_web.py` as root. That helper:

- checks every value against the one shape it may have (addresses, names,
  interface names, cipher lists - and certificates and keys are read by
  openssl, the key must be the certificate's own);
- writes the files: `/etc/nginx/certs/otp.pem` (certificate + chain),
  `otp.key`, `otp-ca.pem` (the root, for `ssl_trusted_certificate`),
  `otp-dh.pem`; for the VIP address `otp-vip.*` and
  `/etc/nginx/conf.d/otp_vip.conf`; `/etc/keepalived/keepalived.conf`;
- asks nginx (`nginx -t`) and keepalived (`keepalived -t`) before reloading
  them, and **puts every file back as it was** when either says no;
- writes what it did to `/var/lib/otp/web/status.json` - shown on the pages
  and by `otp --web-status`.

It never touches a `keepalived.conf` that is not otp's own (it refuses, and
says so). `install.sh` (1.0.47 and later) installs the helper and the units.

---

## Certificates

### Download (1.0.191)

*Download* on a certificate's card opens a window with the format: the certificate
as PEM (`.crt`), with its chain (`.pem`), as DER (`.cer`), PKCS#7 with its chain
(`.p7b`) - or **with its private key**: PKCS#12 (`.pfx`) or PEM with the key
locked (PKCS#8, AES-256). With the key, a password of 10 characters at least,
typed twice, locks the file - never without one; *For older Windows* makes a PFX
with 3DES that Windows before 10 (1709) and Server 2016 open. Full administrators
only; each download with the key is an event (*warn*). On the command line:
`otp --tls-for NODE|vip --tls-export pfx FILE` (the password asked for; `--legacy`).

### Upload

On the pages: *Upload…* on the node's (or the VIP address's) card. Drop the
files, or paste PEM:

| You have | Send |
|---|---|
| `.pfx` / `.p12` (Windows, an export from a CA) | the file; its password in *Password* (empty if none). Old PFX files (RC2/3DES) are read too |
| `.crt` / `.cer` / `.pem` + `.key` | both files; add the chain (intermediate) and the root if you have them |
| one `.pem` with everything | that file |
| a key with a passphrase | the key and the passphrase in *Password* |

The certificates are sorted by themselves: the one that belongs to the key,
the chain up from it in order, the root (self-signed). The chain is checked
against the root when a root is given. The password is used once to open
the file and is not kept.

Command line:

```bash
otp --tls-import /root/otp1.pfx --tls-for otp1                    # OTP_TLS_PASSWORD=... for its password
otp --tls-import cert.pem key.pem chain.pem root.pem --tls-for otp1
otp --tls-import otp.pfx --tls-for vip                            # the VIP address's own
```

### Request (CSR)

*Request…*: the name (CN), other names (SAN, names or addresses), the key
(RSA 2048/3072/4096 or EC P-256), organisation, unit, city, country. The key
is made on the node and stays there (sealed in the database); copy or
download the request, give it to your CA, then *Upload…* only the
certificate it sends back.

### Self-signed

*Self-signed…*: for a test, or until the real one comes. Browsers warn until
it is trusted by hand.

### Certificates from acme (1.0.216)

An acme of yours (the certificate manager) can put its certificates here and renew
them by itself - each node's and the VIP address's: **Certificates from acme** on
the same pane. Switch it on, *Pair with an acme* (a code shown once, 15 minutes,
five tries), put the code into acme's target *An application of ours (acme push)*
with `https://otp.example.cz/admin/`, and *Try* there; *Discover* in acme then shows
the slots (`node:otp1`, `node:otp2`, `vip`) and makes the certificates. Instead of
the code, acme's key can be pasted (*Or paste acme's key*).

- Every request of acme is signed (Ed25519), the private key travels sealed to this
  server (X25519 + AES-256-GCM); a request older than 5 minutes or sent twice is
  refused. acme's address must be one that may reach the administration.
- What acme puts in is kept exactly as an upload is: the same card shows it ("acme
  push: …"), every node puts its own into nginx within seconds, the other node of a
  cluster takes it by replication. Automatic certificates leaves that card alone
  from then on (*Look after it* gives it back).
- A certificate is taken only for a card whose name it holds, unless *Take
  certificates of other names* is on. Switching it off, or *Forget it* on an acme,
  ends it; what was put in stays.
- The protocol, for acme's side and for other applications: [acme-push-protocol.md](acme-push-protocol.md).

### Which certificate goes where

- **A node's own**: what is answered on `https://otp1.example.cz/` - the
  node's own name. Without one, the self-signed certificate `install.sh` made.
- **The VIP address's own**: answered on the VIP address itself - for its
  name (`otp.example.cz`), for its IP address typed in the browser, and for
  a client that sends no name at all. nginx listens on the address on both
  nodes (`net.ipv4.ip_nonlocal_bind = 1`, in `/etc/sysctl.d/90-otp-vip.conf`),
  so the node that takes the address over answers on it at once. Without a
  certificate of its own, the VIP address answers with the certificate of
  the node it is on - so either give each node a certificate that also names
  `otp.example.cz`, or give the VIP address its own.
- A certificate is put in when the node's helper has finished everything
  asked of it - including DH parameters, which made on the node take
  minutes (4096 bits up to ten). The card shows how far it is.

A certificate that ran out is refused on the pages. The cards show how many days are
left (orange under 21 days).

### TLS settings

*TLS settings…* on a card, or on the command line:

| Choice | Protocols | Ciphers |
|---|---|---|
| **Standard** (default) | TLS 1.2, 1.3 | ECDHE with AES-GCM and ChaCha20 only |
| **Mozilla intermediate** | TLS 1.2, 1.3 | the same plus DHE (for old clients) |
| **Mozilla modern** | TLS 1.3 only | chosen by TLS 1.3 itself |
| **Custom** | TLS 1.2 and/or 1.3 | any OpenSSL cipher list (checked with `openssl ciphers`) |

- **DH parameters** - only DHE ciphers use them: none; an RFC 7919 group
  (ffdhe2048/3072/4096, ready at once - recommended); or made on the node
  (2048 takes seconds, 4096 minutes; made once and kept).
- **The server chooses the cipher** (`ssl_prefer_server_ciphers`).
- **HSTS** - off, 6 months, 1 year, 2 years.

```bash
otp --tls-preset intermediate --tls-dh ffdhe2048 --tls-hsts 31536000 --tls-for otp1
```

*Stop looking after it* (the bin on a card): otp no longer changes that
node's TLS; nginx keeps the files it has.


### Trusted roots of the system (1.0.265)

*Settings → Certificates and TLS → Trusted roots of the system* puts certificate
authorities of your own - your company's root, an intermediate - into the trust of
the **operating system as a whole**, on every node: curl, dnf, LDAPS to a domain
controller, SMTP, syslog over TLS, otp's own connections - every program that uses
the system's trust. Everyone may see the card; a full administrator adds and takes
away.

It never touches the distribution's list. It uses the way the system itself takes
local additions:

| System | otp writes | then runs | the result |
|---|---|---|---|
| RHEL, AlmaLinux, Rocky | `/etc/pki/ca-trust/source/anchors/otp-<sha256>.pem` | `update-ca-trust extract` | `/etc/pki/ca-trust/extracted/` |
| Debian, Ubuntu | `/usr/local/share/ca-certificates/otp-<sha256>.crt` | `update-ca-certificates` | `/etc/ssl/certs/` |

**The system's updates go on as before.** The `ca-certificates` package brings
the distribution's list and runs the same tool when it is updated; the tool always
merges that list with the folder of local additions. So a package update keeps
otp's additions, and otp's additions keep the package's list - each complements
the other. The card shows each node's list (how many authorities, when it was
made last) and the package's version, so you see the updates arriving.

- **Only otp's own files**: otp lists, writes and removes only `otp-*` files
  in that folder. Anything else there (put by you, or by a configuration tool)
  is shown as *added by somebody else* and left as it is.
- **What is taken**: PEM pasted, or a `.pem`, `.crt` or `.cer` (DER) file; a
  chain adds every authority in it. Only certificate authorities
  (`basicConstraints CA:TRUE`, allowed to sign certificates) - a server's own
  certificate and anything with a private key in it are refused. 50 at most.
- **Warned, still taken**: an authority that ran out or is not valid yet; an
  intermediate signed with SHA-1 or a key under 2048 bits (the system's
  crypto policy DEFAULT refuses them); an intermediate without its root - only
  programs that take a partial chain (curl, Python 3.13 on) trust it alone, so
  add its root too unless the system's list has it.
- **Both nodes**: the set wanted is the cluster's. Each node's daemon has its
  root helper (`otp_web.py`, through `otp-web.path`) bring its machine to that
  set within seconds of a change, at every start and every half hour; the card
  says per node *as wanted*, *waiting* or *failed* with the tool's words. A
  standalone server is a cluster of one.
- **Labels**: files are written root's, `0644`; SELinux labels them `cert_t`
  as every file of that folder (`restorecon`) - nothing new in otp's module.
- **The database guard** signs the set wanted (`oscerts:want:NODE`): with
  `db_guard` on, a set written into the database by somebody else is not put in.

**otp's own connections** (the directory, mail, syslog/SIEM, isemon, SMS, ACME,
the remote backups) make their TLS contexts with Python's
`ssl.create_default_context()`, which reads OpenSSL's default places - on the
distribution's Python (the one install.sh chooses) that is the system's list
above, so an authority added here reaches them at their next connection. The
database connection does so with *the system's authorities* chosen in
Encryption to the database server. A Python built with an OpenSSL of its own
(`install.sh --python PATH`) that looks where there is nothing is pointed at the
system's list at the start; the card says which list otp's connections use. An
authority imported into a directory, the SMS gateway or isemon is still used
there as before (the gateway's: alone; the others': beside the system's).

```bash
otp --os-roots                          # what otp added, what others did, each node's list
otp --os-roots-add /root/corp-ca.pem    # one, or a chain: shown, then asked (--yes)
otp --os-roots-remove 43e0734e943ad2b1 --yes
```

Taking one away takes it out of every node's trust: whatever relied on it
(LDAPS, mail, syslog…) fails from its next connection - unless the system's own
list has it too.

---

## The VIP address

### How it works

keepalived (VRRP, unicast between the two nodes) holds the address on one
node. Every two seconds it asks `/usr/libexec/keepalived/otp-vip-check` two
questions:

1. **May this node hold it?** otp answers in `/run/otp/vip-state`, written
   every three seconds. The node may hold it only if **all** of these hold:
   - its own pages answer `GET https://127.0.0.1/healthz` with `200 ok` - which
     goes through nginx and PHP-FPM to the daemon and the database;
   - RADIUS is listening;
   - it is not in maintenance (so also not being upgraded);
   - it is not being rebuilt from the other node.

   Two failed checks in a row (about six seconds) and the node gives the
   address up. If otp itself stops, the file goes stale and the node gives it
   up as well. If the whole node is gone, the other stops hearing it and
   takes the address within about three seconds.
2. **Is it the node the address is meant to be on?** - the one chosen with
   *Move it here* (by default the first node). That node gets priority, so
   the address goes back to it once it is well again (after five seconds).

When the address moves, the new node announces it (gratuitous ARP), and the
browsers' next requests go there. Signed-in sessions stay valid: they are
in the database.

### Turning it on

1. Pick a free address in the nodes' own network (`192.0.2.10/24`) and a DNS
   name for it (`otp.example.cz` → `192.0.2.10`).
2. A VRRP id (1-255) that no other VRRP on that network uses (other
   keepalived pairs, routers with VRRP/HSRP using VRRP). Default 51.
3. Open VRRP between the nodes (below).
4. On the pages: the address with its prefix, its name, the VRRP id; the
   interface per node if it is not the one with the node's own address.
   *Save*, then *Turn it on*. Each node installs keepalived
   (`dnf install keepalived`, AlmaLinux AppStream) if it is missing, writes
   its file and starts it. Within seconds the table shows which node holds it.

```bash
otp --vip-set 192.0.2.10/24 --vip-fqdn otp.example.cz --vip-vrid 51
otp --vip-set 192.0.2.10/24 --vip-iface otp1=ens192 --vip-iface otp2=ens192   # other interfaces
otp --vip on
otp --web-status
```

### Moving it by hand, and back

*Move it here* on a node's row, or `otp --vip-move otp2`. It stays there
(it is now the node it is meant to be on) until moved again. It still leaves
that node by itself when the node is not well.

### Maintenance and upgrades

Nothing to do: a node in maintenance - by hand, or during an upgrade from the
pages or `install.sh --upgrade` - gives the address up, and the other takes it.
When the node is back in service and is the preferred one, the address
returns to it.

### Turning it off

*Turn it off…*, or `otp --vip off`: keepalived stops on both nodes and its
file is removed; the address is on neither node. The nodes keep answering on
their own addresses; a load balancer of your own works as before.

### On both nodes at once (split brain)

If the nodes cannot hear each other's VRRP - VRRP blocked by a firewall, or
the network between them split while both still run - each thinks the other
is gone and both take the address. The pages say so in red.

- Check that IP protocol 112 is allowed **both ways** between the nodes
  (below), and that both use the same VRRP id.
- `journalctl -u keepalived` on both.
- Until it is fixed, take one node out: `otp --maintenance on` on it.

With two nodes and no third party this cannot be ruled out entirely; it is
the same for any keepalived pair. *When the nodes lose each other* on the High
availability pane (1.0.218, [split-brain.md](split-brain.md)) can make the node
cut off from the network step aside - it lets the VIP address go.

### What it does not do

- It is for the **pages** (HTTP/HTTPS). RADIUS stays active/active on the
  nodes' own addresses.
- Both nodes must be in **one layer-2 network** (one VLAN) with the address.
  In clouds that do not allow an address to move by ARP (AWS, Azure, GCP),
  use their load balancer instead.
- VMware: nothing special is needed - keepalived uses the node's own MAC
  address, so no "MAC address changes" or "forged transmits" in the port
  group.

---

## What to open in the firewall

`install.sh` opens HTTPS/HTTP and RADIUS in firewalld; `otp --ha-setup` and
`--ha-join` open PostgreSQL to the other node; turning the VIP address on
opens VRRP from the other node. Other firewalls in the path (between the
VLANs, in front of the servers) need the same.

### Into each node

| From | Port / protocol | What |
|---|---|---|
| browsers, the load balancer | TCP 443 (and 80, redirected to 443) | the pages, the administration, `/healthz` |
| the VPN concentrators (RADIUS clients) | UDP 1812 (authentication), UDP 1813 (accounting) | RADIUS |
| the other node | TCP 5432 | PostgreSQL replication (replicated cluster) |
| the other node | IP protocol 112 (VRRP) | the VIP address (when on) |
| administrators | TCP 22 | SSH |
| monitoring | TCP 443 `/healthz`, ICMP | |

### Out of each node

| To | Port | What |
|---|---|---|
| domain controllers | TCP 636 (LDAPS) or 389 (+StartTLS); 3269/3268 for a global catalog | Active Directory |
| the other node | TCP 5432 | PostgreSQL replication |
| the other node | IP protocol 112 | VRRP |
| DNS, NTP | UDP/TCP 53, UDP 123 | names, the clock (TOTP needs it right) |
| mail server | TCP 25 / 587 / 465 | QR codes by mail (if used) |
| isemon | UDP or TCP 514 | logs (if used) |
| package repositories | TCP 443 | `dnf` (keepalived, PostgreSQL, updates) |

### firewalld (AlmaLinux)

What the tools add, for reference (otp2 at 192.0.2.12, seen from otp1):

```bash
firewall-cmd --permanent --add-service=https --add-service=http
firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="198.51.100.1/32" port port="1812" protocol="udp" accept'
firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="198.51.100.1/32" port port="1813" protocol="udp" accept'
firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="192.0.2.12/32" port port="5432" protocol="tcp" accept'
firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="192.0.2.12" protocol value="vrrp" accept'
firewall-cmd --reload
firewall-cmd --list-all
```

### iptables

When the nodes run plain iptables instead of firewalld (on otp1; on otp2 the
same with 192.0.2.11):

```bash
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -p tcp --dport 80  -j ACCEPT
iptables -A INPUT -p udp -s 198.51.100.1/32 --dport 1812:1813 -j ACCEPT
iptables -A INPUT -p udp -s 198.51.100.2/32 --dport 1812:1813 -j ACCEPT
iptables -A INPUT -p tcp -s 192.0.2.12/32 --dport 5432 -j ACCEPT      # replication
iptables -A INPUT -p vrrp -s 192.0.2.12/32 -j ACCEPT                  # VRRP (protocol 112)
iptables -A INPUT -p tcp --dport 22 -j ACCEPT
iptables -A INPUT -p icmp -j ACCEPT
iptables -A INPUT -j DROP
# keep them over a reboot (AlmaLinux: dnf install iptables-services)
service iptables save
```

IPv6 (ip6tables) the same with the IPv6 addresses; VRRP over IPv6 is
`-p vrrp` too. `-p vrrp` and `-p 112` are the same.

### nftables

```
table inet otp {
  chain input {
    type filter hook input priority 0; policy drop;
    ct state established,related accept
    iif lo accept
    tcp dport { 80, 443 } accept
    ip saddr { 198.51.100.1, 198.51.100.2 } udp dport { 1812, 1813 } accept
    ip saddr 192.0.2.12 tcp dport 5432 accept
    ip saddr 192.0.2.12 ip protocol vrrp accept
    tcp dport 22 accept
    icmp type echo-request accept
  }
}
```

### A firewall between the nodes and the VPN, or between VLANs

- UDP 1812/1813 from each VPN concentrator to **both** nodes' own addresses
  (not to the VIP address).
- TCP 443 from the users' and administrators' networks to the VIP address
  **and** to both nodes (a browser may be sent to a node's own name).
- Stateful firewalls: RADIUS answers come from the address the request was
  sent to.

---

## Troubleshooting

| Seen | Why, and what to do |
|---|---|
| a node's row: *failed: keepalived ... is not otp's* | `/etc/keepalived/keepalived.conf` exists for something else: move it away, *Try again* |
| *failed: nginx does not take it* | the reason is nginx's own; nothing was changed. Usually a certificate/key pair or a cipher list |
| *no interface here holds ...* | choose the interface for that node |
| holds it: neither; may hold it: no - *its pages do not answer* | nginx or PHP-FPM down on that node: `systemctl status nginx php-fpm` |
| *in maintenance* | `otp --maintenance off` |
| the address on neither node, both healthy | `journalctl -u keepalived`; VRRP blocked one way; a different VRRP id on each (save again) |
| *being put in…* stays | `systemctl status otp-web.path otp-web.service`; `install.sh --upgrade` once on the command line puts the units in |
| the browser still sees the old certificate | it may be shown the other node's; check both cards, and the name it asks for |


## Where the VIP address goes back to (1.0.52)

Settings → High availability → The VIP address, *When the node it left is
well again*:

- **always back to NODE** (the default; the first node unless chosen): the
  preferred node gets 50 more VRRP priority while it is healthy, so the
  address returns to it within a few seconds after a failover. Moving the
  address by hand makes the other node the preferred one.
- **it stays where it is**: no preference. The node that holds the address
  (keepalived MASTER) keeps it; after a failover it stays on the node it went
  to, also when the first one is well again. It moves only when its node
  fails (maintenance, an upgrade, /healthz failing, RADIUS not listening, the
  node gone) or when moved by hand (*Move it here*, `otp --vip-move NODE`) -
  and then stays there.

```bash
otp --vip-return otp1      # always back to otp1
otp --vip-return stay      # stays where it is
```

Every move is in Settings → High availability → **History**.


## The whole chain (1.0.269)

nginx sends each certificate with every intermediate authority up to a root (never the root). A certificate
uploaded without its intermediates is completed by otp from the authority's *CA Issuers* address, as a browser
would do it; when that cannot be done (no address, no way out, a company CA), **Upload the missing authority**
on the card takes the authority's certificate (PEM or .cer/.crt; a root is kept to check with and never sent).
The card's **Chain** line says it in green or red; **Complete the chain** / **Check the chain** asks again. The
file nginx has is checked too, and each node connects to itself (and the VIP holder to the VIP address) after
nginx takes a certificate, as a client that fetches nothing - a refusal is an event and the card's **Sent** line.

Check it from any machine:

```bash
openssl s_client -connect NAME:443 -servername NAME </dev/null 2>/dev/null | grep -E "^ *[0-9] s:|Verify return code"
```

At least two certificates (`0 s:` the certificate, `1 s:` the intermediate) and `Verify return code: 0 (ok)`.
