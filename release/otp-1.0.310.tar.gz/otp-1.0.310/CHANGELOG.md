# otp — what changed

Every change is a new version: the number is in `otp.py` (`otp --version`),
on the pages (bottom of the enrolment page, Settings → About), in the name of
the folder and of the archive.

## 1.0.310 — 18 November 2026

**Bug fixes** (the hunt, round 9): the rolling upgrade in a cluster.

- **A node's own upgrade rows are written to the other node's database again** every 30 s while an upgrade runs: the node on the newer version reaches the older one only so - one write lost (its database restarting, the network a moment away) and the upgrade was held for good.
- **A node forgotten while it still beats in its own database keeps its maintenance and its upgrade row**: one on a newer version looked gone here - forgetting it took it out of a maintenance kept on purpose, and the upgrade waited for it for good.

## 1.0.309 — 18 November 2026

**Bug fixes** (the hunt, round 8): time and the VIP address.

- **The clock guard times its own work by a clock that is not stepped**: stepped back 5 min, it wrote nothing and asked no directory for 5 min - and its last row, "aside" and dated ahead, kept the other node treating it as aside.
- **Whether the other node beats, read in its own database, is judged by that machine's clock**: this node's clock 2 min ahead took it for gone - the last node of an upgrade waited for good, and both nodes led.
- **keepalived's check takes no word dated ahead**: after the clock was stepped back, a daemon hung but alive kept the VIP address for as long as the step.
- **The sign-in pages' tidying never ends a RADIUS guard's block early**: kept in the same maps, a block of a day went after 6 h of quiet.

## 1.0.308 — 18 November 2026

**Bug fixes** (the hunt, round 7): an administrator's second step.

- **Wrong codes are counted on the account** too, in the database - every sign-in and node together: signing in again with the password gave five more guesses each time. Past 20 in a day no more codes are taken until another full administrator resets the second step (*Accounts*) or the day is over.
- **Codes by mail or SMS are limited per account and per address**, as the portal's are (`code_send_max` in `code_send_window_min`): five per sign-in only, and signing in again - or setting the step up, with any address or number typed in - sent more without end.

## 1.0.307 — 18 November 2026

**Bug fixes** (the hunt, round 6): backups and the outgoing mail.

- **Age never takes the newest three backups away**: a clock stepped ahead, or backups that failed longer than the days kept, took every older backup away at once - one left.
- **The weekly check of a node that does not make the night's copy** (one database for the cluster - the other node takes the night's turn) is not "cannot be put back".
- **The outgoing mail decides on each mail as it is now**, not as it was when its tick began: a slow tick (the server away) gave up a mail sent again by hand meanwhile.

## 1.0.306 — 18 November 2026

**Bug fixes** (the hunt, round 5): mail, alerts, SNMP, RADIUS repeats.

- **An alert or a report that some recipients took is sent**: with one address gone (550), the same alert went to every recipient again every 15 min and the report every 30, for as long as it lasted. The address that refused it is said in the alerts' log.
- **The report's "Who was refused" counts refusals**, not the challenges of a sign-in in two windows: every user of such a realm was listed, as many times as they signed in.
- **SNMP**: the clock guard's values (ms) and the time of the last backup are kept in an Integer32 - a clock months off, or a time after 2038, made a strict manager refuse the whole answer.
- **RADIUS: a repeat of a request refused late is answered**: the late refusal was kept for repeats only once it was written down; with the database slower than the delay, a NAS repeat arriving after the refusal went was swallowed as "repeated" and got nothing.

## 1.0.305 — 18 November 2026

**Bug fixes** (the hunt, round 4): SELinux.

- **Two refusals of one event each get audit2why's word** (a folder searched and its file read): the second wrote over the first, which then was never "allowed now", never got its boolean - and still counted against enforcing.
- **A rule the same as one in otp_local already is not put in twice** (two programs of otp's refused the same): taking one away left the other allowing it.
- **A boolean, a folder, a port done once a batch**: each `setsebool -P` builds the whole policy again - a batch of many took longer than the pages wait.

## 1.0.304 — 17 November 2026

**Bug fixes** (the hunt, round 3): the pages during an upgrade.

- **A save that fails during an upgrade is said**: *Not saved: otp is being upgraded - try again once it answers*. Everything that failed was silent while a cluster's upgrade ran - a change pressed on the node not being upgraded, refused or timed out, said nothing at all. A look that fails (asked again by itself) stays silent, the band explains it.
- **A daemon down after the upgrade ended is "not answering"**, not "in maintenance" for half an hour: an answer that said the upgrade was done or had failed was taken as "away for the upgrade".
- **The sign-in page during an upgrade loads itself again only when the daemon really answers** (its database open too - it loaded again every 2 s while the database was opening) **and never under somebody typing** a name, a password or a code: *It is back - load the page again* instead.

## 1.0.303 — 17 November 2026

**Bug fixes** (the hunt, round 2): the pages during an upgrade.

- **An upgrade on the command line that failed always says so**: when the rescue could not take the node out of maintenance again, `install.sh`'s EXIT trap stopped half way (`set -e`) - the pages kept "being upgraded" for 30 min, hid "The daemon is not answering" and `/healthz` said maintenance.
- **Root's helper keeps what install.sh said when it stopped it** (its deadline, the service stopped): the step it was on and which version runs now - written over with "root checks the package".
- **Who started an upgrade, why it failed and its id only for a real sign-in**: a cookie of the right form was enough on `?api=upgrade-state`, the sign-in page and the answers while the daemon was away.
- **The sign-in page's "The upgrade to otp X failed"** is one sentence - in Czech it came out half translated.

## 1.0.302 — 17 November 2026

**Bug fixes** (the hunt, round 1): SELinux's root helper.

- **Another program's refusal on otp's files is never offered as a rule**: a rule for `user_t` or a confined daemon reading `/run/otp/api-token` was ticked on the card. A program is otp's by its executable under `/usr/local/lib/otp` or otp's own command line in full - never by a name it gives itself (`comm` "otp-…").
- **restorecon only on otp's own real paths**: the path is what a program asked for - with `..`, or through a link inside otp's folder, `restorecon -R` went wherever it led (up to `/`).
- **otp_local's list is written only once the policy took it**: a take-away whose `semodule` failed (its store locked by dnf) left a rule in the policy that the card no longer listed nor could take away; the file goes back as the policy has it.
- **A batch whose module does not load keeps its other fixes** (a boolean, a label, a port) as put right; **a port of the type it needs already** is settled - it was said to be "another service's".

## 1.0.301 — 17 November 2026

**SELinux on a pane of its own** - *Settings → SELinux*, right under *High security*, as the kit (and acme) has it.

- The card as the kit draws it: a light for each node beside the title (enforcing green, permissive yellow, an error red; turning while a node does what was asked), *SELinux is each machine's own* in a cluster, and **"SELinux refused nothing on this node"** in green when nothing was refused - *What SELinux refuses* is always there on a node where SELinux is on.
- **The upgrade band: every node on a row of its own**, one under the other, as acme draws it - its name (the one whose turn it is in the colour of a link), its step, how far, what happened, when; above them how far as a whole, whose turn it is and how many nodes are done.
- Every link to it goes there: the security check (*High security*), the alert, what is to be done by hand; their words say *Settings → SELinux*. *High security* keeps its own check and settings.

## 1.0.300 — 17 November 2026

**SELinux: what is refused, sorted by what puts it right - and put right from the card** (*Settings → High security → SELinux*). Each node on its own, standalone and in a cluster; nothing changes unless asked.

- **A whole analysis at every look**: every refusal since the start (`AVC`, `USER_AVC`, `SELINUX_ERR`) read with the records of its event - the program, the whole path, the port -, grouped, each group put to `audit2why` and sorted into one kind: **a boolean**, **a label**, **a port**, **a rule of otp's**, **not for a button** (with why: a security-sensitive target, running or changing far more, writes to types of many files...), **not otp's**. A finding's id is the same at every look.
- **Put in what is selected (N)**: what may be put right comes ticked; a confirm lists exactly what root will do. The page sends **only the ids** - that node's root helper finds each in its audit log again and works out every fix itself (`setsebool -P`, `restorecon -R -v`, `semanage port -a`, a rule). **Under enforcing too**. Each step in Events; looked at again at once. What was put right counts no more; refused again after it, it comes back.
- **otp's own local module `otp_local`**: each rule exactly what was refused, in an optional block of its own, listed on the card with **Take it away** (the last one takes the module out of the policy). A module that does not load keeps none of its new rules. An uninstall takes it away.
- *Switch to enforcing* says how many things are left to put right and how many are not for a button; the count before enforcing is as before (otp's and the services' otp works with), less what was put right here.
- **`otp_server`** lets the daemon start `hostname`, `ip`, `ssh-keygen`, `ssh`/`scp`/`sftp`, `ping` and `chronyc` in their own domains under `NoNewPrivileges` (`nnp_transition`) - under enforcing they would not have run at all.
- **The report** has `findings.json` and `os/`: every process with its domain, every boolean, port type and module, the machine's local changes (`semanage ... -l -C`, `semanage export`), every listening socket.
- **Command line**: `otp --selinux-check` lists the ids and fixes; `otp --selinux-fix ID...|all`, `otp --selinux-rules`, `otp --selinux-take-away ID` (as root, asked first unless `--yes`).
- Docs: *SELinux → What SELinux refuses, sorted by what puts it right*.

## 1.0.299 — 17 November 2026

**The pages follow an upgrade while the things that serve them restart** - the daemon and its API, PHP and nginx. Standalone and in a cluster (both nodes, behind the VIP address).

- **A band under every page's header** while an upgrade runs: the version, from which, who started it, how long so far, a bar, the step (*step 7 of 9 · The pages*) and, in a cluster, every node's state. The plan comes with every status from whichever node answers - behind the VIP address the other node while this one is upgraded.
- **This node's progress in a file the pages read themselves** - `/var/www/otp/.upgrade.json`, root's: the root helper writes the package checked (or refused), `install.sh --upgrade` each of its steps, `done` at its end and `failed` from its EXIT trap (a signal too), with what runs then. An upgrade on the command line writes it too; nginx never serves it.
- **While the daemon is away**, every call of the pages is answered *503 upgrading* with how far it is, not "the daemon is not answering"; the page says *restarting* (also while nginx and PHP restart and nothing answers), asks every 2 s, the pill says *in maintenance* - never the red bar or a red toast. `?api=upgrade-state` answers without the daemon.
- **At the end the page loads the new version by itself, once** - as soon as the version it was upgraded to answers (a VIP address moving to the node done already counts), never back to an older one; with unsaved changes it offers *Load it again*.
- **A failure**: a red band with the reason and a way to *Upgrades*; × hides it for that upgrade.
- **The sign-in page** during an upgrade shows the band itself (from the file) and loads again when the daemon is back - not "the daemon is not answering".
- **`/healthz`**: `503 maintenance NODE: being upgraded to X` while the daemon is away in an upgrade (still 503; the VIP address does not depend on it).
- Docs: *Upgrades → The pages while it runs*.

## 1.0.298 — 17 November 2026

**Bug fixes** (the hunt, fifth round).

- **Backups → the weekly check** with no destination switched on is not started - it failed at once, wrote nothing, and was started again every hour.
- **Forgetting a check of another node's backup** writes that node's row in place only - both nodes writing it at once could meet as one key twice in the replication.
- **SNMP: the end of a certificate after 2038** is given as the largest Integer32 - a strict manager refused the whole answer.
- **An administrator's second step**: the answer of a way given up (another way chosen while the QR code was being made or the code sent) is no longer drawn into the way now shown.

## 1.0.297 — 17 November 2026

**Bug fixes** (the hunt, fourth round): the self-service portal.

- **Replacing a token, "Another address or way" after an address was given**: back to choosing the way - it asked for the password and a code of the old token again, and used up another sent code.
- **The code boxes** are wide enough for "12345 67890" (they cut it on a 220 px box) and no wider than a phone; a screen reader names them *The code* (it read "000000").
- **After the last try of a code**, the page is drawn again only while that card is still there - "Send it again" pressed meanwhile lost the code being typed into the new one.
- **A label of a box with a button beside it** (the code and its *Send*) names the box: a click on it lands in it.

## 1.0.296 — 17 November 2026

**Bug fixes** (the hunt, third round).

- **The RADIUS server's counters** (Dashboard, the metrics, SNMP): *accept*, *challenge* and *reject* are counted once, when the answer is ready - a request whose answer could not be built was counted as accepted and taken back, and counts from many requests at once could be lost or make the dashboard fail with "dictionary changed size".
- **The periodic report by mail**: one that did not go (mail off or failing) is tried again in 30 minutes - it was taken as sent and the period was lost until the next one; one waiting in the outgoing mail counts as sent.

## 1.0.295 — 17 November 2026

**Bug fixes** (the hunt, second round). Without a database agent nothing changes.

- **Settings → The database on a node with no agent of its own**, in a cluster whose other node has one: the card of a server no agent looks after, with the other node's server as a tile beside it - it drew an agent of this node's ("Looked after by otp-db-agent at ?:?") with Move, Restart, Renew and Forget, which failed or did nothing.
- **High availability → The database servers** without replication (one node, or both nodes on one server): *– no replication* - it said a red *not set up* for each, with an arrow to "?".
- **A node forgotten or renamed**: its database server's rows go with it (Forget), and rows of a node that is no longer one of the cluster are left out - its tile, its pills on the cards, its "The database agent of … does not answer" alert, its `otp_db_agent_up` and its row of the meter stayed for good.
- **The meter's database rows are timed by this node's clock** when it read them: the database server's clock behind made its row late (dimmed, "?") for good, and an hour behind left it out.

## 1.0.294 — 17 November 2026

**Bug fixes** (a hunt through the code and the pages).

- **The RADIUS test** (the Test tab, and `otp --radtest`): a server whose name does not resolve, an address with no route, or a port out of 1-65535 is said as the answer ("cannot reach …") - it was "it broke, see the log" (HTTP 500). The link to the row of the Log is only given for a test of this machine: for another server it was the newest row of that name here, some other request.
- **A search by address with /32** (`ip:10.0.0.5/32`, in the Log, the tokens, the sign-ins) finds that address, with or without its port - it found nothing.
- **The Tokens quick view** (the Tokens card on Overview): *never used* is the count of all the tokens - it counted only the newest used 1000; *Locked out now* is asked for on its own and lists a token locked before it was ever used too.
- **The Let in quick view**: *People* is the number of people let in over the whole day - it counted the 200 newest rows; a name in it opens the Log on that day, not on the window the Log was last left at.
- **At phone width**: the NTP servers' rows (Settings → Time), the remote backup's destinations and the token window's sections fit their card - they stuck out past it and the page scrolled sideways.
- **The header meter with a database agent that does not answer**: asked once with a short wait, and the 10 s pause counts from the failure - every `/api/load` of the page waited about 9.5 s for it for a minute or two.
- **Joining a database agent at a bare IPv6 address** (`fd00::1`): the whole address is the host - its last group was taken for the port (`[fd00::1]:9443` as before).

## 1.0.293 — 16 November 2026

**The database servers in the header's meter** (isemon's external-database kit, the last part). Without an agent nothing changes. docs/external-database.md → *Monitoring*.

- With an otp-db-agent, the meter in the header (Settings → About → the performance meter) has a row for each database server after the nodes, in the look chosen (graphs, pills, line, rings), named with a small cylinder - the server's own short name (`db1`), or `db·NODE` where that is not one. This node's row is named beside it.
- Its numbers are what the agent reads of its machine (the processor, the memory, the disks, the network, the load), every 2 s while a page looks; the other node's server (layout B) from the row its node writes.
- Pointed at, its panel: the graph of what was pointed at, **The database** - the version, running for how long, the connections, *Waiting to go over (replication)*, the size of otp's database, its data's disk, TLS - and **The machine** in numbers.
- An agent that does not answer: the row dimmed and its name red, its panel says so. The meter does not wait for it: an agent known down is not asked, and one that did not answer is asked again 10 s later.
- docs/external-database.md: the intro brought up to date (1.0.292 and this).

## 1.0.292 — 16 November 2026

**This machine's database shown as a database server** (isemon's external-database kit, opt-in). *Settings → The database → Show this machine's database as a database server* (`db_local_card`, **off by default**; offered for PostgreSQL and MariaDB only). Off, nothing changes: nothing is read, written or shown. docs/external-database.md → *This machine's database*.

- On, a node whose PostgreSQL or MariaDB is on its own machine (localhost, 127.0.0.1, ::1 or a socket) and has **no agent** looks at it every 30 s with its own connection and `/proc` (its version, whether it runs and for how long, TLS, the connections, its data's disk, the memory, the processors and the load, the end of the certificate otp gave PostgreSQL) and writes it into its row of the database, `dblocal:node:NODE` - no password in it. The other node of a cluster reads it as it reads every node's rows: nothing new is opened, asked or let in.
- The card *Database server* is drawn above *Encryption to the database server* with a tile per node - this node's first, another node not heard from lately in amber, a certificate ending within 14 days in red. Actions, only what otp already does for a database on this machine: *Look now*, *Renew the certificate* (Encryption to the database server's, or the link's between the databases), *Restart the database…* while PostgreSQL's own settings wait for a restart and install.sh let otp restart it.
- Not there, on purpose: the agent's rows, join codes, *Forget*, pills on other cards, rows in the meter or on High availability, alerts. With an agent the card stays the agent's.
- Switched off, the row is taken away - also when otp starts with the setting already off (the kit's version kept it then). A move to another server leaves it behind, as the other rows about the old server.
- The card's heading on a phone: the state under the title instead of beside it, so the title is no longer squeezed into a column of a word or two (the agent's card too).
- Czech for the setting and the card.

## 1.0.291 — 16 November 2026

**Moving the database onto the server of this node's otp-db-agent, and off it** (isemon's external-database kit, the moves). One rule behind it: a node has one database agent, and it is the agent of the server its database is on. Without an agent nothing changes. docs/external-database.md → *Moving*.

- **Make it for me**: in *Move to another database*, step *Reaching it*, the server of this node's agent offers *Make the database and the account for me* - the agent makes the database and the account (its password made up when none is typed, shown once), lets this node in (`pg_hba.conf`, or `'user'@'node'` on MariaDB) and opens its firewall; no administrator's password typed anywhere. PostgreSQL is started again by its agent when it has to listen on its network addresses first - never while this node's own database runs on it. Elsewhere an administrator of that server is asked, as before; asked of another server, the agent's making is refused.
- **Off the agent's server** (onto this machine, SQLite, or a server no agent looks after): once the config file is switched, the agent is let go (`agent.json.forgotten`), told this node leaves it, and the wizard's last step and the events say so; its server leaves the pages. Step *What happens* says it beforehand. Onto the agent's server, the step says otp looks after it from the restart on, and Database → TLS comes next.
- **The encryption is the server's own**: with an agent, the TLS settings of the server in use (`db_tls`, `db_tls_ca`) are no longer carried to another server - verify-full against the old server's authority, or TLS asked of a MariaDB that has none yet, failed either way. Turned on there afterwards (Database → TLS). Without an agent as before.
- **The old server's rows left behind**: the moved database no longer gets this node's `dbtls:server:`, `dbagent:node:` and `load:db:` rows of the server it left - the new server's are written as they come.
- **High availability, each node's database on a server of its own**: the move, *Start using it*, *Set it up* and the wizard are refused with words that say so and the way out (switch the replication off, `otp --ha-standalone --yes` on both nodes, move, build the cluster again). A shared cluster's refusal is as it was.

## 1.0.290 — 16 November 2026

**High availability with each node's database on a server of its own** (layout B of isemon's external-database kit): otp1 on db1, otp2 on db2, the two database servers replicating both ways, set up, encrypted and looked after by otp through both nodes' otp-db-agent. PostgreSQL 16 or later. Without an agent nothing changes: `--ha-setup` is what it always was. docs/external-database.md → *High availability (layout B)*.

- **`otp --ha-setup --ha-peer DB2 --ha-peer-node OTP2`**: `--ha-peer` is the other DATABASE server, the new **`--ha-peer-node`** the other otp node. This node's agent prepares its database server (wal_level, listening, pg_hba.conf for the other server, the other node and this one), restarts it, publishes the tables and opens its firewall; the bundle carries this node's own address beside its database server's, and the steps for the other database server and the second node are printed. `--ha-peer-node` without an agent, or the same address as `--ha-peer`, is refused.
- **`otp --ha-join`** on a node joined to its database server's agent: its database goes onto that server - prepared by the agent, every row copied, both subscriptions - config.json points at it, and the agent is told the cluster's authorities.
- What is the nodes' own takes the other **otp node**, never the other database server: keepalived's other node and this node's own address, the addresses the firewall always lets in, the clocks' peers, the split's look at the other machine. The other database server's clock is said as *the database server of otp2* and never corrects the heartbeats.
- The link between the two database servers (`otp --ha-tls-repair`, *High availability → Repair*): each node issues its server's certificate and its agent puts it in - verify-full, hostssl. Rebuild (`--ha-resync`), pause, renewals and the authority's roll go through the agents as on a PostgreSQL of each node's own.
- *High availability → Making it two* on a node whose database is on its agent's server: **Each node's database on a server of its own** - the commands filled in from what is typed (in Czech too).
- The agent is not forgotten while the replication runs through it (`--db-agent-forget`, `--db-agent-leave`, the card).
- Later releases: the move wizard's *make it for me* on the agent's server, this machine's database shown as a database server, the servers in the header's meter.

## 1.0.289 — 16 November 2026

**The database on a server of its own, looked after by otp-db-agent** (isemon's external-database kit, 2nd edition) - layout A: one otp node, or two that share one database, and its database server. Without an agent nothing changes: no file `/var/lib/otp/db-agent/agent.json`, every path as it was. docs/external-database.md.

- **`install.sh --db-server postgres|mariadb`** on the database server: PostgreSQL 16 (AppStream's module or PGDG; Debian/Ubuntu PGDG) or MariaDB installed, initialised, secured, the database and its account, the otp nodes let in (`--otp-node`: pg_hba.conf written link-safe, firewalld), **otp-db-agent** and a join code. **`--db-agent`** the agent alone, or upgraded (its nodes stay joined, no code printed; `--new-code` for one). Passwords from `--db-password-file`, never asked on a command line; `--dry-run` masks them.
- **`otp --db-agent-join -`** on the node (the code on standard input - one on the command line is refused), or *Settings → The database → Connect a database server…* (also from the first step of *Move to another database*): the agent's certificate pinned from the code, the code's secret and the node's signing key sealed to the agent's own key, a client certificate from otp's authority.
- Through the agent, while this node's database is on its server: Database → TLS (the server's certificate from otp's authority, ssl on, verify-full, renewed), the server's own settings told and restarted, PostgreSQL's state, a node at a new address let in before the network changes, MariaDB's certificate (*Turn TLS on*, `otp --db-agent-mariadb-tls`).
- **The card *Database server***: where the database is, the server's tile (engine, running, TLS, connections, disk, RAM, load, uptime, both certificates' ends, nodes not heard from, an agent of another program), *Look now*, *Renew the certificates*, *Restart the database…*, *Forget the agent…*; a pill naming the server on the cards whose work reaches it (Database → TLS, the server's own settings, the firewall), its row on Database → TLS.
- `otp --db-agent-status [--json]`, `--db-agent-renew`, `--db-agent-restart`, `--db-agent-mariadb-tls`, `--db-agent-forget --yes`, `--db-agent-leave --yes`; a line in `otp --status`. Alerts (in Czech too): the agent does not answer, its database does not run, its certificate or this node's not renewed, the agent another program than this otp ships. Prometheus: `otp_db_agent_up`, `otp_db_server_up`.
- The agent: two processes (the side facing the network a program of its own as `otp-db-agent`, no key - root checks, does and signs), both ends pinned, every request and answer signed (a nonce never seen, also across a restart), a closed set of operations, the server's certificate one cluster's, every refusal audited without a secret, its certificate renewed by itself with an overlap, a hardened unit.
- MariaDB asked for TLS (`db_tls` require / verify-*) never goes on in the clear: a server that does not offer TLS is refused (PyMySQL went on unencrypted).
- Later releases: high availability with each node's database on a server of its own (layout B), the move wizard's *make it for me* on the agent's server, this machine's database shown as a database server, the servers in the header's meter.

## 1.0.288 — 16 November 2026

The card watched while signed in with it (Settings → Accounts → Signing in with a certificate → When the card is taken out): what isemon's kit, 4th edition, found on Windows 10 + Chrome with a smart card and on an iPad with a YubiKey. Off (the default) nothing changes.

- **Windows' "Insert a smart card" window and the browser's certificate chooser**: a check waiting on one for over 4 s counts as the card out - the countdown shows at once, behind that window, rather than only after Cancel. The server takes it as out only for a browser whose checks have already found the card, never as "cannot be checked". Put back and answered with OK, the notice goes.
- The notice says: press **OK** in that window, not Cancel - after Cancel Chrome and Edge offer no card to the server until they are closed and opened again.
- **F5 during the countdown** no longer starts it again from the full time: it counts from when the server saw the card out.
- **The mode changed** (off, signout, grace - from the pages, the command line or the other node): each watched sign-in's count starts afresh; none ends at once for time counted under the mode before.
- While root is still putting the certificate's port into nginx (just switched on), a check that got nothing no longer makes the browser "one that cannot be checked" for good.
- **Ended by the server** (the card out too long, another card): the page says why on the sign-in page and tries nothing by itself; it was reloaded without a word.
- **Pages reached by an IPv6 address or a name with an underscore**: the check's picture is let in (the page's policy could not name such an address) - the card went unchecked there, and the sign-in was held once the page stopped checking.
- The words no longer say an iPad cannot be checked: isemon found its cause was a policy header of its own nginx (otp's nginx sends none). *A browser that cannot be checked* stays, as a safety net.

## 1.0.287 — 16 November 2026

Three rounds of looking for bugs and security problems through the whole application; each round's own fixes looked at again by the next. Every finding checked in the code and traced to a real path before it was fixed.

Upgrades and the database
- **An upgrade whose daemon does not start puts the version before back**: its program, deploy/, root's helpers, its unit and the pages are kept until the new one has run for ten seconds without systemd starting it again; a new version that falls over at its start was left in place before, and the node stayed without RADIUS until it was repaired by hand.
- **A replicated node's nightly backup can be put back there**: it is a portable copy now (a dump makes tables anew, which replication does not carry - it was refused, and no copy was made by itself).
- **One copy put back at a time**: from the page, a kept one, `otp --restore` or a remote one - on this node and on the other (the same rows inserted on both stopped replication both ways); a job (an erase, a move) does not start meanwhile.
- A kept copy is no longer downloaded "with its key" when no .key lies beside it (the key in use went with it - put back elsewhere, every token was refused).
- Files written by otp (config.json, keys) are on the disk before their name: after a power cut config.json could be empty, and the daemon did not start.
- config.json changed while the daemon started (`otp --set`, `--ha-readdress`) is read at the next reload.

Sign-in and security
- An account whose row in the database is not as otp wrote it (the database guard) is no longer signed again with what somebody else put in - by a password reset or a sign-in from the directory; such a directory account is refused at sign-in. `otp --passwd NAME` (root) signs it again.
- The roles of directory administrators are not asked again of a directory whose row is not as otp wrote it - they are signed out, as a sign-in is refused.
- A directory or a revocation server (CRL, OCSP) that cannot be reached no longer counts as a wrong password - after it was back, the name or the office's whole address was locked out.
- The certificate's port takes only GET and HEAD, no multipart body, 16 kB at most - as otp's other servers.
- The card watched: the page's check carries a key made from the session - a page of another host of the same site cannot end or unwatch it (only a card found counts without it, so a page loaded before the upgrade keeps going); "cannot be checked" no longer written over a check that found the card at the same moment; the pages are loaded again only once when their address cannot be let into their policy (they did every minute).
- The certificate request (CSR) of an EC key: its key usage in strict DER.

The network, RADIUS, the cluster
- An address with an IPv6 scope id (fe80::1%ens192) in the balancers', SSO, SNMP, metrics, trusted or time servers' addresses is refused when set - root refused it inside its request, and with it every certificate, VIP and firewall change; one kept from before is left out. A network with its mask (10.0.0.0/255.0.0.0) is taken.
- RADIUS on `::`: an IPv4 client (::ffff:a.b.c.d) has its own line in the queue again, not the one of the addresses of nobody's.
- A reply through a proxy is measured with the request's Proxy-State before the code is used (near 4 KB the code was used up and the answer refused).
- A network change on trial that cut the node off from a shared database comes back the promised minutes after the machine started, not an hour later.
- Arbiter mode: one ping not answered no longer takes the only node left out of service - three checks in a row (about 6 s).
- "The other node" is the live one with the newest heartbeat - a node reinstalled under another name and never forgotten was taken for it (the clock guard, the measured clock difference, a split).
- A split: the preferred node's word read by the measured difference of the clocks.

Alerts, backups sent away, the rest
- An alert mail that failed with anything but a mail error (the key that seals the outgoing mail missing - the very alert about it) no longer stops the alerts; "right again" mails are no longer lost.
- A cluster with one database: the nightly copy of the cluster counts - the node that did not make it was told "no nightly copy" every day.
- A backup destination that lists a backup as 0 bytes no longer switches off the cap - never more than the room there is.
- High security's rules for backup destinations apply each time one is used, switched on or not ("Back up now" with its id, verify, put back, Try it).
- A configuration file's VIP without an address is switched off and its number read; realms and clients are matched in any case (the import stopped half way).
- `otp --set-role` and `--passwd` refuse accounts of the directory as the pages do; `otp --api` refuses a `bind_pw` written out on the command line.
- The sign-in by the load balancer ends whoever else was signed in in that browser first - before a refusal (429, 503) that showed their portal to the next person.
- The console's switch handles a full disk; the columns' switch writes only its own key of the session; log lines spared by the monotonic clock.

Pages loaded before this upgrade with the card watched: load them again.

## 1.0.286 — 16 November 2026

Fixed
- **Signing in with a certificate, the card watched: an iPad no longer signed out with its card in** - Safari on iPadOS signs nothing for a page in the background, so the check never arrived and the first one counted as the card taken out (found on a real iPad; the kit *card-removal-watch*, 3rd edition). A session now keeps whether a check in the background has ever found its card in this browser: never yet - *this browser cannot be checked*; found once - a check without it is a card taken out, as always. New setting **A browser that cannot be checked** (`admin_cert_card_unable`): `allow` (the default) - that sign-in is not watched, an event says so and why and the page tells the person; `signout` - signed out as before. The check's picture says no cookie came (3 px) or this browser cannot be checked (4 px); `card-gone` carries why (`nopicture`, `nocookie`), so the events name the reason.

## 1.0.285 — 15 November 2026

Added
- **Signing in with a certificate: when the card is taken out** (`admin_cert_card`: `off` - the default, nothing changes and nginx is written as before; `signout`; `grace`, with `admin_cert_card_s` 5-300 s, default 15, and `admin_cert_card_grace_s` 5-600 s, default 30) - as the kit *card-removal-watch*: the page loads a picture from the certificate's port, a new TLS handshake each time that only the card can sign (nginx keeps no TLS session and no connection there while it is on); 1 px - the card is in, 2 px - out and the session waits, 403 - over. `signout` ends the session at the first check without the card; `grace` covers the page with a countdown (*Put the card back*, the seconds left in a ring that empties, *Sign out*) and the server answers nothing of the session until it is back; another card ends it at once; the sign-in page says why and tries nothing by itself. The state is kept with the session in the database (either node of a cluster, a restart forgets nothing); a watched session whose page stopped checking (asleep - an iPad locked, the browser in the background) is held, not ended: nothing answered until the page, checking the moment it wakes, finds the card; every end is in the events. Kind to the card: one check at a time, one for all the tabs of a browser, a pause after a check that waited on a window of the card's, a lost connection asked again before it counts. The page's policy lets the check's picture in only for a watched session. A password, Windows and RADIUS are not touched.

## 1.0.284 — 15 November 2026

Changed
- **Values for a certificate request: the account picked as a token's "For" is** - while a name is typed, the people of the directory set for administrators are offered (their names, the name shown and the mail); one picked is looked up at once. Enter takes what the list offers when an item of it is chosen, else looks up what is typed.

## 1.0.283 — 15 November 2026

Added
- **A certificate request made in the browser** - *Values for a certificate request → Make a CSR…*: a second window where what goes in is chosen and added to first - the key (RSA 2048/3072/4096, ECDSA P-256/P-384), the subject (CN of the account, O, OU, L, ST, C), the Subject Alternative Name each ticked and edited (the UPN, the SID as its URL for the strong mapping, the e-mail), what the certificate is for (Client Authentication, Smart Card Logon, Secure Email), the template of AD CS - then the key pair and the PKCS#10 request are made **in this browser** (WebCrypto): the private key never leaves it, nothing of it is sent to the server. The request is copied or downloaded (`.csr`), the key downloaded (`.key`) - by default locked by a passphrase (PKCS#8 encrypted with PBES2: PBKDF2-SHA-256, AES-256-CBC; openssl and Windows read it).

## 1.0.282 — 15 November 2026

Added
- **Values for a certificate request** - *Settings → Accounts → Signing in with a certificate*: an account of the directory (its sAMAccountName, `DOMAIN\name` or UPN) looked up, and what its certificate must name to sign in here, each with a button to copy it - the subject (`CN=...`), the UPN of the SAN, the SID as the URL of the SAN (`tag:microsoft.com,2022-09-14:sid:S-1-5-21-...`, the strong mapping of KB5014754), the mail; the whole SAN at once; certreq's `request.inf` and openssl's config to copy or download. It says too whether a certificate of the account would sign anybody in (no UPN, no SID with strong mapping, switched off, locked, no role here). A full administrator only; nothing is changed or kept.
- **Signing in with Windows: the keytab guide's values from AD** - the domain's NetBIOS name and DNS name are read from its crossRef in the forest's configuration (`nETBIOSName`, `dnsRoot`), no longer guessed from the realm: where the NetBIOS name is not the first part of the DNS one (`MERIT_NT` for `merit.cz`) the commands said `MERIT\...` and did not work. The account that already holds the pages' SPNs is named in them; SPNs on more than one account, and a realm that is not AD's, are said. The guide says where its values come from (*from AD*, or *guessed* when the directory did not say), with *Ask AD again*.

Fixed
- **The SID in the SAN's URL** (`tag:microsoft.com,2022-09-14:sid:...`, as Microsoft writes the strong mapping in the SAN) is read too: a certificate naming its SID only there was refused with *strong* mapping ("names no SID").

## 1.0.281 — 15 November 2026

Added
- **SNMP: everything the application can tell, typed** (OTP-MIB, `.7.10`-`.7.17`): the machine (CPU time idle and in all, cores, the load, memory and swap, bytes read and written by the disks and by the network cards - counters, a rate is the monitor's to make; uptime; the file systems otp lives on with size, used, free, % and inodes), RADIUS (the clients, realms and directories set; accepted, rejected and challenged in the last 24 hours and a table of every result), each directory and whether it answers this node, the cluster (whether this node holds the VIP address, the replication both ways), the nightly copy and the backups sent away, the mail queue, the ways of signing in to the administration with the CRLs and OCSP answers, the clock guard, the logs sent to isemon and a SIEM. Each part answered by itself: one that fails leaves the others answered. OTP-MIB has every object in a conformance group (smilint and net-snmp take it without a word).
- **Zabbix 7.0: the template "otp by SNMP"**, to download on *Settings → Monitoring → SNMPv3* (with OTP-MIB) and in `deploy/zabbix/`: items for every object, discovery of the tables (each problem otp sees a problem of its own in Zabbix while it lasts, the certificates, the nodes, the file systems, the directories, the replication, the RADIUS results), triggers with their limits as macros, value maps, graphs and a dashboard of five pages (*Overview*, *RADIUS*, *Machine*, *Cluster and directories*, *Certificates, sign-in, backups*). docs/monitoring.md: the objects and how to put a node into Zabbix.

## 1.0.280 — 15 November 2026

Changed
- **SSH keys: root's are only shown.** On the pages no key for root is made, put on or taken away any more - the list of root's keys, each node's facts and the export of a key's public half stay; a way in as root is put on or taken away by root on the node itself (`/root/.ssh/authorized_keys`). The server refuses it too, not only the page. For the other users who may sign in on the nodes, a key is made or added as before - and **made the way root's was**: in a cluster *The same key on every node* or *Only on* one node.

Fixed (bug and security hunt after 1.0.279)
- **Settings - Accounts: the cards of Windows, the certificate and the sign-in page show a change at once** - after Save they were read again only on F5 (the steps of revocation, by itself on the sign-in page, the second step); asked again a few times in the first minute too, as root's helper puts nginx's part in. A save no longer moves what is in view: the settings drawn again, and the cards, keep their place.
- **Import of settings**: the directory (`admin_directory`) is left as it is too when the file would put *no password at all* in effect by it; a file of a version before 1.0.278 that holds *no password at all* on no longer stops the import half way (left as it is - switched on only from the pages); *Replace* checks that nobody is left without a way in by what it takes back to the defaults, and keeps the switches root's helper reads as rows of their default instead of dropping them (nginx kept serving what was dropped).
- **Sign-in with a certificate**: a person whose certificate cannot be checked for revocation just now is told little (*cannot be checked for revocation (CRL, OCSP) just now*); which responder or CRL address of the inside network did not answer, and openssl's words, go to the events. The certificate's port is looked for where its server listens on this node's own addresses (a node whose HTTPS server listens on one address said "not yet" for good; the VIP's listen line answered by the other node no longer counts).
- **RADIUS queue**: a lone line (one NAS started again, thousands signing in) may use nine tenths of the queue instead of half; an address that is no client never gets a line of its own (it took the lines of real clients with realm names made up) - the line of those addresses is held to half the queue at all times; whether an address is a client is read from the clients kept in memory only.
- **Tokens**: a delegated administrator enrolling a token no longer holds the token's lock while the directory is asked whether it is the same person (a RADIUS worker checking a code of that name waited on a directory that hangs); the token is looked at again afterwards.
- **ACME**: the answers to the CA's http-01 challenge (`acme:chal:`) and the certificate before a renewal (`acme:before:`) are signed rows; a challenge is answered on port 80 only while ACME is on (the reach probe's own answer aside) - a row put in the database by somebody with write access to it no longer got a trusted certificate for the appliance's name.
- **Signed rows**: *Windows tried by itself on the sign-in page* (`admin_kerberos_auto`) is a signed setting (written unsigned by 1.0.274-1.0.279, taken in once); guard.json says which version wrote it - back on a version after a downgrade, the rows signed only since a newer version are taken in again instead of being refused.
- The lowest version a node goes back to (`DOWNGRADE_FLOOR`) is 1.0.278.
- The settings pane no longer keeps the height of the pane before (a gap under a short pane after a long one).

## 1.0.279 — 15 November 2026

Added
- **OCSP for the sign-in with a certificate, as the ocsp-ldap-kit says** - *Ask an OCSP responder* (`admin_cert_ocsp`), **off by default**: `first` (the responder - AD CS's *Online Responder* - and the certificate's CRL when it does not answer), `only` (no answer, no sign-in), `both` (the responder and the CRL, both must say good). The person's certificate and every authority above it but the root, each asked of its own issuer's responder (its *Authority Information Access*) or of **one responder for all** (`admin_cert_ocsp_url`, for certificates issued before the responder was there - refused when saved unless it is an http address a CRL could be fetched from). Asked only for a certificate whose chain is already good, over http with the CRLs' guards (every address checked, the connection made to it, never through the proxy, no redirect, 1 MB and 15 s); the answer checked by openssl against the authorities put in alone (signed by the authority or by a responder certificate it issued with OCSP Signing; only openssl's own words read - a forged, unsigned or out-of-date answer is no answer); kept ten minutes at most, the last good one used until its next update while the responder does not answer, a responder that gave no answer not asked again for a minute.
- **An authority renewed with a new key under the same name** (as AD CS does): the one whose key signed the certificate (its *Authority Key Identifier*, else openssl's check of the signature) is the one asked, and the one above it in the chain. An authority above that names no responder is held to its CRL in every OCSP mode, even with CRLs off.
- **CRLs from the directory** (`admin_cert_crl_ldap`, off by default): the `ldap:///...CN=CDP,CN=Public Key Services,...` address AD CS writes into its certificates is read too, after the http ones, **with the connection of the directory set for administrators** - never the host written in the address; only a CDP object of the configuration's Public Key Services, base scope, only its `certificateRevocationList` / `deltaRevocationList`, kept as its bytes.
- **On the card**: the facts say how revocation is checked as steps (*OCSP → no answer → CRL → none to be had → no sign-in*); **Online status (OCSP)** - a row for each answer kept on every node (certificate, issuer, status: good / last answer kept / run out / unknown / revoked / no answer, next update, serial, when asked), a row opens to its details and each node's answer; **Ask again** and **Clear** asked of every node (a full administrator only, written to the events); a CRL read from the directory has an **LDAP** tag and its authority's name in the CRL table.
- `otp --cert-ocsp [--json]`, `--cert-ocsp-fetch [KEY]`, `--cert-ocsp-clear [KEY]` (asks; `--yes`).
- docs/admin-certificate.md: *OCSP and CRLs from the directory* - the modes, the guards and what to set up in AD CS.

Fixed
- A CRL fetched again (*Fetch now*) is no longer put back over by a fetch that started before it.

## 1.0.278 — 14 November 2026

Three rounds of looking for bugs and security problems through the whole application; what they found.

Added
- **Revocation lists (CRL) of the sign-in with a certificate, as the crl-revocation-kit says** (acme 1.0.104): the CRL of the person's certificate, **its delta CRL** (Freshest CRL - a card revoked since the weekly base no longer passes), and **those of every authority above it but the root** (an issuing authority its root revoked signs nobody in; one that names no CRL at all is not checked, as before), in one `openssl verify -crl_check_all -use_deltas` against the authorities put in alone - never the system's store. Seen within ten minutes (sooner at its next update); the last good one kept until its next update while the address does not answer, then no sign-in; a CRL already past its next update is none.
- **Where a CRL is fetched from**: http only, by the node's own resolver and **never through the proxy** (AD CS's CDPs are inside); every address of the name checked - no loopback, link-local, metadata, multicast or reserved one, in any spelling of the number; private ones are fine - and the connection made to the address checked (no second look-up, no DNS rebinding); no redirect, 8 MB and 15 s at most.
- **The table on the certificate's card** (*Revocation lists (CRL)*): one row for each CRL a node keeps and each one the authorities name - its address (copy), issuer, base or delta, the next update as a pill (good / within a day / last fetch failed / not had / run out / not fetched yet), revoked entries, when fetched; a row opens to this update, number, size, the signature (checked by openssl), the error and **each node's** fetch. **Fetch now** and **Clear** (all, or one row) are asked of every node of a cluster - each does it itself, and a box shows each node's answer; a full administrator only, written to the events. On a phone each row is a block, every value under its label.
- `otp --cert-crl [--json]`, `--cert-crl-fetch [URL]`, `--cert-crl-clear [URL]` (asks; `--yes`) - the same rules and events as the page.
- **The card is redrawn in one step and keeps its place**: a row opened, Fetch now's answers, a refresh - what is clicked or looked at stays where it was on the screen.
- docs/admin-certificate.md: *Revocation (CRL)* - the rules, the lag (after revoking a lost card: `certutil -CRL`, then Fetch now) and the network.

Security
- **The CRL of a certificate is fetched only after its chain is checked**: nginx takes any certificate on the certificate's port, and its CRL address was fetched before the certificate was checked against the authorities put in - so anybody who could reach the port had this server fetch addresses of the inside network and say back what they answered. The chain first now; a certificate of somebody else's authority is refused before anything is fetched. The cache of CRLs that could not be had is bounded too.
- **No password at all cannot leave nobody a way in, on any road to a save**: the check of 1.0.274 read the value as text ("1.0" passed it), was not made for an imported configuration, and not for switching Windows or the certificate off or on afterwards. Now the settings as they will be after the save are checked on the pages, `otp --set` and an import: with no password at all in effect, a way that is on must work (Windows with its keytab, a certificate with an authority); put in effect only from a sign-in made by a way that will still work; never by a file; and not saved at all with neither way on (it lay in wait for the next switch). `otp --kerberos-keytab-drop` and `--cert-ca-drop` refuse to take the last way away, as the pages do.
- **The sign-ins made with a password end** when no password at all comes into effect - they went on for hours.
- **The reason a certificate was refused comes back in a cookie of the site**, not as words in the address: a link of anybody's put any text on the sign-in page as a refusal. (In a cluster upgrade both nodes before relying on the certificate sign-in: a node of 1.0.277 shows the reason of a node of 1.0.278 as "1".)
- **pg_hba.conf is never written by root through a link** (the steps of a cluster, the rename): its path is what PostgreSQL says, in the postgres account's folder. A link there is refused and said.
- **The bundle for a second node** (it carries the key of every token) is made on the pages only while a token's key may be shown there (*Administrators may show a token's QR code and key*); otherwise as root, `otp --ha-bundle`. An export with the secrets made on the pages leaves the backups' password out under the same rule (and says so in the file, so that importing it never takes the password away); adding or changing a backup destination then is written down as a warning.
- **The portal answers a name the directory does not have as slowly as a wrong password** (and a locked or ambiguous one): the time alone said which names exist.
- **Replacing a token on the portal offers only the ways its realm offers**: an app token was made again where the realm had moved to mail or SMS.

Fixed
- **Nothing jumps when a switch is flipped near the end of a pane** (Alerts and reports, System updates, About): the words a switch hides below it (*Not in use while ... is off*) shortened the pane, and one scrolled to its end slid down by their height - the pane now keeps its height while it is worked in. Every pane of Settings is checked at 1920 and 1400 px by the tests.
- *Try my browser's ticket*, *Check the database* and the SMS gateway's *Test* said only "HTTP 200" when what they found was no: a ticket that would not sign in read as "no ticket", a broken database never showed its list, the gateway's steps were not drawn.
- A node's own switch in a cluster stayed flipped when its save was refused.
- The Windows card's "none - set Sign administrators in against the directory" stayed in English on the Czech pages.
- **A fetch from a backup destination is held to the size the destination lists**, with room for it checked first: a server that sent without end filled the database's disk during the weekly check.
- **A scheduled backup that failed is tried again** an hour later, three times at most that day: a weekly schedule went a week more without one.
- **The certificate's port is looked for on the address its server listens on**: a node's HTTPS server on one address gave the certificate's server that address, the look at 127.0.0.1 found nothing, and every save of nginx and the VIP address was put back.
- **Uninstalling takes the certificate's nginx server away too** (and its authorities): left behind, nginx did not start again; nginx's configuration is tried before it is reloaded.
- Importing a configuration made by an older version with *No password at all* stored is not stopped half way.

## 1.0.277 — 14 November 2026

Added
- **The sign-in page's variants, set in three cards of their own** in Settings → Accounts: *Signing in with Windows*, *Signing in with a certificate* and **The sign-in page**. The last holds the one setting the two ways share (*No password at all*) and says in words what a person meets with the settings as they are: name and password offered or not, each way a button or tried by itself, the order, what happens after a refusal and after *Sign out*, and with a computer without a Windows ticket. docs/admin-sign-in.md.
- **A certificate tried by itself when the sign-in page opens** (`admin_cert_auto`, off by default): the browser goes to the certificate's port at once; with no fitting certificate, or the chooser or the PIN cancelled, the person is back on the page with the reason and the form, and the certificate is not tried by itself again in that tab. With Windows by itself too, **Windows goes first, silently**, and the certificate only when the computer has no Windows ticket at all; a refusal of either is never a reason to try the other. With no password at all and only a certificate, it is tried by itself.
- **A computer without a Windows ticket is remembered for 30 days**: when trying Windows by itself ends without a ticket (or the browser's window is cancelled), that browser does not try Windows by itself for 30 days - the form and *Sign in with Windows* are there, the button works, and a sign-in with Windows forgets it. Computers in the domain sign in silently as before.

Changed
- **The Windows card looks like the rest**: chips for its state, the facts in two columns that do not move when a switch is flipped, the keytab, the names and their SPN, each node, the commands for a domain controller (with a Copy button) and the browsers' settings. The certificate card the same.
- **The last way without a password cannot be taken away**: dropping the keytab, or the last certificate authority, is refused while *No password at all* is in effect and nothing else would sign anybody in.

Fixed
- **Windows and the certificate are offered to a browser on another machine too**: the sign-in page cut what it knew down to the language for anybody not on the server itself (1.0.274, 1.0.275), so *Sign in with Windows* and *Sign in with a certificate* were drawn - and tried by themselves - only in a browser on the server, and with *No password at all* a remote browser had nothing to press. The page now keeps which ways are on (yes or no, as the health check says to anybody).
- **NTLM is never asked for nor taken**: a browser that answers Negotiate with NTLM (a computer outside the domain) - or sends NTLM, Basic or Digest by itself - gets a refusal with no new challenge, so it never shows its own name-and-password window.

## 1.0.276 — 14 November 2026

Fixed
- **The certificate sign-in's port and the balancer's own port are never one port**, whichever is set first: with *Sign administrators in with a certificate* on (8443), *The balancer's own port on the nodes* (`web_proxy_port`) set to 8443 afterwards was taken - two nginx servers on one port. It is refused now, saying another one (9443); the certificate's port is checked against the balancer's, 80/443, the API's, RADIUS's, the SSH gate's and a local database's - of this node and of the other node of a cluster - on every way of saving (the pages, `otp --set`, an imported configuration), and switched on or moved it is tried on the node first: something else listening there already (not otp's own certificate server) refuses it.

## 1.0.275 — 14 November 2026

Added
- **Signing in to the administration with a certificate - a smart card, a YubiKey (PIV), or one in the computer** - off by default (Settings → Accounts, *Sign administrators in with a certificate*). nginx asks the browser for a certificate on **a port of its own** (`admin_cert_port`, 8443) - never on 443, so nobody else is ever asked for one - and only that sign-in is served there. otp checks it itself: the chain to an authority put in on the pages (openssl verify) and its dates, a key usage for signing in (Client Authentication or Smart Card Logon), **not revoked** (the CRL at its CRL Distribution Point, kept until its next update - no CRL, no sign-in; `admin_cert_crl`), and the **UPN** in it looked up in the directory the administrators sign in against (on, not locked, not expired; the role of its groups). `admin_cert_map`: **compat** (the SID of KB5014754 must be the account's when it is there), **strong** (it must be there), **upn**. **The second step, when it is on, is asked after it every time.** The account is named by its sAMAccountName, as with a password or Kerberos. docs/admin-certificate.md.
- **The authorities** are put in once (PEM, DER, .p7b; a person's certificate refused), kept in the database (signed with the guard on) and written by every node. **A cluster and its VIP address**: root's helper of each node makes nginx's server on the port from the node's HTTPS server and the VIP address's (its address, name and certificate); the firewall lets the port in for the administrators' networks; SELinux lets nginx have it; nginx is checked to listen (and to stop) after the reload.
- **On the sign-in page**: *Sign in with a certificate* - a nonce in a cookie of this browser (refused when the sign-in was not started from it), the certificate's port, back to 443 signed in or with why not (a certificate nginx refuses itself - run out, not for a client - says why too, not nginx's own 400).
- **No password at all - only Windows or a certificate** (the 1.0.274 switch, now for both): no field for a password anywhere; switched on only from a sign-in made with Windows or a certificate; in effect only while one of them is on.
- **The card** in Settings → Accounts: the authorities, which account a certificate is, revocation and the CRLs fetched, each node (the authorities written, nginx listening on the port), *Try my certificate* (who it would sign in, and as what - nothing opened), the AD CS template, a YubiKey, the browsers and the network.
- `otp --cert on|off|status`, `--cert-ca FILE`, `--cert-ca-drop SHA256`.
- The directory's `objectSid` is read with a person's entry (for the SID in a certificate).

## 1.0.274 — 13 November 2026

Added
- **Signing in to the administration with Windows (Kerberos)** - off by default (Settings → Accounts, *Sign administrators in with Windows (Kerberos)*). A browser on a computer in the domain sends a Kerberos ticket for the name it opened (SPNEGO, `Authorization: Negotiate`); otp checks it with the system's own GSS-API library (libgssapi_krb5, called through the standard library - nothing to install) against the keytab put in on the pages, and looks the person up in the directory the administrators sign in against: the role of their groups, as after a password. **The second step, when it is on, is asked after it every time.** **NTLM is never taken** (bare or inside SPNEGO), nor any mechanism but Kerberos 5. Only accounts of the directory; the realm from the directory's base DN or set. docs/admin-kerberos.md.
- **The keytab**: put in once by a full administrator (or `otp --kerberos-keytab FILE`), checked (a keytab, a key of `HTTP/`, not only DES/RC4), kept sealed in the database (signed with the guard on) and written out by **every node** itself (`/var/lib/otp/kerberos/http.keytab`, 0600). Its principals, key versions and kinds of key are shown; its keys never. One key of the service account serves every name of it (the VIP address's and each node's).
- **A cluster and its VIP address**: a ticket is taken by whichever node holds the address; one used on one node is refused on the other, also after the VIP address moved (the cluster's replay cache is in the database).
- **On the sign-in page**: *Sign in with Windows*; *...by itself when the sign-in page opens* (never again in that tab after signing out); *...and no password at all - only Windows*: no name and password offered, every password refused (local accounts too) - switched on only from a sign-in made with Windows and with a keytab in, in effect only while Kerberos is on; the way back as root: `otp --set admin_password_off=0`. In this mode no field for a password is shown anywhere on the administration pages either: not *A new password* in Your account, not *Set a new password* of an account, not the first password of *Make an account* (the directory's people get their account at their first sign-in with Windows); a change of a password is refused by the daemon too.
- **The card** in Settings → Accounts: the keytab, the names the pages are opened by and their SPNs, each node (the keytab written, the library there), the commands for AD (setspn, ktpass) filled in with this server's names, the browsers' settings, and *Try my browser's ticket* (who it would sign in, and as what - nothing opened).
- `otp --kerberos on|off|status`, `--kerberos-keytab FILE`, `--kerberos-keytab-drop`.
- nginx takes a header of up to 32 kB (`large_client_header_buffers 4 32k`) for the ticket of a person in many groups - put in by the upgrade.

## 1.0.273 — 13 November 2026

Changed
- **Your account - a new password is typed twice**: beside "The new one" there is "The new one again"; the two must be the same, and the one you have now must be filled in, before anything is sent. A slip of a finger no longer leaves a password nobody knows.
- **SSH server - "Who may sign in" without root is allowed**: saving AllowUsers that leaves root out was refused ("AllowUsers without root lets nobody in as root") unless root could not sign in at all. Leaving root out is a choice of its own - the accounts listed sign in over SSH and use sudo, root signs in only at the console - so it is saved as it is. The field's help says so. The on-trial time still puts back what the node had if nobody keeps it.

## 1.0.272 — 13 November 2026

1.0.271 was not released on its own (its full run was cut by a restart of the test machine): its changes below ship in this version. Bug-hunt round 3 (the database layer and upgrades, the pages, the pages' certificates and nginx, TLS of the database connections and of isemon): every finding checked in the code and traced to a real path before it was fixed.

Fixed
- **An upgrade that adds an index could leave the node down**: the tables made at start ran without the 120 s statement limit, but the columns added within it put the limit back on their way out - the indexes made after them (minutes on a large log) were cut, and the daemon did not start. The limit is now put back only by the outermost.
- **nginx's certificate found changed by hand or by a restore was never put back**: "put in again" was said in the events, and nothing was asked of the root helper - nginx kept the wrong (or a run-out) certificate. It is asked again now.
- **A node renamed** carries its database's certificate (TLS of the database connections, kind local): left under the old name it was never renewed nor alerted, and once it ran out the connection lost TLS - under high security the database itself.
- **The cluster's authority for isemon's certificates** is made by one node only, as for the database's (1.0.262): *Try it* with mutual TLS on, before any authority was made, made one on both nodes - a duplicate key, and replication stopped for good.
- **A large firewall** (some 1850 RADIUS clients and more) made the request to the root helper bigger than it took, and the whole request was refused - renewed certificates, the VIP address and the access lists with it. It takes up to 4 MB and 20 000 rules now.
- **The RADIUS log on MariaDB**: a user name of 191-253 characters was refused ("Data too long"), and kept on SQLite or PostgreSQL it stopped every move of the database to MariaDB. Every short column of the log is kept at 190 characters.
- isemon's sending takes a client certificate renewed by *Try it* too (it kept the old one until it ran out).
- **The pages**: a tab left open in the background no longer signs out the tab in use (the last use of any tab counts); the Web, VIP and Firewall panes do not stop their own asks on a busy daemon (each took more than 5 s, the next one stopped it, and the pane was never drawn again); a slow *Try a sign-in* answer is not written into another popup, and the HA bundle's passphrase is shown in a popup of its own when the first was closed meanwhile (the bundle saved could never be opened).

## 1.0.271 — 12 November 2026

Two bug-hunt rounds over the whole application (remote backups, the cluster, the web API, RADIUS, tokens and codes, the network and the root helper, ACME, mail, alerts, SNMP, SIEM): every finding checked in the code and traced to a real path before it was fixed. 1.0.270's full run stopped at its time limit with every test until then passing; its changes ship here.

Fixed
- **The firewall after a reboot**: a saved ruleset with counters (iptables-services with `IPTABLES_SAVE_COUNTER=yes`) got the jump to otp's chain after the system's final REJECT - the live rules were right, but after a reboot RADIUS, the pages and SSH on another port were refused.
- **A remote backup that failed left no trace**: a copy of the database that failed (the database away, the disk full) or no room for it was only a line in the log - no line in *Backups sent*, no event, no alert until "no backup in time" a day and a half later. Every failure is now said.
- **Remote backups**: an SCP/SFTP folder beginning with `~` is the home folder (it was a folder named `~`, and every backup to `~/otp` failed); old backups the server would not delete are said, not told as deleted; a backup to a folder is on the disk (fsync) before the old ones are deleted; a wrong password that passes openssl's padding check (1 in 256) is the wrong password (the password of before 1.0.139 is still tried); a damaged archive is said as damaged, not an error of the page; the token count is not written when a token came or went during the copy (the weekly check said the backup could not be put back).
- **The cluster**: a node with no heartbeat in the other node's database was taken as alive - while node1 was rebuilt nobody led (no alerts, no once-a-day work); the link between the databases whose last step (pg_hba) failed is asked again an hour later (it stayed failed for good, the other node coming in without TLS); its other node is the live one, not the first by name (a node reinstalled under another name); a rebuild refuses a missing `ha_slot` instead of taking 2 (the wrong subscription dropped, the rows numbered as the other node's).
- **Network**: a change of the IPv4 address or the DNS kept a second IPv6 address set by hand (it was dropped; IPv4 kept them since 1.0.262).
- **SSH**: with sshd on more than one port, a change not kept and put back opened only the new port; an app's SSH code is held after 20 wrong in a row (15 minutes, doubled every 10 more, a day at most), counted in the token's row on both nodes and through restarts - five a node every five minutes was all.
- **Time**: the nodes take each other's time when `ha_peer` is a name (chrony was never told the other node).
- **Tokens put back from a backup**: numbers that are not numbers (`Infinity`, text) are left out instead of stopping the restore half way or breaking every token backup after it; a step of the last code from the future is capped at now (every right code was refused as used).
- **Firewall trial**: *Keep* after its time is refused - the other node may be putting it back at that moment.
- **Alerts and SNMP traps**: a problem said is over only once it has stayed away as long as it had to stay to be said (a disk about its limit mailed "new" and "over" all day); a report sent from the other node's pages no longer writes its stale copy of the alerts back (they were mailed again).
- **ACME**: a name that is not a full DNS name fails with its state, event and alert (it was a log line every hour until the certificate ran out); the order is finalized once the CA says it is ready (RFC 8555).
- **CA Issuers**: NAT64 addresses of the metadata service and AWS's IPv6 one are not asked; private addresses still are (an AD CS publishes on the inside).
- The pages' places for heavy reads are taken only by somebody signed in (a flood of unsigned asks told administrators "busy"); SIEM facility 0 (kern) is sent as 0; a SIEM error of the thread itself clears with the next good send.

## 1.0.270 — 12 November 2026

A bug hunt over what the last versions added (the whole chain, the cluster's wish for the database connections and restores, the system's trusted roots, LDAP under load, SELinux): every finding checked in the code, these fixed. Standalone and HA alike.

Fixed
- **A copy put back could stop on "duplicate key" and be undone**: a backup made after 1.0.268 holds each node's *SELinux was* row, and the restore writes that row again from the node's SELinux row in the same copy - while the copy's own row was still waiting to be written. Restoring a backup of a machine already restored once failed; a database move too. The rows are written once the copy is in.
- **Switching the encryption of the database connections off could be undone at once**: the node was switched first and the cluster's wish after, and between the two the node's own follow saw "not encrypted, wished encrypted" and encrypted it again - the wizard's next phase then failed. The wish is written first, the follow asks again before every step and waits two minutes after the wizard worked on the node. In a cluster the wish a node derives (set up before 1.0.268) is written by the first node only, after it was missing two minutes: two nodes writing a new row at once is a duplicate key that stops replication.
- **The chain**: a certificate uploaded with an intermediate of another chain beside it (the other key's - RSA and ECDSA in one PEM -, an old one) took that one for the top: a public chain was said to lead to "a root the system does not trust (a private CA?)" and the right intermediate was not fetched. The walk starts from the top of the certificate's own chain. A root reached that does not make the chain check (an authority out of date, no list of roots) is no longer called private - openssl's reason is said. An answer at a CA Issuers address that does not read no longer breaks the upload, an ACME renewal or an acme push (the chain is said unchecked, the certificate goes in).
- **CA Issuers addresses**: only http/https on ports 80 and 443, never this machine, a link-local address (a cloud's metadata service) or a broadcast one - the address comes from the certificate sent, and an acme push key's holder makes those; redirects checked the same way. Thirty seconds for each fetch in all (a server sending a byte now and then held the upload); an answer with no certificate kept ten minutes, not a day.
- **The second (ECDSA) certificate's chain** is checked, kept and shown (*Chain (second)*) - it is what most clients take; *Complete the chain* completes both and **Upload the missing authority** takes the second one's authority too (it was refused). An incomplete second chain makes the button primary.
- The VIP's card reads the node that holds the address first (every node writes the VIP's files); a private authority's certificate whose root was given is no longer "incomplete" for the file nginx has.
- **The system's trusted roots**: the system's tool that failed or timed out after the files were written was never run again - the node then said "applied" for good with the certificate missing from the system's list. A sync now runs it again when one of otp's is not in the list, and a node whose list lacks one says so (failed, with *Read it again*). A certificate of 12 kB was taken by the daemon and refused by the root helper, which then refused every sync. Debian's folder of local authorities made 2775 root:staff (older or upgraded systems) was refused - taken now when its parent is as writable.
- **SELinux from the command line**: `otp --selinux enforce`, `--selinux-check` and `--selinux-report` gave ausearch the otp command's stdin, a pipe already read: nothing refused was ever found, and enforcing could be switched on with refusals there. The root helper's programs get /dev/null.
- SELinux: a failed periodic look no longer wipes what the node said (the high security check and *To be done by hand* lost SELinux, and the error was never shown); a step asked of a node that was away more than an hour is not done when it comes back (high security may have been switched on since) - said; a step tried whose answer could not be written no longer stays "asked" until a restart runs it again; the page no longer asks every 2 s for ever while a node is away; a long audit log in the report no longer replaced what audit2why and audit2allow say.
- **LDAP**: a server that hangs (accepts, does not answer) was waited for twice when the kept connection met it; a bind refused with result 8/13 (signing wanted), 1 or an answer that does not read is not a wrong password - it used up the person's tries.
- A token confirmed is counted active at once on the overview (was up to 5 s pending); a directory whose *check the certificate* is unset gets the IP address warning too.

## 1.0.269 — 12 November 2026

The whole chain of the pages' certificates - nodes and the VIP address, in a cluster on both nodes.

New
- **Certificates and TLS checks the chain the way every client that is not a browser does.** nginx must send the certificate with every intermediate authority up to a root; a certificate uploaded without them was sent alone - browsers fetch the missing link themselves (CA Issuers) and said nothing, curl, Python, Java, a VPN client, rsyslog and monitoring refused it ("unable to get local issuer certificate"). Whatever comes in - an upload, a PFX, a request signed elsewhere, ACME, acme push - is checked against the system's roots (and a root given with it), and a chain that does not reach one is **completed from the authority's CA Issuers address**, as browsers do (4 steps at most, http/https, through the proxy where ACME goes through it); what is fetched is only a link to a root of the system, a root is never sent.
- The card's **Chain** line: green *complete - N certificates up to …* (with *fetched: …* when otp completed it, *a private root* for a company CA whose root was given), red *incomplete - the authority … is not sent* with why, or *it leads to …, a root the system does not trust*; self-signed: no chain. **Complete the chain** (primary when it is incomplete; otherwise *Check the chain*) and **Upload the missing authority** - a dialog that names the authority missing, PEM or a .cer/.crt file, only certificates of authorities, never a key; a root is kept to check with, never sent.
- The file nginx has now is checked as well (the system's roots, nothing fetched) - certificates put in before this version too; and after every time nginx takes a certificate each node connects to itself as a client that fetches nothing - its own name, and the VIP address on the node that holds it (also when the VIP comes over): a refusal is an event, and the card's **Sent** line says it.
- In a cluster: the VIP's certificate and every node's own completed from either node's pages, the same chain on both (replication), nginx's files on each node with the certificate and its intermediates (tests/r269/t_chain_ha.py, VRRP on).

## 1.0.268 — 12 November 2026

Disaster recovery checked end to end from a remote backup: a cluster on PostgreSQL 16 with TLS between the databases and to each, the VIP address (VRRP) on and the guard of root's actions on, backed up to SFTP, SCP and SMB 3 at once; both machines lost; one installed from nothing, the backup fetched over SFTP and put back, the second joined - and compared with the cluster at the time of the backup (`tests/r268/t_dr_remote.py`): every row of every table, every setting, each node's configuration, keepalived's and nginx's files, the cluster's authority, the encrypted link, the guard, the local users and their keys, RADIUS on both, the destinations. Two things were not as before; now they are.

Fixed
- **Each node's connection to its own database is encrypted again after a restore**: it lives in the machine's config.json, which a machine installed anew keeps as its own - put back from a backup, or joined to the pair again, the daemons reached their databases encrypted but unchecked (sslmode prefer) where the cluster had verify-full. The wizard now keeps the cluster's wish in the database (`dbtls:want`, in every backup, signed with the guard on); a node whose connection is not as wished moves there by itself - its PostgreSQL's certificate from the link between the databases (or made, without it), the connection tried apart first and moved only when it goes, as the wizard does it; tried again every 10 minutes and said in Events while it does not go. Only towards TLS: the wizard switching it off is the wizard's business; a node the rescue moved back follows the rescue's way back. A cluster set up before, and a backup made before, take the wish from what the nodes had.
- **SELinux enforcing before a restore is said after it**: the mode is the machine's (a restart and a time permissive come before enforcing) and a machine installed anew came up as its system had it - unsaid. What is kept of each machine for the backups now holds SELinux's mode too; a node put back where it was enforcing and is not now gets *To be done by hand* - "SELinux was enforcing on this node before it was put back from a backup", with the steps (make it ready, restart, enforcing) - gone by itself once it is enforcing again.

## 1.0.267 — 9 November 2026

Ready for domain controllers on Windows Server 2025 (otp checked against what they change: LDAP signing, TLS 1.2+, a new certificate on every controller, channel binding, no RC4, no NTLMv1, no SMB1) - [docs/active-directory-2025.md](docs/active-directory-2025.md).

Better
- **A controller asking for LDAP signing is said as such**: a sign-in over plain LDAP refused with result 8 (*strongerAuthRequired*, the default of Windows Server 2025) read "the directory said 8"; now "the domain controller wants a signed or encrypted connection (LDAP signing ...): reach the directory by LDAPS or STARTTLS". Result 13 too.
- **Settings → Directories**: a directory over plain LDAP says that Windows Server 2025 controllers refuse it; a server given by its IP address while the certificate is checked is pointed out - a new controller's certificate usually carries its name only, and the check of the name would refuse it. The security check lists both; `otp --directories` says them too (`--json`: `ip_hosts`).

## 1.0.266 — 8 November 2026

Two fixes found in a real SELinux report from a cluster (AlmaLinux 9.8, both nodes ready for enforcing).

Fixed
- **The SELinux report's `processes.txt` was empty on every node**: it ran `ps -eZo …`, which procps-ng refuses ("can not use output modifiers with user-defined output"), and the refusal was filtered away with the rest. Now `ps -eo label,user,pid,comm,args` - the processes with their SELinux domains; should ps say anything else, that is kept in the file instead of nothing.
- **Settings → High security → SELinux, "What was refused"**: the table ran out of the node's box (on a phone by half its width) - the general rule keeping monospace cells on one line won over the card's own. The refusals wrap inside the box now; on a narrow screen the program and file go under the refusal.

## 1.0.265 — 8 November 2026

SELinux looked at for enforcing, a bug hunt, otp under load over RADIUS and HTTPS - and the system's trusted roots.

New
- **Settings → Certificates and TLS → Trusted roots of the system**: certificate authorities of your own (a root or an intermediate; PEM, a chain, or a DER `.cer`) put into the trust of the operating system of every node - for curl, dnf, LDAPS, SMTP, syslog over TLS and otp's own connections. Added the way the system takes local additions (`/etc/pki/ca-trust/source/anchors` + `update-ca-trust extract`; Debian/Ubuntu `/usr/local/share/ca-certificates` + `update-ca-certificates`): the distribution's list is not touched and keeps coming with `ca-certificates` updates, the two together. Only otp's own `otp-*` files are touched; anything else there is shown read-only. Per node: as wanted / waiting / failed, the system list's size and the package's version. Only certificate authorities are taken (CA:TRUE, allowed to sign certificates), never a private key, at most 50; expired, SHA-1-signed, RSA under 2048 bits or an intermediate without its root are warned of. HA: the wanted set is the cluster's (each node writes its own row, the newest wins; signed by the database guard), each node brings its machine to it after a change, at its start and every half hour. `otp --os-roots`, `--os-roots-add FILE`, `--os-roots-remove FINGERPRINT`; the console lists them. otp's own TLS clients use the system's list (a Python whose OpenSSL looks where there is nothing - `install.sh --python PATH` - is pointed at it at the start).

SELinux (enforcing)
- **The encrypted link between the databases under enforcing**: PostgreSQL may read the cluster's authority (`/etc/pki/otp/ha-ca.pem`, `cert_t`) - RHEL's policy allows it only with an LDAP boolean on, and replication would have stopped. A rule of its own in otp's module.
- **The other node's PostgreSQL port** is labelled `postgresql_port_t` where it is not the usual one (asked by "Put in what otp needs").
- **A node installed without the pages** (`--no-web`) gets otp's module too.

Under load (a new test: `tests/r265/t_load.py` - RADIUS ramp, mixed, challenges, accounting, retransmissions, 100 HTTPS clients, both at once, a 10-minute soak; no wrong answer, no code let in twice, no growth found)
- **Accounting has a database connection of its own**: it waited behind the pages' one - its p99 over a 10-minute soak went from 3.8 s to under 10 ms.
- **The pages' status and counts are kept 5 s** for every tab together (four scans of the tokens and a day of requests on every poll before); a few heavy page requests at once at most - more are told "busy" and asked again, a page never piles requests on the reading connection, the 5 s refresh waits for the one before it.
- **The directory's reading connection is kept and used again** (not opened, bound and closed for every request); its time is measured as the directory's own - this node's own waiting no longer counts as a slow directory, and a refusal for it says "this node is busy" (it said "LDAP server(s) have gone away").
- **Requests that waited longer than 4 s are dropped** (the VPN has given up on them; answering used the code up) and a burst from one place no longer starves the others (a queue per client and realm).
- **RADIUS's receive buffer**: `install.sh` raises `net.core.rmem_max` (a file in `/etc/sysctl.d`), as the daemon (not root) could not get its 8 MB; it says when it got less.
- **`radius_workers` changed** starts or stops workers at once.
- **Mail and SMS codes are sent from queues of their own**, and a code that waited longer than it is good for is not sent.
- **The enrolment and administration sign-in** no longer lock out a whole office behind one address after a few typos (per address 50, per name as before).
- **php-fpm**: 24 workers, not 12.
- A database restore checks the free space first; an unsigned request no longer scans the meta table; the user cache of a directory drops its oldest, not everything; a reply that cannot be sent is logged once in 5 minutes, not once a reply; a failure of the API at its start never stops RADIUS; the sign-in protection no longer counts a name with two @ as a guess.
- **Measured** (4 CPUs, SQLite): password + code about 200 sign-ins a second, code only 200-300; with 100 people and admin tabs at the pages as they really ask, RADIUS stays as it is. A flood of pages from 100 clients asking as fast as they can still slows RADIUS - one Python process works both.

## 1.0.264 — 7 November 2026

otp tried against a Cisco FTD (Secure Client) and an Omnissa UAG (Horizon) as their second factor - emulated at the wire (the appliances themselves are not in the test lab): every packet as those boxes send it, every answer's authenticators checked.

- **New: `docs/vpn-testing-ftd-uag.md`** - what to set on the FMC and the UAG, the scenarios to try on the real boxes (right and wrong code, password and code together, the second window with the app, mail and SMS, a recovery code, a locked account, a node down, the group policy, accounting), and for each what otp's Log and Events say and what to look at on the box (`show vpn-sessiondb`, `debug radius all`, `test aaa-server`; UAG's log archive and RADIUS test).
- **The RADIUS timeout recommended for ASA/FTD is 15 s, not 60 s**: otp answers the second window at once and sends the code after it, so a slow mail or SMS gateway never held the answer; 60 s only made the first sign-in after a node went silent wait that long before the other node was asked - longer than Secure Client waits.
- **A name with two @** (UAG's *Name ID suffix* added to a name typed whole: `novak@corpnet.cz@corpnet.cz`) is said as such in the Log - it read "the request carries no User-Name".
- Tests: `tests/r264/t_ftd_uag.py` - two daemons, a mock AD, a slow directory, mail and SMS; FTD flows (password and code together, the second window with app/mail/SMS/recovery codes, retransmissions answered once, a slow directory within FTD's timeout, accounting, the second server of the group) and UAG flows (passcode alone, AD password then challenge, CHAP and MS-CHAP refused with the reason, name forms, repeated attempts and lockout, NAS-IP/NAS-Identifier, an unknown source).

## 1.0.263 — 7 November 2026

The daemon's connection to its own database and the link between the databases (two gaps found in acme, which runs the same code):

- **A connection rescued to no TLS goes back to TLS by itself**: when the daemon's connection to its PostgreSQL stopped because of its TLS (a certificate run out, the authority file not yet rewritten, a PostgreSQL put back without its certificate), it was moved to no TLS - right, it never leaves the machine - but it stayed so until somebody ran the wizard again, even after the link had put its certificate right. Now what it went back from is kept (`dbtls:rescued:NODE`), tried every 10 minutes apart, and moved back as the wizard moves it once it goes ("otp (it works with TLS again)"). Set by hand since (the wizard, or switched off on purpose), it is left as it is. The page says "rescued" after a restart of the daemon too. Under high security nothing is moved, as before.
- **One renewal of the one certificate**: with the database's encryption set up before the link's, its old row made Settings → The database renew PostgreSQL's certificate at the same moment as the link did, with fewer names - the link then made it again ("put right by itself" at every renewal). The database's own renewal now stays out while the link is set on, also while the link's steps run; it takes over when the link is switched off.

## 1.0.262 — 7 November 2026

Bug hunt, three rounds (the whole application, with the HA re-addressing of 1.0.261 looked at again each time, and each round's own fixes looked at again by the next).

HA and re-addressing
- **Split mode "priority": RADIUS kept while the preferred node changes its network**: the other node took the preferred one's silence (its new address not there yet) for a split and stepped aside - with the preferred one rebooting, nobody answered. A node changing its network, or away as planned, is now a reason to stay.
- **A new network is refused while no other node serves** (the other one in maintenance, restoring, stepped aside): both were silent for minutes. Looked at again just before the node goes into maintenance; then it stops with nothing of the network changed.
- **`radius_bind` carried over** to the new IPv6 address (or to all addresses when IPv6 goes off), and from any specific address not kept to all addresses - RADIUS no longer stays unbound after the restart.
- **Two addresses where one starts like the other** (192.168.1.1 and 192.168.1.10) were refused as "one address" - compared whole now.
- **Second IPv4 addresses are kept** when the first one changes (they were dropped), and the other node is told the new address only when replication runs on the one that changed (`ha_address` empty or the old one).
- **Going back after a trial** is no longer refused for an old network whose gateway is outside its subnet (cloud machines with /32): the old network is put back as it was.
- **Shared database (ha_mode shared) with the VIP**: keepalived's peer follows the other node's fresh heartbeat address after it changed its network.
- **Alerts quiet while a node changes its network** (as for maintenance and upgrades): a slow reboot no longer mailed "the replication is down".
- **A machine without a static host name** takes its short name too (the root helper read it as empty).
- **The certificate shown in Settings → Web** is read where root writes it (`OTP_VIP_CERT_DIR`).
- **A new network is refused only when the other node would come back while this one restarts**: alive but in maintenance or stepped aside, or its own new network on trial. A partner gone for good (or a node made standalone) never blocks it.
- **`radius_bind` is rewritten only for an address the change takes away**: a bind on a second interface, the VIP or an address kept is left as it is.
- **Shared database: keepalived's peer is the other node's own HA address** as it publishes it (not the address of its default route); a node that does not publish it keeps `ha_peer`.
- **A VIP of one address family with nodes of the other** (a cluster joined over IPv6 with an IPv4 VIP, or the other way round): the nodes' addresses of the VIP's family are used - root refused the whole web request, for good (no certificates, keepalived or firewall changes).
- **The database's encryption on a cluster whose link was never encrypted**: only the lead node makes the cluster's authority - both made it at once and replication stopped for good.
- **The preferred node of split mode is not changed while the nodes cannot reach each other**: changed on one half only, both could step aside (a mode or an arbiter set on each half is taken as before).
- **A renewal of the link's certificate while the other node was down** no longer stays "failed" for ever: it finishes when the other node answers.
- **`otp --ha-forget`** no longer takes away the maintenance and upgrade rows of a node that is still running.
- **The clock guard** counts the other node as able to take over only when its own clock is right.
- **The daily look for a new version** is made by one node of a replicated cluster (both could write its first row at once and stop replication).
- **Keep after a change that did not move the address** (only the gateway, DNS, the host name or IPv6) no longer takes the node's own line out of the other node's `pg_hba.conf` - replication broke at its next reconnect.
- **A daemon restarted in the middle of a network change** puts back what it had changed (`radius_bind`, the database's address, the web certificate) - the job failed, but the settings stayed on the new address.
- **The order of a network change in a cluster**: the node goes into maintenance and the VIP leaves it before the other node is told the new address (keepalived was rewritten on both while this node still held the VIP). `radius_bind` takes its new value only once root has taken the new network.
- **A trial not kept in time waits to go back** (at most 30 minutes) while the other node is out of service, so the two are not down at once; the other node is told the address back by itself once it is reached again.
- **Shared database with an empty `ha_mode`** (clusters from before 1.0.213): the node is taken out of maintenance after its network change.
- **Replication over IPv6**: a change of that IPv6 address is refused with what to do (it was not told to the other node).
- **`ha_address` as a host name** that names the old address: the other node is told again, as in 1.0.261.
- **The split card can be saved while the nodes are apart** when its rule itself is not changed.
- **Power off, restart and OS updates of named nodes** take a list of names only: a name given as text was matched by its letters (`otp2` took in `otp` too).
- **"Not heard from" is not mailed** for a node in maintenance, changing its network or restarting as asked.

Security
- **Passkeys**: an RSA key of more than 8192 bits or with a large exponent is refused (one sign-in with it held the daemon - RADIUS too - for minutes). A passkey is added only within 15 minutes of the second step given, not on the sign-in's cookie alone.
- **The enrolment pages: a code sent to the old token is proof only while its codes go to the same place** - an administrator sending them elsewhere (a phone stolen) now ends what the code sent to the old place could do. A replacement of the token is taken by one request only (two tabs replaced the key twice).
- **Configuration import "exactly the file"** no longer lowers high security's settings by dropping them to their defaults; a node's own setting refused in an import is said, not left out silently.
- **The enrolment pages in a cluster of two versions**: the proof from the old token is kept in both forms, so a code sent by one version is taken by the other.
- **Passkeys**: Your account says beforehand that a passkey is added within 15 minutes of signing in.
- **Accounts from the directory**: their role and password are refused (they came back from the directory's groups within minutes); "the last full administrator" counts them only while the directory they sign in through is set up.
- **Read-only administrators** no longer see the access lists and trusted balancers in High availability's load balancer card.
- **A remote backup fetched back** is downloaded only where token keys may be shown (`admin_show_key`), as one made now.
- **To be done by hand under the database guard**: the commands shown to run as root are written by the reading node from its own entries, never taken from a row of the database; an entry of a newer node is shown without its command.

RADIUS
- A second-window code typed just after it ran out, and a recovery code while the servers are apart, are no longer counted as guesses against the place; the second window ends at once on this server's own trouble (a key that cannot be opened, a token gone) instead of asking again for a code that can never pass. A password ending in digits no longer counts towards stopping the person's recovery codes.

The rest
- **The load balancer's guides keep one person on one node** (source address or cookie persistence): the enrolment page's sign-in is kept on the node that made it until it is copied to the other. The Apache guide no longer asks `/healthz` on the balancer's port (it is not served there, every node was taken out).
- **Ports that cannot work are refused**: the API's port on a database's or another service's port, a RADIUS port on SNMP's or the SSH gate's - the next restart stopped the daemon in a loop. An API that cannot listen is said and tried again every 30 s; RADIUS answers on.
- **Alerts of events in a replicated cluster** are read per node: the quieter node's events were missed.
- **A remote backup restored from the pages** binds the tokens and keeps the names as every other restore does.
- **The balancer's port on the nodes (`web_proxy_port`)** is refused when it is the port of something else (the API, the databases, RADIUS, the SSH gate, 5432/3306) or already in use, and SELinux is asked to label it as a web port where it is not 80/443/8443.
- **`otp --acme-order`** waits for the machine's full DNS name instead of using the short one (and marking the certificate as ACME's on the way).
- **The console** has To be done by hand in Upgrades: show, mark one done, clear "done lately". `otp --after-clear` clears all of "done lately", not only the 20 lines shown.
- **The load balancer's port on an SELinux enforcing node**: labelled for nginx before it is written, and a reload nginx did not take (or a port nobody listens on after it) is said as failed, with nginx put back - it was "done" and nginx kept its old configuration. `install.sh --upgrade` labels it too and no longer stops on a failed nginx restart.
- **A failed upgrade from the pages on a node alone** puts it back in service (it stayed in maintenance and RADIUS answered nobody); in a cluster with another node serving, as before. The upgrade's check also looks that the API listens.
- **Going back below 1.0.259** is refused while the balancer has its own port on the nodes.
- **A realm taken into another** is refused when one keeps its tokens under the part before the @ and the other under the whole name: its people's tokens would not be found any more.
- **Long lists of the pages** (enrolment, overview, codes) are read on the reading connection; the enrolment list without dates asked shows the last 30 days (All shows everything).
- **An API that could listen but not start** closes its port and is tried again with the reason said.
- **The nightly copy's check** with no active tokens to try is no longer "cannot be restored".
- **Settings → Upgrades: "What changed" for a package sent** is there again - from 1.0.253 to 1.0.261 the package carried this list as it was at 1.0.252, so a new version had no section in it and nothing was shown. It now shows every version between the one running and the one sent ("What changed since 1.0.259"), not only the newest.
- **This file in the package** is the whole history again: from 1.0.253 to 1.0.261 the package carried the list as it was at 1.0.252.

## 1.0.261 — 7 November 2026

The re-addressing of a node from the pages, tried in every way: IPv4 and dual stack, the link
between the databases encrypted or not, each node's connection to its own database encrypted or
not, node A, node B and both - with the VIP address (VRRP) and RADIUS through it all the while.

- **A node's new address from the pages, with a short host name**: Settings → Network → Change it and restart, with the host name left as the machine has it (`otp1`, not `otp1.example.cz`), was refused by the root helper ("the host name is the whole name") after the other node had been told the new address; it was put back, but the change could never be made. Root now takes a short name when it is the one the machine has; a new short name is still refused.
- **A planned change is not a failure**: while a node changes its network or restarts as asked, the other node says its silence and the replication from it stopping meanwhile as expected (warn, "expected while … is changing its network"), and maintenance is no longer said as the node "not healthy" with level bad - none of it mailed as a failure any more. Unplanned, as before.
- **Dual stack: the node's own certificate made again for the new IPv6 address**: a node's self-signed certificate named the old IPv6 address beside the new one after its addresses changed; the old one is now replaced (taken out when IPv6 is switched off), addresses compared whatever way they are written.
- **"The certificate nginx has … is not the one saved"** no longer said after every certificate made again where root puts the certificates elsewhere (`OTP_VIP_CERT_DIR`): the daemon looks where root writes them.

## 1.0.260 — 6 November 2026

- **To be done by hand → Done lately → Clear** (Settings → Upgrades): a Clear in the heading of Done lately empties the list the page shows - exactly its lines, so one come meanwhile stays; what is still to be done is never touched (the Done marks stay as they hold). With nothing in it, Done lately is not drawn at all - no heading, no Clear. Said in the events (who, how many); `otp --after-clear` on the command line. Both nodes: each writes the lines it cleared in its own row (`after:cleared:NODE`), every node's read together.

## 1.0.259 — 6 November 2026

The load balancer's guides publish the enrolment pages alone, at L7 or L4; the administration's
second step by e-mail or SMS sends its first code by itself and counts down to the next.

- **Only the enrolment pages through the balancer**: every configuration lets an exact list of the portal's paths through and answers 404 to everything else - the administration, /metrics, /healthz - so neither //admin/ nor /assets/../admin/ gets past (the guides before 1.0.259 passed everything on, the administration with it - look at a balancer set up by them). The client's address is put in, never added to; the client's X-Otp-Sso-Key and X-Otp-Restore are taken away; TLS 1.2 and 1.3, HSTS, the portal's 8 MB and 130 s. The sign-in by the balancer's guides do the same (they blocked /admin as a prefix).
- **The load balancer, L7 or L4** (Settings → High availability → The load balancer): a Layer switch - TLS ended on the balancer with X-Forwarded-For, TLS passed through with the PROXY protocol, or passed through with no client address (not advised) - for HAProxy, nginx, the F5 and the NetScaler (Apache L7 only). The address the balancer comes from is its own field; the settings line, the notes and the checks (/admin/ through the balancer must be 404) follow it.
- **The nodes' own port for the balancer** (`web_proxy_port`, Firewall and access → Behind a load balancer or WAF; 0 = none, as before): a server of its own on each node with the enrolment pages alone, the X-Forwarded-For or the PROXY protocol believed there from the balancers alone (`web_proxy_header=proxy_protocol`, only with the port), the firewall opening it to them alone. 443 stays as it was.
- **Fixed in the generated configurations**: the F5 monitors (`recv "ok "`, asked on 443), the ASA's `reactivation-mode depletion deadtime 1`, HAProxy's missing timeouts; the RADIUS secret field is gone - always `<the shared secret>`. The page warns when the administration is reachable from the balancer, when the balancer may not ask /healthz, and when the firewall is not otp's.
- **The performance meter: no second missing** - a page asking a moment before the sampler read the counters made the sampler find them unchanged, and that second was left out of the graph; the page takes the sampler's last reading while it reads.
- **The administration's second step by e-mail or SMS**: the first code goes by itself when the step is shown (once a sign-in - F5 sends nothing again and says how long the code is still good for); "Send another" counts down to the next one allowed (30 s) and says how many more may go (5 a sign-in); at the fifth the button itself becomes Sign in again and the note says why. The API says it all in `send` (GET, send, enrol_start and both 429s).

## 1.0.258 — 6 November 2026

To be done by hand: one place for what an update cannot do itself.

- **Settings → Upgrades → To be done by hand**: what an update cannot do itself - a step as root on the command line, what the installer left (SELinux, the firewall, a package) - as one band a thing and a node: what and why, the command in a box with Copy, when it was first seen; Look again (this node at once, the other within a minute) and Done (for what otp cannot check; for what it can, marked by hand and written in the events). DONE LATELY: what, how (done, by itself, taken back), who, when. With nothing to do, "Nothing is to be done by hand."
- **The count beside Upgrades** in the settings menu and on the Settings tab - red for a bad one, amber otherwise. Nothing else at the top of the pages changes.
- **What there is to do, checked by each node itself**: otp newer than the parts root installs (copied by hand, an install.sh --upgrade that stopped half way), upgrades from the pages not installed, nginx refusing the additions or the upload guard, SELinux's module not the one of this version, SELinux refusing otp something (never "switch it off"), PHP without the php2shell fix, no firewall opened at the install. A new version adds one entry and every place says it.
- **install.sh writes /usr/local/lib/otp/root-facts.json** (root's, readable, no secret): which version put the root parts in, what nginx, SELinux and the firewall made of it - before the daemon starts; at its end it says what is still to be done by hand.
- **The performance meter, the other node** (a cluster): its panel shows its own cores, disks,
  filesystems, cards and processes, as this node's, under its name - asked of it through its row
  only while that panel is open (it said "shown on its own pages").
- **Both nodes' graphs together**: the other node's readings reach the page up to 12 s after they
  were read (its row every 5 s, this node reading it every 5 s, the page asking every 2 s) - the
  right edge of both graphs now stands 14 s back, and the other node's graph no longer grows by
  jumps at the edge.
- **No holes while the page is behind other tabs**: it goes on asking every 30 s (drawing nothing),
  and the daemons go on reading for 75 s after each ask - a browser lets a page in the background
  ask once a minute only. Back in front, the graphs are whole. A page closed: both nodes stop
  within 75 s (10 s for one in front, as before).
- **The alerts mail them** (An upgrade of otp, in Czech and English); `otp --after` (`--json`), `otp --after-done ID [--node N]`; a line in `otp --status` and `otp --check` (which fails on a bad one); the console's first screen. Both nodes: each writes its own row; RADIUS never waits for any of it.

## 1.0.257 — 6 November 2026

Your account lists the passkeys of the account; the performance meter draws a cluster's nodes in
rows, on one time.

- **Your account → Passkeys - Face ID, Touch ID** (the administration's pages, while the second
  step by a passkey is on and it is this account's): a table of the account's passkeys - the
  device, the name of the pages it is for, when it was added and last used. The pencil names one
  in its row (Enter saves, Escape leaves it), the bin takes one away (asked twice, as everything
  that destroys); the last one cannot be - it is the second step itself, reset by another full
  administrator. **Add a passkey of this device** adds another (an iPhone beside the iPad, a
  second Windows computer), up to 10: by an address, or while a node runs a version before
  1.0.254, the page says why it cannot. Every passkey of the account signs in. Both nodes: the
  question kept with the sign-in, the passkeys in the account's own row. In the events.
- **The performance meter in a cluster**: the nodes one under the other, a row each with its
  name, the same four chips in the same places - as acme draws them - and no more hidden for want
  of room than a single node's.
- **Both nodes' graphs on one time**: this node's right edge stood 3.5 s back, the other's 10 s,
  so the same moment was 6.5 s apart in the two graphs; both now 10 s, moving together.
- **The numbers at once when a page looks again**: the other node's last numbers are shown while
  it wakes up to the page (it was "does not answer", with dashes, for the first seconds of every
  look); a node that does not answer keeps its last numbers, dimmed.

## 1.0.256 — 6 November 2026

The third round of looking for faults (the tokens and their files, the cluster's rows, the
administration's panes), each put right.

- An exported .totp file names its owner inside (`" OTP_NAME`); an import refuses an entry of a locked ZIP whose file name says another owner, since in a locked ZIP the names of the files are not locked - a renamed entry gave one person's key to another's token. Files not locked are imported by their names as before (renamed on purpose, into a realm); exports of earlier versions as before too, with a word that the owner is read from the file name only.
- Token names cannot be switched from "as typed" back to small letters while tokens named with capitals are there (Settings, the command line and a configuration import): they would have been found by nobody. Rename them first - the token's window - Move to now takes a change of letters alone.
- Two nodes: the waiting recovery codes and the name of a token changed alone could be put back by the other node's older row; they are now stamped with the key.
- The database download with the key that opens its tokens is refused where showing the keys of tokens is switched off (and so under high security), as the token exports are.
- Pages: a token administrator is no longer offered what the API refuses them on a token in use - replacing it (New QR code, The app instead), changing where its codes go, taking it away - nor moving a token to another name, which is a full administrator's; a waiting token keeps them all.
- Pages: the "In the directory" buttons are shown only to token and full administrators - a read-only account's press ended in a refusal.
- Accounts: switching an account off asks first; switching off your own account, or changing your own role, asks with a warning that only another full administrator can undo it.
- Test: the test made on this node names it, as on the other one - behind a shared address the test could reach the node that was not asked.
- Database: on a node of a cluster the buttons that move or set up the database stay shut whichever kind is chosen in the list.
- Settings: the dots saying whether both nodes have the settings keep coming back after a failed look (retried after 15 s, 30 s, 60 s, then every 2 min) instead of stopping until the page is opened again.
- Settings: the card "When the nodes lose each other" and "Take my own picture away" are shown to full administrators only.
- Czech: taking a certificate out of the mail server's or the SMS gateway's trust no longer reads "u adresáře"; a few texts that stayed in English (time servers set, tokens left out of an export, a user's SSH key taken away, a group put in a role, the mail queue's "tried until") are in Czech.
- Remote backups: *Download one made now*, which holds the key that opens the tokens, is refused too where showing the keys of tokens is switched off.
- Database: the download "with its key" is shut on the page where showing the keys of tokens is
  switched off, and says why.

## 1.0.255 — 6 November 2026

Two rounds of looking for faults over the whole of otp (RADIUS, the sign-ins and the second step,
the enrolment pages, the cluster, the network, backups, certificates, the command line, the
console and the installer), each put right.

- RADIUS: in a realm where the password is followed by the code, nothing that is not a code is any longer taken off the password - the directory never gets a password cut short (a wrong password counted there, the account locked out in the end) - and a space or line end typed after the code no longer refuses the code.
- RADIUS: a code by mail or SMS, or from the app in the second window, that was right is let in even when the database fails to drop the question or mark the token used afterwards; this is logged, and the VPN's retry is no longer refused as a used code.
- RADIUS: the realm's and the groups' reply is built and measured before the code is used (or sent): a reply that cannot be built, or too long for a packet, is refused without using up the code.
- Sign-in protection: a token key this node cannot open, a directory that could not say whether a name is another account, and an answer to a second window that ran out are no longer counted as guesses from the place they came from.
- Performance meter: a page left open for more than a day keeps its graphs moving (the animation's start is moved to now before its 24 h run ends).
- Performance meter: the chip with the keyboard focus keeps it across the redraw every 2 s, and an open panel keeps its scroll position.
- Performance meter: a node whose clock is stepped back no longer leaves its graphs blank - the page and the daemon (its own history and the other node's) start that node's readings again, and a since later than now is ignored.
- Performance meter: the other node's network rate reads "received ↓ / sent ↑" instead of the generic "down / up" (in Czech it said "nefunguje").
- Performance meter: the previews in My account no longer add tab stops inside their picker buttons.
- Second step by e-mail or SMS: after a reload, or a send refused as too soon, the box for the code is still shown; during setup, a way already sent a code reopens with its box.
- Czech: the load balancer sign-in throttle message and "that request did not come from this page".
- The console's Delete for an account, a client, a realm, a directory and an SSH token works again: the command it ran refused for want of --yes, though the console had asked already.
- An upgrade no longer loses every nginx addition on a machine whose nginx has no auth_request: the admin block's 32 MB limit was taken as missing, a second one was put in, and nginx refused the file.
- otp --acme-order takes the same lease as the pages and the renewals, and looks names up with ACME's DNS servers: ordered while a node renewed it, both spent the CA's limit.
- otp --rbackup-now tries the backup afterwards when rbackup_verify=after, as the pages do, refuses while a backup is being made on this node (--yes over it), and with --rbackup-all asks the other nodes to make theirs too.
- otp --status asks whether the RADIUS ports are listened on with the address family of radius_bind, and only a port in use counts as listened on.
- The installer no longer prints the secret of the test client for 127.0.0.1, nor a radtest command line with it.
- Settings - SSH keys refuses to write an authorized_keys longer than the 1 MiB read of it: the keys past that were dropped.
- Settings - Time recognises the file's own server, pool and other chrony lines separated by tabs or several spaces: they were left in beside otp's block.
- A column added while the daemon runs (tried again after a busy start, or on the other node of a replicated pair) waits only a moment for its table (PostgreSQL 300 ms, MariaDB 1 s) and is tried again later: its 10 s wait held every sign-in queued behind it, and RADIUS failed meanwhile.
- The daemon's main loop no longer waits on the root helper: the link's TLS steps try again at the next pass while a request before them is unread (one left unread for 3 min is written over, as before), and taking the other node's old address out of pg_hba.conf runs in a thread of its own. Up to 90 s there held the heartbeat back, and the other node took this one for gone.
- A rebuild from the other node that fails after the tables were emptied puts the node in maintenance before it leaves the rebuild: for a moment it answered RADIUS from the emptied tables.
- The connection to a database on the same machine goes back to no TLS only after two failures in a row with TLS alone, and never while PostgreSQL is starting, stopping or refusing: a restart of PostgreSQL dropped TLS for good.
- Watching whether the nodes lost each other is timed on the monotonic clock: a clock stepped forward by NTP made a node step aside at once, and one stepped back held off a real split.
- Backups to other machines: the list of backups sent and each destination's last send and Try it are kept per node (`rbackup:runs:NODE`, `rbackup:last:NODE:ID`, `rbackup:tried:NODE:ID`) and read merged. In a cluster one node's write no longer takes away the other's, a destination changed meanwhile is no longer lost, and the row is no longer made by both nodes at once. The list kept by versions before is still read, and is still written while a node of one is in the cluster.
- Backups to other machines: "this node's backup" means this node of this site. Another site's node of the same name is no longer verified, put back or taken as its own. Two nodes whose names give the same backup file name are reported in the alerts, and their old backups are not taken away.
- Backups to other machines: the room check counts PostgreSQL and MariaDB too, by the size of the node's last backup (before the first one, as until now).
- Backups to other machines: trying a destination named on its card works while it is switched off.
- Automatic certificates: right after the start, the renewal check waits for DNS to say the node's full name. A certificate is no longer ordered for the short host name.
- Network: going back from a new network that was not kept is no longer refused on a cluster sharing one database, nor while a restart or power-off is under way. A restart or power-off is refused while a node's new network waits to be kept or is going back.
- Network: search domains and DNS servers are checked as the root helper checks them (no dot at the end, no zone id). When the change stops before the network was touched, the node's settings, config.json and certificate are put back as they were.
- With db_guard on, the marks of the administration's second step in a sign-in are signed too: a sign-in opened with the password alone could no longer be made whole by changing its row in the database (sign-ins opened by 1.0.254 sign in again once while the second step is on; while a node of 1.0.254 is in the cluster, its sign-ins are taken as before).
- With db_guard on, an account whose second step was changed in the database by somebody else (a row otp did not write) is held until it is reset, instead of setting up a new one with the password alone.
- Switching the second step on ended password-only sign-ins only where the database had them at that moment: one opened on the other node before it read the settings again stayed whole. Such sign-ins now give the second step on either node.
- Two requests at once could each send a second-step code past the 30-second gap and the limit per sign-in; the slot is now taken before the code goes and given back if it fails.
- New setting "Its SMS only to a number in these attributes" (portal_first_sms_attr): which directory attributes the one-time code before the first token may be sent to by SMS; empty works as before. Settings shows a warning when the code goes to mobile or telephoneNumber, which every user may change on their own account in Active Directory.
- Lockouts of the one-time code before the first token and of sign-ins by the load balancer are now named on the Locked out page and can be cleared there.
- The sign-in throttle counted a name typed with composed and decomposed accents as two people.
- `/api/portal/me` now runs the same checks as every other step of the enrolment pages: a sign-in by the balancer after SSO was switched off, or one that now needs the one-time code, is ended instead of shown as signed in.
- The second step held (with the guard against writes to the database on) says so on the page,
  with the way out (a reset by another full administrator), instead of offering a way to set up.
- `otp --acme-order` and a renewal by this node's daemon no longer order the same certificate
  together: the daemon leaves a name the command line holds.

## 1.0.254 — 6 November 2026

A passkey (Face ID, Touch ID, Windows Hello) as the second step of the administration, and an
icon for a shortcut on a home screen.

- **Settings → Accounts → "...with Face ID, Touch ID or Windows Hello (a passkey)"** (off by
  default), beside the app, e-mail and SMS: the second step of signing in to these pages, never
  instead of the password - the password is always asked first. An account sets it up at its
  first sign-in, as e-mail and SMS are; more ways allowed, it chooses. A full administrator
  resets it as the others (Accounts, or `otp --reset-2fa NAME`); the account sets one up again.
  Accounts shows "a passkey", of which device for which name of the pages.
- **The checks of the server**: ES256, RS256 and EdDSA signatures checked by otp itself (no
  library, nothing run); the question used once, on either node of a cluster; the origin and the
  name of the pages checked; the device must check who it is (the face, a finger, the PIN); its
  counter may not go back (a copied passkey refused, said in the events); wrong answers counted
  as wrong codes are. No attestation asked: the server keeps only the public half.
- **A passkey is for a name**: offered on these pages opened by a name over HTTPS
  (`https://otp.firma.cz/`); opened by an address it is not offered, and the page says why. Set
  up for one name, it works on that name.
- **Both nodes**: the question kept with the sign-in, so one node asks and the other takes the
  answer.
- **Older versions do not know a passkey** (they read it as no second step set up, and the
  password alone would set up another): no passkey is offered or set up while another node of
  the cluster runs a version before 1.0.254 (the page says which), and going back below 1.0.254
  is refused while an account signs in with one (reset its second step first). With the guard
  against writes to the database on, the setting is signed as its siblings are. A browser answer
  nested too deep is a wrong answer, not an error of the server.
- **The icon of a shortcut on an iPad's or iPhone's home screen** (Safari → Share → Add to Home
  Screen): the shield, 180 × 180, with the name of the installation under it.
  `/apple-touch-icon.png` answers (nginx, added to an existing configuration on update).

## 1.0.253 — 5 November 2026

The performance meter (from the server-load package), off until switched on.

- **Settings → About → The performance meter in the header** (off by default): how busy the
  server is - the processor, the memory, the disks and the network - beside the state at the top
  of every page, for full administrators. Pointed at (or tapped), each part opens its details:
  each core with its frequency and temperature, the disks and the filesystems, the network
  cards, the processes taking most. Off, nothing is read or written for it on any node, and the
  pages ask nothing.
- **Smooth graphs**: the daemon reads once a second, at an even pace, only while a page looks
  (it stops 10 s after the last ask); the graphs are drawn by the time of each reading and moved
  on by one CSS animation each - nothing redrawn by a timer, no jump when a panel opens or two
  tabs ask. A time nobody looked stays empty. **F5** draws the last two and a half minutes at
  once.
- **Both nodes of a cluster**, each in a group with its name: one small row of meta for each
  node (`load:<node>`), written every 5 s only while a page looks - its readings of a second
  each, so the other node's graph is as smooth. A page closed: both nodes stop within 45 s.
  The other node's panel shows its numbers and its two minutes; its cores, disks and processes
  on its own pages. A node not heard is said so. Standalone: no row.
- **The looks**, chosen by each administrator under the account's name (kept with the account,
  in the settings file too): graphs, pills, one line, rings or not shown; the details as tiles,
  a table, a map of the cores, one wide panel or a short tip. What fits the header is shown at
  each width.
- Temperatures from every sensor the kernel reads (coretemp, k10temp, drivetemp...), each core
  with its own (physical package and core id); filesystems of the kernel only (no FUSE, NFS,
  CIFS or FAT - a hung mount never stalls the page).
- Czech: every text of the meter.

## 1.0.252 — 5 November 2026

Three rounds of looking for bugs and security holes, in HA, standalone, the root helper, the pages
and the installer.

Security
- **Uninstall and installer**: `install.sh` never put `acme.php` and `metrics.php` in: every ACME
  HTTP-01 order and every Prometheus scrape got 404. Both are put in now. An uninstall with SSH
  passwords off no longer lets the Unix password in through keyboard-interactive (otp's PAM block
  is gone); where a key and then the code is asked, it is left as it was.
- **The root helper**: `pg_hba.conf` is changed only when it is a file of the account postgres -
  whatever answered on PostgreSQL's socket named the file root rewrote. The machine's keep of
  `authorized_keys` is capped (too big, nobody's users or keys were put back after a restore).
  Security keys (`sk-ssh-ed25519`, `sk-ecdsa`) are read: they were refused, never dropped and not
  counted as root's keys.
- **The administrators' second step**: five wrong codes end the sign-in, the password is asked
  again (only the throttle held in memory counted). Switching the second step on ends the other
  sign-ins again - it ended none since the settings were read after the check.
- **The enrolment pages**: a code sent to the old token is proof only for that token - replaced by
  an administrator meanwhile, it took over the new one. Codes counted as sent when nothing went
  (the mail or SMS server away) are given back.
- **High security** is not switched on while a change is on trial (the firewall, SSH) - what came
  back by itself was never looked at. `otp --selinux permissive` is refused under high security,
  as on the pages. The database guard reads the settings through it at the start and on the
  command line too: unsigned rows were taken until the first change of a setting.
- **Backups**: the first pin of an FTPS certificate over another check asks for the saved password
  again; a download or an upload looks for room on the disk first.
- `DOWNGRADE_FLOOR` is 1.0.252.

HA and standalone
- A **Back up now** of the other node was started again and again (its done list was cut by sorted
  order, not by age).
- **Database guard**: guard.json counted as there once written (a warning a minute, and the
  version's rows never taken in); an older node counted in a cluster with no `ha_mode`; otp's own
  `fw_trial_back` claimed signed (it raised a tamper alert at every firewall trial run out).
- **A cluster of one shared database** made from the pages or the command line makes each node's
  own settings `key@node` (RADIUS address and ports, mail HELO...): the second node bound the
  first one's address. A second bundle with another address of the other node puts it in; a join
  under the first node's own name is refused; a node alone again can change its own settings (its
  row of the cluster before hid every save).
- `--ha-renamed` refuses a node answering now; a node forgotten on the pages drops its maintenance
  and upgrade rows when it does not answer; the joining address is let in only until the node has
  joined.
- Asks written by a node renamed or taken out are taken away too.
- **Updates of the system**: stopped while a node was out of service, it comes back; a restart
  after an update that failed later ends the update (the node stayed "restarting" in maintenance,
  everything else refused) and is said as a bad event; a maintenance set by hand is kept.
- **Upgrades of otp**: a maintenance left by an upgrade that failed is no hand maintenance (sent
  again, it ended "back in service" with the node still out); not started beside an update of the
  system, a network change or a restart.
- **Time**: "Set this node's clock now" of the other node is an ask by its value, not a time set
  against that node's clock (a clock 5 minutes ahead never took it).
- **Database**: a column that could not be added at the start (another node's pg_dump holding the
  table) is tried again while the daemon runs; MariaDB's OPTIMIZE and CHECK TABLE are no longer cut
  at 300 s; a realm is 190 characters at most on MariaDB (its column).
- Logs: the encryption of the link between the databases, and housekeeping errors that are not the
  database's, spared (a line every 5 s); SIGHUP takes config.json as read only once read; work
  folders left by a restart (the verify's, uploads, restores, the MariaDB dump) taken away.
- Alerts: scheduled updates and restarts that did not start, an SSH change refused, a restart after
  an update that failed.

Pages
- Settings → SSH server and the split card take the saved wish again while nothing waits to be
  saved; the password policy says a draft is not saved, and takes the saved one again when
  untouched. Clear puts each time picker to its own default (Events: all time). The lockouts'
  countdown goes on after the browser tab was hidden. The SELinux report is waited for by each
  node's own clock.
- The Overview's "Refused, last 24 h" counts sign-ins only, as the line under it.
- Accessibility: switches named by their words; the password policy's boxes named by their labels;
  Czech help with markup read out in Czech.
- Czech: e-mail addresses and host names in a text no longer keep it English ("A mail to…"); the
  RADIUS reasons and every new text.

## 1.0.251 — 5 November 2026

- **Settings → Local users → Password policy**: every setting has an (i) - what it does, which
  file or PAM module holds it, its name on the command line (`otp --local-policy-set KEY=…`) and
  its built-in default; on the switches too, a click on the (i) does not switch them. English and
  Czech.
- **A cluster upgraded one node at a time, with the database guard on**: a node of a version before
  counts while it was heard from within a day, not only while it is alive - one restarting, or put
  back after an upgrade that failed, had the new version's rows taken in meanwhile, and what it
  wrote once back was refused for ever. Switching the guard on asks the same.
- **Asks for nodes no longer of the cluster** (local users, SSH keys, OS updates, Back up now):
  each node takes away its own asks for a node missing from the list for an hour - the asks of the
  local users held sealed hashes of passwords, kept in the database for ever.
- **The guard's list of refused rows**: a row of meta (an ask, a job) refused and taken away since
  is no longer listed - it stayed lit until the next start. A setting, an account or a directory
  taken away stays listed: that is itself what the guard is there for.
- **Values inside a row of another shape** (a string or a list where an object belongs - a key a
  version before kept as another type): read as nothing in every place (106) instead of raising
  at `.get()`.

## 1.0.250 — 5 November 2026

- **A cluster upgraded one node at a time, with the database guard on**: the rows signed only since a
  version (the backups' destinations and their password, a Back up now asked of the other node, the
  DNS of ACME) are taken as before it while a node of a version before is seen alive by its signed
  heartbeat - it writes them unsigned - and signed once as they are when every node runs it. Until
  now they were signed at the node's first start, and what the other node wrote after was refused
  for good.
- **A Back up now asked by the other node** and refused, done or never fetched no longer stays: an
  ask past its time is not looked at (it was refused again at every tick, an error in the log every
  ten minutes for as long as it was there), and the node that asked takes its own old asks away.
- **Rows of another shape are put right, not raised at every tick**: a row of the database or an
  answer of the root helper that is not of the shape otp writes (written by a version before, an
  error's words, somebody's hand) is taken as none - read again and written right at the next tick.
  Before, many a tick raised before it wrote its row again, the same warning for ever: the local
  users and the password policy of a node, its own heartbeat (it beat no more, and the other took
  it for gone), the outgoing mail (no mail went out at all, a code by mail neither), the SSH gate,
  an ACME order's lease (the certificate was never renewed), the cluster's authority, the SNMP
  traps, the backups' destinations and history, SSH keys' and updates' asks, the size of the
  database, the tuning of the database. The status of the pages and the page of upgrades no longer
  answer with an error for a package's row of another shape.
- **The root helper's answer is taken only as an object**: an answer of another shape (a helper of
  another version during an upgrade) is an error that says so, never kept as the node's state.
- **A warning of a periodic task says where it broke** when the fault is in otp's own code
  (`[at otp.py:LINE in FUNCTION]`) - the words of an error otp means to say are left as they are.

## 1.0.249 — 5 November 2026

- **SELinux after the upgrade from a version before 1.0.248 is said**: when otp's needs were last
  put in is kept in root's folder since 1.0.248, the old note in otp's own is not read - what SELinux
  refused since the machine started is counted again, also what was put right long ago. The
  installer says so at the upgrade, and Settings - High security - SELinux and `otp --selinux-check`
  say it beside the count: not new refusals, gone at the next restart of the machine.
  Said once: at the next restart of the machine what is counted is new again.
- **Security - signed rows of the database**: every row the guard signs is taken away with the
  signature of its going (an SSH token removed, an administrator's second step reset, an acme
  unpaired, a certificate forgotten - 41 places): with plain SQL its last value put back by somebody
  with the database was taken as signed still. Switching the guard on while the service runs leaves
  nothing for the next start to take as otp's word; a node joining a shared database starts its
  counts again whatever the cluster's guard; the guard's file stays the service's when root writes it.
- **Security - the root helper**: the certificate files of PostgreSQL read before a change are never
  read through a link (put back after a change that did not take, a link to /etc/shadow became a
  file postgres could read); a FIFO in place of the policy's old note no longer holds the helper; a
  kept user's shell outside /etc/shells only as the exact no-login paths; the console notice put back
  after a trial keeps its backslashes as they were.
- **Security - the command line as root**: `otp --ha-resync` makes its copy as the otp account (the
  folder of the copies is that account's, which could make it a link); config.json is never read
  through a link; `otp --enroll CORP\novak` refused, as the pages refuse it; a file to export into is
  emptied only when written; the installer takes `--admin-password -` (from the terminal) or
  OTP_ADMIN_PASSWORD - a value on its command line still works, said.
- **Security - sign-in**: `x1\CORP\novak`, `x2\CORP\novak`... counted apart while the directory was
  asked for novak - now counted as novak; a token's name that more than one account of the directory
  answers to is refused; an administrator making a token under an alias suffix is refused when the
  directory cannot say whose the main name is, or when it is somebody else's.
- **Security - saved passwords**: the check of an FTPS destination switched off or changed, or old
  TLS allowed for a directory, asks for the password again, as another server does.
- **Behind a balancer**: a download with its key, or a file sent to be put back, that waits on the
  other node says which node to open.
- **Local users**: sudo without a password refused for every way in (the console, the API), as the
  page refused it; what could not be put back is held for its week across restarts of otp too, and
  when the kept row cannot be opened; a copy's putback row is never put back.
- **A ZIP of .totp files not locked** says so beside what was imported.
- **Security - going back to an older version**: the oldest version this one goes back to is now
  1.0.249 - the root helper's holes fixed in 1.0.248 and 1.0.249 came back with an older one, and
  the otp account could ask root for one.
- **Security - backups**: a backup into a folder is written under a name nobody knows, never through
  a link (a writer of the share overwrote the token key with it); the retention never takes away the
  backup just sent, nor counts one stamped ahead of the clock; another host key trusted, a host key
  forgotten, or another certificate pinned forgets the saved password with it - typed again for the
  server it is.
- **Security - the cluster**: the database and account in config.json are never PostgreSQL's own
  (postgres, template0/1, a superuser) when root sets up or joins a cluster - the otp account could
  have made root give the superuser a password it chose and let it in from the network; TLS between
  the databases is not switched off while high security is on (from the command line neither), nor
  SELinux switched to permissive; a node joining a cluster on the command line keeps a copy of what it
  held first, refuses the first node's own name, and `otp --ha-setup` is refused on the second node
  (both became the first, and replication stopped); a rebuild that fails on the command line leaves the
  node in maintenance, as the pages' does.
- **Security - the enrolment pages**: after the one-time code a sign-in of its own begins, the one the
  password opened is ended (a cookie planted before had the person's enrolment) - as the
  administrators' second step since 1.0.149. Port 80 refuses multipart bodies too.
- **Security - the root helper**: a user's own child working on their SSH keys has 30 s (a user
  could stop it and hold every ask of the helper); the replication password is never handed on from
  PostgreSQL's log; the OS updates' progress written best effort, and the package manager always
  waited for.
- **Security - more**: an administrator making a token while the directory cannot say whether the
  person has one under another name is refused; tokens imported with a step other than 30 s keep
  their last step; a name ending in a dot after its realm is refused, as RADIUS reads it without; an
  expired second (ECDSA) certificate is refused on upload and on the put back of the one from before
  ACME (which now keeps its second one); the console never sends a control sequence of the data to
  the terminal; settings checked without their spaces are kept so (a metrics token pasted with one
  never matched).
- **The network on trial** goes back by itself also when the database is on another machine the new
  network cut this node off from (a note of it kept on the machine, acted on when the database cannot
  be read).
- **Alerts and monitoring**: "Look again" while a mail was on its way no longer mails the same twice;
  events and "right again" notices are kept while a failed mail is waited out; SNMP traps say no
  "right again" during maintenance, and "traps do not go" ends once they go again (and only while traps
  are on); the alert of replication behind works; isemon's and SIEM's trouble of a target taken away
  ends with it; the report's days follow the local midnights across a change of summer time; the SNMP
  test works with an IPv6 address.
- **The database**: MariaDB's driver no longer cuts a statement of minutes at 130 s; a transaction
  that failed at its start no longer leaves the lane writing one statement at a time; a change made on
  the other node is no longer lost when one is saved here at the same moment.
- **Local users and their policy**: a password good for 0 days is refused (an empty box made every
  password run out at once); the boxes are named in the messages.
- **The command line**: what a console user does through sudo is in Events as theirs everywhere; the
  files to export into are no longer refused for root's own folder.
- **The API**: an id sent as true is refused (`{"id": true}` deleted row 1 - the localhost client); a
  damaged locked ZIP says so instead of "it broke"; the test of RADIUS with the localhost client's
  secret goes only to this server's own port; a realm's suffix is 253 characters at most.
- **The pages**: Trust it in a new backup destination no longer makes a second one; forgetting a host
  key says the password goes with it; the firewall's "not saved" no longer stays after saving;
  clearing blocked sources says how many were cleared.
- **The pages**: a change made while its card was being saved stays unsaved (it was counted as
  saved); the account pickers of SSH server no longer pile up a listener every redraw; Czech words for
  what was left English (Database - Move in a cluster, the balancer's note, OS updates, Settings on
  every node, High security's popup, ACME's certificate before).

## 1.0.248 — 4 November 2026

**Fixes from a review of the code (security and bugs), three rounds.**

- **Security - the remote backups under the guard of root's actions.** Their destinations, their
  password and their schedule were rows nobody had to sign: with `db_guard` on, somebody who could
  write the database could add a destination of their own and have every backup sent there - with
  secrets.key in it, the key of the guard itself. They are signed now; the rows written by the
  versions before are signed once, as they are, at the first start of this version (in Events).
- **Security - the local users' root helper:**
  - putting back what a backup kept of the machine gives keys only to a normal user of this machine
    of the same name and UID - never to an account of the system that has a kept user's name;
    key lines with options before the key are left out (said - put those in by hand);
  - which features of authselect otp switched on is kept in a folder of root's
    (`/var/lib/otp-root`), not in the service's own - and only otp's two are ever switched off;
  - a kept row of the machine that was never sealed is not opened;
  - a user's own authorized_keys of thousands of lines no longer keeps the helper busy.
  - a local user made by two asks at once (the same one sent twice) is said as there already, not as
    a failure of the second.
- **Security - sign-in through the load balancer:** requests from anywhere naming somebody counted
  against that person before the balancer and its key were checked - twenty of them kept their
  sign-in refused for a quarter of an hour. Counted per address until the balancer is known.
- **A backup put back from the pages** (or from the command line while the service runs) puts back
  the machine's own within a minute - within the hour the machine as it was had been kept over it,
  and nothing was put back. Only on a machine installed anew (no tokens of its own): on a machine in
  use, its users and keys are left as they are - a key taken away since the backup came back
  otherwise.
- **The putback**: one user that cannot be made (a group of that name there, say) no longer stops the
  others, root's keys and SELinux's booleans; a putback that fails is tried again in 10 and 20 minutes
  (it was at every tick), then given up and said in Events; its row is taken away with its signature.
- **Joining a cluster of one shared database** takes the guard of root's actions as the cluster has
  it, and puts back what the cluster kept of the machine - only the replicated join did.
- **`otp --ha-resync` and `otp --ha-join` (replicated)** start the guard's counts again, as the pages'
  rebuild does - rows of the other node were refused as older ones put back.
- **Local users:**
  - "make it on B too" gives the user the UID it has on A (it took the lowest free one of B - another
    user's UID on A); two users added within seconds no longer get the same UID;
  - an add sent to a node where the user is already there changes nothing of theirs - it took away
    sudo and set a new password there;
  - "must change at the next sign-in" only for a user with a password - a user of a key only was
    asked at every sign-in for a password never given;
  - unlock takes away every `!` (`passwd -l` on RHEL writes two);
  - saving the full name again keeps its other fields (room, telephone); a shell the user has, not
    of /etc/shells (`/bin/false`), no longer refuses a change of the name;
  - `otp --local-policy-set dictcheck=0` (and `usercheck=0`, `existing=0`) switches it off - `0`
    was taken as yes;
  - `otp --local-users`, `--local-user` and the console wait for each node's list asked, not for the
    old one;
  - one worker of the local users at a time, however long it takes.
- **Settings in a cluster:** a node not heard from for a day is no longer shown red on every card;
  a cluster of one shared database shows its pill; "Ask again" asks at most once in a few seconds.
- **SELinux:** "Look again" or a report no longer put aside a step asked and not done yet (making
  ready, enforcing) - it never happened, and nothing said so.
- **The firewall managed by otp, behind a load balancer**: the balancers' networks are let in to the
  pages too - nginx checks the client's address they forward, the firewall sees theirs.
- **The pages:** the SNMP card and the pill of Settings shared one variable - the SNMP card was drawn
  from the wrong data after a while; the colour of the database card no longer opens the next popup
  of something else when its own was closed before its answer.
- **Security - a second token by a name spelled twice:** `A\B\novak` came through as `B\novak@realm`,
  the form refused since 1.0.101 - the directory found novak, the token was another one, enrolled by
  whoever had the password before novak did. Refused.
- **Security - certificates from acme:** a paired acme's key read from the database without the
  guard's signature - with `db_guard` on, a key put in by somebody who can write the database could
  push the pages' certificate. Signed keys only.
- **Security - the root helper:**
  - the SELinux report written by the folder's descriptor, never by its path (a link put in place of
    the service's folder had root write it anywhere); when otp's needs were last put in, kept in
    root's folder - a time ahead written there hid every refusal from the check before enforcing;
  - the balancers' networks for nginx refused with a scope id (`fe80::%x;...`) - lines of nginx's
    configuration could be put in that way;
  - the TLS of the database never lets PostgreSQL's superuser (or its own databases) in from the
    network;
  - a port for SSH that SELinux has for something else (8080) is made sshd's, or refused - taken as
    done, sshd could not listen there and SSH was down;
  - the firewall is put in even when nginx or keepalived refuses a step - a trial's rules put back
    never reached iptables;
  - a network profile of /run going back after a trial: its settings put back one by one too (the
    reboot kept the change's copy in /etc);
  - chrony.conf put back as it was when chronyd will not start on the new one.
- **Security - the pages:** a test of a sign-in (RADIUS test, directory try) counted per person again
  whatever comes before the name (`a1>CORP\novak`, `a2>...` were a fresh count each); with
  `portal_show_secret` off, the key no longer goes to the enrolment page in the `otpauth://` address
  either; the PHP side no longer takes a session or a header with a line end after it.
- **Security - SIEM:** no control character anywhere in a line sent (a name with a line break forged
  an event in the RFC 5424 and CEF formats).
- **RADIUS:** the check that a name of an alias suffix is not another person's refuses when the
  directory cannot say (it let in); an unsigned request with a tab in the password is answered (it
  was left unanswered).
- **High availability:**
  - a node renamed keeps its place as the preferred node of a split - left on the old name, neither
    node was preferred, and with the other one away nobody answered RADIUS; a preferred name no node
    has falls back to the first node;
  - a dead node whose clock ran ahead no longer reads as alive (and the lead) for as long as it was
    ahead;
  - a VIP moved by hand is wanted for a minute from when each node saw it, not by the asking node's
    clock;
  - the ACME account and the keys for certificates from acme are made by one node of a replicated
    pair - both making them at once stopped the replication;
  - the rename of 1.0.x (opt -> otp) keeps the replication's password out of the other node's log
    when the change fails.
- **Security - the command line as root:**
  - a file given from outside the service's reach (`--restore`, `--restore-bundle`, `--import-config`,
    `--ca`, `--downgrade`...) is copied into a folder opened once and used by its descriptor - by
    its name, the otp account could put a link in its place, and root gave it any folder of the
    machine; links in a folder copied are left out;
  - the daemon is sent its signal (`--ha-setup`, `--ha-bundle`, a change of the address) only when
    otp.lock names the daemon's own process - the number in the file was taken as it was (-1: every
    process of the machine);
  - `--tls-export` and `--isemon-tls-bundle` write their file as root, not through a link, with the
    file's mode set - as the otp account `/root/x.pfx` was refused, and a file there kept its mode;
  - `--radtest USER PASSWORD` says that a password on the command line stays in the shell's history.
- **The console as root** stays root: the local users and their password policy are done by a child
  of its own - the console became the otp account for good (restarts, upgrades and `!` then ran as
  otp), and who did it was no longer said.
- **Security - with the guard of root's actions on:**
  - the DNS settings of ACME are signed too (a sealed secret of the database put in place of the
    DNS key went to a server named by whoever wrote it);
  - a token's key written into its row unsealed is no longer sealed at the next start and taken
    (once only, at the first start with the guard on, for what was there before); a recovery code in
    the shape of before 1.0.14, and a plain list of codes, only where the token's sealed copy has it;
  - rows of a version before are taken as otp's only by a node that ran that version with the guard
    - a node installed anew or joining signs nothing it finds.
- **Security - imports:** a file not locked in a locked .totp ZIP is not imported (put in by somebody
  who had the file); a password's hash with rounds out of a sane span is no password (an import of
  two thousand million rounds made every try burn minutes).
- **Remote backups:** the archive itself is checked to be locked before it is sent, and the manifest
  says the password it was locked with (read twice, set between the two, an archive not locked was
  named .enc and sent).
- **The pages' PHP:** `mail`, `putenv`, `error_log`, `dl` and friends are not allowed in otp's pool.
- **Putting back the machine's own after a restore:** a user that signs in to nothing (`nologin`,
  `false`) is made again so; what could not be put back is kept as the backup had it for a week (it
  was read again at once, the machine as it is now in its place); the service takes a restore of its
  own name at once, a join or a restore under another name at its start.
- **Smaller:** a full name changed keeps its other fields; unlock of older hashes ($1$, $2a$);
  "make it on B" keeps the UID the user has on B; a node not preferred waits at most half an hour
  for the first node to make the ACME account (ten minutes for acme's keys); a report of SELinux
  asked of every node skips one with a step under way; the directory away for the alias check is
  said as away (the other node asked, as for any sign-in), not as another account's name.

## 1.0.247 — 4 November 2026

**A backup put back on machines installed anew brings everything back - on both nodes of a
cluster** (checked end to end: a cluster of two backed up to a destination, both machines lost, one
installed from nothing restored from the backup alone, a second installed from nothing joined).

- **What the nodes had put in on their machines is put in again.** The copy brought back each node's
  rows saying what it had done there - so the new machine said "done" and never put in the SSH
  server's file and otp's gate for SSH (PAM, the gate's secret, SELinux's boolean), the time servers,
  the console at login, the password policy or SELinux's steps. Those rows are the machine's own now:
  not taken from a backup; a node joining under a name the cluster had forgets its old ones.
- **The machine's own, which no row held, is kept for the backups**: the local users (UID, full
  name, shell, password's hash, aging, sudo), the SSH keys root and each of them sign in with, and
  SELinux's booleans. Each node reads them now and then (and at once after a change on the pages) and
  keeps them sealed in a row of its own, signed with the guard on - so every backup carries them.
  Put back by itself when the service starts after a restore or a join under a known name: users
  made again with their UID, password and sudo, keys added - only what is missing, nothing of the
  machine as it is taken away. In Events; `otp --machine-kept` says what is kept of each node,
  `otp --machine-kept putback` puts it back by hand.
- **The guard of root's actions comes back on** where it was - from the backup's config.json on the
  restored node, from the first node on the one that joins.
- One ask of the local users' root helper at a time - two of them at once (the users' and the
  machine's keep) took each other's place.
- RESTORE.md says what comes back by itself, and what is still by hand (SELinux's mode, the
  encryption to a database on another machine).

## 1.0.246 — 4 November 2026

**Settings in a cluster: in effect on every node?** At the right of each card's heading of
*Settings* a thin pill: a dot a node - green, it has in what is saved; amber, not yet (the pill's
edge amber too); red, not heard from; grey, a version that does not say - a thin line, and a refresh
icon. Pointed at, the dots say it a node a line (*in effect · read in 9 s ago*, *not yet · it reads it
within seconds*, *not heard from · 2 min ago*); the icon asks both nodes again at once (it spins).
Looked at again every 15 s while Settings is open, every 3 s while a node has not caught up and for
18 s after a save. Only in a cluster - a node alone shows nothing. The heartbeat carries the mark of
the settings each node read in, and a node says it at once when it read a change - its own or the
other's - or is asked. `GET/POST /api/settings/nodes`. (As acme 1.0.42 has it.)

**The password policy with SSH keys, otp's codes and sudo** (found in acme). A password that runs
out is asked to be changed at the next sign-in also over SSH with a key or with otp's code - sshd asks
PAM's account step. A user with no password (a key only) has none to change, and would have been let
in by nobody once login.defs' days ran out: such a user is now made with no password aging, and *Also
for the users there now* leaves them out; given a password later, it gets the policy's aging then.
otp's code for SSH never counts as a wrong password for the lockout (its PAM lines end the step before
pam_faillock), and the lockout keeps a password out, never a key or a code. sudo - and a normal user's
`otp --console` through it - asks for the user's own password: a user made with sudo and no password is
refused on the page (*give them one*), and a user's popup says when one may use sudo but has no
password. The card says all of it (*With SSH keys, otp's codes and sudo*).

**The lights a node under *High security* and *Guard against writes to the database*** (1.0.244) are
gone - the pill of the card says it now.

## 1.0.245 — 4 November 2026

**A password policy for the local users** (*Settings → Local users → Password policy*; not set by
otp by default - each node as its system has it, nothing written). One policy for the cluster, put in
by each node into the system's own files, so that it holds however a password is changed (`passwd`, a
password run out at sign-in, these pages): the length, the kinds of characters, the same character in
a row, the characters not in the old one, no word of the dictionary, not the user's name
(pam_pwquality's drop-in); the last passwords not taken again (pam_pwhistory); how long a password is
good, the warning before, the least days between two changes (login.defs - and, asked, on the users
there now); the lock after so many wrong passwords (pam_faillock; never root). With authselect the
features that put the modules into PAM are switched on, and off again when no longer needed - only
those otp switched on. Switched off, every file is as it was. Each node's light says whether it has
put it in; *In effect on the nodes* shows what each has, and where a module is not in its PAM. A
password typed on the pages is checked against it first (`pwscore` where it is installed). Each
user's own **password aging** in their popup, and the day their password runs out. `otp --local-policy`,
`otp --local-policy-set KEY=VALUE…`, `otp --local-user aging NAME --local-max-days N …`; on the console
too. The policy's row is signed by the guard of root's actions.

**The database card on the overview says why it has its colour.** Clicked, its popup starts with
one line in the card's colour: green - a copy of the last two days is here, and when the next is
made; yellow - the last copy is older than two days, or there is none yet, and whether one is made
by itself; red - the key that opens the tokens is not on this node, and where to put it back from.

## 1.0.244 — 4 November 2026

**`otp --get KEY…`, the counterpart of `--set`.** The value of a setting as it is in effect on this
node - saved on the pages, from config.json or the default: one key gives the value alone (for a
script: `[ "$(otp --get db_guard)" = 1 ]`), switches as 0 or 1, lists as JSON; several give
`KEY=VALUE` a line, with `--json` one object. A key not known ends with 2 and the keys that were
probably meant. A secret is never shown, not even in part: only `set` or `not set`. `otp --settings
--search` stays for looking around.

**High security and the guard: how each node stands** (*Settings → High security → Settings*). Under
both switches a small panel, a line a node: a green light and *on*, grey and *off*, red and *not
answering* (what it said last), with *this node* marked and how many rows the guard refused there.
This node as it is now, the other as its last heartbeat says. Only the nodes of the cluster: a node
alone shows itself, a pair the two - a node not heard from for a day (taken out, renamed) is not
listed.

**A local user made is in SSH keys at once** - *Whose keys* offered it only after the page was loaded
again: each node reads its users for the SSH keys again after a change of its local users, and the
pane watches until the read has come.

**Local users: switches, not boxes to tick** - *To be changed at the first sign-in*, *May become root
with sudo*, *Its home folder too*, the nodes a change goes to and *Also the accounts with no shell*.

## 1.0.243 — 4 November 2026

**Local users of the machines** (*Settings → Local users*, full admin). The users of each node's own
system, one row a user and a column a node: made, given a password, sudo (wheel / sudo), locked
(the password and the account - no SSH key lets them in either) or unlocked, their full name and shell
changed, taken away with or without the home folder - on every node of a cluster at once or on the
ones ticked, the same UID on each; a user on one node only made on the others with a click. **root is
shown only**, never changed from the pages (the API refuses it); accounts of the system and of the
services are neither shown nor changed. A password typed on the page goes to the nodes as its sealed
SHA-512 hash only, to `chpasswd -e` on its standard input, and is taken out of the database once done;
the rows asking are signed by the guard of root's actions. Also `otp --local-users`, `otp --local-user
add|password|lock|unlock|sudo-on|sudo-off|drop|drop-home NAME` (a password asked at the terminal) and
four items in `otp --console`. See docs/local-users.md.

## 1.0.242 — 3 November 2026

**Alerts for what the nodes already saw** (*Alerts and reports*). Mailed now, each with a switch of
its own, on by default - they are failures: **the key that opens the tokens missing** on a node, two
nodes under one name, RADIUS in trouble while it listens (under *A node or RADIUS down*); **logs not
reaching isemon or the syslog servers** (with the lines dropped); **the SNMP agent not listening** or
its traps not going; **a certificate the CA did not renew** - at once, not only once it is about to run
out; the certificates of **PostgreSQL's TLS and the link between the nodes** running out (with *A
certificate running out within*); **the update of the system failed**, or a node that cannot look for
updates; **an upgrade of otp that failed**; **a change on trial that went back** (the network, the
firewall, the SSH server - whoever made it may have lost the way in; the network's going back is now in
Events too); **rows of the database not written by otp** refused (the guard against writes);
**mails with a code or a token that do not go**; a clock out of sync on a node without chrony. Off by
default, for who wants them: the replication behind by more than N MB, SELinux, the security check,
each sign-in by the load balancer refused. *The nodes apart* and *the clock guard* have switches of
their own too (on, as they were). Fixed on the way: with no event at all when the alerts first looked,
what happened later was never mailed.

**High security: the code from otp over SSH is no password.** With *Ask for a code from otp* and no
system password to fall back on, otp sets sshd to keyboard-interactive (the code) and root to a key
and the code - the check took both for passwords: *SSH lets people in with a password* and *root may
sign in over SSH with a password* stood against switching high security on. Said now only where a
password really lets in.

**Accounts picked, not typed** (*SSH server and notices*, *About*): *Who may sign in*, *Only these
accounts* and the console at login's *normal users* are lists of the accounts of the nodes - root and
every user who may sign in there - several at once, or everybody (nobody / every normal user for the
console); chips to take one away, a search when the list is long. One set before that the nodes do not
list (a pattern of sshd's) stays, said so. *Add an SSH token* is a list too: only an account of the
nodes, one without an SSH token - the server refuses any other name, and a second token for one
account.

**The VIP address no longer lost for good when its name was taken away.** With a certificate of the
VIP address's own kept and its name (*FQDN*) emptied afterwards, each node's root helper refused the
whole request ("a certificate of its own needs the name it is for") - and no change of nginx,
keepalived or the firewall reached the node again: once keepalived stopped, the VIP address stayed
away. The node's certificate now serves the address until a name is given again (said in the log);
given a name, its own certificate is back on it.

## 1.0.241 — 3 November 2026

**SSH tokens: the account names offered from the nodes** (*SSH server and notices → Add an SSH
token*): root and every user who may sign in on the nodes (a login shell, UID 1000 and up - the same
list as *SSH keys → Whose keys*) are offered as the account is typed; one that has an SSH token
already says so. Not read from the nodes yet: they are asked, and offered as soon as they say. Any
name can still be typed.

**One switch for the guessing guards** (*Sign-in protection*): *Wrong directory passwords per person*
and each directory's own cap go with *Block a place that keeps guessing* - off, none of them is applied
(and shown as not in use; what is set is kept for when it is switched on). **Note:** a node with *Block
a place* off and a cap set had the cap applied until now - after the upgrade it is not, until *Block a
place* is switched on. `otp --dir-caps` says so too.

## 1.0.240 — 3 November 2026

**SSH keys of every user who may sign in** (*Settings → SSH keys*, full administrators; was *SSH keys
of root*). *Whose keys*: root as until now, or any normal user of the nodes (UID 1000 and up, a login
shell) - their own `~/.ssh/authorized_keys` read from every node, a key added, made here (the private
half shown once, kept nowhere), exported or taken away, on the nodes where the user is. Read and written
**as that user** by a child of the root helper with their UID, GID and groups: `~/.ssh` 0700 and the
file 0600, theirs; a link in their home is refused and never followed. System accounts, `nologin` ones
and anything else refused. Every change in Events with the user's name. docs/ssh-keys.md.

**The console at login for normal users too** (*Settings → About → The console at login*: *normal
users: nobody / every one / these…*; `otp --console-users "alice bob"`, `'*'` or `none`; on the
console under The service). Off by default - root only, as until now. Named users land in the console
**through sudo, with their own password**: only who may become root with sudo gets it; anybody else
named gets one line saying so and the ordinary shell. What is done from such a console is in Events as
`command line (sudo alice)`. `/etc/otp-console-login` gets a second line (`users: …`); root's own switch
is kept apart. Both nodes of a cluster each their own, standalone the same. docs/console.md.

**Dual certificates in and out** (*Certificates and TLS*): an RSA and an ECDSA certificate of the same
names uploaded together - both keys in the PEM, two PFX files, or one of each; on the command line
`otp --tls-import rsa.pfx ecdsa.pfx` - are both put in, the RSA one the main and the ECDSA one beside it,
as ACME's "both" keeps them (nginx gives each client the one it takes). One alone is as until now, and a
second one there before is dropped. Two RSA, other names or a key without its certificate are refused.
*Download* of such a certificate asks which: RSA, ECDSA, or both (a .zip of the two in the format chosen,
each key locked with the password); in Events which and with what.

**A key shown once, shown big**: the balancer's key (signed in by a load balancer) and Prometheus's
token are in a large box across the dialog, picked whole with one click, with Copy beside them.

## 1.0.239 — 3 November 2026

**Signed in by a load balancer or WAF (SSO)** (*Settings → The enrolment pages*; off by default - the
pages as until now). The enrolment pages published to the internet through a NetScaler, an F5 APM or
another balancer that signs people in against the directory first: who it signed in comes in a header
(`X-Otp-User`, or one named), and the pages ask no password again. Believed only on a connection from
the balancers named - the machine the request really came from (nginx's `$realip_remote_addr`, passed
to the page as `OTP_PEER`), never the client's address from `X-Forwarded-For` - and only with the key
in `X-Otp-Sso-Key` (made on the pages or with `otp --sso-key`, shown once, kept sealed, compared in
constant time). Everything after the password as it was: the directory asked who it is, the realm's
groups and *Who may enrol* decide, **the one-time code by mail or SMS before the first token is still
sent and asked**; replacing a token asks no password but still the old one's code. The same person on
the next page goes on in the same session, another one on the same browser ends it. *Sign out* goes
to the balancer's own sign-out when one is set, or holds the sign-in by the balancer until asked again.
Every refusal in *Events* with its reason. The card shows the last sign-in by the balancer each node
saw and - switched on - the configuration of NetScaler (nFactor/LDAP, rewrite of the headers, `/admin`
dropped, the Web App Firewall), F5 APM (access profile, iRule) and nginx / oauth2-proxy, filled in with
this server's values, with Copy buttons. Refused on without the balancers named or without a key. Each
node's root helper adds one line to the enrolment pages' `location = /` (checked with `nginx -t`); off,
only that line goes - both nodes of a cluster, the VIP address too, standalone the same. The
administration pages are not concerned. `otp --sso-status`, `otp --sso-key`; on the console under
Tests and checks. docs/portal-sso.md.

**Fewer reads of the database for the web state.** Whether "behind a load balancer" or "signed in
by it" was ever switched on is read at most every 30 s (and at once after a save here), not on every
look at the web state - during a restart of PostgreSQL (its TLS renewed) one RADIUS answer on the VIP
address could come too late.

## 1.0.238 — 3 November 2026

**SELinux: what the policy now allows no longer counts as refused.** After an upgrade with a newer
`otp_server` (1.0.237's rule for systemd's `/run/otp`), the card still said *SELinux refused 1
thing* with a red dot, and *Put in what otp needs* did not clear it - there was nothing left for
it to put in, and only a change starts the count again. Every kind of refusal is now put to
`audit2why`: one the policy loaded now allows (*would be allowed by active policy*) is listed as
*refused before, allowed now* and not counted - the node can be ready for enforcing. Without
`audit2why`, or for anything it does not say is allowed, counted as until now.

**Behind a load balancer or WAF: switched off is off again.** Switched off on the pages, the 0 was
dropped as the default value - and read as *never switched on*, so nginx kept believing the header
from the balancers named (1.0.237). The row is kept off now, and a node switched off on 1.0.237 (the
balancers still named) has otp's lines taken out of nginx at the upgrade.

## 1.0.237 — 3 November 2026

**Behind a load balancer or WAF** (*Settings → Firewall and access*; off by default - nginx as until
now). Switched on, nginx takes the client's own address from the header the balancer sends
(`X-Forwarded-For`, or the one named: `X-Real-IP`, `True-Client-IP`...) - only for requests from the
balancers' addresses named, never anybody else's - so that the sign-in pause, the caps, who may reach
which page, nginx's limits and every log see the client, not the balancer. In this node's server and
the VIP address's, on every node, through the root helper (`nginx -t`, put back when refused). It
takes the place of what `otp --trusted-proxy` wrote while on; off, only its own lines go. Refused on
without the balancers named. docs/load-balancers.md.

**SELinux: the first rule learnt on a real node.** Before every command of the unit - `systemctl
reload otp` too - systemd hands `/run/otp` back to the service's account; with `/run/otp` labelled for
the pages it was refused that (`init_t → httpd_var_run_t file { setattr }`), and under enforcing the
reload would have failed. `otp_server` allows systemd the owner and mode of what is there, nothing
else, in a block of its own. The card says plainly when something was refused that otp does not know
yet - *Put in what otp needs* changes nothing for it: the report is what tells how.

## 1.0.236 — 3 November 2026

**The SELinux report, for otp's module** (*Settings → High security → SELinux → Download the report
(all nodes)*; `otp --selinux-report`). Every node gathers what SELinux says there - what it refused
since the start (raw, readable, `audit2why`, `audit2allow`'s suggestion), the card's state, the labels
of otp's files and what the policy says they should be, the programs' domains, ports, booleans, the
versions, and what otp uses on the node (switches and ports, nothing secret) - and the pages give one
file with each node's in it. Nothing is changed to make it; kept sealed in the database an hour.
Sent on, it becomes rules of `otp_server`, so that a new installation needs less of it.

**SELinux's tools put in by the installer and every upgrade** where they are missing (RHEL, Rocky,
AlmaLinux): `policycoreutils`, `libselinux-utils`, `policycoreutils-python-utils`, `audit`,
`selinux-policy-targeted` - with SELinux disabled too; the mode is not touched. auditd started where
SELinux is on. Without a repository, said and gone on.

**The command line and the console have what the pages have:**

- `otp --selinux check|prepare|apply|enforce|permissive` (asked first unless `--yes`).
- `otp --dir-caps`, `otp --dir-cap NAME=3/30|setting|none`, `otp --dir-policy NAME` (the domain's
  lockout and password policy and the cap recommended), `otp --dir-sample NAME USER` (every attribute
  of one person).
- `otp --guard-status`: the guard against writes to the database on this node, and every row that
  reaches root not as otp wrote it.
- The console: SELinux (how it stands, a step, the report) and the guard in *Encryption, sending out,
  time, network, high security*; the directories' caps, policy and attributes in *RADIUS clients,
  realms and directories*.

## 1.0.235 — 3 November 2026

**Bug hunt, round B** - the tokens and the enrolment pages, the root helper, the backups, TLS, ACME and
the VIP address, mail, SMS and alerts - and the fixes of 1.0.234 read again by somebody else.

- **A fix of 1.0.234 taken back**: a node rebuilt from the other signed every row it was given - rows
  written into the other node's database by somebody else included. It now only forgets what it had
  seen, and signs nothing.
- **Moving into another database**: what was written while it was carried, or after - a token enrolled,
  a password changed - was left behind, and *Start using it* did not see it (it compared the events,
  which were carried on purpose). It compares the tokens, accounts, settings, clients, realms and
  directories now, and refuses an older copy.
- **The VIP address switched off by a name not answered**: with `ha_peer` (or `ha_address`) a host name
  and DNS away for a moment, the node stopped keepalived and took its configuration away. It goes on
  with the addresses last known now; a name not answered is asked again in half a minute.
- **A change of sshd on trial** whose time ran out while the machine restarted was kept for good: its
  timer does not outlive a restart. The helper puts it back at its next run. The timer is armed before
  the change goes in - a timer that could not be made left the change with nothing to undo it.
- **SSH on another service's port** (443, 1812, 5432…) refused - sshd could not bind it and stopped; and
  SELinux never takes a port from the service its policy gives it.
- **"Quiet" while a node is worked on**: both nodes wrote one row (the metrics, SNMP and the pages ask on
  every node), and two first rows at once stop replication. Each node writes its own now. A test alert
  or *Forget* on the node that does not send no longer writes back an older copy of what was sent.
- **The enrolment pages**: a sign-in kept open from before a token was taken away or made again went on to
  enrol a new one without the code before the first token. Every step asks again now. A name the
  directory lacks, or an account that is switched off or locked, counts as any wrong password does - at
  the administrators' sign-in too - so the answer does not tell them apart.
- **Backups to other machines**: room for them checked first (twice the database - the copy and the
  locked one), as for the copies on this machine; an unlocked archive refused even where no password is
  in play; the weekly check reads the newest *nightly* copy (it read the hand-made ones, and passed with
  nothing read); locking or opening a large one is not cut off after two minutes.
- **ACME**: two nodes ordering with the manual DNS step take turns instead of cancelling each other; any
  failure of an order is written down (an odd answer of the CA was only logged, and the order was due
  again every hour).
- **Mail and SMS**: a code being sent is not taken back for another try before one try can have ended
  (it went out twice); a redirect to another host does not carry the gateway's credentials; the weekly or
  monthly report missed on its day goes on a later day of the period.
- Smaller: the SNMPv3 count of starts written whole (cut short, it went back); a time zone or interface
  name that reads as an option refused; a changed SELinux module put in again where an earlier try
  failed; a row good on the second read no longer listed as refused; the export of a token carries the
  last step used (a code just used was good again after an import); the box of a directory's own cap
  shows the number that is saved.

## 1.0.234 — 3 November 2026

**Bug hunt, round A** - six areas read again: systemd and the files' owners, replication between
the nodes, the new features, RADIUS, installing and upgrading, the pages and the API.

- **The enrolment pages with the code before the first token** (1.0.228): every *right* first
  sign-in held a place as a wrong password - five people behind one address enrolled, the sixth got
  *too many wrong passwords*. Each count of a request now gives back its own place.
- **Wrong directory passwords - counted by the account**, not by the name typed: `novakj` and
  `jan.novak@corp.cz` were two counts, and both together got twice the cap through to the directory -
  the lockout there that the cap is for. A name the directory does not have is held back the same
  way, so the answer no longer tells which names exist; a capped name keeps the address's count
  too; an empty password, never asked of the directory, does not count. A directory renamed keeps
  its own cap, one taken away takes it with it.
- **SELinux** (1.0.233):
  - otp's module labels `/run/otp` and `/var/run/otp` both - the policy reads one as the other, so
    on RHEL the label could have never applied, and with it the token stayed unreadable to the pages
    under enforcing. install.sh says when the policy still does not label it.
  - What was refused before otp's needs were last put in no longer counts: after the first
    permissive start, *Put in what otp needs* was not enough - enforcing waited for a second
    restart. *Switch to enforcing* never starts the count again.
  - auditd not running is said, and enforcing refused: nothing would have been written down.
  - The first look two minutes after the start, the heavy commands at the lowest priority; a step
    whose answer could not be written is not run again every 5 s.
- **The guard against writes to the database** (1.0.231), in a cluster:
  - A setting, an account, a sign-in and its signature are written in one transaction, as the
    heartbeat is since 1.0.232; a signature that fails inside one is said, not lost without a word
    (PostgreSQL turned the COMMIT into a ROLLBACK).
  - A row read with the signature of another moment is read again once before it is refused - the
    VIP address's row read as not there for a moment, and the address could move.
  - An older signature of the same value is no older row: a row signed here and straight in the
    other node's database was refused there for good.
  - The address of the other node's last signed heartbeat is taken for three minutes at most.
  - A node rebuilt from the other signs its rows again; going back below 1.0.231 is refused while
    the guard is on on any node (switch it off first).
- A change of settings made on the other node while this one was reading its own was missed until
  the next change: the mark of the change is read before the settings now.
- The first sign-in of a directory administrator through the other node waits for the account's
  signature too.
- The enrolment pages no longer show the mail or SMS server's own words when a code cannot be sent
  (its name, its certificate, the account it refused) - those are in Events.
- Smaller: *Read the domain's policy* greyed out for a directory switched off; its own cap no longer
  saved as "no cap" when the box was emptied while typing; a threshold of 1 said plainly; a word in
  the port of *Show what the directory has* answered 400, not 500; install.sh's module test safe
  under pipefail.

## 1.0.233 — 3 November 2026

**SELinux** (*Settings → High security → SELinux*, a card for each node; `otp --selinux-check`).
Nothing changes unless asked: a machine with SELinux disabled stays so, and otp runs on it as before.

- otp's module `otp_server` (`deploy/otp_server.cil`): only labels - `/run/otp` and the API token as
  the web server's own run files, so the pages (php-fpm, `httpd_t`) can read the token under
  enforcing. Put in by install.sh and every upgrade where SELinux is on (only when it changed), taken
  out by `--uninstall`.
- The card: the mode now and after a restart, the module, the labels of otp's files, the booleans
  (`httpd_can_network_connect`; `authlogin_radius` with SSH with a code) and ports (the SSH gate,
  sshd's own, a local PostgreSQL's) otp needs, and what SELinux refused since the machine started,
  grouped and counted. Looked at every half hour and on *Look again*.
- The steps, each asked of one node and done by its root helper: *Make it ready (permissive)* -
  the configuration, every file labelled at the next start, `selinux=0` off the kernel's command
  line, the module; the machine is not restarted. *Switch to enforcing* - from permissive only, and
  only with nothing missing and nothing refused since the start. *Back to permissive*. Each in Events;
  with the guard on, one written straight into the database is not done.
- The security check lists what keeps a node where SELinux is on from being protected; on a disabled
  node it says nothing.
- docs/selinux.md says all of it.

## 1.0.232 — 3 November 2026

**`systemctl reload otp` took the pages off the node.** systemd gives the service's `/run/otp` back
to `otp:otp` before it sends a reload; the pages (the `otp-web` group) could then not read the API
token - `/healthz` said *503: the pages cannot read the daemon's API token*, keepalived took the VIP
address away from the node, and it stayed so until otp was restarted. Any reload did it, the guard of
1.0.231 had nothing to do with it (logrotate signals the daemon itself and was never affected).

- The daemon gives `/run/otp` and the token back to `otp-web` the moment the reload arrives, and
  checks it every 5 seconds (said in the log when it had to).
- On 1.0.231 and older: `systemctl restart otp` instead of reload, or after one
  `chgrp otp-web /run/otp /run/otp/api-token`.

**The guard against writes to the database (`db_guard`, 1.0.231) in a cluster.**

- Another node's heartbeat and its signature are written in one transaction: replication brought
  them over as two, and a node reading between them refused the other's heartbeat (*meta node:otp2 -
  its signature is not right*). The address a node had in its last signed heartbeat is still taken
  while a newer one waits for its signature (a node still on 1.0.231 writes them apart); a heartbeat
  with another address is not.
- `otp --set db_guard=1` is taken by the running service at once - no reload, no restart.
- Shown as a switch - it was a box for 0 or 1 - and called *Guard against writes to the database*,
  with a help that says what it is for and that nothing else is to be set: switched on on every node.

**Wrong directory passwords per person, per directory** (*Settings → Sign-in protection*; as in
1.0.230 until changed).

- Every configured directory has a card: its servers, the link's encryption, and *As the setting
  above*, *Its own* (a cap and a window for it alone) or *No cap*. Each directory counts on its own.
- *Read the domain's policy* (full administrators) connects with the directory's bind account and
  shows the domain's *Account lockout*, *Password policy* and every *Fine-grained password policy*
  it may read, and recommends a cap below the lowest threshold over the longest window.
  *Use it* only fills it in - nothing changes until *Save the changes*.
- docs/sign-in-protection.md (1.2) and docs/high-security.md say all of it.

## 1.0.231 — 3 November 2026

**Root's actions only from rows otp signed** (*Settings → High security*, `db_guard`; off by default -
as until now). What a node does as root - the firewall, sshd and root's SSH keys, the network, a
restart, the system's updates and their proxy, the time servers, nginx's certificates, the VIP, the
TLS of the database link - follows rows of the database, and so do the accounts and sign-ins of these
pages. Anybody who could write the database (its server, a db_password found out, a copy put back)
could have the node do any of it.

- Every such row is signed when otp writes it - an HMAC with a key from secrets.key, in no database -
  in a row of its own beside it (`sig:<kind>:<hash>:<node>`; each node writes only its own). Versions before
  this one leave those rows alone.
- On: a sign-in, an account, the administrators' directory, a setting that reaches root, a row of
  meta root acts on, another node's heartbeat - not written by otp, or an older one put back - is
  not acted on; settings keep their last good value. Said in the log, in Events and in the security
  check. RADIUS, the codes and the tokens are never held up by it.
- Kept in this node's config.json, not in the database; switched off only on the node itself. A copy
  put back, an import, the database moved and a node renamed are signed again afterwards.
- docs/high-security.md says all of it.

## 1.0.230 — 3 November 2026

**Wrong directory passwords per person capped** (*Settings → Sign-in protection → Wrong directory
passwords per person*, `dir_pw_tries`; 0 by default - as until now). A directory password is tried
against Active Directory at each sign-in to the enrolment pages, at each new token there and at each
sign-in of an administrator from the directory - each with a count of its own, on each node alone:
from many addresses, enough wrong ones for a name reached the directory to lock the account there.

- Set below the directory's lockout threshold (3 for 5 to 10): after so many wrong passwords for one
  name within `dir_pw_window_min` (30 min), from anywhere, on any node, the directory is no longer
  asked for that name - only the pages wait, the account in Active Directory stays unlocked.
- A right password does not count. One count for the whole cluster, in the database; one name
  whatever its spelling (DOMAIN\\novak, novak@corp.cz, Novak).
- Shown and cleared under *Locked out* (Accounts and Sign-in protection). RADIUS is not affected.

The card of a directory: its two upper sections side by side, of the same width, across the whole
width - a third, empty column left them narrow. On a phone one under the other.

## 1.0.229 — 3 November 2026

**Where a person's e-mail address and mobile number are read from the directory - on each
directory's card** (*Settings → Active Directory → Edit*, *A person's e-mail and mobile number*).
As until now by default: `mail`, and `mobile` with `telephoneNumber` when that is empty - left as
it is, nothing changes.

- Any attribute, or several in order (the first with a value is taken); `proxyAddresses` read as
  Exchange keeps it (the primary SMTP: address). Used for the codes by e-mail and SMS, for what the
  enrolment pages fill in, and for the one-time code before the first token.
- *Show a person's attributes*: the whole entry of one person, from the card as it is now (saved or
  not), with what the boxes would read, the attributes that can hold an e-mail address and those
  that can hold a phone number each with *Use*, and every attribute of the entry - those of a schema
  of one's own too - listed with *For e-mail* and *For mobile*, to be found and chosen whatever its
  value looks like; or typed by hand, by name or by OID. A full administrator only; written into Events; the kept password goes only to the
  servers it was given for.
- The card of each directory shows where both are read from. Both nodes of an HA pair read alike.

## 1.0.228 — 3 November 2026

**A one-time code before the first token on the enrolment pages** (*Settings → The enrolment
pages → A one-time code before the first token*, `portal_first_code`; off by default - as until
now). Somebody with no token yet signs in with their directory name and password, and a code goes
to the e-mail address or the mobile number the directory has for them - read from it at the
sign-in, nothing typed. The sign-in page asks for it; until it is typed nothing else can be done -
no token made, nothing of the person shown. The directory password alone - guessed or found out -
no longer makes anybody a token of another person.

- The page in the middle of the sign-in card: where the code went on a line of its own (masked),
  the box for the code, *Confirm*, and *Send it again* and *Back* side by side. The code can be
  pasted as the mail or the SMS has it - "482 913", even with words around it - and goes at once.
- By e-mail, by SMS, by SMS with e-mail when the directory has no mobile number, or the other way
  round. Saved only with the mail or the SMS gateway set up; neither can be switched off under it.
- Its own words in *Settings → Message texts* (a mail and an SMS), Czech and English.
- The limits of every code: tries, codes sent per person and per address, the time a code is good
  for; *Send it again* and *Sign in as somebody else* on the page. Each code sent, each wrong one,
  the sign-in with it in Events - never the code.
- Somebody with a token signs in as before. An account the directory has no address or number for
  is told to ask the administrator, who makes its token.
- One setting for the cluster: both nodes of an HA pair and every node on one database alike; one
  machine alone the same. docs/codes-by-mail-and-sms.md says all of it.

## 1.0.227 — 3 November 2026

**The last of five rounds of looking for bugs.** Found by it, and mended:

- **A node that steps aside for the split or its clock went on answering for seconds** while the VIP
  address was still on it - "draining", meant for maintenance asked for by hand, up to 20 s: a code
  was let in there and again on the other node, and a node whose clock was off refused right codes.
  It is silent at once now, on its own address and on the VIP; maintenance by hand still drains.
- **A node aside for its clock stayed silent for good when the other node died** (1.0.226, priority
  mode of the split card): it was kept aside for as long as the nodes were apart. It answers again
  once the other node's row is stale; the other node takes its "aside" only while that row is fresh.
- **"Connection refused" was taken for the preferred node's database down** (1.0.226): a firewall
  between the nodes that rejects says the same, and both nodes answered. A bare refusal counts only
  when the preferred node's machine takes a connection on 443, 22 or 80.
- **A sign-in waited up to 8 s while the other node's PostgreSQL restarted** (1.0.226) - longer than
  a VPN waits: it gave up, the code was used by then, and its next try was refused as used. 2.5 s now
  (1.2 s for a database that refuses outright).
- **A node whose database went away left the VIP address unanswered 14 s**: keepalived is told at once.
- **A node aside for its clock was counted as answering** by an upgrade or a restart of the other
  node when its clock was behind: its rows are read by the measured difference of the clocks.
- **A code typed with another dash or space was counted as wrong** - "123–456" (en dash), the
  no-break hyphen, the full-width "－" of an input method, the minus sign, a tab, or "ě" sent as "e"
  and a caron. Read as the digits meant everywhere now: RADIUS, the portal, the pages, the admin's
  second step, the SSH gate, the command line.
- **The code boxes of the portal and the admin's second step cut "1234 5678" to 7 digits** - an
  8-digit code as the app shows it, counted as wrong; 10-digit mail and SMS codes the same. And
  "123-456" or the Czech row was refused there as "digits only" while the server took it.
- **Password and code in one (password_otp): a recovery code of 11-12 digits typed with a dash or
  spaces was never found** - the password with digits on it went to the directory. And "++++++"
  (111111 on the Czech row) was refused.
- **A tab inside a code was said to be a wrong shared secret.**
- **`otp --scratch` on a node without its key file made a new key** silently: the codes it gave
  opened nowhere else, those before them were gone. The same guard as for every other secret now.
- **The bundle for the second node made a new key on a node that had lost its own** - after the join
  neither node opened any token. It is refused now.
- **A frozen node held a person's row 2 minutes when the sign-in came through the portal or the
  pages** on a shared database (RADIUS: 10 s since 1.0.226). 10 s for every sign-in now.
- **One shared database, no HA mode: a node dead longer than a day was forgotten** - its alert went,
  "back to normal" was mailed, its metrics vanished. Kept until it is forgotten (`otp --ha-forget`).
- **An upgrade from 1.0.201 or older sent the SMS gateway past the proxy** - the codes by SMS
  stopped where the gateway is reached through the proxy only. Kept on as it was.

Looked at and found as it should be: RADIUS on the VIP address and on each node's own, the VIP
moving for every cause (maintenance, split, arbiter, clock, directory, database, a killed daemon) and
coming back by itself, never both nodes silent; codes typed in every form on every path; no code or
password in any log; upgrades from 1.0.200, 1.0.214 and 1.0.221 on SQLite, PostgreSQL and MariaDB;
a downgrade below 1.0.224 refused. The latency under full load is the same as 1.0.221's.

## 1.0.226 — 3 November 2026

**The fourth of five rounds of looking for bugs.** Found by it, and mended:

- **The SSH gate wrote the code typed into the events and the log** - as U+0030 U+0034..., a code
  still good for two more tries, or the password typed at the code's prompt by mistake. Only the
  kinds of characters are said now (6 digits, 1 dash).
- **Two nodes on one new shared database each made a key of their own**, without a word: what one
  sealed the other could not open - its RADIUS requests dropped, its tokens "cannot be opened". The
  key's mark is kept in the database now; a node with another key says so loudly, and no new key is
  made once the database has one.
- **A node stopped half way through a sign-in held that person's row for hours** on a shared
  database (a VM paused, a node cut off): its open transaction now ends after 10 s, the server's own
  keepalives finding it gone.
- **A code used twice during a routine restart of the other node's PostgreSQL** - it refused the
  question for a second, or the watch of the nodes held the question off for 5 s after one probe
  that did not answer (since 1.0.224), and the code was let in here on this node's rows alone. Asked
  again while it restarts (up to 8 s; 3 s when it refuses outright), held off only while the nodes
  are apart; a code let in unasked and used on the other node too is said in the events.
- **"Only the preferred node" silenced both nodes when the preferred node's database stopped** - the
  other node took it for the link cut and stepped aside, and the preferred node had no database to
  answer with. A database refusing while its machine answers is not a cut link: the other node goes on.
- **The wait for a place at the directory stopped for good** after four waits ended in a refusal
  (since 1.0.222) - its count was never given back.
- **A question for a code that would not be sent** (too many waiting) - the person waited for a code
  that never came. Left unanswered now, the VPN asks again.
- **The limit of codes sent between two nodes**: the first of a window was not counted again, and
  two at the same moment both gave back. Decided by order now: of two, exactly one.
- **Going back and forth between versions**: going back is allowed to 1.0.224 at the oldest (an older
  one finds names sent decomposed no more, and has the hole where one person signed in as another);
  names of tokens are put in one form at every start and after a copy is put back (not once for
  good); Czech names with their marks apart are no longer taken for another language.
- **Codes typed on the Czech row, in full-width digits, with a dash** are read everywhere now: when
  confirming a token, in a realm of the code alone, in the SSH gate, in the test on the pages.
- **The SSH gate**: a code sent by mail or SMS stopped working when its token was taken away or
  moved to another address (it worked 5 min more); a token made again in the step the old one was
  last used no longer refuses the new one's right code.
- **Clusters of one shared database**: alerts, Prometheus and SNMP say the other node too (a node
  dead there was never alerted on); a test sign-in asked of the other node is made there.
- **The clocks guarded**: a node put in maintenance while the other is aside for its clock is no
  longer taken for one that answers (nobody answered for 12 s); the preferred node aside for its clock
  when the nodes lose each other stays aside (both answered); on MariaDB the other side's clock is
  read in UTC (an hour off in the hour summer time ends).
- **And**: the administrators' code by mail or SMS is once across the nodes too; a key sealed again
  between two steps of a sign-in no longer refuses the right code with "a code may be used again"
  on; Make a token no longer fills the form with a late answer for the name typed before; the
  messages new on the enrolment pages are in Czech.

## 1.0.225 — 3 November 2026

**The third of five rounds of looking for bugs.** Found by it, and mended:

- **A database put back made the codes used since the copy good again** - every recovery code
  used between the copy and putting it back worked once more, on either node of a cluster (and a
  code from the app within its minute). The codes used up are kept used up now, whatever comes
  back; the same when the database is switched to another server.
- **A node rebuilt from the other lost what only it knew** - replication paused or broken, the
  usual reason for a rebuild: a recovery code used on it was good again on both. And a sign-in
  answered in the moment before the rebuild began was not known to the other node, or was refused
  as having no token. The node goes out of service first now, the sign-ins in hand finish, and its
  codes used up are kept.
- **A sent code typed as the mail shows it was refused** - "821 275", with a dash or a no-break
  space, or on the Czech row of the keyboard without Shift: each a wrong try counted. Read as the
  digits meant now, in the second window, on the enrolment pages and in the administrators' own
  second factor (as the SSH gate reads them since 1.0.190).
- **Codes not sent counted against the limit of codes sent** - after a short outage of the mail
  server or the SMS gateway a person who tried again was shut out for 15 minutes. A code that could
  not be sent is not counted; one waiting in the outgoing mail is written as waiting, not as sent; a
  code not taken because too many were waiting is written down. Two nodes no longer let one more
  past the limit between them. A code's mail is no longer tried in its code's last half minute, and
  one left half way by a restart is tried again within two minutes, not ten.
- **A question for the app's code went on after the token was switched to mail or SMS** - three
  wrong tries counted on the new token. It ends now: "sign in again".
- **Regressions of 1.0.224 mended**: putting the names of tokens in one form of their letters, at the
  first start without the key that opens them, left those tokens unopenable for good. It waits now
  until the key is there, leaves any token whose key does not open, keeps recovery codes never
  sealed to be made again (by their old hash), and keeps a code used on the other node used.
- **And**: a reader of the pages no longer sees the network's map through the cards of the clocks
  and of the nodes losing each other (full administrators only, as Time and Network); a token is not
  renamed to DOMAIN\name; a flood of accounting no longer pushes the sign-ins' repeats out of the
  memory that answers them; a question for a sent code runs out by the corrected time on both nodes
  alike; two nodes started together on one new database no longer stop on making the first
  account twice.

## 1.0.224 — 3 November 2026

**The second of five rounds of looking for bugs** (sign-ins first). Found by it, and mended:

- **One person signed in as another** (since 1.0.222). RADIUS took the token the enrolment pages
  tie to a directory account under another spelling, and a realm reading names "by the form of
  the name" (or one of every suffix) took a userPrincipalName for an account name: Wanda, whose
  UPN is xavier@guest.cz, signed in as xavier@corpnet.cz with her own phone. A token is taken for
  another spelling now only when its own name, looked up as its own realm reads names, finds the
  very same directory account (the same DN). And a name under another suffix of a realm
  (corpnet.example for corpnet.cz) that is another account's userPrincipalName under the main one
  is refused - on the pages, in RADIUS, and for an administrator making a token under it.
- **A token administrator could make a second working token** for someone with one in use under
  a bare name (zofie beside žofie@corpnet.cz). Refused, as under any other spelling.
- **An administrator's new token was replaced from an old page** - a session that had proven the
  old token went on and put its own key in place of the one the administrator made (a phone
  stolen). The proof holds for the token it was made on only.
- **Make a token sent the previous person's name and mail** - typed over in the form, the QR code
  of the second went to the first one's address. What the directory said of a name goes when the
  name is changed.
- **A slow directory held up the realms of the code alone again** (since 1.0.222) - every RADIUS
  worker waited for a place at it. A place is waited for only while the directory answers quickly,
  and by a quarter of the workers at most.
- **"No answer" for things that are not the directory gone** (since 1.0.223) - the directory's own
  answer to a group search, the reading account refused, this node's own limit: refused and
  answered again. And the other node counts as reaching the directory only when it really does -
  connected, its TLS made, its reading account let in (a TCP connect took a hung server for well).
  A realm of the second window with the directory down is left to the other node too (it said
  "no token" and counted a wrong sign-in). A request left unanswered is written in the log.
- **A code accepted on both nodes for up to 40 s after the link between them came back, with the
  default settings** - the question to the other node's database stayed held off by its back-off.
  It is asked again every 2 s while held off, and the hold lifted the moment it answers.
- **The report of the time apart said "none twice"** - made before the other node's rows had come
  over, and without the codes of the first 20 s. Made once they are here, from the first code the
  other node could not be asked about; each code counted once.
- **Two nodes silent together** with the clocks guarded: a node aside for its clock stayed aside a
  minute after the other node died (its word is fresh for 25 s now, and its heartbeat alive); and
  with "only the preferred node" the other stepped aside while the preferred one was aside for its
  clock. A time server's answer lost once no longer throws the measurement away; a clock about
  the limit no longer moves the VIP address to and fro (back below the limit less the warning);
  both clocks off alike no longer step the first to measure aside; saving the card keeps the
  correction; the correction is dropped when the machine's clock is put right.
- **A restart under load used codes up without answering** - the sockets were closed under the
  workers. The requests in hand are answered first (3 s at most).
- **A code by mail or SMS, the administrators' second factor and the SSH gate** used up without an
  answer when the database's reply was lost (as a code from the app was before 1.0.222).
- **Regressions of 1.0.222 mended**: a token stored with its name decomposed (Z + ˇ) is renamed to
  the composed form once, its key and recovery codes with it (it was found by nobody); a password
  ending in "-" followed by a recovery code is split right again.
- **And**: a confirm on one node no longer makes a key made meanwhile on the other the one in use;
  wrong codes for a waiting key from two nodes at once are all counted; a key sealed again between
  two steps of a sign-in no longer refuses the right code; "123-456" is taken when confirming too;
  a name sent decomposed is looked up in the directory composed; DOMAIN\name is refused for a new
  token (RADIUS reads it as name); the token mail's plain text says the hash too.

## 1.0.223 — 2 November 2026

- **RADIUS on the VIP address did not work** - each node listens on every address, and so
  received the requests sent to the VIP address, but answered from its own address: most VPNs
  (Cisco ASA, FortiGate, MikroTik, pfSense) throw away an answer that does not come from the
  server they asked. Each answer goes out from the address its request came to now. The VIP
  address can be the VPN's one RADIUS server; or both nodes as two servers of a group, as before;
  or both. The firewall already lets RADIUS in from every client to every address of the node,
  the VIP address included (docs/high-availability.md).
- **A node that cannot reach the directory hands its sign-ins over at once** - with *Step aside
  when the directory cannot be reached* (Settings → Time → The clocks of the nodes), a sign-in that
  meets the directory unreachable gets no answer while the other node is well, so the VPN asks the
  other node at once - not an Access-Reject, which the VPN takes as final, for the up to 15 s
  until the node steps aside and the VIP address moves. Nothing is used up meanwhile: the
  directory is asked before the code. Without the switch, refused as before.
- **The clocks of the nodes, switched off, still showed the last measurements** - nothing measured
  is kept or shown once it is off.
## 1.0.222 — 2 November 2026

**The clocks and the health of the nodes** - Settings → Time → *The clocks of the nodes*
(docs/clock-guard.md). A node whose clock is off refuses right codes - and answers, so the VPN
never asks the other node; its heartbeat, its pauses and lockouts are off with it; a node that
cannot reach the directory refuses every password the same way. Three ways to choose:

- *As until now: nothing is watched* (the default) - nothing of it runs, exactly as before.
- *Measure and warn* - each node asks the reference time servers itself (SNTP, not its chrony's
  word), measures the other node's clock through its database, shows it, alerts.
- *Step aside when not well* - and a node whose clock is off past a limit steps aside: the other
  node answers, the VIP address goes to it, only while the other is well, never both; back by itself.

And four switches: codes by the corrected time (right codes keep working on a node whose clock is
off), heartbeats by the measured difference, pauses and lockouts by the corrected time, and
stepping aside when the directory cannot be reached. A table on the card says what happens in
each kind of trouble with the choices made, before saving. A node alone, HA pair, one shared
database server: all three.

**Bugs found by the first of five rounds of looking for them** (the sign-ins first):

- **Right passwords refused when several came at once** - a directory answering in milliseconds
  turned sign-ins away ("LDAP server(s) have gone away") whenever 8 were inside it at the same
  moment: 7 of 30 at once, 73 of 200. A place is waited for a little now; a directory really slow
  still holds no more than half the workers.
- **A code let in on both nodes just after the link between them came back** - a connection to
  the other node's database from before the break was dead, and its first use put the other node
  down for 20 s more. Asked again on a new one now, and the old ones are closed when the nodes
  find each other again. A sign-in no longer waits 1.5 s to find out what the watch already knows
  (the other node is gone); codes let in during a short outage are no longer reported under the
  next real split.
- **The database writing a sign-in and the answer lost** (the connection dropped as it said
  "done") left the code used and the request unanswered - the VPN's retry, here or on the other
  node, was refused as used. The sign-in's own write is looked for now: there, it is let in.
- **SQLite: another writer between the two writes of a sign-in** used the code up without an
  answer. The two are one transaction now on SQLite too.
- **A key replaced while a sign-in with the old one was being checked** (the command line, or
  another node on one shared database) got the old key's step, and every code of the new key was
  refused as used. The step is written only on the key that was checked.
- **With "a code may be used again" on, an older code set the used step back**, and the codes used
  since were good again once it was switched off.
- **The pause after wrong codes counted fewer tries than were made** when many came at once from
  separate processes; and **lasted 10 min instead of 30 s after the clock was stepped back**.
- **A name sent with its letters decomposed** (Žofie as Z + ˇ) found no token.
- **A recovery code typed with a dash** (8765-4321) was a wrong code.
- **The enrolment pages and RADIUS took a person for two** - signed in on the pages as
  falco@corp.loc (a realm looking names up by the account), the pages found his token
  falco@corp.cz (his userPrincipalName) and made no other; RADIUS found nothing under
  falco@corp.loc and refused him for good. RADIUS finds the same token now. A token administrator
  could hand that person a second, working token under the other spelling - refused now, as under
  the same one.
- **A key typed in by hand never said its hash** (and the administrator's view neither its digits
  nor its period): with SHA-256, 8 digits or 60 s set, an app made codes that never worked. Said
  beside the key now, on the pages and in the mail.
- **A token not yet confirmed and thrown away on the enrolment pages** left the mail of its key and
  its waiting shape behind.

## 1.0.221 — 2 November 2026

- **The table *What happens* on *When the nodes lose each other* moved with every switch** - its
  columns took their widths from their words, and the costs are longer or shorter with each
  choice. The columns are fixed now. The four switches are two by two on a wide page (not three
  and one alone), one under the other on a phone.

## 1.0.220 — 2 November 2026

- **A switch clicked on the card *When the nodes lose each other* sent the page to the top** -
  the card is drawn again whole on every change, and for that moment the pane was short. The
  page stays where it is now; the same on *Certificates from acme*.

## 1.0.219 — 2 November 2026

- **The settings of *When the nodes lose each other* were drawn under every pane** of the
  settings (in the list of those of no pane of their own) - Restart and power off, and the
  others. They are on their own card on High availability only, as they were meant to be.
- **The card *When the nodes lose each other* stayed empty** - its title and words only: the
  pages did not pass its requests on to the daemon (`?api=split`). It is drawn now, on both
  nodes.

## 1.0.218 — 2 November 2026

**When the two nodes lose each other (split brain)** - a card of its own on Settings → High
availability. Two replicating nodes that cannot reach each other each take the other for gone
and go on alone: a code may be let in on both halves, the wrong tries are counted on each half
apart, and what is changed on each half goes its own way. Without a third machine it cannot be
ruled out; what can be done is chosen here (docs/split-brain.md says all of it):

- **Who answers while they are apart** - one of three:
  - *As until now: both nodes go on* - the default. With every switch below off nothing of
    this runs at all: no question to the other node, no arbiter, nothing written - exactly as
    before. An upgrade changes nothing.
  - *The node that still sees the network* - each node asks its arbiter (its default gateway,
    or addresses given, each node its own; ping, or host:port over TCP). The node that reaches
    neither the other node nor its arbiter is the one cut off: it steps aside - RADIUS is not
    answered there, the VIP address goes to the other node - and comes back by itself. Saved
    only once the arbiter was tried from every node.
  - *Only the preferred node* - the other one steps aside while they are apart.
- **And while they are apart** - any of: recovery codes only with the other node asked
  (refused meanwhile, not counted); half the tries to the pause and the lockout; changes on
  the pages only on the preferred node; a warning while apart and, together again, a report of
  the codes let in without the other node asked - by name, those let in on both.
- The card shows both nodes as they are now, the three choices as cards with what each gains
  and costs, and a table of what happens - a node switched off, a node cut off from the
  network, the link between them broken - worked out from the choices before saving.
- "Apart" is told by the other node's own database - the very one asked before a code is let
  in - every two seconds; after its answer comes back, codes are checked against it again at
  once, not after the back-off of up to five minutes.

## 1.0.217 — 1 November 2026

A hunt for bugs - the database pane, RADIUS, acme push, the cluster - and what it found:

**The database pane**
- **"Empty it first" could drop the tables of the database in use**, reached under another
  name (127.1, the machine's own name or address, an alias): the server is told now by what
  it is, not by the name typed. The move, *Use it* and *Set it up* the same.
- **The password of the database in use was sent to another server** typed in without one,
  and given to the account set up there instead of a new one. Never now: a new one is made.
- **Setting up another database under the account in use changed its password** - the next
  start could not reach this node's own database. Refused, with what to do instead.
- **A PostgreSQL or MariaDB copy put back brought back the copy's own rows of this node** -
  another node's heartbeat (a node alone took itself for one of a cluster), a job "running",
  the tuning of that day. Kept as they are now, as a copy of otp's own always did.
- Import: a bad value stopped it after the clients were in - every value is checked first
  now. *Exactly the file* signed out an administrator signed in through the directory (its
  way in went back to none), kept a cluster's value the file did not have when it had only
  one node's own, and a file without clients (or realms, directories) took them all away.

**RADIUS and the tokens**
- The transaction of 1.0.214 (a code used up all or nothing) was skipped now and then under
  load - workers sharing a connection took another's transaction for their own.
- Password + code: a recovery code sent again gave the directory the password with the code's
  first digits on it - a wrong password counted by AD, and "refused" said for "used once".

**The cluster**
- **A system update with an automatic restart could leave its node in maintenance for good**
  when the restart could not start (the other node down): RADIUS was not answered there
  again, and every later restart was refused. Ended as an update without a restart now.
- A system update, a restart and a power-off of one node took a node in maintenance by hand
  for one that answers - both went silent. Only nodes in service count now.

**Certificates from acme** - none of the hunt got past the signature, the nonce or the time:
- A request sent to both nodes at once could be sent again to the other: the nonces are kept
  as otp's codes used once are, row by row, the other node asked.
- What the card keeps is in rows of their own: an acme paired on one node while the other
  refused a wrong code was lost, the two nodes kept different acmes, and the wrong tries were
  counted on each node apart (and thirty at once were all tried).
- The second certificate (another key type) was not checked: one of the same type or of
  other names took the card unchecked. Odd input is said as the protocol says, a ninth acme
  is refused (not the first dropped), a pasted key's name is cleaned, refusals are logged by
  their code only, and the page passes on the protocol's headers as ASCII only.

## 1.0.216 — 1 November 2026

**Certificates from acme (acme push)** - a new, additional way for a certificate to arrive:
an acme of yours (the certificate manager) puts its certificates on these pages and renews
them by itself. Settings → Certificates and TLS → **Certificates from acme**: switch it on,
*Pair with an acme* (a code shown once, 15 minutes, five tries) or paste acme's key; in acme a
target *An application of ours (acme push)* with `https://otp…/admin/`, *Try*, *Discover*.

- Off until switched on: nothing else behaves differently. Every request of acme is signed
  (Ed25519; 5 minutes at most, never twice - on either node), the private key travels sealed
  to this server (X25519 + HKDF + AES-256-GCM). acme's address must be one that may reach the
  administration.
- What acme puts in is kept exactly where an upload by hand is, and is put into nginx the same
  way, on every node; in a cluster any node answers for all of them and the other takes its
  own by replication. Automatic certificates leaves that card alone, as after an upload. An
  upload, a request, a self-signed one or *Look after it* takes the card back, as before.
- Only a certificate holding the card's name, valid now, with its own key - unless *Take
  certificates of other names* is on. Each install, pairing, wrong code and forgotten key is
  an event. Switched off or forgotten: what was put in stays.
- The receiver is acme's own reference part (acme 1.0.7), unchanged but for the
  application's name; otp's own certificate code is called by it, not changed. The protocol is in
  `docs/acme-push-protocol.md`; Certificates and TLS in `docs/tls-and-vip.md`.
- The card is the same as ai's (1.0.60), tile for tile and word for word: its state in the
  corner, the two switches, the address for acme, this server's id and its sealing key as
  tiles a click copies, *Pair with an acme* showing the code in a window of its own (with the
  address, and until when it is good), *Take it back*, *Or paste acme's key…* in a window of
  its own, the acmes paired and what acme sees here as tables. The two switches and *Forget it*
  wait for the save bar at the bottom, as every other setting does; *Put them back* forgets
  them.

## 1.0.215 — 1 November 2026

- **Import → "Exactly the file" took away every node's own settings** the file did not
  have - another RADIUS port on the second node, its own mail server - on every node of
  a cluster, unseen. They stay now unless the file has them; the shared settings not in
  the file still go back to their defaults, as before. The import dialog says so.
- INSTALL.md says what needs root and who does it, and that **whoever can write otp's
  database is root on every node** (the asks of the pages for each node go through it) -
  with how to keep that as safe as root itself.
- A RADIUS client's shared secret stays as it is: shown whole, to a full admin only, each
  look written down; the list shows it masked.

## 1.0.214 — 1 November 2026

**Moving to another database, a wizard** - Settings → The database → *Move to another
database…* asks, one step at a time with Back and Next: which database (SQLite,
PostgreSQL, MariaDB - one whose driver is missing said so), its address, reaching it
(tried, made empty or set up with the admin's password, which is never kept), what will
happen, and then moves everything and switches over, showing how far it is. Tested in all
six directions. On a node of a cluster (replicated or shared, or another node heard from)
it does not start: it says why and what to do instead - the cluster is never broken by it.
The buttons by hand are still there, folded under *By hand*.

- **"Set it up" wrote the new database's address into config.json while PostgreSQL or
  MariaDB was in use** - the next start went to the empty one. It is written there only
  when this node runs on SQLite or on that same database.

**RADIUS, tokens and the two nodes under load** - what sign-ins in their thousands on a
replicating pair, with the database dropped and replication stopped, showed:

- **A lock set by one node was lost to a wrong code counted by the other at the same
  moment** - the newer row won, and the right code got in afterwards. Wrong codes on both
  nodes are merged: both nodes' times, the higher count, the later lock.
- **A database that dropped in the middle of a check used the code up and left the
  request unanswered** - the NAS asked the other node, which refused it as used. A code's
  step and its once-only rows are written in one transaction now; a recovery code too.
- **A burst of more than about 256 requests was dropped by the kernel** before otp saw it
  (the socket's default 208 KB buffer). The RADIUS sockets take 8 MB: 1600 at once held.
- **A recovery code sent again (the NAS asking twice, or the person) was counted as a
  wrong code**, and paused or locked the token. It is said as used, not counted.
- A code typed with a space in it, as the phone shows it, is taken.
- Password + code: a recovery code of another length than set was never found after the
  password. Every length from 6 to 12 is tried.
- **Replication**: a token renamed on one node while its code was used on the other could
  be used again under the new name - codes used once are kept by the token's id too. A
  rename onto a name the other node had just made stopped replication; it is settled the
  same way on both. Times compared across the nodes never go backwards (a clock a moment
  behind lost a change), and settings made on both nodes keep the newer one.
- A token made on both nodes at the same moment no longer gives the admin a raw
  "duplicate key" error.

## 1.0.213 — 1 November 2026

**Joining a cluster, without a hand on pg_hba.conf, iptables or firewall-cmd** - what
building a cluster on machines with iptables and no firewalld showed:

- **The firewall let the other node in only once the cluster was made**, and the join
  stopped on "No route to host": otp's own firewall (OTP-IN) put "The other node" in
  only with ha_mode set. The node being joined is let in at once now - on the first node
  as its address is given (`--ha-setup --ha-peer`, or the bundle made on the pages), on
  the second as it joins - for a day at most, for good once it has joined. The firewall
  pane shows it.
- **"✔ firewalld lets … reach PostgreSQL" was said whether firewalld ran or not**, and
  nothing else was opened. The command line opens the firewall that really runs - otp's
  own, firewalld when it runs, or the system's iptables with its REJECT at the end (the
  rule said not to be saved there) - checks it, and says what it did or could not do.
- **A bundle made on the pages left the first node unready**: PostgreSQL listening on
  localhost alone, no pg_hba.conf line, no firewall - the join said "Connection refused".
  *Make the bundle…* asks for the second node's address and does each, shown step by
  step; letting PostgreSQL listen on the network restarts it, so it is ticked first.
- **A cluster of one shared database is written as one**: ha_mode = shared, and the
  other node's address as ha_peer, on both nodes (the bundle and the join). Both ran as
  two servers alone - no VIP, nothing asked of the other.
- **Join a cluster…** is drawn anew: the bundle dropped or chosen and named, *Check it*
  opens it and tries its database from this node before anything changes, and a failed
  connection is said as what it means (nothing listening, a firewall, pg_hba.conf, a
  bundle older than the password) with what to do - on the command line too.
- A node whose join stopped half way says so - "password authentication failed" was all
  there was - with the join to run again.

## 1.0.212 — 1 November 2026

- **Replicated HA: `otp --ha-join` stopped with one direction of the replication only** -
  "no pg_hba.conf entry for host <this node's address>". Before the first node is told to
  take the second one's rows, that subscription's connection - to the second node's own
  address - is tried on the second node, and PostgreSQL there let in only 127.0.0.1 and
  the other node, not the machine itself. `pg_prepare_local` (`--ha-setup`, `--ha-join`)
  puts this node's own address (`--ha-address`, else the one it reaches the network
  with) into pg_hba.conf as well, once. A node left half joined by it: add the line by
  hand (`host otp otp <its address>/32 scram-sha-256`, then `SELECT pg_reload_conf()`)
  and run `--ha-join` again - or upgrade first and run it again.

## 1.0.211 — 1 November 2026

**Every pane looked through for both nodes**: what each shows of each node, what each
changes on which, and what could take both nodes down or stop replication
(`tests/round/t_round6.py`, 27 of 27). This version mends what could stop the
service or the replication; what is only shown of one node follows in the next.

A cluster of one shared database:
- **It was not seen as a cluster**: ha_mode stays empty there, and the guards that
  keep a node answering looked at ha_mode alone. A node heard from in the last day
  makes it one now: a restart (on a schedule, after a system update, a new network)
  waits for the other node to answer and takes this one out of service first; the
  firewall always lets the other node in; the alerts and the periodic report are sent
  by one node, not both; the disks and logs pane shows both; NTP peers with the other.
- A new address of a node is not carried to the other node's db_host or pg_hba.conf
  from here: the change is refused until it is ticked as done by hand.

One thing at a time on the cluster:
- A new network, a restart or power-off, a system update and an upgrade of otp on
  different nodes at once are refused - each looked at its own node only, and both
  nodes could be down together.
- A job on the database (a copy put back, erasing, giving the disk back) is refused
  while the other node runs one; putting a copy or a dump back too.

The database pane:
- **"Set it up…" is refused in a cluster**: it could give otp's account of the database a
  new password, and the other node - its replication, or its one database - was shut out.
- **Restarting PostgreSQL from the pages**: never the server both nodes share, never
  while the other node does not answer, never on both at once - and this node's RADIUS
  steps aside meanwhile, the other answers.
- **Tuning a replicating PostgreSQL keeps replication's workers free**: parallel queries
  as many as the processors could take every background worker, and the replication's
  apply worker found none. A max_worker_processes someone raised is never lowered. What
  was there before is noted only once it is changed.
- A copy sealed with another key is refused in a cluster of one shared database too
  (this node's key file was replaced, and the other node opened no token any more). A
  copy put back keeps each node's own tuning, encryption to the database and asks.
- Erasing a log goes in batches, with a breath between.

Elsewhere:
- Maintenance: the last node in service is said to be the last (the dialog said the
  VPN would go to the other node, already in maintenance).
- High availability: Resume is possible after only what goes out was paused; a pause
  or resume the other node could not be reached for says what was done.
- Alerts: "Look again" on the node that does not send them no longer mails them too.
- SSH: Keep keeps the change only on the nodes it was on trial on when pressed.
- RADIUS: the sign-ins' and the accounting's ports are checked on the node they are
  saved for.

## 1.0.210 — 1 November 2026

- **The machine's console filled with "systemd-rc-local-generator: /etc/rc.d/rc.local
  is not marked executable, skipping"** - a harmless notice of systemd's, written at each
  `systemctl daemon-reload` (every package an update installs, otp's own upgrade), and
  put on the console because the kernel's console showed every message up to debug -
  over otp's own screen there too. install.sh writes
  `/etc/sysctl.d/80-otp-console.conf` (`kernel.printk = 4 4 1 7`, as RHEL comes): the
  console shows errors only, the journal keeps everything (`journalctl -k`). A
  kernel.printk an administrator set in sysctl.d is left as it is; the file goes when
  otp is taken away.

## 1.0.209 — 1 November 2026

**A bug hunt, fifth round**: the border between otp and root (every request the root
helper takes, the upgrader's package check), certificates and the network around them
(ACME, the VIP, the firewall and its trial, moving a node's address), and what grows
over months of running. Each finding shown to fail first (`tests/round/t_round5.py`,
26 of 26). The RADIUS path held 120,000 requests at a flat 49 MB.

The firewall and the pages:
- **A change of the firewall not kept in time opened the administration to everybody**
  when its lists of who may reach the pages had never been saved in otp: the put-back
  wrote "everybody" for the administration and the enrolment pages - nginx opened them,
  and the firewall opened 80 and 443 from anywhere. It goes back to the lists nginx had
  (or, not known, to the private networks of the install).
- With ACME by HTTP-01 and the pages kept to some networks, port 80 was kept to them
  too and no certificate was renewed: it is open to the CA from anywhere (it answers the
  CA's question and sends everything else to HTTPS).

The cluster:
- **The VIP with a host name for a node's address** (ha_address or ha_peer), or no
  other node named, made root refuse the whole request - and no certificate, firewall
  rule or list of who may reach the pages reached that node again. The name is looked
  up; with no address the VIP waits, said in the log, and the rest goes.
- Moving the other node's address wrote it before the subscription was moved: a move
  that failed half way left config.json on the new address and replication on the old
  one, and asked again it said "nothing to change". It is written once moved, and a
  subscription still on another address is moved when asked again.
- A certificate is ordered by ACME on one node at a time (from either node's pages
  while the other renewed it, both ordered it).

Root:
- **A change of sshd that went wrong half way stayed half made**, with no trial to put
  it back: only sshd refusing it was undone - a package that did not install, a notice
  that could not be written or a reload that failed left the drop-in and PAM as they
  were being changed. Every file goes back as it was now.
- pg_hba lines are not written for PostgreSQL's words (all, sameuser, samerole,
  samegroup, replication) in place of otp's database or account.
- /etc/hosts: the lines taken out for the machine's old addresses and name are only
  those it has now - any line could be taken away before.
- A certificate PostgreSQL does not take is not left behind: ssl and its files as they
  were, so its next restart does not fail on them.
- The upgrader refuses a signed package with a folder no file of it is in.

Smaller:
- ACME takes names under a punycode TLD (.рф). The network: /31 and /32 addresses are
  taken; an IPv6 DNS server among the IPv4 ones is refused on the page, not by root.
- The tests asked of every node are not remembered for good; the SSH gate answers 32
  requests at once at most; a directory's cache of groups keeps to its size.

## 1.0.208 — 1 November 2026

**A bug hunt, fourth round**: who may call what on the pages' API and how sign-ins
end, the pages themselves (what they put on the screen, the password boxes, the
translations), and the three databases side by side - moving between them, putting a
copy back, upgrading an old one. Each finding shown to fail first
(`tests/round/t_round4.py`, 18 of 18); no route was found that lets a lower role read a
secret or change a setting.

The pages:
- **A password typed with a dead key or composed by the keyboard was saved wrong**
  under its dots: ď, ť, ň, a háček on a capital, Android's keyboards, an IME - what was
  typed before the letter was lost (Heslo + ˇc + ka1 was saved as ˇčka1). It affected
  every password and secret box: a person's own new password, accounts, clients,
  directories, the mail, proxy and SMS secrets, the passphrases. The letter is put in
  where the caret was now, and nothing of it shows.
- One who must change their password first is no longer let send a database, a
  package or a backup (up to 4 GB) only to have it refused afterwards.
- The generated passphrase of a token export goes back to dots once the export is
  pressed, and is forgotten when "not locked" is chosen.
- A test of every node (the proxy, isemon's TLS, the database's TLS, a node asked) ends
  after its time even when every answer fails - it asked once a second for good, its
  button busy. Names in four confirmations are no longer shown escaped twice.
- The Monitoring pane's introduction, two lines of High security and a copy's note are
  in Czech now.

Signing in:
- **A name two accounts of the directory answer to signed into the administration as
  the first one** - its password, its groups, and the account of whoever signed in under
  that name before. It is refused now, as RADIUS and the enrolment pages refuse it; an
  account whose directory entry changed is said so in the events.
- The enrolment pages no longer send their owner the administrators' note on the token
  or who made it.

The databases:
- **"Start using it" refused the database just carried into** whenever the move took
  more than a minute (any real log of sign-ins): what was written while it was carried
  goes across too now.
- **A copy could not be put back over a large database**: emptying a log of millions of
  rows went past the two minutes a statement may take. Putting a copy back has no limit
  now, and the limit is lifted on a live connection, not one the server dropped.
- A PostgreSQL database made from the pages is C.UTF-8, as a cluster's are: under C,
  "Žofie" and "žofie" were two people again; under a language, clients and realms came
  in another order and another client's secret answered. Clients and realms are put in
  the same order on every engine.
- MariaDB: a token with a long name (up to 180 characters) could not be switched off,
  unlocked or sent a code - the keys kept for it were longer than 190. They may be 255.
- A dump's full administrator switched off is no longer counted as one who can sign in
  when it is put back. An older database missing a column an index is on starts (the
  columns are added first). No empty option file is left behind when the password
  cannot be used.

## 1.0.207 — 1 November 2026

**A bug hunt, third round**: tokens and their files, the secrets kept, how the program
holds up when things go wrong, the cluster's failover and resync, every option of the
command line, and RADIUS signing-in end to end - each finding shown to fail before it
was mended (`tests/round/t_round3.py`, 29 of 29; the earlier rounds still 29 and 23).

The cluster:
- **A setting changed on both nodes while the link was down stayed swapped** for good:
  each took the other's change. The later change is kept on both now (by its time, the
  same moment by byte order). `otp --ha-compare` compares what the settings, accounts,
  clients, realms and directories hold, not only how many rows there are.
- **`otp --ha-bundle` on a node already replicating set it up again as the first
  node**: slot 1, a restart of the only node answering, and the old subscription and
  slot left behind (the WAL kept growing). It now only makes the bundle for the other
  node again, its slot the other one's, nothing changed or restarted.
- **Both nodes did the lead's work** while one direction of the replication was stopped
  and the network was fine (an error, a paused subscription, the rolling upgrade):
  reports and alerts went out twice, ACME ordered on both. A node that only looks stale
  is asked in its own database first.

Secrets:
- A secret kept as its dots goes to the server it was given for only: the mail server's,
  the proxy's, the SMS gateway's, a directory's binding account, the database's and the
  DNS servers' for ACME - with the server changed it is asked for again (it was sent to
  the new one, in clear with TLS off). An imported configuration that moves the server
  leaves the secret to be typed again.
- `otp --export-config --with-secrets` is locked with a passphrase, as on the pages.
- pg_dump and pg_restore get the database password in a 0600 file, not the
  environment; the statements that move the database are kept out of its log.
- The SMS gateway's password and token are out of the debug log in every form they
  are written in. A secret shown as its last two characters always has eight dots
  (its length was told).

Tokens:
- A .totp file's step, digits, algorithm and state are read (and written back out);
  recovery codes of 6 to 12 digits are taken. A token's backup keeps it switched off
  with what it was before. New recovery codes made while a new key waits wait with it.
- An issuer with a colon in it is refused (the apps read it as the account's name). A
  backup brought in together with .totp files or ZIPs is refused, not half read.

Signing in:
- **With the guard of places on, a disabled or expired directory account blocked
  everybody behind its address** (its VPN reconnecting): refused before any password
  is checked, it is no guess. A wrong code asked again in a challenge, mail or SMS
  realm is one now.
- The SSH gate answers a request again when its first answer failed.

Holding up:
- A system update whose helper stopped answering half way is ended as failed after an
  hour (it stayed "running" and refused every later one).
- The machine's own name for ACME and the cluster's addresses are looked up in the
  background, never by a request waiting on DNS. Timers that waited out a time use the
  monotonic clock (a clock set back no longer holds them). The periodic report is given
  back when it could not be sent; NTP retries a failed apply after ten minutes.
- A remote backup that is not a readable archive is said to be so, not a traceback.

The command line:
- **`--set node_name=NEW` while the daemon runs** made the command line act as a node
  that did not exist yet (`--maintenance on` for nobody, `--ha-forget` of the running
  node): it acts as the name the daemon answers under until it starts again.
- **`--set SECRET=-` with nothing on stdin** saved an empty secret: refused.
- `--config FILE` that is not there is refused (the defaults were used: SQLite).
- `otp` alone, and `otp --json`, give the state again, not the help.
- `--del-client`, `--del-realm`, `--del-directory`, `--del-user` and `--ssh-token-del`
  ask, or take `--yes`, as every other step that takes something away.
- `--json` is kept by `--enroll NAME@ALIAS`, `--backup`, `--rbackup-status` and
  `--ha-tls`; `--status --json` and `--token NOBODY --json` give the same exit code as
  without it. `--events` takes `--hours`. A word `--methods` does not know is refused.
  `--api` no longer takes settings like acme_key for secrets. The hint of
  `--acme-order` gives a form that works.

## 1.0.206 — 31 October 2026

**A bug hunt, second round**: read through again across the whole program - the threads
side by side, the settings and where each is used, the enrolment pages as somebody on
the internet sees them, installing, upgrading and putting back, the protocols spoken by
hand (SNMP, mail, syslog) - each finding shown to fail before it was mended
(`tests/round/t_round2.py`, 23 of 23; the first round's still 29 of 29). On Python
3.14.8: the whole suite, the console (56 of 56) and the cluster of two - signing in
57/57, operations 17/17, maintenance 14/14, ACME 36/36, alerts 13/13, TLS 32/32.

The enrolment pages:
- **The directory password alone made a second token** in a realm of every suffix (`*`)
  that looks accounts up by their account name: "jboss@whatever.x" was a new name, its
  token the asker's, and RADIUS let it in. The account's token under any suffix is its
  own now - replacing it asks for the old one first.
- In a realm that looks names up by the account name, another account's
  userPrincipalName no longer leads to this one's token (and the other way round): a
  token is the same person's only as its realm reads its names.
- A name more than one account answers to is refused, as RADIUS refuses it.

Signing in and the cluster:
- **An SSH code from the app was good once on each node**: taken in token_once now, on
  either node, as a token's.
- **A sign-in waited on the SMS gateway or the mail server** while the helpdesk sent
  that person something (a test code, the token by mail): the token's lock is let go
  while it is sent.
- **The rolling upgrade could wait for good** for the node done first: its heartbeat no
  longer comes over to the older one; it is read in that node's own database.
- The SSH gate and the watch over the database's TLS no longer end on one database
  error (the gate stayed silent until a restart).
- A list of clients, realms or directories read just before a save is no longer kept
  over it (a new client stayed unknown on one node).
- A connection to the other node's database made before its address or TLS changed is
  closed, not kept. ACME looks the database's and the other node's names up as the
  machine does.
- A node's own settings saved while it was alone become its own when the cluster is
  made - the second node took the first one's RADIUS address and mail name.
- A new node_name waits for the next start, as the page says - it took effect at once,
  and every setting of the node's old name stopped applying.
- An import of the settings into a cluster saves the cluster's values (it saved them for
  the importing node, and "replace" then took them away).

Settings:
- An address, a host name or a time is kept without the spaces around it ("127.0.0.1 "
  took RADIUS down). The mail's From is an address ("Name <addr>" broke every mail; one
  saved before is read as its address). The sign-ins and the accounting on one port are
  refused. The proxy's address and the SMS gateway's need a port that is one and an IPv6
  address in brackets.
- The proxy's "new versions" and "system updates" switched off stay off (a setting of
  before 1.0.202 switched them on again at every save).
- An IPv6 DNS server for RFC 2136 updates is written right in nsupdate's script.

Mail, syslog, SNMP:
- **Mail to several people, one of them refusing for now, went again to all the
  others at every try**; now only to the ones left. Each domain on its own, and a server
  that took some is not tried again by the next MX.
- The last try of a mail before it runs out is made, and its giving up said (it ran out
  without a word).
- SIEM: a connection closed by the receiver is seen before it is written into (the first
  line after its restart was lost and counted as sent); lines thrown away while it is
  away are counted. isemon's connections made again when its TLS settings change.
- SNMP's engine time from a clock that never goes back (an NTP step back stopped every
  answer); the page's own test works where the managers' network is set (this machine
  let in for the moment of the test only).

The pages and the console:
- **A change typed after a refresh was not saved**: on Time, Firewall and access and
  the VIP address, the draft was taken again from the server under a box being worked
  in - the box wrote to the old one, Save sent the new one unchanged and said "saved".
  The draft is kept while a box of it is in use, and the boxes write to the draft as it
  is (`tests/ui/draft_ntp.js`, `draft_fw.js`). A change in the moment after a save is
  no longer lost (Time) nor an error (VIP).
- The VIP address saved against what its draft was made from: another administrator's
  change made meanwhile was sent back the way it was.
- Enter in "Send a sample" sent another SMS at each press; a double click on "Export
  it" made two files of the key. One at a time now.
- Nine Czech sentences with no tags in them were never shown (the isemon and
  Monitoring pages' first words among them); two more had no translation.
- The outgoing mail's list refreshes again after the browser tab was away; the progress
  of a backup put back stops when its window is closed, and says so after a minute of
  nothing.
- The console: a number of two digits in a list of ten and more is taken as typed - "12"
  picked the first ("all") on its 1, and cleared every lockout.

Installing:
- `--with-db` kept for the next `--upgrade` (one from the pages has none: the drivers
  were left out of the new Python); the engine in use gets its dump program anyway.
- `--uninstall` takes otp out of sshd's PAM first: SSH by password or code was refused
  after it, keys alone working.

## 1.0.205 — 31 October 2026

**A bug hunt, first round**: the whole program read through by area - RADIUS and
signing in, the database and the cluster, the pages and their API, the root helper,
ACME, TLS and the backups, the pages' scripts and the command line - each finding shown
to fail before it was mended (`tests/round/t_round1.py`, 29 of 29). On Python 3.14.8: the
whole suite, the cluster of two (`t_ha_auth.py` 57 of 57, `t_ha_acme.py` 36 of 36,
`t_ha_alerts.py` 13 of 13).

Signing in and the cluster:
- **A code used on one node was taken again on the other while the replication from it
  stood still**: the other node's database was asked only while its heartbeat - which
  comes over that same replication - was fresh. It is asked always now; a node really
  gone costs one sign-in 1.5 s now and then, not every one.
- **The key that opens the tokens, lost, was made anew by the first secret sealed** (a
  client saved, an enrolment) - past the daemon's own refusal at its start: the tokens
  stayed lost, and two nodes sealed each with a key of its own. No new key while the
  database holds tokens sealed with one, whatever seals.
- **On SQLite a name with a capital letter outside A-Z** ("Žofie") was never found again:
  not signed in, not changed, not dropped. LOWER() takes every letter, as PostgreSQL's.
- The administration's second step: a code from the app taken on either node once, as
  a token's (it could be used again on the other node); `totp_window` 0 is 0 there too.
- A group named without its place, the directory slow or away while it was looked up:
  refused as "the directory has gone away" - it was "not in the group", and counted as
  somebody guessing (five people behind one address blocked for 30 minutes). A group's
  DN written with spaces after its commas matches.
- No Calling-Station-Id from the NAS: the recovery codes are no longer stopped for a day
  by 20 wrong tries of anyone who knows the name - the day's 100 counts.
- A new address asked by the other node is worked on in a thread of its own: it held
  the heartbeat up to a minute, and the other node took this one for gone.
- Going over to another database: a recovery code used between the carry and the
  switch is counted (it was usable again on the new one).

The machine (root helper):
- **A renewed certificate was not served**: only its files changed, no line of nginx's,
  and nginx was not reloaded - it went on giving the old one until it ran out. A
  certificate or key file changed reloads nginx.
- A change of sshd on trial changed again and refused by sshd lost its timer: nothing
  would have put it back. The timer goes only once the new change is in.
- Files written in /etc/otp take their mode on the file itself, never by its name (a
  link put there had root change another file's mode); a FIFO there no longer holds the
  helper. A user name ending in a new line is refused (it broke PAM's file).

Certificates (ACME, TLS):
- RSA and ECDSA ordered: the second refused, the first is put in alone - it was thrown
  away with it, and the CA's weekly limit spent on nothing.
- An order puts its certificate into the TLS settings as they are when it comes, not as
  they were when it began (changes made meanwhile were undone); one no longer looked
  after is left alone.
- A name longer than 64 characters gets a certificate (in its names only, as Let's
  Encrypt takes it). What is due is worked out off the main loop. The renewal window is
  asked through ACME's DNS servers; the proxy's own name through the machine's.
- A CA not answering left a folder behind each time - after a refused account, with a
  key in it.
- openssl is given passphrases on a pipe of its own, never in the environment.

Backups, mail, the rest:
- **A backup could go out unlocked** (sent away, or downloaded from the page) when its
  password was taken away during a long dump: it is not sent nor handed out then.
- A backup the server does not list after it was sent is not taken as sent; trying a
  backup looks at this node's own, never another node's in its place. A broken upload
  leaves nothing behind.
- An alert going between warning and trouble is mailed once more, not at every turn.
  SIEM: a connection made again when its TLS check is switched on.
- isemon over TLS switched on and off where a target is an IPv6 address.
- An export of the settings carries the ECDSA certificate's key as the other's (it
  could not be opened elsewhere, and nginx's every change was refused there).
- An account that only reads no longer sees the firewall's rules and the access lists
  through the cluster's pages.
- Pages: a certificate's issuer escaped in the confirmations; a generated passphrase
  back to dots once typed over and gone after the file is saved.
- Command line: `--secret -` and the like read one line of stdin with no terminal
  (it ended in a traceback); `@env…` is no longer taken as a secret on the command
  line; `--directory-test --json` and `--isemon-test` exit 1 on failure;
  `--lockouts-clear` finds the name whatever its case.

## 1.0.204 — 31 October 2026

**Python 3.14**: install.sh runs otp on `python3.14` where the distribution offers it
(AppStream: `python3.14`, `python3.14-psycopg2`, `python3.14-PyMySQL`), else on the
newest one after it, as before (3.13, 3.12, 3.11, the system's own). Only the
distribution's packages - their security fixes come with the system updates; otp
never builds or fetches a Python of its own. An upgrade takes it by itself where it
is there (`--python PATH` and `--system-python` still decide instead); the root
helpers stay on the system's python3.
- Tested on Python 3.14.8: otp imported and compiled with every warning an error
  (no DeprecationWarning, no SyntaxWarning of 3.14 - `return` in `finally` and the
  like), installed on it, and every test run on it (below). Nothing of what 3.14
  changed is used: no multiprocessing (its start method changed), no
  `tarfile.extractall` (its filter changed).
- On 3.14.8: every test of the suite (25 of 25), the cluster of two
  (`t_ha_auth.py` 57 of 57, `t_ha_acme.py` 36 of 36).

## 1.0.203 — 31 October 2026

**Automatic certificates: several ordered side by side** - *Order certificates now…*
and the renewals by themselves order up to three certificates at once (each node's,
the VIP address's), not one after another: with DNS-01 most of an order is waiting for
DNS (deSEC: three minutes and more each), and the waits now run together. Each card
shows its own order under way and what it waits for; the bar above says how many are
being ordered and how many are done.
- The account at the CA is made ready first, once: orders side by side would otherwise
  each make one of their own (after a new kind of its key, or one the CA forgot).
- One after another as before where side by side cannot work: DNS-01 by hand (the page
  shows one TXT record at a time), acme-dns (one subdomain for every name, the last two
  TXT records kept), the same name twice. An order gone wrong never stops the others.
- RSA and ECDSA of one name stay one after another: the second one uses the name the
  first one proved.
- Tested on the cluster of two (`tests/hasb/full/t_ha_acme.py`, 36 of 36): all three at
  once with the test CA slow to answer each challenge by 4 s - begun in the same second,
  done in 7 s, put in nginx on both nodes, RADIUS answering every time (708 of 708); and
  on one server (`tests/acme/t_acme.py`, 77 of 77).

## 1.0.202 — 31 October 2026

**The proxy: a switch for each thing that may go through it, all off by default**
(Settings → Proxy). Until now, switched on, everything otp asked of the web went
through it - ACME (Let's Encrypt, the deSEC, Cloudflare and acme-dns APIs) and the SMS
gateway too, so a proxy down or wrong stopped the certificates and the codes by SMS.
Now it is used only for what is switched on, each on its own:
- *The new versions of otp* (Upgrades), *The system updates (dnf, apt)*,
  *ACME: the CA (Let's Encrypt)*, *ACME: the DNS APIs (deSEC, Cloudflare, acme-dns)*,
  *The SMS gateway*. All of them off, it is used nowhere; the proxy itself is off by
  default. *Try it* tries the proxy, whatever is switched on.
- RADIUS, mail, Active Directory, the database, syslog, isemon, the backups (FTP, SFTP,
  SCP, SMB), the other node and the VIP address's check never go through it, nor does
  anything else otp asks.
- `http_proxy`, `https_proxy` and the like from the environment (`/etc/environment`, a
  shell) are dropped as otp starts - not taken by the VIP address's check, ACME, SMS or
  what otp runs (smbclient, nsupdate, openssl).
- A proxy switched on before: the new versions and the system updates go on through it,
  as they did, until changed; ACME and SMS go straight from now on unless switched on.
- Tested (`tests/siem/t_siem.py`, 54 of 54): each switch sends its own through the proxy
  and nothing else; off, nothing; none from the environment. (1.0.201 was not released.)

## 1.0.200 — 31 October 2026

**Automatic certificates: Order certificates now…** - one button above the cards opens a
window with every certificate asked for (each node's, the VIP address's): each with a
switch of its own, all on to begin with, and what it has now (from the CA, days left, the
last try failed, one put in by hand). The ones switched on are ordered from the CA one
after another, as *Order it now* on each card - after the account or the CA changed,
say; the progress says which and how far ("2 of 3"), and ACME renews each from then on.
Shown where there is more than one; from any node, as each card's own.
Tested (`tests/acme/t_acme.py`, 71 of 71).

## 1.0.199 — 31 October 2026

**Automatic certificates: a renewal refused after the account changed** - "Could not
validate ARI 'replaces' field :: requester account did not request the certificate being
replaced by this order". Since 1.0.196 each order says which certificate it renews
(ARI), and Let's Encrypt takes that only from the account that ordered it; another key
of the account (The key of the ACME account), an account made again or another CA is
another account. Now:
- the account that ordered a certificate is kept with it, and an order says it replaces
  it only from that same account;
- one the CA refuses all the same (a certificate of 1.0.196, whose account was not kept)
  is ordered again at once as a new one, and its steps say so.
- Tested (`tests/acme/t_acme.py`, 67 of 67): the test CA refuses as Let's Encrypt does.
  `docs/acme-ari-replaces-check.md` describes it for other projects that use ARI.

## 1.0.198 — 31 October 2026

**In your DNS** (Automatic certificates), as isemon draws it: over the whole width,
each column a share of its own, the copy button at the right of its text's cell.
What a cell says - *not checked yet*, *there* - no longer moves the others, after a
reload (F5) or Check DNS alike; a text too long for its column ends in "…" and shows
whole under the pointer. *Edit the columns* takes this table again: since 1.0.196 a
heading spread over two cells had left it out.

**Edit the columns, through the whole administration**: every table of the pages and
of the settings checked in a browser with editing on (`tests/ui/cols_audit.js`) -
22 tables: each has its grips, the menu on the right button over its heading and
over its rows, and a column carried to another place; the layout kept through the
card's own refreshes and a reload (`tests/ui/colskeep.js`). Left out, as they should
be: the tables of a key and its value, without headings.

## 1.0.197 — 31 October 2026

**Automatic certificates**:
- *What the last order did*: the time of each step in a column of its own, never
  broken in two (it took the room and stood "+ 1 s" one under the other), the step
  beside it from the left.
- *In your DNS*: the texts not wrapped - "its zone at deSEC", "the VIP address", a
  record - the table scrolls on a narrow screen instead.

## 1.0.196 — 31 October 2026

**Automatic certificates (ACME): every key Let's Encrypt takes, as upsmon has it**
(Settings → Automatic certificates):
- *The key of the certificate*: **Both: RSA 2048 + ECDSA P-256** (advised - the new
  default), Both: RSA 4096 + ECDSA P-384, or one key: ECDSA P-256 or P-384, RSA
  2048, 3072 or 4096. Both orders two certificates for the name - the second one
  only signed, the name already proven: nginx gets `ssl_certificate` twice, RSA
  (`otp.pem`) served by default, ECDSA (`otp-ecdsa.pem`) to the clients that take
  it. A certificate put in by hand on Certificates and TLS leaves the ECDSA one out.
- *The key of the ACME account*, new: ECDSA P-256 (ES256), P-384 (ES384), RSA
  2048, 3072 or 4096 (RS256) - never one of a certificate; a change makes a new
  account at the next order.
- Shown on the ACME card (*Keys*), beside the certificate's key, beside the account
  at the CA, and in the order's steps.
- Where the CA offers them: a profile asked for (classic, tlsserver, shortlived -
  6 days), and its renewal window (ARI, RFC 9773) followed - earlier than otp's own
  measure only, never later; each order says which certificate it replaces. The
  CA's Retry-After waited for.
- A key left at its default renews as **Both** at the next renewal (*Order it now*
  for it at once); one saved before stays until changed.
- Tested on the cluster of two (`tests/hasb/full/t_ha_acme.py`, 28 of 28) and on one
  server (`tests/acme/t_acme.py`, 62 of 62); the test CA uses a name proven before
  again, as Let's Encrypt does.

**In your DNS** (the ACME card): the copy buttons one under the other right after the text,
and still at each refresh - they jumped about, put in place only after the card was drawn.

**Upgrades**: *What root said last* folded until opened - a long log pushed the
rest of the page down.

## 1.0.195 — 31 October 2026

- **Backups to SMB**: "smbclient: ERROR: Could not determine network interfaces,
  you must use a interfaces config line" - Samba reads the network interfaces over
  netlink, and otp.service let the daemon open none (RestrictAddressFamilies), so
  smbclient stopped before it connected. otp.service takes AF_NETLINK; and where
  it is kept from it all the same (a hardening of one's own), smbclient is asked
  again with an interfaces line of its own, which it needs nothing more for.

## 1.0.194 — 31 October 2026

**Alerts: the database and its replication, and the VIP address, each a switch of
its own** (Settings → Alerts and reports):
- *The database and its replication*: the replication stopped, a node's database
  in trouble.
- *The VIP address (VRRP)*, new: the VIP address on no node or on both, a node
  whose keepalived says FAULT or is not running.
- Neither while the cluster is worked on - a node in maintenance, an upgrade, the
  system's updates, a restart - nor for 10 min after; the same outside of them is
  mailed. One mailed before is not said to be over because maintenance began.
- Tested on the cluster of two (`tests/hasb/full/t_ha_alerts.py`, 13 of 13).

## 1.0.193 — 31 October 2026

- **System updates**: "restart needed" / "restart after the update" on a line of
  its own on every node's card, always - not where the room ran out.

## 1.0.192 — 31 October 2026

- **The pages**: the tags at the head of a node's card (*System updates*: "this
  page", "16 waiting", "restart after the update"; and every pane with node
  cards) ran out of the card where there was no room; they go on to the next
  line, each whole.

## 1.0.191 — 31 October 2026

**SSH with a code: root let in - the real reason the code was refused**
- With root signing in with a key only (`PermitRootLogin prohibit-password`) and
  the code asked of root too, sshd handed PAM `"\b\n\r\177INCORRECT"` for
  whatever root typed - its guard against root's passwords - and every code was
  refused, whatever keyboard. Root gets a `Match User root` block of its own:
  `PermitRootLogin yes`, `PasswordAuthentication no`, a key and then the code -
  never a password alone, and no system password for root when otp does not
  answer. Each node writes its files anew once after the upgrade, by itself.
- *Hide the code as it is typed* (Settings → SSH server): the code asked with
  echo off (pam_radius `prompt_attribute`, RADIUS Prompt 0) - nothing shown as it
  is typed, as for a password. The SSH clients show no stars for it.
- A space after the colon of every prompt: the RADIUS words were trimmed on their
  way, and the code was typed right against the ":".

**Certificates: Download in the format wanted** (Settings → Certificates and TLS):
a window with the formats - PEM, PEM with the chain, DER, PKCS#7 - and with the
private key: PFX (PKCS#12, AES or 3DES for older Windows) or PEM with the key
locked. With the key always behind a password typed twice, full administrators
only, each an event. `otp --tls-export FORMAT FILE` on the command line.

## 1.0.190 — 31 October 2026

- **SSH with a code**: a code typed on the top row of a Czech keyboard without
  Shift (`+ěščřžýáíé` for `1234567890`) is read as the digits it meant - "794872"
  came to otp as "ýíčáýě" and was refused; digits of other scripts and spaces in
  it too. A code that is not digits says in its event which characters came
  (U+00FD …), so it is plain what the SSH client sent.
- **The pages**: a pane drawn again after a change - a switch on *SSH server and
  notices*, and every pane drawn the same way - jumped back up while it was
  drawn; it stays where it was scrolled to (`tests/ui/sshd_scroll.js`).

## 1.0.189 — 31 October 2026

**SSH with a code: why a code was refused, said** - a code mailed and typed right
was refused, with nothing to say why:
- Every wrong code is an event (*ssh*), not only the last, with why: the code
  typed is one sent at HH:MM:SS that ran out N s before (a mail that came late),
  none of the codes sent to the account in the last hour, or not digits at all
  (pam_radius sending it otherwise than read).
- The prompt says when the code went - *Type the code mailed to f\*\*\*\*@merit.cz
  (11:16):* - so the mail to look for is known when several came.
- A code that ran out, or was given up after three wrong ones: signing in again at
  once sends a new one (it was refused for 20 s, "a code went a moment ago"). The
  one still good is asked for again, as in 1.0.188.

## 1.0.188 — 31 October 2026

**SSH with a code: one prompt, and the code that came is taken** - tried with a
real sshd and ssh client (a key, then keyboard-interactive, as PuTTY does it;
`tests/sshd/t_sshreal.py`):
- No `Password:` before the code any more: pam_radius runs with `skip_passwd`, and
  otp's gate asks itself - *Code from the app:* for an app's token, or the code is
  sent by mail or SMS and asked for at once. A PAM block put in by an older
  version is given `skip_passwd` by itself on each node.
- The code mailed was refused when a later sign-in had sent another one - a mail
  that came late, the code from it typed. Every code still good that went to the
  account is taken now, each once.
- Signing in again within 20 s was refused (a code went a moment ago); the code
  already sent is asked for again instead, and no second one goes.
- The prompts end with ": " - the code typed was stuck to the words
  (`...@merit.cz590292`); an app's token keeps its language for its prompt too.

**The command line and the console: the rest of what the pages do**:
- `--siem-test`, `--proxy-test [URL]`, `--snmp-test`, `--snmp-trap`, and
  `--isemon-test` from every node, each answering for itself (`--node`: one).
- Encryption to the database server: `--db-tls`, `--db-tls-probe MODE`,
  `--db-tls-apply server|connect|server_off` (`--db-tls-mode`, `--db-tls-ca`,
  `--ca FILE`); to isemon: `--isemon-tls`, `--isemon-tls-probe`,
  `--isemon-tls-apply`, `--isemon-tls-off`, `--isemon-tls-bundle FILE`.
- Certificates: `--tls-csr CN`, `--tls-selfsigned CN` (`--names`, `--org`,
  `--days`), `--tls-forget`.
- `--ntp`, `--ntp-sync`, `--net`, `--hisec`, `--hisec-waive RULE on|off`.
- `--api GET|POST /api/... [BODY]`: any question of the pages, answered as JSON -
  run by the page's own code, with its checks and events; a body holding a secret
  only through stdin (`-`).
- The console: menu 13 (encryption, sending out, time, network, high security).
- What the command line asks of every node is done by each node's daemon - it
  was done a second time in the command's own process, which ends with it.

## 1.0.187 — 31 October 2026

**A cluster of two, tested as it runs: PostgreSQL replicated both ways and the
VIP address by keepalived (VRRP)** - five new tests (`tests/hasb/full`) on two
nodes, a prober asking RADIUS on each node and on the VIP address every 0.3 s all
the way through:
- signing in on node a, node b and the VIP address: a code from the app, the
  directory's password and a code, a code by e-mail and by SMS (a challenge, its
  answer on the other node too), realms by name and by alias, backup codes, a
  locked user locked on both nodes - 57 of 57;
- a daemon ended (the VIP address on the other node in 5 s), a machine off
  (4-5 s), maintenance (handed over, nothing lost) - 17 of 17;
- the link between the databases and the daemons' own connections encrypted
  (verify-full); a node's certificate near its end and the cluster's authority
  near its end, each renewed by itself, replication and every connection on TLS
  all the way, no request left unanswered - 32 of 32;
- the updates on a schedule and the restart on a schedule: one node at a time,
  never both down, the VIP address unanswered for 2 s at most, a code let in
  through it every time - 14 of 14;
- ACME for each node and for the VIP address: ordered by themselves, then,
  running out, renewed by themselves - the CA having forgotten its account
  meanwhile - each node's nginx files with them - 16 of 16.

What they found, put right:
- The link between the databases: the cluster's authority within two years of
  its end was looked at only when a certificate of the node that may make a new
  one ended soon. With only the other node's ending, no new authority was made -
  and that node, not allowed to make it, renewed nothing at all: its
  certificate ran out and replication stopped. The authority is now looked at
  all the time, a node not making it renews its own as ever, and making it
  failed is tried again the next day (it was the next month).
- A node that had just renewed its own certificate stayed on the old
  authority's when a new authority came meanwhile: it now takes the new one.
- ACME: an account the CA no longer knows (deleted, deactivated, a CA of the
  same address started anew) had every renewal refused, until the certificates
  ran out. A new account is now made by itself and the request asked again.
- ACME: a CA giving fewer days than `acme_days` (short-lived certificates, a
  test CA) had each new certificate due at once - ordered again every hour,
  until the CA's limits refused them all. Such a certificate is renewed at a
  third of its life.
- The web part of a node that could not be set up when the daemon started
  (nginx not there yet, a disk full) was never tried again until a restart: it
  is tried again every 15 minutes.
- keepalived's check of the VIP address gives it up at once when the daemon is
  gone (its lock file's process), and after 10 s of no word (20 before): a
  daemon that ended took the VIP address with it for up to 20 s.
- A new authority of the cluster has the minute it was made in its name: two
  made on the same day had the same name.

**The command line and the console: everything an operator needs without the
pages** - a review of both against the pages, with tests of their own
(`tests/cli/t_cli.py`, 152 checks; `tests/cli/t_console.py`):
- New: `--acme`, `--acme-order TARGET|all` (followed), `--updates
  status|check|start|cancel` (`--node A,B`, `--reboot ask|auto|never`),
  `--restart-nodes`, `--restarts`, `--mail-test`, `--sms-test`, `--ssh-tokens`,
  `--ssh-token-add` (the app's QR code shown once, or `--by mail|sms --to`),
  `--ssh-token-del`, `--lockouts`, `--lockouts-clear all|KIND:WHO` (on every
  node). The console has them in a menu of its own (12), and adds and changes
  realms and directories in a form.
- A secret is no longer taken written out on the command line (`ps` and the
  shell's history keep it): `--set KEY=-` asks for it (or reads one line of
  stdin, or `OTP_VALUE_KEY`); `--secret`, `--bind-pw` and the secret of
  `--radtest` take `-` only. The docs' examples that wrote passwords out are
  put right.
- `--enroll` under another suffix of a realm (novak@corp.local) made a second
  token beside novak@corp.cz - the one RADIUS looks up first, so the QR code
  shown never let anyone in. It is made under the realm's own suffix, as the
  pages do.
- Unlock (the pages, the command line, the console) gave the recovery codes
  back only in the process that was asked: each daemon kept refusing them from
  the places it had counted, for a day, and the other node of a cluster too.
  It is now marked in the database every node reads.
- `--add-realm --groups` emptied the replies of every group (Class,
  Filter-Id: the VPN's policies): a group it had keeps them.
- The second step of signing in switched on from the command line or the
  console left every sign-in to the pages open, as made with the password
  alone; it ends them, as the pages do. `--set-role` and `--disable-user`
  sign that account out.
- `--tls-import`: a certificate put in by hand is kept - ACME's next renewal
  replaced it - and one run out is refused, as on the pages. A TLS setting
  changed here is written in the events.
- `--settings --search` showed every setting; `--set` takes `--node` for a
  node's own setting of another node, or `*` for the cluster's own value.
- `--realms` cut the realm's other suffixes at 16 characters; the console did
  not show them at all.
- Who is locked out is written to the database on a server alone too (it was
  in a cluster only), for `--lockouts`.

## 1.0.186 — 30 October 2026

**Signing in: always answered, quickly, whatever else runs** - a review of the
whole way a RADIUS request goes, and of everything that runs beside it, with a
load test of its own (`tests/load/t_latency.py`, SQLite and PostgreSQL): one
request at a time is answered in 1.5 ms (SQLite) / 3.5 ms (PostgreSQL); at 150
requests a second, with the pages, the log, the events, Prometheus, a backup
every second, settings saved and the logs rotated with a SIGHUP every 3 s all at
once, half are answered within 2.3 ms and 99 in 100 within 14 ms (SQLite) - none
left unanswered, every one rightly let in or refused.
- `log()` never fails: a log rotated at night onto a full disk left a closed file
  behind it, and every RADIUS worker that wrote a line after it ended - one by
  one, the process up, nothing answered. A file that cannot be opened is tried
  again every 10 s.
- The journal is written by a thread of its own: a journald or a disk that
  stalled held every thread that logs, RADIUS's too.
- isemon's and the SIEM's sending can no longer end on an error (it stopped
  until a restart).
- logrotate's SIGHUP opens the logs again and nothing else when config.json is as
  it was - it emptied the caches RADIUS answers from and made the directories
  anew every night. A SIGHUP while the daemon still starts no longer ends it.
- A check of a code is written down after the answer went, not before.
- Accounting has a queue and workers of its own: a NAS restarted sends thousands
  of Stops at once, and the sign-ins waited behind them.
- An unsigned request with no password to read (none, CHAP) or one that decodes
  to nothing - anyone can send such from a NAS's address - is refused as before
  and written down once a minute a client, not each one a row.
- A repeat is answered outside the lock every packet takes.
- RADIUS's own database connections wait 2 s at most to be made (10 before).
- All the directories together hold at most all the workers but four: the
  realms of the code alone are always answered.
- SQLite: the hourly tidy's checkpoint no longer waits for the night's backup
  reading the file, with every RADIUS write behind it until it gave up.
- In a cluster: whether a code was used on the other node is asked on a few
  connections, 1.5 s at most, not at all while the other node is not heard from,
  and after a failure not for 20 s, then longer each time (5 min at most).
- Maintenance (the night's updates, a restart one at a time): the VIP address
  is given up at once, and RADIUS goes on answering while the address is still
  on the node (20 s at most) - it went silent for seconds before.
- What the node runs on (Settings → About) and its full name for ACME are found
  in threads of their own, not in the main loop - it was taken for gone by the
  other node when they took long.
- The check of a backup reads the copy of the database in a process of its own.
- Prometheus gets the same answer for 10 s, counted on the pages' connection.
- The alert *The database is in trouble* works: it was never sent (a call
  without its argument). Now: RADIUS on a node could not use the database in
  the last 5 minutes.
- A client's realm written with a dot at the end (`corp.cz.`) is taken without it.

## 1.0.185 — 30 October 2026

- The SNMPv3 tile of the Overview is gone again: SNMPv3 has its card where otp
  says what it lets in - *Settings → Firewall and access*, *SNMPv3* (its port,
  from where), there while SNMPv3 is on; its words now in Czech too.
- *Settings → Monitoring*: SNMPv3 first, Prometheus last - its settings and its
  card.

## 1.0.184 — 30 October 2026

- SNMPv3 switched on puts a tile of its own on the Overview, in a row under the
  others and as wide as they are: answered requests, the port, who asked last,
  the traps sent - red when it does not listen or the user is not set, orange
  when the last trap did not go; a click shows the rest and opens the settings.
  Switched off, the tile goes.
- The firewall lets SNMPv3 in by itself while it is on (from *SNMP only from*, or
  from everywhere) and takes the rule out when it is switched off - as it did in
  1.0.182, now tested and said: *Settings → Firewall and access* lists it among
  what otp lets in.

## 1.0.183 — 30 October 2026

**SSH with a code**
- *A key, and then the code*: sshd wants an SSH key and after it the code
  (`AuthenticationMethods publickey,keyboard-interactive`) from the accounts the
  code is asked of - a key alone no longer lets them in. Root as before unless
  *Root too*. A `Match User` block at the end of otp's drop-in, checked with
  `sshd -T` to reach nothing of the system's own settings, or refused.
- An SSH token by mail or SMS says its code in Czech or in English, chosen for
  each token (and the second prompt of ssh with it).
- The port of otp's gate for SSH is a setting of its own on *Settings → SSH
  server*, in a card with its words - it stood without them at the bottom of
  every page of Settings. Changed, each node listens on the new one and tells its
  pam_radius.

## 1.0.182 — 30 October 2026

**SNMPv3**
- Each node answers SNMPv3 itself - an agent of the otp daemon in a thread of its
  own, no snmpd: the system group, the engine's own objects and otp's (OTP-MIB,
  `deploy/OTP-MIB.txt`: RADIUS, the database, the tokens, the alerts, the
  certificates, the cluster, and every sample of `/metrics` as a table). Read
  only; GET, GETNEXT, GETBULK.
- authPriv only: one user, HMAC-SHA-256/-512/-1 and AES-128/-256, the two
  passphrases kept sealed. Each node an engine ID of its own, shown on the page.
  Only from the networks set; the firewall lets in those.
- Traps (SNMPv2-Trap, authPriv) from the node that sends the alerts: something
  wrong, right again, and a test one from the page; the receiver's
  `snmptrapd.conf` lines written on the page with the engine IDs.
- *Settings → Monitoring*: the settings, each node's agent (port, engine ID,
  asked and answered, the last asking), *Ask it* (the node asks its own agent as
  a manager would) and *Send a test trap*.
- `otp.service` may bind ports below 1024 (`CAP_NET_BIND_SERVICE`, nothing else),
  for 161 - `install.sh --upgrade` puts the unit in.
- Tested against pysnmp: discovery, GET, walk, bulk walk, every authentication
  with every encryption, wrong passphrases, an unknown user, traps received.

## 1.0.181 — 30 October 2026

**SSH with a code: SSH tokens of their own**
- The codes for SSH no longer come from the VPN's tokens: *Settings → SSH server →
  SSH tokens* - an account's name as on the nodes and an app's secret, made there
  (the QR code shown once), made anew, removed; kept apart as the second step of
  the administration is. In no realm, asked by no RADIUS client, not in the RADIUS
  log; every sign-in an event. A code is good once; five wrong ones in five
  minutes and the name waits five.
- An SSH token gets its codes from an app, or by mail or SMS where sending is set
  up: Enter at the first prompt of `ssh`, the code is sent and asked for in a
  second prompt (Access-Challenge); at most one every 20 s and five in 15 minutes
  per account. The mail and the SMS have words of their own (*Settings → Message
  texts → SSH*).
- pam_radius asks otp's own gate on 127.0.0.1 of its node - a listener of its
  own, in a thread of its own, with a secret of its own (sealed). Each node finds
  a free port for it in 18129-18199 (never the kernel's ports for outgoing
  connections, never one taken), remembers it and tells its pam_radius; the
  node's card shows it.
- From 1.0.178-1.0.180: the RADIUS client *SSH of the nodes - pam_radius* goes by
  itself and pam_radius is told the gate - make an SSH token for each account.

**Encryption to the database server: renewal said outright**
- The card and `docs/database-tls.md` say what was already so: the certificate
  is renewed by itself 45 days before it ends, while everything runs - a reload
  of PostgreSQL, no restart, the connections go on; in a cluster with the link's
  TLS, with the link's certificate. A server elsewhere renews its own.

## 1.0.180 — 30 October 2026

- More room around buttons, in every window and card: a row of buttons right
  under a field, a note or a table had it pressed against it, and what came after
  the row (the results of *Try it on every node* in the isemon wizard) stood
  right under it. A place that sets its own spacing keeps it.

## 1.0.179 — 30 October 2026

- isemon's *Send a test sign-in…*: Success or Failure is a switch, green or red
  with the word beside it - it was a box to type `s` or `f` into.

## 1.0.178 — 30 October 2026

**SSH to the nodes with a code from otp (pam_radius)**
- *Settings → SSH server → Signing in with a code from otp*: sshd of every node
  asks for a code from the account's token instead of its password, through
  `pam_radius` and the node's own RADIUS on 127.0.0.1 - both nodes and a node
  alone. otp installs pam_radius (EPEL on RHEL), makes the RADIUS client *SSH of
  the nodes - pam_radius* with a random secret, keeps that secret in
  `/etc/otp/pam_radius.conf` (0600, never on a command line), turns SELinux's
  `authlogin_radius` on and puts a marked block into `/etc/pam.d/sshd` - on
  trial like every change of the SSH server, taken out to the byte when switched
  off.
- Only some accounts, root in or out (out by default: a way in if otp is in
  trouble), and the system password when otp does not answer (`localifdown`;
  only with passwords on - under high security's *SSH: passwords* there is none).
- Each node's card says whether the code is asked there. How it works and what
  breaks it (a kernel with `ipv6.disable=1`): `docs/ssh-with-a-code.md`.

**isemon: a test sign-in isemon shows**
- *Send a test sign-in…* next to *Send a test line* on each node's card: a
  `totp.cgi` line in totpcgi's own shape (Success or Failure) under a name given
  (`otp-test` by default), its message saying it is a test from otp and the
  node - isemon shows it among the sign-ins. Sent to the receivers only, not
  into the node's files. The test line before is still there (isemon files it,
  but shows nothing of it).

**isemon over TLS: the wizard comes back after *Make the file***
- Saving the file for the isemon machine closed the wizard; it now opens again
  with everything as it was, to finish the settings.

## 1.0.177 — 30 October 2026

- A switch of another node stands right under the setting's own switch, its
  node's name after it - it stood off to the side, after the name (*A copy of the
  database every day* and every other switch of a node's own).
- The alert of a certificate running out says "VIP adresy" in Czech, as the
  pages do.

## 1.0.176 — 30 October 2026

**ACME: what is being waited for, said as it goes**
- While a certificate is ordered, the line above the cards says which one and
  what is waited for now - *Wait for DNS to carry it* (the seconds set), then
  deSEC's name servers (which have the record so far, how long), then the minute
  for deSEC's other places, with the seconds left. It said "waited 5 s for DNS to
  carry it" for minutes, as if the setting were not kept.

## 1.0.175 — 30 October 2026

**ACME by deSEC: the CA asked only once deSEC has the record everywhere**
- Let's Encrypt checks a record from several places of the world; deSEC's
  name servers are anycast, and a place they had not reached yet answered
  `During secondary validation: DNS problem: NXDOMAIN` - though the record was
  there. otp now asks deSEC's own name servers straight (not through a resolver,
  which would keep "not there" for the CA) until both have it, then waits a minute
  more, and only then asks the CA.
- Each certificate's card keeps what its last order did, step by step and when
  (*What the last order did*).
- The menu of the settings in order: *Monitoring* with the alerts, isemon and
  syslog; *System updates* beside *Upgrades*; the SSH server and root's SSH keys
  under *Access*; *Server* is the machine itself - network, proxy, time, high
  availability, restart, disks and logs.

## 1.0.174 — 30 October 2026

**ACME by deSEC with a domain of your own: where the way to the record stops**
- A domain of your own at deSEC (`acme.example.cz`) has to be delegated to it by
  the zone above it (NS records). *In your DNS* lists those records too, and
  *Check DNS* says whether the internet is sent to deSEC for it. Without them the
  CA answered `NXDOMAIN looking up TXT for _acme-challenge.NAME` though the record
  was there at deSEC.
- An order that fails so says where to look; *Check DNS* done with the machine's
  own DNS servers says that they may see what the internet does not, and to set
  *DNS servers for ACME* to public ones.

## 1.0.173 — 30 October 2026

**Prometheus**
- *Settings → Monitoring*: each node answers `https://NODE/metrics` in
  Prometheus' text format - RADIUS since the start (by what became of each
  packet), the requests of the last day, the tokens, the database, the cluster
  and its replication (running, errors, how far behind), the certificates of the
  pages and when they end, the mail queue, isemon and syslog, the alerts open now,
  high security. Asked with a token (`Authorization: Bearer`) made on the page,
  shown once and kept sealed; from the networks set only, where any are. The page
  shows the `prometheus.yml` with the nodes' addresses and what this node answers
  now. An upgrade puts `location = /metrics` into nginx's file by itself.
  `docs/monitoring.md`.
- The name of a setting that wraps onto two lines keeps its (i) and its node's
  tags on the last line, level with the boxes beside it.

## 1.0.172 — 30 October 2026

**isemon over TLS, the database's TLS and the link's each by itself, ACME beside your own certificates**
- *Settings → The database → Encryption to the database server* shows on the
  page: its calls were not let through by the pages' own proxy, so the card
  never came - and an answer that does not come is now said on the card.
- The daemon's own connection to its PostgreSQL and the link between the two
  databases (High availability) are encrypted and switched off **each by
  itself**, in any order: the connection gets a certificate from otp's
  authority where the link has none, uses the link's where it has one; the link
  switched off leaves the certificate where the connection uses it (renewed from
  then on by *The database*), the connection switched off leaves it where the
  link does; it goes from PostgreSQL only when neither uses it. The link no
  longer follows the connection's TLS settings. Tested on two replicating nodes in
  every order, with renewals, replication and RADIUS all the time.
- *Settings → isemon → Encrypted sending (TLS)*: the lines to isemon over TLS
  (6514/tcp, `host:6514/tls` in the targets), isemon's certificate checked. A
  wizard: where isemon is; its certificate - one otp's own authority makes for it,
  given once in a ZIP locked with your passphrase together with the rsyslog
  configuration (gtls) and the steps, or isemon's own CA's, or a public CA's;
  **mutual TLS** - each node shows isemon a certificate of its own, made and
  renewed by the node itself, so isemon takes lines from otp's nodes only; *Try it
  on every node* (connected, TLS, isemon's certificate, whether isemon kept the
  connection); *Switch over*. What to do on the isemon machine:
  `docs/isemon-tls.md`. A connection isemon closed (rsyslog restarted) is noticed
  before the next line, not after it was lost. High security: isemon over TLS only,
  its certificate checked.
- *Automatic certificates*: **DNS servers for ACME** - public ones (`1.1.1.1,
  9.9.9.9`) for everything on the page: the address of the CA and of the DNS API,
  *Check DNS*, *Try port 80*; empty, the machine's own. After the wait, the TXT
  record is looked for there before the CA is asked.
- A certificate of your own replaced by ACME is kept: **Back to the one
  before…** on its card (and on *Certificates and TLS*) puts it back, its key as
  it was; ACME then leaves it alone. The TLS settings (protocols, ciphers, DH,
  HSTS) are set on *Certificates and TLS* whoever gave the certificate, and kept
  through ACME's renewals.
- "The web address" is called **the VIP address** everywhere.
- The names of the settings: the tags of a node's own setting stay one block at
  the right, only the name wraps - the boxes along a row in line. The copy buttons
  of *In your DNS* right after the records, one under the other. An empty name of
  another node's certificate says the name it stands for.
- High availability on a PostgreSQL with other databases: the replication slots
  looked up in otp's database only.

## 1.0.171 — 30 October 2026

**Fixes to 1.0.170: secrets saved, the other nodes' values in line, the names**
- A secret saved on the settings pages (the deSEC or Cloudflare token, a
  password) stayed "1 change not saved" after *Save*: what was saved was not
  taken off the list of changes, and a secret, shown as dots once saved, never
  looked the same as what was typed.
- The other nodes' values of a node's own setting stand right under its box -
  along a row they are in line, whatever the words under each say.
- *The node's DNS name* (was "This node's DNS name"): empty, it says the name
  the certificate is for now; the other node's and the web address's are under
  the box, each changed from there. In *High availability* the names (isemon,
  syslog, the certificate) are with *What it calls itself*, an empty one said
  in words. "Empty: the cluster's value ((empty))" says it once.
- *In your DNS*: the copy buttons in line down each column.

## 1.0.170 — 30 October 2026

**Encryption to the database server, as a wizard; ACME beside Certificates and TLS**
- *Settings → The database → Encryption to the database server*: the daemon's
  own connection to its database encrypted and checked on every node, on the
  live database, nothing stopped - a card like the link between the databases
  (each node, its state, its certificate). PostgreSQL on the same machine is
  given a certificate from otp's own authority (reloaded, not restarted),
  renewed by itself 45 days before it ends and made again when the machine's
  names or addresses change; two nodes replicating use the cluster's
  certificate once the link between the databases is encrypted; a server
  elsewhere (or a node's PostgreSQL that another node shares) is checked with
  its authority given in the wizard, the system's, or otp's own. *Try it on
  every node* first; each move is tried apart, then switched, and put back at
  once if the first statement on the new connection does not go. Switched off
  the other way round. A connection on the same machine that stops working
  because of its TLS goes back to no TLS by itself, with an alert, so RADIUS
  keeps answering (not under high security). The link's TLS (High
  availability) cannot be switched off while the daemons' connections use its
  certificate.
- *Automatic certificates* and *Certificates and TLS* side by side: each
  certificate says who renews it. One put in by hand (uploaded, answered to a
  request, self-signed) is kept - ACME does not replace it, switched on or not -
  until *Look after it* or *Order it now*; a certificate from your own CA is
  never overwritten by switching ACME on. Its TLS settings stay as they are.
- Every certificate's name from one page: *Its name…* on each card - the other
  node's and the web address's too. Unsaid, the name is the one of the
  certificate it has now, or the full host name the node says of itself (the
  other node's card said "for –" and *Try port 80* asked `http://?/`).
  *Order it now* works for any of them from any node.
- DNS-01 by **deSEC.io** (free): its domain and an API token (sealed) - and for
  any DNS-01 way a zone of its own for the records (*The TXT records go into*),
  each name with one CNAME in your DNS, once: a domain whose DNS has no API gets
  certificates and renewals by itself. The card **In your DNS** lists what each
  certificate needs there - the CNAMEs, or for HTTP-01 where the names point -
  with the steps of the way chosen and **Check DNS**, looked up from the node as
  the CA will.
- A node's own setting shows the other nodes' values under its box, each
  changed from there - not only in *High availability*.
- High availability on a PostgreSQL with other databases: the replication's
  subscriptions and slots are looked up in otp's database only (the catalog is
  the server's - a second database's, or one left from before, was taken for
  otp's).

## 1.0.169 — 30 October 2026

**Automatic certificates, every node a card, the exceptions of high security**
- *Settings → Automatic certificates* (ACME, off until switched on): the
  certificate of the web address - and, where asked, each node's own -
  ordered from Let's Encrypt (or its staging, or a CA of your own: step-ca, an
  internal CA) and renewed by itself 30 days before it runs out. Checked by
  HTTP-01 - nginx sends port 80's `/.well-known/acme-challenge/` to acme.php,
  the answer kept in the database so whichever node has the web address gives
  it - or by **DNS-01** for servers not on the internet: RFC 2136 (nsupdate with
  a TSIG key, kept sealed, given in a file, never on a command line),
  Cloudflare, acme-dns, or by hand (the TXT record shown, the order waiting for
  *It is in DNS*). The account's key kept sealed; *Try port 80*; every order an
  event. In a cluster the web address's is ordered by one node, served by both.
- Every node a card, as on *Time*: *isemon*, *Syslog and SIEM*, *Disks and
  logs*, *Proxy → Try it*, the backups of each node and the directory's
  *Check* show both nodes, each with its state and what can be done on it.
  The tests are made on the node they are for - a test line to isemon or to
  the syslog servers, the proxy tried, the connection to Active Directory -
  asked once on the page, answered by each node.
- *Proxy → Try it* always tries - straight where no proxy is set or the
  address is in the list, through the proxy otherwise - and draws the way it
  went: this node, the proxy, the address; each step with its time (the name
  looked up, the connection, the tunnel, TLS and the certificate, the answer).
- *High security*: every rule can be made an exception with its switch - it
  then stops nothing and is not enforced; what was only advised (the second
  step of the administration, the key shown, short recovery codes, long
  sign-ins, direct mail without TLS...) is now a rule like the others. The
  security check (updates, certificates, backups) is listed apart.
- *Backups tried*: a card of its own, its gaps as every card's, with *Clear the
  list* and a cross on each try.

## 1.0.168 — 30 October 2026

**High security - and a whole backup not locked when chosen**
- *Settings → High security* (off by default): every way of doing something
  less safely switched off, on every node. It is switched on only once nothing
  stands against it: switching it on first looks over everything and lists
  what does, each with what to set and a link to where - and refuses until
  the list is empty. While it is on, all of it is refused wherever it is
  changed (the pages, the API, the command line) and greyed out on the pages:
  - a directory over plain LDAP, its certificate not checked, old weak TLS;
  - RADIUS without the Message-Authenticator (answers, and a client that sent
    one), without Sign-in protection; a client's secret under 16 characters;
  - mail to the server unencrypted or only if offered, its certificate not
    checked; direct delivery without TLS required;
  - the SMS gateway over http://, the telephone gateway without HTTPS or
    without checking its certificate;
  - the database or the replication without TLS that checks the certificate;
  - backups over plain FTP, FTPS not checking the certificate, SMB not
    encrypted;
  - syslog over UDP or TCP (only tls://), its certificate not checked;
    isemon (plain syslog);
  - the pages' TLS other than standard (ECDHE, AEAD) or modern (TLS 1.3);
    the administration reachable from everybody;
  - SSH with passwords, root with a password, more than 4 tries;
  - debugging, a window of codes wider than one step, a code used again;
  - tokens exported not locked.
  Advised beside it, stopping nothing: the administration without a second
  step from an app (or with one by mail or SMS), administrators showing a
  token's key, the enrolment page showing the key as text, recovery codes
  under 10 digits, codes by mail, enrolment for anyone, sign-ins to the
  administration over 8 hours or idle over 30 minutes, a proxy without a
  password.
- *Backups → Try the newest* (and *Try the backups*: by hand, after every
  backup, or weekly): the newest backup of the node fetched back from a
  destination, opened with the password, every file checked against its
  manifest, the database read to its last line and counted, the tokens tried
  against the key in it, config.json read - nothing is put back, the database
  in use untouched. The newest nightly copy is read through too. Each try is
  listed with every check, written down, and alerted when it fails.
- The security check: the *High security* page also lists, as advice, what
  is not as it should be now - the firewall off, no backup going to another
  machine or none ever tried, a backup that cannot be put back, security
  updates or a restart waiting, certificates running out.
- A restart on a schedule waits while an update of the system, or a node's
  look for updates after it, is still going on - it used to be given up for
  the day when its time came during an update.
- *Export and import → a whole backup (.json)*: locked with a passphrase as
  before, or - chosen at the export, and never under high security - not
  locked: a plain file otp reads back with no passphrase. The event says NOT
  LOCKED.

## 1.0.167 — 30 October 2026

**The .totp export locked with a passphrase - or, when chosen, not**
- *Export and import → .totp files in a ZIP*, and one token's *Export .totp*:
  locked with a passphrase by default - a ZIP with AES-256 (WinZip AE-2) that
  7-Zip, WinRAR, PeaZip and `7z x` open, and otp reads back. *Not locked* can
  be chosen: a plain ZIP, or one token's `.totp` file itself. Every export is
  an event that says which.
- *Bringing tokens over* reads locked ZIPs - otp's own and AES-256 ones made
  by 7-Zip or WinZip - and asks for the passphrase.
- The export now goes through a POST that carries the passphrase in its body;
  the old address of the download (a GET) is gone.

## 1.0.166 — 30 October 2026

**Syslog and SIEM, a proxy, the disks and the logs**
- *Settings → Syslog and SIEM* (off until switched on): every event and every
  RADIUS sign-in - who, from where, let in or refused and why, never the code
  typed - to up to 8 syslog servers or a SIEM, as RFC 5424 syslog over UDP,
  TCP or TLS (RFC 5425 framing, the server's certificate checked, a CA of its
  own given if needed); the message as JSON, CEF or RFC 5424 structured data.
  Each node sends its own from a thread and a queue of its own: a sign-in
  only puts a line in the queue, a server that is down or slow holds nothing
  up. What each node sent, what failed and what waits is on the page, with a
  test line to send.
- *Settings → Proxy* (off until switched on): an HTTP proxy, with a user name
  and a password kept sealed, for what otp asks of the web - the new versions,
  the HTTP SMS gateway - and for dnf or apt on every node, handed to the root
  helper in its request and to the update in a file only root reads, never on
  a command line. Names, domains and nets reached straight are listed; *Try
  it* asks an address through it. Mail, Active Directory, the database,
  syslog and the other node never go through it.
- *Settings → Disks and logs*: each node's disks, how much its system journal,
  otp's logs and otp's data take; the journal limited in size and age
  (journald.conf.d/00-otp.conf) and how many of otp's log files are kept and
  how big one grows (/etc/logrotate.d/otp) - put in by every node itself,
  again whenever changed, through its root helper (logs.ask).

## 1.0.165 — 30 October 2026

**Every table paged and held; restarts that never stop the service**
- Every table of the pages scrolls inside itself under headings that stay, and
  past 50 rows it is paged with the same buttons as every list - the clients,
  the realms, the accounts, the firewall's rules, the backups, the keys, the
  certificates, the histories and the rest. The page a table is on stays while
  it is drawn again by itself. The lists the daemon pages itself (the tokens,
  the log, the enrolments, the events, the outgoing mail) keep theirs.
- A setting that depends on one that is greyed out is greyed out too: *On the
  day* of a weekly restart, update, report or backup cannot be changed while
  the schedule itself is off.
- A restart one after the other - by hand, on a schedule, or after an update -
  never stops the service: it is refused while only one node answers; a node
  whose turn comes with nobody else answering stays up; one that does not
  restart and come back stops the rest; and a node is not restarted while the
  web address has not moved off it (waited for up to 90 s, not 20).

## 1.0.164 — 30 October 2026

**Updates and restarts on a schedule**
- *System updates → On a schedule* (off until switched on): a look for updates
  every day at a set time - for the cards, the alerts and the report, nothing
  put in - and the updates put in by themselves in a window: only the security
  ones (`dnf --security`, `unattended-upgrade` on apt) or all of them, every
  day, week or month, one node at a time as by hand, each out of service while
  it is updated, restarted by itself where needed or the restart offered.
- *Restart and power off → On a schedule*: the nodes restarted in a window, one
  after the other - only the ones an update left waiting for a restart, or all.
- One node starts each, once in its window; one that cannot start (a node
  down, something going on) is said in the events, not tried over and over.
- An update by hand can be the security updates only, too.
- *SSH server*: *Who may sign in* with names in it was refused on every node
  ("['root']" is not a user name) - it is put in now.
- A switch being switched (the console at login) no longer shows a checkbox
  over itself for a moment.
- *Outgoing mail*: 50 mails a page with the pages at the bottom; the counts,
  the search and the buttons stay where they are and only the mails scroll,
  under headings that stay. The alerts and the reports are named as such in
  it, not "a mail".
- The report as wide as its tables need (1000 px at least), and its window on
  the page as wide as the screen allows: no scrolling sideways.

## 1.0.163 — 30 October 2026

**The SSH server and the notices at sign-in; the alerts' and the report's language**
- *Settings → SSH server and notices*: root signs in with a key only, with a
  key or a password, or not at all; passwords on or off for everybody; the
  port; how many tries a connection has; who may sign in (AllowUsers). Put in
  on every node by its root helper as `sshd_config.d/00-otp.conf` - read
  before every other file - and checked by `sshd -t` first: what sshd does not
  take is not put in. Refused where root has no key and could not sign in any
  more; AllowUsers without root refused while root may sign in.
- A change is on trial on each node (5 min by default): unless *Keep it* comes
  in time, a timer of systemd's own puts back what the node had - with the
  daemon or the web down too. *Put it back now* does it at once. While a new
  port is on trial the firewall lets the old one in as well; SELinux is told
  of a port other than 22.
- The notice - often what a security policy wants said - before signing in
  over SSH (Banner), at the console (`/etc/issue.d`, or `/etc/issue` kept
  beside it) and after signing in (`/etc/motd.d`, or `/etc/motd`).
- The alerts and the report have a language each - Czech or English - or the
  mails' language.
- The report is wider and its tables' lines are neither cut nor wrapped.

## 1.0.162 — 30 October 2026

**Alerts by mail, and a report by mail**
- *Settings → Alerts and reports* (off until switched on): a mail when something
  is wrong - the other node not heard from, a node not listening for RADIUS,
  the replication stopped, the database in trouble, the nodes on different
  versions; a nightly copy that did not come, a backup that failed or none
  sent in time; a certificate running out; a disk filling up; a clock out of
  sync; security updates or a restart waiting; a directory out of reach; the
  SMS gateway failing; and, if wanted, each source Sign-in protection blocks.
  Mailed once it has lasted a few minutes, said again while it lasts (every
  24 h by default) and once more when it is over - laid out as cards, red for
  what is down and amber for warnings, with a link to the page to fix it.
- In a cluster one node looks at everything and sends - the first by name of
  the nodes heard from; when it is gone, the other node says so and sends
  from then on. Each node writes what only it can see (its disks, the
  directories it cannot reach, the SMS gateway, its nightly copy) into a row
  of its own every minute.
- A report by mail - every day, week or month, of the one that has just ended:
  the sign-ins by day as bars, who was refused (with how often, how often let
  in, and the last reason), why, who signed in most, the RADIUS clients, the
  blocked sources, the sign-ins to the administration, the events worth a
  look, the tokens (new, locked, idle), the servers (disk, clock, updates,
  nightly copy) and what is wrong now. Sent once for the whole cluster; it
  can be looked at on the page and sent at once by hand.
- The page shows what the alerts see now, each node's disks, the report and
  the mails that went; *Send a test alert*.

## 1.0.161 — 29 October 2026

**SSH keys of root: one place for a key of one's own, the key made not repeated**
- *A key for root* only makes a key now: *Use my own* is gone - a key of one's
  own is added in the list, where *Add a key* takes its public line or .pub
  file and also a private key (with its passphrase), of which only the public
  half is used and nothing else kept.
- After a key is made its public half is no longer shown again above the list:
  it is in the list, marked *made here*, exported or taken away there.

## 1.0.160 — 29 October 2026

**The updates' window cleared for good, each SSH key exported by itself**
- *Clear the window* in *System updates* empties the window of every node, in
  the database: for every page and after a reload too, hidden or shown - what
  a node says after it is shown again. Nothing is left behind it ("Hidden - 262
  line(s)" stayed).
- *SSH keys of root*: each key in the list is exported by itself - its public
  half as a .pub file named by its comment - from a button beside its bin, in
  place of the one export of all of them.

## 1.0.159 — 29 October 2026

**A key for root as isemon draws a router's, and the two new panes fixed**
- *Settings → SSH keys of root* has *A key for root*, drawn as isemon's key of
  a router: *Make a key* (Ed25519, or RSA 4096) and *Use my own* (a public line
  or .pub file, or a private key whose public half is worked out here), the
  public half below to copy. Unlike isemon it keeps no private half: otp never
  signs in as root, so a key made here is shown once, to download or copy, and
  one given leaves only its public half. In a cluster it goes onto both nodes
  (the same key) or onto one, as chosen; *Put it on again* puts it where it is
  missing. A key put there before stays until it is taken away in the list.
- The keys root has now are read from every node and listed with the ones made or
  given here marked; *Export them* saves them as one authorized_keys file (public
  halves only); *Add a public key* also reads a .pub file. A key that is there
  already is no fault.
- "Being written on…" no longer stays: a read again is not a change waiting, a
  node says what it has done after each change, and a change not done in five
  minutes is said as such. The root helper's service has no start limit any
  more - several asks in a few seconds left `otp-web.path` failed and every
  later ask unanswered; `install.sh --upgrade` clears such a failure.
- *System updates*: *Hide it*, *Clear the window* and the node buttons of the
  log work (the redraw waited for the clicked button to lose the focus); *Look
  for updates* is followed until the node says it is done, its log shown; the
  updates waiting are looked at again after an update and after its restart.
- *Look for updates* also tells whether the update will need a restart, before
  it is made - the packages it is for (kernel, glibc, systemd, linux-firmware…)
  on the node's card and above *Update* - and whether one is waiting already,
  which is then offered at once; a node restarted is looked at again.
- Room between the parts of both panes - the buttons beside a card's title no
  longer touch (*Hide it* / *Clear the window*, *Add a public key* / *Export
  them*) - and the choices as wide as their words.

## 1.0.158 — 29 October 2026

**SSH keys of root, and system updates, from Settings**
- *Settings → SSH keys of root*: the keys that may sign in to each node as
  root (`/root/.ssh/authorized_keys`), in one table with a column per node.
  A public key you have already is added to the nodes you choose; a new key
  is made here - Ed25519, or RSA 4096 - and its private half is shown once,
  to download or copy, and kept nowhere on the server. A key is taken away
  with two confirmations, and the last key of a node only when said again.
  RSA under 3072 bits, DSA and lines with options before the key are refused.
  The file is written by the root helper as 0600 root:root in a 0700 folder,
  never through a link; what sshd says (PermitRootLogin, keys, passwords,
  port) is shown beside it. Every change is in Events.
- *Settings → System updates*: what dnf (or apt) has waiting on each node -
  how many, how many of them security, the packages - and an update of all
  of them with a bar and what the package manager says as it goes (hidden,
  shown or cleared at will). In a cluster one node at a time, the other
  first: each is put into maintenance - the web address moves away and the
  other answers RADIUS - updated, and back in service before the next one
  starts. A restart an update needs is offered at the end (one node after
  the other) or made by itself, as chosen. An update is refused while an
  upgrade of otp, a restart or a power off is going on, or a node is not
  heard from; it can be stopped between nodes.
- The update runs outside the root helper's own service, under its own lock,
  so a long update holds nothing else up; RADIUS is never waited on.

## 1.0.157 — 29 October 2026

**The page's own panels only, and shorter words everywhere**
- No browser tooltip is left anywhere on the pages: whatever gets a title -
  drawn when the page opens or any time later - says it in the page's own
  panel, never beside it (the message texts' editor, the values of About and
  isemon, the language buttons of the enrolment pages had the browser's white
  box). The pictures of the enrolment pages keep their words for screen
  readers without a tooltip.
- A pane's opening words and a card's notes take three lines at most on the
  administration pages: a click opens the rest in place, and the whole is in
  the page's panel on the pointer. Warnings, errors, words with a link or a
  button in them and everything in a dialog are shown whole, and so are the
  enrolment pages.

## 1.0.156 — 29 October 2026

**Shorter words under the settings**
- Under each setting's box its words take three lines at most; a click on
  them opens the rest in place, and the whole is shown, as before, when the
  pointer rests on the setting's name or its (i). The settings pages were a
  wall of words.
- *Czech and Slovak letters in names* and *Letters of other languages in
  names* say what they do in one line; the rest is on the (i).

## 1.0.155 — 29 October 2026

**Letters in names: Czech and Slovak ones a setting of their own, both off**
- Settings → The tokens → *Czech and Slovak letters in names*
  (`names_czsk_letters`) and *Letters of other languages in names*
  (`names_any_letters`), both off by default: with both off, the names of
  people, tokens and accounts take letters without accents, digits, `. _ -`
  and `@` only; the first lets in á č ď é ě í ľ ĺ ň ó ô ŕ ř š ť ú ů ý ž ä,
  the second the letters of every language. Display names are never checked.
- Upgrading keeps everybody signing in: on its first start this version
  looks at the names of the tokens and accounts there, and where nobody chose
  the settings and names with such letters are there, it switches on what
  they need, and says so in the events. A new server starts with both off.

## 1.0.154 — 29 October 2026

**Letters of other languages in names: off unless switched on**
- Settings → The tokens → *Letters of other languages in names*
  (`names_any_letters`), off by default. Off, the names of people, tokens and
  accounts take letters without accents, digits and the letters of Czech and
  Slovak; a name with any other letter (Cyrillic, Greek, Polish ł, German ß or
  ö...) is refused - at the VPN before anything is asked, on the enrolment
  pages (said plainly), when a token or an account is made, and when an
  administrator from the directory signs in. On: letters of any language.
  A name that only looks like another (a Cyrillic а for a Latin a) is one way
  to pass for somebody.
- Upgrading: a token or an account whose name has such letters stops
  signing in until the setting is switched on.

## 1.0.153 — 29 October 2026

**Active Directory with Czech (or any) diacritics - checked, and two fixes**
- A person's groups (nested) are looked for from the root of the domain, as
  a group named without its place always was: with the directory's base set
  to the people's OU (OU=Uživatelé,...), every group kept beside it
  (OU=Skupiny,...) was missed - nobody was in any group, and every realm with
  groups refused everybody. Not a matter of diacritics: any base below the
  domain did it.
- An administrator from the directory whose account has letters beyond
  ASCII (žofie, žofie@corpnet.cz) can sign in: the account's name was
  refused. Account names take letters of any language now.
- Checked against a directory with diacritics in OUs, groups, names, a login
  name and a comma in a DN (CN=Novák\, Petr): RADIUS with the groups by name
  and by DN in any case, nested groups, reply attributes (Class = Uživatelé),
  the administrators' groups, the people search, the enrolment portal, the QR
  link and the token's mail - tests/cz/t_cz.py, 23 checks.

## 1.0.152 — 29 October 2026

**The Teltonika SMS gateway: one login at a time**
- otp keeps one login to the Teltonika and uses it again for about four
  minutes, as before; a new one is now made only after giving the one before
  back (RutOS `/api/logout`) - after it ran out, after a test on the pages, or
  when a send is tried again. A command on the server gives its login back as
  it ends. Before, each new login stayed listed among the box's sessions
  until it ran out by itself. Each node of a cluster keeps its own one.

## 1.0.151 — 29 October 2026

**The space between cards**
- A card drawn after a block of cards with a holder of its own (Network:
  *New settings* and *Taken back unless kept*) touched it: the space between
  cards now holds there too. Every pane and tab of the administration was
  measured for it.

## 1.0.150 — 29 October 2026

**Settings where they belong**
- *A new network goes back unless kept within* is on Settings → Network, and
  *A firewall change goes back unless kept within* on Settings → Firewall and
  access, each under *Taken back unless kept* - not on Sign-in protection.

**RADIUS keeps its pace while the server works**
- The daemon's copies of the database - *Back up now*, the copy before a
  restore or an upgrade, the backups sent to the destinations - are made by a
  process of their own (`otp --dump-copy`): made in the daemon, a big copy
  took a third of RADIUS's pace for minutes. Measured: 364 answers a second,
  none lost, p99 345 ms while a 700 000-row copy was made.
- RADIUS has four connections of its own to PostgreSQL and MariaDB (it had
  one): every sign-in waited for the one before it there, and one row held
  by a lock held them all.
- *Give the disk back* (VACUUM FULL, OPTIMIZE) in a cluster puts this node
  out of RADIUS meanwhile - the other node answers; alone, the page says that
  sign-ins wait for it.

## 1.0.149 — 29 October 2026

**Back up now on every node of a cluster**
- Settings → Backups → *Back up now* makes the backup of every node, as the
  schedule does: the node the page is on at once, the other within a minute
  (each node its own backup to every destination). A backup to chosen
  destinations only stays this node's.

**A deep look at security, failures and load: what was found is fixed**

*Security*
- The command line run as root (the root console's *What is in it* and
  *Put it back* on a listed backup among others) copied the file named into a
  folder already the otp account's: a link planted in the backups folder let
  that account read any file of root's, and one put into the folder during
  the copy had root overwrite any file. A file the otp account can reach is
  now opened by that account itself; any other is copied by its descriptors
  into a folder of root's, handed over only once it is filled. Going back
  below 1.0.149 is refused from now on.
- The console's *Upgrade this node from a package* runs a package through
  root's upgrade helper - its signature checked before anything of it is
  unpacked or run; a folder only when it is root's alone, said as unchecked.
  The console's live log no longer follows a link nor hangs on a FIFO.
- Root's helper changes pg_hba.conf, its copies and the database link's
  certificate in PostgreSQL's folders by descriptor, never by name: whoever
  runs as postgres could have pointed a name at a file of root's.
- A test of somebody's sign-in tries a person's password 5 times in 15
  minutes at most (it was 80 in 5); a test sent to another RADIUS server needs
  that server's secret - this machine's own is used for 127.0.0.1 only.
- The second step of the administrators' sign-in hands a new session once
  given; switching it on ends the other sign-ins already open. Errors say
  the directory's and the database's details only to an administrator past
  the second step.
- A remote backup destination moved to another server needs its password
  typed again: *Try it* sent the saved one to the new server.
- A realm keeping its tokens under the name alone - bare, or with the
  suffix `*` or none - next to such a realm of another directory is refused:
  one person's token signed in the other directory's account of that name.
- Recovery codes rest after 20 wrong tries from one place, and for everybody
  only after 100 from everywhere: a stranger who knew a name could switch off
  that person's recovery codes for a day.
- nginx without auth_request takes no upload over 32 MB (it took 4 GB from
  anybody on the allow list before the page could refuse it).

*Always answering, never refusing the right people*
- A database that is there but does not answer - locked, full, a statement or
  a lock wait run out - is now treated as one gone: no answer, so the VPN asks
  the other node. It refused everybody with a right code.
- RADIUS's own connection to PostgreSQL and MariaDB waits 8 s for a statement
  and 3 s for a lock (it was 120 s and 10 s): past that the request is left
  unanswered instead of holding every sign-in behind it.
- Putting a backup back puts the node into maintenance for the whole of it:
  the VPN asks the other node instead of waiting or being refused.
- A copy or a dump is not made when it would fill the disk under the
  database (128 MB and the database's size must stay free).
- Sign-in protection forgets places no longer counted, and publishes the
  blocked and the busiest 500 only: many IPv6 /64s grew memory and the list
  shared between the nodes without end.
- The first sign-in of a directory administrator in a cluster is made by
  one node only: on both at once replication stopped on a duplicate.
- A client that signs its requests is held to it also when the database
  does not answer just then (the request is not answered).
- A mail or SMS token put back from a token backup takes its recovery codes
  again.

*Under load, with a slow or half-dead directory*
- A directory server that takes the connection but leaves its searches
  unanswered is passed over for 30 s and the next server asked, as one that
  does not connect: it held every RADIUS worker, realms without a directory
  too, and the second server was never asked.
- One directory takes at most half of the RADIUS workers at once; a request
  past that is refused at once as the directory's trouble - a slow directory
  no longer stops the realms that do not ask it.
- A request waiting longer than 10 s (it was 15) is not worked on: the VPN
  has asked again or asked the other node by then.
- RADIUS's own connection to the database: PostgreSQL and MariaDB give up a
  statement after 5 s and a lock wait after 2 s, SQLite a busy file after
  3 s - then no answer, never a refusal.
- Old log rows are taken away 1000 at a time with a pause between, and
  SQLite's write-ahead log is cut back after it and kept under 64 MB.

## 1.0.148 — 29 October 2026

**The console at login: no "on" beside the switch**
- Settings → About → *The console at login*: the switch alone shows on or
  off; words beside it only while a node is being switched or has not said
  yet.

## 1.0.147 — 29 October 2026

**The console at login: saved with the save bar**
- Settings → About → *The console at login*: the switch only shows what it
  will be and waits on the save bar at the bottom, as every other setting -
  the node is switched by *Save the changes*, not at the click; *Put them
  back* takes it back.

**More bugs fixed**

*High availability*
- What one node does for both - the hourly tidying, the repair of the database link's
  certificates and a new authority for it when the old one nears its end, putting back a
  firewall change not kept - is now done by one node alone: the first by
  name of the nodes heard from. Both nodes used to write the row for it, and
  when both made it at once, replication stopped on a duplicate key.
- *Encrypt the link* and *switch it off* tell the other node only over a row
  it already has; a row new on both nodes at once stopped replication.

*Sign-in and codes (fixes of 1.0.146's own changes)*
- The count of wrong passwords per name could be got round on the pages'
  and the portal's sign-in with a name such as `a>CORP\novak` - each prefix
  counted on its own. Only the administrators' tests keep their own count now.
- Requests at the same moment no longer get more codes sent than
  `code_send_max`: the limit is checked again as the send is written.
- A number dialled at home with its 0 is never taken as one with its
  country code (`0491 12345678` with +49 stays +49 491 12345678).
- "The recovery codes are not taken for a day" is written also when two
  nodes counted past the limit at once.

*Network*
- A change of the network waiting for a restart that never comes is given
  up after an hour: checked where the new address is on the machine all the
  same, else the other node gets this one's address back, maintenance ends,
  and restart / power off and new changes work again. Telling the other
  node runs on the network's own thread.

*Backups*
- Putting a backup back keeps who is signed in now: the sign-ins in the
  copy came back with it - one signed out since opened the pages again.
- A settings file without the secrets keeps the key of the pages'
  certificate only where it belongs to the certificate in the file; beside
  another certificate nginx would not start. It says which came without it.

*Install*
- config.json of a new install is made with its owner and mode set on the
  open file, never by name - the otp account can no longer swap a link in
  between the steps.
- `--python PATH` and `--system-python` are remembered: the next upgrade -
  from the pages too - tries that Python first instead of the newest.

*Logs and SMS*
- An error of the minute's work (the upgrade, the web address, a new
  address, the cluster's history) is written once an hour while it stays
  the same, not every minute.
- An SMS gateway that answers with the text it was sent no longer puts the
  code into the events and the log.

## 1.0.146 — 29 October 2026

**A second deep look through the whole program: bugs fixed**

*RADIUS and the codes*
- Two nodes no longer write the same row for "a code was just sent" and the
  recovery-code guard: each node keeps its own row (`NAME@@NODE`), so
  logical replication never stops on a duplicate key.
- Sign-in protection: a single trusted IPv6 address trusts its /64 (requests
  are told apart by their /64); a directory that could not be asked is the
  server's trouble, not a guess, and is not counted against the place.
- A phone number written as `420603123456` (country code, no +) is no longer
  made `+420420603123456`.
- The Teltonika debug log no longer holds the text of an SMS with its live
  code.

*Realms, clients, directories*
- Taking away a realm that a client takes alone is refused (that client would
  have taken every realm); the import that replaces everything switches such
  clients off instead.
- A directory renamed keeps its realms (any case) and the administrators'
  sign-in directory; the one administrators sign in against cannot be taken
  away. Saving a client, realm or directory someone else just took away says
  so instead of making a new one; switches sent as text are read as on/off.
- Taking away an administrator account takes its second step with it - a new
  account of the same name starts without it.
- The command line keeps a client's, realm's or directory's on/off, position
  and timeout when it saves one again, writes those changes to the events,
  and no longer takes an abbreviated option for another.

*Pages and API*
- A request on a kept-alive connection no longer reads the previous one's
  body; a database fault says only "cannot be reached" to someone not signed
  in.
- Settings import: firewall rules of a node this machine does not have are
  left out (and said) instead of stopping the import; per-node settings are
  kept after the shared ones.
- Token files with a name `/` or `\` cannot be written (export and import
  quote it); token imports refuse names the program would not make.
- The firewall trial's first change keeps the rules as they were to go back
  to; a token administrator is no longer shown a firewall page that fails.
- Online upgrade: an address that does not answer, a package cut off or a
  check that takes too long is said, not an error 500. A package to go back
  to cannot be started from the pages once going back is switched off.
- Certificate lists (mail server, SMS gateway, directory): adding nothing
  no longer empties the list; only *Take all away* does.
- Moving a firewall rule up or down is written to the events.
- Network trial: a reboot the root helper did not answer is waited for, a
  failed job puts the other node's address back and leaves maintenance; a
  job stalled past its time is said.
- The portal says plainly when no way of getting codes is open for the
  account.

*Install, console, backups*
- install.sh writes config.json in place of a link only by replacing it;
  `--uninstall --yes` without a terminal refuses instead of doing nothing;
  Ctrl+C during an upgrade rolls it back as a failure; chrony's config is found
  on Debian too.
- The console: packet text shown without colour is made safe, the token list
  is no longer cut at 1000, *Install from package* checks the version in the
  package's otp.py; `--upgrade-follow` keeps its progress line.
- Old FreeRADIUS import: a `#` inside quotes is kept, a block inside a client
  (`limit { }`) no longer ends it, and one client it cannot take no longer
  stops the rest.
- The scheduled remote backup is not skipped for the day when the database
  was away at that minute; folders a stopped backup or restore left behind
  are taken away at start (6 hours old); SFTP/SCP to an IPv6 address works.

## 1.0.145 — 29 October 2026

**Going back: the list of versions tidied**
- Each version one row - the version and *yes* on the left, *What changed* and
  *Go back to X* side by side on the right; on a narrow screen the buttons go
  below as a whole instead of being squeezed.
- The versions it may not go back to are folded below, the reasons said once
  there, each version with a short word (*below 1.0.139*; the whole reason when
  the pointer rests on it) - a long reason no longer stretches every row.

## 1.0.144 — 29 October 2026

**Going back to an older version: switched on in Settings, with what changed**
- Settings → Upgrades → *Offer going back to an older version*
  (`upgrade_downgrade`), off by default: off, the pages show nothing of going
  back and the API refuses it; on, the card *Going back to an older version*
  is there. On the server, root can always: `otp --downgrade`.
- Each version in its list has *What changed*: what came in it, and - folded
  - what going back to it gives up, the versions after it up to this one.
  Read from the CHANGELOG.md installed beside otp.py (install.sh puts it there
  now), or from the package at the address where it is not there.

## 1.0.143 — 29 October 2026

**Going back to an older version - only a safe one**
- Settings → Upgrades → *Going back to an older version*, `otp --downgrade
  VERSION|FILE` (and `--downgrade-check`), the console's Upgrades → *Go back
  to an older version*. Never by putting the database back: the tables stay as
  they are, whatever their size, and the older version runs on them.
- Refused below the highest floor (`DOWNGRADE_FLOOR`, now 1.0.139) of any
  version that ran on this database (kept per node in the database) and of any
  installed on this machine (`/usr/local/lib/otp/downgrade-floor`, root's
  alone - the otp account cannot lower it, so the server cannot be taken back
  to a version with a fixed hole); and when the database has a NOT NULL column
  without a default that the older version does not know.
- The package is checked as an upgrade's; the nodes go back one at a time,
  each in maintenance, as in an upgrade. Root's helper puts an older version
  in only when going back is asked for, and never below its floor.
- The console's *Upgrade this node from a package file* refuses an older
  package and points to going back.

## 1.0.142 — 29 October 2026

**From the web: choose the version to go to**
- Settings → Upgrades → From the web: with more than one version at the
  address newer than the one running, a list beside the buttons lets you choose
  which one *Upgrade to X now* and *Only fetch it* take - the newest is chosen.
  With only one newer version the page is as before. Each is checked as before
  (its signature, every file); an older one is never offered nor taken.

## 1.0.141 — 28 October 2026

**The console at login, switched on the pages**
- Settings → About → The console at login: a switch for each node - on, root
  signing in at the machine's console or over SSH lands in `otp --console`;
  off, the ordinary shell. Full administrators; the node's own root helper
  writes /etc/otp-console-login (as `otp --console-at-login on|off` does), and
  each node says how it is within a minute - a change made on the command line
  shows too. Every switch is written in Events.

## 1.0.140 — 28 October 2026

**A network on trial goes back whole**
- Before a new network is put in on trial, the node keeps what it has: the
  root helper the connection's whole NetworkManager profile (every address -
  the second ones too - routes, MTU, DHCP or set by hand), the host name,
  /etc/hosts and the IPv6 switch; the daemon this node's own settings
  (radius_bind, mail_helo, isemon_hostname, db_host, ha_address) and the
  pages' certificate. Not kept in time, exactly that comes back - until now
  only the first address, the gateway and DNS were asked for again, and the
  certificate and settings were worked out again the other way round.
- A network from DHCP can be put on trial and go back too.
- Going back to a short host name (otp1) is no longer refused by the root
  helper.
- After the reboot - going back or not - the job checks and says, step by
  step: replication both ways, the link between the databases encrypted and
  checked (verify-full) on both nodes with this node's certificate naming its
  address, and the web address (keepalived) set up again.

**High availability**
- `otp --ha-setup` on a node whose daemon never ran yet made a bundle without
  the key that seals the tokens; the second node wrote an empty secrets.key
  and its daemon could not start. The key is made first now, and
  `--ha-join` refuses a bundle without one.

## 1.0.139 — 28 October 2026

**Remote backups are locked with the password you typed** (important)
- Until now the password of the backups was used as it is kept in config.json,
  sealed: the backups were locked with that sealed text, not with the password
  typed on the pages. They opened only on the machine that made them; on a new
  machine (`--restore-bundle`, the page, `openssl enc -d` as RESTORE.md says)
  the password did not open them. Now the password typed locks them.
- Backups made before 1.0.139 still open on the machine that made them (otp
  tries the old way too). **Make a new remote backup after the upgrade**: only
  that one opens anywhere with your password.
- A backup that is not locked is no longer put back where a password is in play
  (one set, or typed): otp never sends one unlocked, so it was put there by
  somebody else.
- SFTP/SCP: with both a password and a key with a passphrase, each prompt gets
  its own answer (the password went to the key, and the key failed). The SCP
  folder takes no characters a shell reads (use SFTP for those).

**Security**
- `otp --ha-setup`: db_name and db_user are checked before they are written
  into pg_hba.conf as root (a value with a space or a new line in config.json
  wrote a line of its own there).
- A token administrator can no longer make a token for a person who has one in
  use under another name RADIUS would then stop using (another suffix of the
  realm, or the same account in another realm on the same directory) - a full
  administrator's to do, as replacing a token is.
- Administrators' second step: a sign-in left waiting from before the account
  set its second step up can no longer set up its own over it.
- The command line and the console: names, reasons and attributes that came in
  a RADIUS packet are shown with their control characters as \xNN - escapes in
  them cleared the screen, set the title or wrote the clipboard of the
  terminal (`otp --log`, `--request`, the console's live views).
- Telling the other node a new address: where the link's certificate names the
  old address, the other node is reached checked by the cluster's authority -
  no longer unchecked, nor in the clear.
- `--add-client` without `--secret` no longer takes OTP_PASSWORD as the shared
  secret (it is OTP_SECRET). `--radtest USER CODE SERVER PORT -` and
  `--bind-pw -` ask for the secret instead of taking it on the command line;
  the help shows these.
- The directory sign-in test on the pages is counted (as a radtest is) and
  written in the events.

**RADIUS**
- A right code is no longer refused because a second answer to the same
  question (a retransmit, or the other node) counted a try meanwhile.
- RADIUS no longer waits for a page saving a setting while that page waits for
  a slow query (`client seen`, written once a minute a client).
- Moving to another database no longer takes RADIUS off its own connection for
  the whole move.
- The short pause after wrong codes works with `rate_limit_tries` above 50;
  sign-in protection works with `radius_guard_tries` above 1000 and
  `radius_guard_names` above 500.
- Sign-in protection: a Calling-Station-Id with a port (203.0.113.5:51234,
  [2001:db8::5]:51234) is counted as its address - it was a new place at each
  connection and never blocked. A code used once already (the same request
  sent to the other node) is not counted as a guess.

**High availability and the network**
- Going back after a network trial works when the old host name is a short one
  (it was refused, and the new network stayed).
- The firewall trial: the row its put-back is claimed by is made when the trial
  starts, by one node - made by both at the moment it ran out, it could stop
  replication.
- TLS between the databases: a password with a ? in it no longer breaks
  switching it on or off, and the password stays out of PostgreSQL's log.
- The change of the addresses and the TLS of the link no longer write over each
  other's request to the root helper.
- Putting a copy back that brings another key: the cluster's authority is
  sealed again with that key (it could not be opened after).

**Smaller**
- The console: letters with accents typed in its windows (passwords too) come
  out as typed; Delete on a token, replacing a token in use (asked first) and
  "Try it (and look somebody up)" on a directory work; a filter like
  `a{9999999999}` no longer closes it.
- `otp --tokens --limit=N`, `otp --request 0`, a port in `--radtest` that is
  not a number.
- A search such as `name:,` on the pages no longer ends in an error.
- A reload while config.json is missing keeps the settings in effect (it went
  back to the defaults).
- A body nested too deep is refused as not JSON, not an error.
- Restoring no longer leaves a file open each time.
- Putting a backup back from the page: up to 4 GB, as nginx takes.
- Czech texts that were missing: the enrolment sign-in, the notices when the
  daemon cannot be reached; two window titles showed &amp;.

## 1.0.138 — 28 October 2026

**New versions are looked for at https://github.com/falco81/OTP/tree/main/release**
- The default upgrade_url is the release folder of the OTP repository. A
  value saved as the old default (falco81/Utils/tree/main/otp) is taken as the
  new place; an address of your own stays as it is.
- That folder keeps the last ten versions.

## 1.0.137 — 28 October 2026

**Sign-in protection: guessing from one place blocked (RADIUS)** - Settings →
Sign-in protection, off by default
- Switched on (`radius_guard`), the place each VPN request comes from - its
  Calling-Station-Id, the address the person connects from - is counted:
  too many refusals from one place (`radius_guard_tries`, 20) or too many
  different names refused from it (`radius_guard_names`, 5) within
  `radius_guard_window_min` (15) and it is blocked for `radius_guard_block_min`
  (30). A blocked place is refused at once: nothing checked, and nobody's token
  counts its guesses - a guesser can no longer lock other people's tokens.
  `radius_guard_trusted`: addresses or networks never blocked. The server's
  own trouble (a directory away) is never counted.
- The table under it: every place counted and every token locked, how far each
  has got towards its limit (a bar that fills), how long a block still runs,
  the names tried; a filter by name or address; Clear one, the ones shown, or
  all. The same rows in Accounts → Locked out. Each node counts its own; both
  are shown and cleared.

**Changes that could cut the server off go back by themselves unless kept**
- A node's new network (`net_confirm_min`, 10 min) and a change of the
  firewall or of who may reach the pages (`fw_confirm_min`, 5 min) are put in
  on trial. A banner on every page counts the time down with *Keep it* and
  *Put the old back now*; `otp --change-keep net|fw [--node N]`,
  `otp --change-back ...`, the console (Cluster) and `otp --status` too.
- The network: not kept - or come up without its new address - the node goes
  back to its old network (a restart; the other node of a cluster told the old
  address again: its pg_hba.conf lets both in while the new one is on trial,
  and only the new one once it is kept). The firewall: the rules and the access
  lists as they were before come back on every node.
- The console's settings browser has the new group, and its main screen says
  when a change waits to be kept.

New: docs/sign-in-protection.md.

## 1.0.136 — 28 October 2026

A review of the whole application for bugs and security problems, with the
VPN's sign-ins - the reason otp exists - first: nothing else may hold them up.
Tested under load (RADIUS, the pages, backups, consoles and the command line
at once, and the database stopped for 17 s).

**RADIUS no longer waits behind anything else**
- RADIUS has a database connection of its own (chosen once per statement,
  never waiting for the main one while holding its own; a copy put back
  still holds RADIUS for the whole of it). With one connection for
  everything, a slow page held every sign-in behind it: just after a start,
  the uncached overview of a month took 29 s under load and the VPN timed out
  (160 of 166 requests unanswered). Now, with the same load plus the pages, a
  backup and three command lines running together: no request unanswered,
  p99 0.45 s.
- A database that does not answer is tried again at most every 2 s, not by
  every request in turn (one answer in 10 s, the queue full).
- The command line (and so the console) no longer makes the tables, indexes
  and triggers again on every run - on PostgreSQL that took locks every
  RADIUS write waited behind. Only when this node's database was not made by
  this version yet.
- `otp` runs imported, its compiled form kept: a command takes half the time
  (0.56 s instead of 1.2 s). The console asks for its status every 30 s, not
  at all while a live view, a page or a shell is open, and the web address
  every minute.
- Junk from a client's address with no Message-Authenticator and a password
  that cannot be read with its secret (control characters in it) is dropped
  and noted sparingly, not written down a row each (thousands a second could
  be sent). A password in another encoding than UTF-8 (cp1250) is still
  refused, not left unanswered.
- The narrowest clients of an address all switched off: the address is not
  answered - before, a wider range answered it with its own secret and realms.
  Of two of the same width, the one switched on answers.
- A refusal sent late (radius_reject_delay_ms) is given to the NAS's repeats
  once it went; before, the repeats got nothing and the NAS took the server
  for dead.
- An account's own entry in the directory (disabled, expired, locked) is kept
  15 s, not a minute.
- Codes are sent at most 8 at a time, at most 200 waiting: a mail server that
  hung no longer kept a thread per code without end.
- One housekeeping step breaking no longer skips the rest (backups, the time,
  tidying) with a traceback every 5 s.
- Under systemd only warnings and errors go to the journal as well as to
  otp.log - every line twice, and a slow journald held every thread that logs.

**Security**
- *Export with the secrets* (the pages) is locked with a passphrase made there
  and shown once; importing it asks for it (the command line too:
  `--passphrase-file` or `OTP_PASSPHRASE`).
- A backup of the tokens is always locked (a passphrase of 8 characters at
  least).
- Backups to other machines are never sent unlocked: without the backups'
  password nothing is sent and *Download one made now* is refused - unlocked,
  they hand the key of every token to whoever reads the destination.
- The second step of the administration: an account with mail or SMS codes
  that can no longer be sent is no longer set up anew by whoever has the
  password - it waits for a reset (Accounts, or `otp --reset-2fa NAME`). An
  app code used twice at once is refused the second time.
- The enrolment pages: a code typed back checks the token again - switched
  off, locked or confirmed meanwhile, it is not replaced.
- A test message to a token's phone: one in 30 s, ten an hour.
- The directory's errors (its server names, its TLS) go only to somebody
  signed in.
- The console's choice at login is kept in `/etc/otp-console-login`, where only
  root writes; `/etc/otp` is the otp account's group's, which could have put a
  link there for root to follow (a file overwritten) or a pipe (root's login
  hanging). Written beside it and renamed; read only as a plain file.
- Secrets off the command line, where `ps` shows them: the console's radtest,
  a client's secret and secret settings go by the environment
  (`--secret -`, `--set KEY=@env`, `--radtest NAME -`); install.sh's test
  client too; an SSH key's passphrase goes to ssh-keygen through SSH_ASKPASS.
- The replication password is kept out of PostgreSQL's log when the cluster is
  readdressed (as it was when it is made).
- A backup destination's folder or share with `;` or `"` in it, or one
  beginning with `-`, and an account beginning with `-`, are refused
  (smbclient takes `;` as the next command, ssh `-` as an option).
- A backup put back is unpacked only when it fits on the disk.
- `otp` is started with `python -I`: nothing from the folder it is run in.

**Fixes**
- An upgrade from the pages that hangs is stopped as a whole (install.sh and
  what it started), install.sh's own put-back runs first; before, the deadline
  never fired.
- The console's radtest can answer a challenge (codes by mail or SMS).
- A client changed on the command line or in the console stays switched off
  if it was.
- `otp --set` refuses `ha_*` and, without `--yes`, `db_*`, as the pages do;
  the console says where they are changed. `KEY=@env` without its variable
  set saves nothing.
- A backup from another machine put back is no longer refused at 32 MB: the
  guarded upload takes it (install.sh adds it to an nginx file that has the
  guard).
- install.sh no longer takes the otp account's write on /etc/otp away for a
  moment on upgrade.

## 1.0.135 — 28 October 2026

**The otp console: every menu by arrows and Enter, windows instead of prompts**
- Nothing is typed at a bare prompt any more. Every question is a window over
  the menu: fields moved between with Up/Down (Tab), choices (app / mail /
  SMS, a role, on / off) changed with Left/Right, passwords as stars only, the
  help of the field under them; Enter checks everything before it is run (a
  needed field empty, a number out of its limits, an address or e-mail that
  is none, two passwords not the same, a missing file - it says which and the
  window stays), Esc closes it. Deleting, switching off, putting a copy back,
  a restart, an upgrade ask Yes / No first, No unless chosen.
- Tokens, accounts, RADIUS clients, realms, directories and the backups kept
  here are lists to scroll (arrows, PgUp/PgDn, Home/End, scroll bar, `/` to
  find); Enter on one offers what can be done with it - for a token show,
  switch off / on, unlock, new recovery codes, try a sign-in, delete; for an
  account its password (twice, as stars), its role, off / on, reset its
  second step, delete; a client changed or deleted; a directory tried; a
  backup looked into or put back.
- A command's short answer comes in a window, a long one on the scrolled
  screen. Settings → Change one by its key opens the same window as Browse.
  Cluster → move the web address picks the node from a list; Upgrades → from
  the web lists what is newer, a version is picked, then the progress.
- New accounts and passwords go to `otp --add-user` / `--passwd` through
  OTP_PASSWORD, never on a command line.

**The live views: scrolled, and what is typed is a grep**
- The console opens on the live log, every line (Esc: the menu;
  `OTP_CONSOLE_START=menu` opens on the menu).
- The live log, the live RADIUS requests and the journal are a screen of
  their own: followed at the bottom, Up/PgUp/Home scroll back (paused, the
  new lines counted), End or Enter follow again, Left/Right along long lines,
  a scroll bar on the right; the last 20 000 lines kept.
- Typing filters the lines as `grep -i` does - any case, a regular
  expression or the text as it is - the hits marked; Backspace, Ctrl+U, Esc
  clears it and Esc again goes back. Keys typed quickly are no longer lost
  (the terminal was flushed at each key).

**Which node holds the web address, in the console's top bar**
- The bar shows `VIP 192.0.2.10 on nodeb` (or `VIP off`), and a red line under
  it when no node holds the address or two do. A narrow window shortens the
  bar (the tokens first) or puts it on the line below.

## 1.0.134 — 28 October 2026

**The otp console: long output on a screen of its own, settings changed in a window**
- A command's output longer than the screen opens on a screen of its own:
  arrows, PgUp/PgDn, Home/End (and Space, j/k, g/G) scroll it, a scroll bar on
  the right says where you are and how much there is, Esc / q / Enter go back.
  Drawn in one write a frame, so nothing blinks; a window made bigger or
  smaller is drawn again to its size. Colours kept; lines too long are cut at
  the edge rather than wrapped.
- *Settings → Browse and change*: every setting, in the groups of the pages,
  with its value (set ones bright, defaults dim) and key; arrows, PgUp/PgDn,
  Home/End, `/` to find (n: the next), and a scroll bar. Enter opens a window
  with what it is (its help), what it is now and as it comes, what it may be -
  a switch or a list chosen with the arrows, a number between its limits, a
  text typed (a secret as stars) - checked exactly as the daemon checks it
  before `otp --set` saves it; a wrong value says why and stays open.
- Lines and boxes drawn as UTF-8 characters (`NCURSES_NO_UTF8_ACS`), as PuTTY
  shows them; ASCII where the terminal is not UTF-8.

**Upgrades from the web on the command line and in the console**
- `otp --upgrade-check` looks at upgrade_url now and lists what is there.
- `otp --upgrade-online [VERSION]` fetches the newest (or VERSION), checks its
  signature, asks (`--yes`: does not), upgrades every node one at a time and
  follows it: a bar for the whole and one for each node, drawn again in place
  every second, with what each node is doing - in a cluster too.
- `otp --upgrade-follow` follows an upgrade going on (started anywhere);
  Ctrl+C stops the following, not the upgrade.
- The console's *Upgrades* has all three.

## 1.0.133 — 28 October 2026

**The otp console, checked through**
- The bar at the top said *THIS NODE IS IN MAINTENANCE* of a node in service:
  it took the maintenance record (`{on: false, …}`) for a yes. It now says it
  only when the node is, with why; another node in maintenance is named on a
  line of its own; and a daemon not answering is said in red. The cluster
  (nodes answering, replication) and the tokens in use are read as
  `otp --status --json` gives them - before, they were never shown.
- A question or a command's output starts on a clean screen - not under what
  the last command left there.
- *Make one (enrol)* asks how the codes come (app / mail / SMS) and where they
  go, as `--enroll --by --to` wants; *Move the web address* asks to which node;
  a question left empty goes back to the menu instead of running the command
  half asked; *Settings → Look* searches the help texts as well.

## 1.0.132 — 28 October 2026

**The otp console: Esc everywhere, colour everywhere**
- Esc goes back wherever the console waits: in a menu, in a question (what was
  typed is dropped), at *Enter or Esc - back to the menu*, and in the live
  log, the live RADIUS requests and the journal (q and Ctrl+C too). A password
  or a secret typed is shown as stars only.
- Every output in colour (colorama): each table's heading, and its cells by
  what they say (active, on, accept green; off, rejected, failed red; waiting,
  maintenance yellow; never, - and times dim; addresses magenta) - the colour
  never shifts the columns; every other line too: "key: value", addresses and
  times. The same for `otp ...` typed by hand on a colour terminal; JSON,
  `--no-color`, `NO_COLOR` and anything not a terminal stay plain.
- The live log starts from the end of the file without reading all of it.

## 1.0.131 — 28 October 2026

**The otp console: menus by the arrows**
- A text screen (curses): arrows or j/k, Enter or → to choose, Esc, ← or
  Backspace back, numbers to jump, Home/End, PgUp/PgDn, `!` a shell, `q` to
  leave. Only what changes is written - nothing blinks - and a window made
  bigger or smaller (PuTTY included) is drawn again to its new size. The bar
  at the top (version, machine, the service, node, cluster, tokens,
  maintenance, problems) is asked for every 20 s in the background. Arrows sent
  as ESC [ A by terminals that ignore the keypad mode work too.
- The live log in colour: the level, what it is about, addresses, accepted and
  rejected words, warnings and errors whole.

**Message texts**
- The save bar is at the end of the editor, as at the end of any other page:
  scrolled to the bottom it is there, and once something is changed it sticks
  to the bottom of the editor.

## 1.0.130 — 28 October 2026

**The otp console** (new: docs/console.md)
- `otp --console`: the whole of otp by its menus on the server's screen or
  over SSH - status and checks, the live log (coloured, filtered, following
  rotation), the live RADIUS requests, tokens, the administration's accounts
  and their second step, settings (search, change, export), RADIUS clients,
  realms and directories, the cluster, the web address and maintenance,
  backups, upgrades and the service itself. Each action is the `otp …` command
  it shows; `!` opens a shell and comes back, `q` leaves for the shell.
  Colour with colorama, English.
- It opens by itself when root signs in at the console or over SSH
  (`/etc/profile.d/zz-otp-console.sh`) - never for a command run over SSH,
  scp/sftp or a script. `otp --console-at-login on|off|status`; install.sh
  switches it on the first time and an upgrade leaves the choice alone.

**Settings, the menu on the left**
- Opened, it is exactly as tall as shut, item for item: a pointer that opened
  it over one item stays over that item (a longer name was wrapped onto two
  lines and moved everything below it).

**Message texts**
- The save bar is out of the way until something is changed, as below the end
  of any other page, and then at the bottom; the words above the editor are
  shorter.

## 1.0.129 — 28 October 2026

**Message texts: only the editor scrolls**
- The heading of the pane and the list of messages stay where they are; the
  editor on the right is the one thing that scrolls (its own bar), and the
  page itself does not - the save bar stays under it. On a low screen the
  list gets a thin bar of its own when it does not fit; under 900 px wide it
  is one column and the page scrolls, as before.

## 1.0.128 — 28 October 2026

**Message texts: one scroll bar**
- The list of messages and the editor no longer scroll each on its own: the
  page scrolls, and the list - shorter now, one line a message - stays in
  view beside the editor. The administration's four messages are a group of
  their own (*The administration*) under their short names.

## 1.0.127 — 28 October 2026

**The second step: by e-mail and SMS**
- *Send a code* on the sign-in page sent the code and then showed nothing -
  the page had no place for its message and stopped there. Now it says where
  the code went, right under the button, and the box for the code appears;
  Enter in the address box sends it.
- The codes have their own words, not the VPN's: four new messages in
  Settings → Message texts - *The administration: a sign-in code by mail /
  by SMS* and *…checking an address / a number* - with their own mail
  (band, greeting, what it is, the warning, the foot, the plain text) and SMS,
  in the language of the sign-in page.

**On the command line**
- `otp --admin-2fa on|off|status` switches the second step for every account,
  or says how it stands: the ways offered, who has set it up, who will at
  their next sign-in.

## 1.0.126 — 28 October 2026

**The second step fits on one screen**
- While it is asked, the sign-in page's picture and welcome line go; the ways
  are one row (App · E-mail · SMS), the QR code is smaller, and the code and
  its button sit side by side - as do the address or number and *Send a code*.

## 1.0.125 — 28 October 2026

**A second step for the administration pages** (new: docs/admin-second-step.md)
- `admin_2fa` (Settings → Accounts, off by default): after the password every
  account of these pages - local or from the directory - gives a code of its
  own (not a VPN token). The ways offered: an authenticator app
  (`admin_2fa_app`, the default), a code by e-mail (`admin_2fa_mail`, while
  mail is set up), a code by SMS (`admin_2fa_sms`, while SMS is set up).
- The first sign-in sets it up on the sign-in page: the app's QR code and its
  six digits, or an address / a phone number proved by a code sent there.
  Afterwards the code is asked each time; an app code is good once, codes sent
  at most every 30 s and five per sign-in. Until the step is given the
  sign-in can do nothing else, and the pages taking a file see no role.
- Wrong codes count as wrong passwords (Accounts → Locked out); every step is
  an event.
- Accounts: a column *Second step* and a button to reset it (the account's
  sign-ins end; it sets it up again at the next sign-in). On the command line
  `otp --reset-2fa NAME`, and `otp --users` shows the column.

## 1.0.124 — 28 October 2026

**A password being typed is dots only**
- Everywhere a password, a passphrase or a secret is typed (settings, the
  directories, the clients' shared secrets, backups, the database with its
  key, the load balancer guide…), only dots are shown while typing - not the
  last two characters. Those show only on one that is kept, as the daemon
  sends it (dots and its last two), after a save or when the page is opened.

## 1.0.123 — 28 October 2026

**Refreshing by itself never takes anything from under the person using the page**
- A list opened, a box typed in, a switch just turned, the mouse held down on a
  button, a help panel being read or words selected: the card it is in stays
  exactly as it is (the same elements, never taken out of the page - a list
  taken out closed), and everything around it is drawn new. A card whose shape
  changed meanwhile is drawn the moment it is left. What was changed and not
  saved goes over into a card drawn again; folds left open stay open.
- Everywhere a pane refreshes itself: Time, Network, Restart and power off,
  Lockouts (every second), High availability (nodes, checks, replication, the
  addresses, each node's own settings, the web address), Certificates and TLS,
  Firewall and access, Outgoing mail, Upgrades. Before, some stopped refreshing
  altogether while a box had the focus; others closed an open list.
- Overview, Log and Events wait while a box drawn in them is being used (no
  longer only half a minute).

**One save bar, at the bottom, where something is saved - and only there**
- Shown on every pane with a setting, and on Firewall and access, High
  availability (the web address), Time, Message texts and the enrolment pages'
  looks; never on a pane that does things at once (Network, Restart and power
  off, Backups' jobs, Export and import…). It no longer turned up on Network
  now and then (its form looked like settings) and went with F5.
- Time: the time servers are saved with the bar (was a button of their own).
- Message texts: saved and thrown away with the bar (were buttons of their
  own); Ctrl+S presses it.
- High availability: *Save the new addresses* is *Change the addresses* - it
  does it at once.

**The database: downloaded with its key, and put back with it**
- *Download* (a kept copy or dump) and *Download it* / *Download one* (made
  now) ask: **with the key** - one `NAME.with-key.tar` holding the copy or dump
  and the key that opens its tokens, locked with a passphrase given there (10
  characters at least; the lock of the cluster's bundle) - or **without** it.
  Before, a dump never had the key and a copy only while showing keys was on.
- *Restore from this file* takes such a file: it asks for the passphrase,
  shows what is in it, and puts back the database and its key together - as a
  job the page follows (a big database took longer than the page waited).
  The passphrase never goes into an address: the file is made first and
  fetched with a ticket good for ten minutes, once.

**Upgrades from the web**
- *Settings → Upgrades → From the web*: `upgrade_url` (default
  https://github.com/falco81/Utils/tree/main/otp - a GitHub folder, a page or
  listing linking to packages, or one package) is looked at once a day
  (`upgrade_check`) and on *Look now*. A newer `otp-X.Y.Z.tar.gz` is offered:
  *Upgrade to X now* fetches it, checks its signature like a package sent by
  hand, and upgrades the nodes one at a time; *Only fetch it* stops before.
  Nothing is put in by itself. docs/upgrades.md.

**Hide this**
- On what is over and only says how it went: a restart or power-off (it went by
  itself after half an hour), an upgrade, a job on the database or of the
  cluster (the bar stayed until F5), a test mail, the SMS gateway's test, a
  try of a backup destination.

## 1.0.122 — 28 October 2026

**install.sh: chrony**
- On a fresh install and on every upgrade (also one started from the pages,
  node by node in a cluster), chrony is installed where it is missing,
  systemd-timesyncd is stopped if it runs, chronyd is enabled and started and
  `timedatectl set-ntp true` is set. The machine's own /etc/chrony.conf
  (AlmaLinux's pool) is used as it is; without any time server in it the
  installer says so. Before, Settings → Time showed *chrony is not
  installed* until otp was told to set the time servers.

## 1.0.121 — 28 October 2026

**The web address (VIP) after a node's address is changed**
- After Settings → Network changed a node's address, keepalived on it could
  stay *not well* (*no interface here holds …*) until *Try again* was pressed:
  its part was asked of root before the restart, when the machine did not
  have the new address yet, and a failed request was asked again only by hand.
  Now:
  - the interface for the web address is found by the web address's network
    when none holds the node's own address (yet);
  - the change of network asks for the web address again after the restart
    and waits for it (a step of its own: *the web address (keepalived) set up
    for …*) before the node comes out of maintenance;
  - a request that failed before a restart is asked again once by itself
    after it.

## 1.0.120 — 28 October 2026

**Settings → Time** (new: docs/time.md)
- Each node's clock as chrony sees it: how far off the time servers, synchronised
  or not, the source it follows, stratum, last correction, frequency, root
  delay and dispersion, leap status, time zone and its own time; how far apart
  the two nodes are; every source with its state, stratum, poll, the last eight
  tries, when last heard and its offset. *Step it now* (chronyc makestep).
- The time servers for the whole cluster, when otp is to set them: servers and
  pools with iburst, prefer and NTS; the two nodes as sources for each other;
  makestep, minsources, the networks the nodes serve the time to (opened in
  the firewall by itself), the time zone. Each node writes them into
  /etc/chrony.conf between marks (the file's own lines commented out, and put
  back when otp stops setting them) and restarts chronyd.
- A clock not synchronised, or more than a second off, is a problem on the
  overview and in otp --status.

**High availability → Each node's own settings**
- Says where the rest of a node's own setup is: its network, IPv6 and host
  name in Settings → Network (IPv6 on makes RADIUS listen on :: by itself),
  its clock in Settings → Time.

**Settings, the menu**
- In groups that say what is in them: RADIUS, Tokens, Mail (Mail, Outgoing
  mail), Access (Accounts, Certificates and TLS, Firewall and access), Server
  (Network, Time, High availability, Restart and power off), Data (The
  database, Backups, Export and import), Monitoring and updates (isemon,
  Upgrades, About) - not everything under "This installation".

**Settings → Network**
- A finished change (*The network of … is changed*) has a *Hide this* button,
  and goes by itself 6 hours after it was done (a day when it failed) - it
  stayed for a day before.
- *The web address is meant to be in another network* is shown only when the
  new address is outside the web address's network, with why it matters.

## 1.0.119 — 28 October 2026

**Settings → Network** (new: docs/network-and-power.md)
- Each node's IPv4 address with its prefix, gateway, DNS servers, search
  domains and host name (FQDN), as NetworkManager has them, read on either
  node's pages; and a form for new ones. *Check it* lists what will happen.
- *Change it and restart* is done by the node itself, followed on the page step
  by step with a progress bar: in a cluster the other node is told the new
  address first (its pg_hba.conf, its subscription, its ha_peer), this node's
  ha_address, the settings that named the old address or host name (RADIUS's
  address, the mail greeting, the isemon name) and its own certificate where it
  was made here are made again, maintenance moves the web address to the other
  node, NetworkManager, the host name and /etc/hosts are set and the node
  restarts. Back up it checks its new address, replication both ways and the
  link between the databases (its certificate made again for the new address),
  and comes back into service by itself. The node keeps its name in otp
  whatever the machine is called (pinned in config.json first).
- IPv6 (dual stack), switched on per node: by hand or automatic; RADIUS listens
  on IPv4 and IPv6 (::), nginx answers on both, the firewall covers both.
  Replication between the databases stays on IPv4. The web address takes an
  IPv6 address of its own (High availability → …and its IPv6 address), moved by
  the same VRRP instance (virtual_ipaddress_excluded) and listened on by nginx.
- A page whose own node restarts waits for it, counting; where it was opened
  at the node's old address or name, it goes to the new one.

**Settings → Restart and power off**
- Restart or power off this node, the other, or both: one after the other (each
  in maintenance while it restarts - RADIUS and the pages never stop), both at
  once, or both switched off. Each node does its own part when its turn comes,
  so either node's pages follow it: going down, restarting, up again, with a
  countdown; the page reloads when its own node is back.

**RADIUS**
- Listening on :: where IPv6 is switched off on the machine falls back to IPv4
  (0.0.0.0), said in the log, rather than listening on nothing.

## 1.0.118 — 28 October 2026

**RADIUS**
- The second request of a sign-in with a second window (the code typed after a
  code by mail or SMS, or asked for from the app) shows what the first request
  checked: *checked with the first request (ID): found CN=…; the directory
  password; a member of CN=VPN,…*. The account, its password and its groups are
  checked once, in the first request - for a realm's own suffix and its other
  suffixes alike; the second carries only the code.

## 1.0.117 — 25 October 2026

**One person, several suffixes** (new: docs/realms-and-suffixes.md)
- A realm takes other suffixes too: *…and also the names ending in @*
  (`otp --add-realm NAME --aliases a.local,b.cz`). `novak@dpmo.local` is then
  the token `novak@dpmo.cz` - in RADIUS, on the enrolment pages and in *Make a
  token*. Looked up by UPN, the name is tried under each of the realm's
  suffixes.
- Tokens made under such a suffix before go on working; the realm's editor lists
  them and *Move them under @…* renames them (key, recovery codes, history),
  leaving any that would land on a token already there.
- Fixed: the enrolment pages kept using a token the same account had in another
  realm on the same directory (signed in as falco@dpmo.local, the token
  falco@dpmo.cz), and RADIUS then refused falco@dpmo.local - *No token is
  enrolled*. RADIUS now finds that token too, where both realms read the same
  directory by sAMAccountName, and the decision says so.
- Writing another realm's suffix as one of a realm's own offers to take that
  realm in, in one step: its suffixes, its groups (after the realm's own), the
  clients allowed it.
- The list of realms shows the other suffixes under the one each takes.

## 1.0.116 — 25 October 2026

**Who is locked out** (Settings → Accounts → Locked out)
- Also what the database counts for every node: the codes sent to a person or
  an address ("too many codes were sent") and tokens locked after wrong codes -
  how many of how many, the time left, *Clear* one or *Clear them all*. Written
  into Events.
- "too many codes were sent - wait N min" says how long is really left, not the
  whole window.

## 1.0.115 — 25 October 2026

**The enrolment pages**
- Replacing a token with a confirmation asked for: *Cancel - keep the old
  token* right under the new one. The new token is thrown away; the old one and
  its recovery codes stay as they were (written into Events).
- The page says what leaving it does: nothing - the old token goes on working,
  and the next sign-in shows the new one waiting, to confirm or throw away.
- *I want to get my codes another way* on a line of its own, not glued to the
  button beside it.

## 1.0.114 — 25 October 2026

**The enrolment pages**
- *Your recovery codes*: the box for the code looks like every other box on the
  page - a field with its label, half the card wide, the button to send a code
  beside it, as tall as it.
- The words under a token of codes by e-mail or SMS are in Czech too.

## 1.0.113 — 25 October 2026

**Codes by SMS** (docs/codes-by-mail-and-sms.md, "When a code does not arrive")
- *Test the connection* under the Teltonika gateway: signs in with what is
  saved and lists its modems - operator, network, band, signal (quality, RSSI,
  RSRP, RSRQ, SINR), the SIM, which modem sends the codes - with how long each
  step took. Nothing is sent. Written into Events.
- A sign-in the Teltonika leaves unanswered ("The read operation timed out") is
  asked again once by itself; a send is still never repeated.
- New debug switch *...every code sent by e-mail and SMS* (on with *Debug
  log*): every request to the SMS gateway and its answer with how long it took,
  how long a code waited for the one before it, every line of the conversation
  with the mail server. Passwords, the gateway's token and the messages are
  never written.

**The enrolment pages**
- The name at the top opens *About you*: what the directory said at sign-in -
  the name, account and UPN, e-mail, mobile and phone, department and job
  title, the realm and the groups of it that let the person in, when the
  account ends and when the password was set, and their token.
- *People may look at their recovery codes again* (Settings → The enrolment
  pages; off unless switched on): after signing in, a card shows the person's
  recovery codes - the used ones crossed out - once they type a code from the
  token (the app's, or one sent to them now). The directory password alone
  never shows them. Each look is written into Events.

## 1.0.112 — 24 October 2026

**Who is locked out** (Settings → Accounts → Locked out; docs/operations.md, section 18)
- Every address and name with wrong attempts still counted - signing in to
  these pages or the enrolment pages, codes typed there, password changes, the
  tests: locked out (with the time left, counting down) or still counting
  (how many of how many, and when they are forgotten), which names were tried
  from an address and from which addresses a name was tried, on which node.
- *Clear* forgets one; *Clear them all* forgets every one, on every node. The
  other node clears its part within five seconds. Both go into Events.

**Realms**
- The list always shows what people may choose: a realm of the app alone showed
  no tag at all, as if it had lost it.

## 1.0.111 — 24 October 2026

**Backups**
- *How to put it back* (Settings → Backups): the RESTORE.md every backup
  carries, as a backup made now would have it - read on the page (each command
  with a copy button) and *Download RESTORE.md*, to keep apart from the backups.
  No secret is in it.

## 1.0.110 — 24 October 2026

**Two machines with one name** (docs/renaming-and-readdressing.md)
- Fixed: a node could take the other node's name. The settings page drawn by
  otp2 was saved through the web address after it had moved to otp1: measured
  against otp1, otp2's name in the box looked like a change and otp1 saved it.
  Both then wrote one heartbeat - the other was *gone*, the web address *on both
  nodes at once*.
- A machine's own settings (its name, its database) are saved only on the node
  the page was drawn by; any other node refuses them (409, nothing saved). A
  node's own setting saved from the page goes to the node that drew it.
- When another node answers than the one that drew the page, the settings are
  drawn again from it, and the page says so.
- A name another node is answering with is refused (pages and `otp --set`).
- Every heartbeat carries the machine it came from: two machines with one name
  are said on every page (problems), in `otp --ha-status` and in the log.
- A restart under a new name carries nothing over when another machine is
  answering with that name.
- Fixed: after the web address moved, the save bar could count changes nobody
  made (the boxes of one node measured against another's values) and save
  them.

**Backups**
- *What was sent* can be cleared (*Clear the list*), or one line taken off it.
  The backups themselves stay where they went; Events says who did it.

## 1.0.109 — 24 October 2026

**Backups to another machine** (Settings → Backups; new: docs/remote-backups.md)
- One file brings any loss back - one server or a cluster, onto a machine
  installed from nothing: the whole database (tokens, clients, realms,
  directories, accounts, every setting, the certificates and keys of the pages,
  the web address, the firewall, the texts, the authority of the database link,
  the logs), the key that opens the tokens, this machine's config.json and the
  files it names, a manifest with the SHA-256 of each, and RESTORE.md - the exact
  steps, filled in with what the backup is.
- Locked with *The password of the backups* (kept sealed in the settings;
  *Make a strong one*): AES-256-CBC, PBKDF2-SHA256, 600 000 rounds - opened by
  otp, or by openssl alone on any machine. RESTORE.md and a .sha256 go beside
  it, not locked.
- Destinations, as many as needed: a folder (a mount), FTP, FTPS (explicit or
  implicit; the server's certificate checked against the system's authorities,
  an authority of your own or a pinned fingerprint; a client certificate made
  here or brought as PEM or PFX), SFTP and SCP (OpenSSH; an ed25519 key made
  here or your own with its passphrase, an SSH certificate, or a password; the
  server's host key trusted once and checked after), SMB (account, domain,
  SMB3 encryption). Keys and certificates as on isemon: Make, Use my own,
  Download (written into Events), Forget, the public half to copy with the line
  to run on the server. *Try reaching it* signs in, writes a file, finds it and
  takes it away again.
- *Back up now*, *Download one here*, a schedule (daily or weekly, at a time),
  how many are kept at each destination and for how long; each node of a
  cluster sends its own. *What was sent* lists every backup and what each
  destination said.
- Putting one back: from a destination's list, or a file sent from the page,
  or on the command line - `otp --restore-bundle FILE [--yes]` on a fresh
  install. A copy of what is replaced is made first.
- Command line: `otp --rbackup-now`, `otp --rbackup-status`,
  `otp --restore-bundle`, `--passphrase-file`, `--keep-node-name`.
- install.sh installs openssh-clients and samba-client for them (best effort).

**A test SMS that takes long says why**
- *Send a test* on a token's card and the test SMS in Settings count the
  seconds on the button while they wait, and the answer says how long each
  step took: signing in to the Teltonika, finding its modem, and the modem
  sending it - RutOS answers only once the modem has given the SMS to the
  network. Sign-in codes were never held up by it: they are sent in the
  background.

**Message texts**
- The list of messages stays where it is; only the editor beside it scrolls.
- Czech for the page's description and "When the name is not known".

## 1.0.108 — 24 October 2026

**The web address said "on no node" while a node held it**
- VRRP was working - keepalived moved 192.168.42.34 as it should and the
  table of nodes said *holds it* - but the card above it said *on no node*.
  1.0.106 brought a second function of the same name as the one that tells
  which addresses this machine has; it took the old one's place everywhere,
  could not run `ip` from the service (no /usr/sbin in its PATH) and answered
  "none". The old one (it reads the kernel's own list) is back; the addresses
  card has a function of its own name.

## 1.0.107 — 24 October 2026

**TLS between the databases can be switched off again**
- *Switch TLS off…* in the green bar (Settings → High availability →
  Replication) and `otp --ha-tls-off --yes`. The steps run the other way round
  so replication never stops on them: both databases let the other node in
  without TLS too (hostssl → host), both links go back to Database → TLS, then
  the cluster's certificates leave both PostgreSQLs (ALTER SYSTEM RESET: ssl
  as postgresql.conf says) and /etc/pki/otp/ha-ca.pem goes. Switched off, the
  nodes no longer put it back by themselves; *Repair* turns it on again.

**The Database page says how the link to the other node is protected**
- Under *Encryption to the database server*: encrypted and checked
  (verify-full) by the High availability page's own setting, with a link
  there. That field is this daemon's connection to its own PostgreSQL and
  stays empty - after the link was encrypted it looked as if nothing had
  happened.

**Fixed**
- *The addresses of the two nodes*: "This machine has: ?" - the service's
  PATH has no /usr/sbin, so `ip` was not found.

## 1.0.106 — 24 October 2026

**A node renamed or given a new address: put right in place** (new:
docs/renaming-and-readdressing.md)
- *Settings → High availability → The addresses of the two nodes* and
  `otp --ha-readdress [--ha-address NEW] [--ha-peer NEW]`: on the node whose
  address did not change, the other node's new address moves this node's
  pg_hba.conf line (host/hostssl kept, the old file kept beside it), its
  subscription and config.json over, and the other node is told straight into
  its database and puts its own side right by itself - its address in
  config.json, a new certificate for the link. The firewall, keepalived and
  nginx follow by themselves. Before this, a new address meant taking the
  pair apart and building it again.
- The page warns when config.json names an address this machine no longer
  has; `otp --ha-readdress` alone shows the addresses as the node has them.
- A renamed node starts its link steps again under the new name.

**The link between the databases**
- A node whose certificate lacks the name the other node reaches it by is
  told so by the other node and makes itself a new one at once - not at its
  next look ten minutes on. (On otp1 the look at start did not catch it.)
- *Start the steps again* in the bar when they have run for more than three
  minutes; `otp --ha-tls` (how it is, each node's step, when certificates
  end) and `otp --ha-tls-repair` (the button) on the command line.

## 1.0.105 — 24 October 2026

**The link between the databases: stuck on "does not match host name"**
- Each database's certificate named its node's address only as an address.
  libpq 13 - the one RHEL/Alma 9 has, and the daemon uses to try the other
  node - reads names alone, so the try failed ("server certificate for "otp2"
  (and 2 other names) does not match host name "192.168.42.33"") and both
  nodes waited at "link verify-full". Replication went on as before,
  unencrypted. Every address is now in the certificate both as an address and
  as a name.
- Nothing to press after the upgrade: each node sees at start that its
  certificate lacks a name, makes a new one and goes through the steps again;
  a node that gave up meanwhile starts again as soon as the other node has put
  its side right. A node waiting at the link step for more than two minutes
  also looks whether its own certificate is what is wrong.
- The names a certificate must have also come from the cluster's own list of
  nodes (the address each one is heard at), not only from the other node's
  setting.

## 1.0.104 — 24 October 2026

**The link between the two databases: encrypted and checked with one button**
(Settings → High availability → Replication)
- The orange bar that said the link is not encrypted has a **Repair** button.
  On a running cluster, on both nodes, nothing stopped: the cluster gets its
  own authority, each PostgreSQL a certificate from it (put in by the root
  helper, reloaded - not restarted), each node moves its link over to
  verify-full once it works against the other, and then each PostgreSQL lets
  the other node in over TLS only (host → hostssl in pg_hba.conf). The bar
  follows each node's step; one that does not work stops there and says why,
  with nothing in use changed.
- The link has settings of its own (ha_tls, ha_tls_ca in config.json): the
  daemon's connection to its local PostgreSQL is left as it is. The old advice
  to set Database → TLS to verify-full would have broken that connection.
- Certificates renew themselves 45 days before they end; the authority is
  replaced two years before it ends, the old one trusted beside the new one.
- It looks after itself: every ten minutes, at start and after a database is
  put back, each node checks its PostgreSQL's certificate, the authority file
  and its link, and goes through the steps again when anything is not right
  (a reinstalled or rejoined node, a PostgreSQL set up anew, a certificate run
  out while the machine was off). Repair also mends a link whose certificate
  ran out and stopped replication.
- Backups: the authority is in every copy of the database (its key sealed);
  putting a copy back keeps the authority the running cluster has, and a copy
  from before it makes a new one that both nodes take. Each node's progress is
  not taken from a copy (it describes the machine).
- A node joined again does not put a plain host line back in front of a
  hostssl one in pg_hba.conf.

**Certificates of the pages after a restore**
- nginx's certificate is compared with the one saved in the database, not only
  written once: missing or different (a machine put back from its own backup,
  nginx set up again, a file changed by hand) it is put in again, and the event
  says so.

**Fixed**
- Settings: "Put them back" did nothing while a value was changed - the
  changes were never forgotten, so the page was not drawn again.

## 1.0.103 — 24 October 2026

**Realm groups that can be read, however many there are** (Settings → Realms)
- Each group of a realm is a card of its own: its name (the CN) to read, its
  whole DN under it, wrapped, never cut short; a "the whole DN" / "a name
  alone" mark; its place in the order numbered, moved with arrows (the first
  group the person is in answers); edit and remove beside it.
- A group's own answer lines show only when it has some - otherwise one small
  "+ its own answer" link, so a long list stays a list.
- The list counts its groups; past six it gets a search box and scrolls inside
  the section instead of stretching the window.
- The realms table shows the groups as chips by name with the whole DN on
  hover; past three, "+N more" opens the rest and "fewer" folds them again.

**The ways of getting a code each in its own colour**
- The app violet, e-mail blue, SMS orange - the same in the realms table, the
  tokens list, a token's detail and everywhere else a token's kind is shown.

**Fixed in the administration pages** (a walk through every page)
- In English the administration pages stopped loading: the token list stayed
  empty and no button worked. A text looked up in a translation that was not
  loaded failed; it now comes back as it is.
- "The mail is" (HTML / plain text) on a mail token's card was never saved.
- The person picker offered names no realm takes (a userPrincipalName with
  another suffix: pkolar@corpnet.loc for the realm corpnet.cz) - the token
  made under it was refused by the VPN. Such names are no longer offered.
- An account that must choose its own password got a page of dashes and
  "change your password first" errors; the form for a new password now opens
  by itself (with the new one asked twice and a way to sign out).
- The overview offered an older package as one "ready to be put in" - now
  only a newer one.
- "Open the Log" in the Let in / Refused popups opens the Log filtered to
  them, for the last 24 hours.
- The Log's disabled "Last" button said to sort by a heading that does not
  sort; it says to shorten the window or narrow the search.
- The time picker stays inside the window on a phone (it scrolls, opens
  upwards when there is more room); the HA node table scrolls on its own.
- Making a token: an address typed by hand for e-mail came back empty after
  switching to SMS and back.
- The Test tab: the first step of a mail/SMS token (a challenge) counted as a
  wrong password and after about 16 tests locked every administrator of that
  address out for 3 minutes. Challenges no longer count, and an address may
  take 100 failed tests (still 20 per administrator and person).
- A broken config file gives "the file is not JSON" instead of the browser's
  own error; "that is not a phone number" now says how to write one.
- Czech for texts left in English: the note after making a mail/SMS token,
  the enrolment steps, events (where codes go, language, mail format, test
  message, restore), the SMS test, the database check, a refused directory
  reading account. The notes column of the tokens list no longer squeezes
  to a word a line.

**Message texts: every word people get, edited as it will look** (Settings →
Tokens → Message texts)
- Every mail and SMS this server sends - the sign-in code by mail, checking an
  address, a token with its QR code, the sign-in code by SMS, checking a
  number - and what the VPN's second window asks, in Czech and in English.
- A mail is shown as it arrives, in the window of a mail program: click into
  any of its texts and write, with a toolbar as in a word processor - bold,
  italic, underline, a colour, a link, formatting taken away, undo. What is
  filled in when it is sent (the code, the name, the account, the minutes...)
  stands in blue chips, put in from the toolbar or under each box, and cannot
  be broken by typing. The layout - the band, the box with the code, the QR
  code, the warning - stays as it is, so the mail looks alike in every mail
  program, Outlook included.
- An SMS is written beside a phone showing it, with its length counted: how
  many SMS it makes, GSM or Unicode, accents taken out where that is set.
  The VPN's questions beside a window showing them, counted in bytes (253 at
  most, as RADIUS carries them).
- *Put back as it comes* for a whole message in one language, and for each
  text alone: back exactly as it was before it was changed. *Preview* with
  sample values, *Send a sample* to an address or a number - both with what
  is not saved yet. Texts left empty leave their block out of the mail.
- Kept in the database, only what differs from the default: every node of a
  cluster sends the same words within seconds, and two administrators saving
  at once are told rather than one overwriting the other. If the database
  cannot be asked, the defaults are sent - never nothing.
- What is written is checked: only the values a text may have, braces on
  their own refused, the formatting kept to what mail programs show alike
  (everything else taken out, its words kept).
- The verification mail has its own greeting, band and foot now (they were the
  sign-in mail's), and the token mail's band text is no longer fixed in code.
- The plain text version of a token mail showed `&#8205;` inside every account
  name and doubled `&amp;`: it is made from the plain values now.

**Mail through the outgoing mail**
- Every mail goes through the outgoing mail - the codes, the tokens' mails,
  the samples, the test mail. With mail sent straight to the recipient's
  server, the test mail can still be sent *straight, this once* to see every
  step of the conversation.
- With mail switched off nothing waiting is tried or given up (codes past
  their time aside), as the page says.
- A mail refused for good stays "refused", not "given up", when its time runs
  out; asking again for a code past its time says so.
- A mail server answering byte by byte is cut off at its deadline: each read
  had its own timeout, so the deadline did not hold.

**The enrolment pages**
- Replacing a mail or SMS token by the app, then reloading: the new token
  could not be confirmed - the box to confirm it and *Keep the old one* are
  there now.
- A waiting app token can be given up for another way (*Choose another
  way*).
- Wrong codes on the pages (checking an address, confirming, replacing) are
  counted per person, with a wide limit per address: one person's typos
  locked out everybody behind the same address, and right codes were refused
  as "too many wrong passwords". Each limit says what it counts. Codes not
  sent because of the per-person limit no longer use up the address's.
- *Send it again* after a reload keeps the language chosen.
- "No signal or no mail?" says the one that fits.

**The administration and the API**
- A NUL or another control character in a token's name lost its key for
  good (enrolling, renaming): refused now.
- An issuer too long for a QR code replaced the token's key and then failed:
  the picture is made first, and free-text settings have a length (issuer 64)
  and no control characters.
- A search ending in `!`, `NOT` or a bracket broke; now it says so under the
  box.
- Lists, objects, true/false, NaN or Infinity where text or a number goes are
  refused with a word (a name sent as a list made a token called `['x']`);
  numbers out of the database's range, and 1e400 through the pages, are a
  400, not a 500.
- Taking away a client, realm or directory that is not there says so, instead
  of "gone" and an event about "None"; a directory's port is 1-65535.
- Python's "invalid literal for int()" is said in words.

**The command line and the installer**
- `--upgrade` set /etc/otp to 2755: the daemon could no longer save its
  config.json after any upgrade. A folder there already keeps its mode.
- `--restore`, `--backup-info`, `--import-config`, `--export-config`,
  `--import-legacy` and `--import-totpcgi` read and write their files as root,
  before the service's account takes over: in /root they failed with
  "Permission denied", the documented recovery included.
- `--import-legacy`: a setting out of range is brought into it (a window of 25
  stopped the import half done), settings set here already are kept unless
  `--replace`, and a client at an address another client has is left out.
- `--unlock` gives the recovery codes back too, and writes an event.
- `--rejects` and `--json` alone do what they say, never start the daemon;
  `--check --json` runs the checks and exits as `--check` does.
- The installer reloads nginx once the guard for big uploads is in.
- `--help` no longer shows defaults twice; a missing folder for
  `--import-totpcgi` is an error.

**Czech**
- Short patterns no longer swallow sentences ("the port 1812 is se používá",
  "timed mimo provoz"); texts with tags are matched; plurals and some 150
  messages, events and mail and SMS steps translated; hints of boxes drawn
  later and long help for screen readers in Czech.

## 1.0.102 — 24 October 2026

- **A group picked in the directory is kept as its whole DN** - for a realm
  (*Lets in*) and for who may enrol (*May enrol*), as the administrators'
  groups already were. It is then the one group picked, matched as it is,
  with nothing to look up; the list of chosen groups shows its name, the
  whole DN on hover. Groups written earlier by their name alone still work
  (1.0.101: the one group that name is in the directory).
- **A full administrator sees the last two characters of every password
  again** - the shared secrets of the RADIUS clients, the directory's
  reading account, the database, the mail server, the SMS gateway - so that
  "the one I set" can be told from another. Every other role sees dots
  alone, and the settings' passwords not at all; an export without its
  secrets carries dots only.

## 1.0.101 — 24 October 2026

A security review of the whole application: eight separate reviews (RADIUS,
LDAP and realms, the administration, the enrolment pages, HA and upgrades,
load and concurrency, the pages, the cryptography), most findings checked on
a running pair of nodes. Nothing was found that lets anybody in when the
database, the directory, mail, SMS or the other node fails, nor any way
round the roles. What was found is fixed here.

**Codes used once - also on two nodes**
- With two replicating databases, the same code sent to both nodes at the
  same moment was let in on each; and replication, which writes whole rows,
  could write an older copy of a token over a newer one - a used recovery
  code came back. Every one-time use (a code's time step, a recovery code,
  an answered question) is now a row of its own in `token_once`, never
  changed, and a node looks in the other node's database before it lets a
  code in. Tested: one code to both nodes at once - let in once; replication
  paused - a code used on one node is refused on the other.

**Guessing codes**
- A lock after 10 wrong codes set the count back to 0: 10 more guesses every
  quarter of an hour, for ever (~870 a day against a realm that asks for the
  code alone). The count now goes on; each lock is twice as long as the one
  before (15 min, 30, 60 … up to a day), and every lock is an event. The
  token's card says until when it is locked, with *Unlock it*.
- Directory password + code: a guessed recovery code after a right password
  counted nothing, past the pause and the lockout. Each request where no way
  of splitting the password gave a right code and the directory refused it
  now counts towards the token's recovery codes: past 20 in a day they are
  not taken for a day (an event says so; *Unlock it* gives them back). The
  directory is still asked once, and codes from the app go on working.
- Each wrong code gets its own number (two at once both read "11" and the
  lock at the 10th was skipped); confirming a new token locks the same way.
- Answers to one mail/SMS question sent at the same moment were all
  compared - the 3 tries were 16. A try is now taken before the code is
  looked at.
- The pause between wrong codes is counted together by both nodes.

Every change was then checked by a review of its own, which found twelve
mistakes in the fixes themselves - fixed before this was released.

**The directory**
- **A group given by its name alone matched any group of that name anywhere
  under the base** - one an OU's administrator could make - for the realms,
  the enrolment pages and the administrators' roles. It is now the one group
  that name is: its sAMAccountName (unique in a domain), or a cn only one
  group has. Two of one cn: neither, said in the log - give the full DN.
- An administrator from the directory switched off here signed in again
  under another spelling of the name (`falco`, `falco@corp.cz`, `CORP\falco`).
  One person is now one account, found by the DN.
- Computer accounts (`PC123$`) are not people: refused.
- Locked out in AD, the password expired, or a state that cannot be read:
  refused where the realm checks accounts (`msDS-User-Account-Control-Computed`).
- `DOMAIN\name@realm` and `name@x@realm` are not names (each made a second
  token for one person).
- Names alone (`bare`) only within one directory.
- A directory server that hangs is passed over for 30 s: every sign-in of
  every realm no longer waits out its timeout first.
- An empty password, an empty DN, a control character in a password, an
  empty result code from the server: refused.

**The administration and the enrolment pages**
- *Showing keys* switched off now holds for downloading the database too: the
  copy goes without the key that opens the tokens.
- The codes in the subjects of code mails are dots in the outgoing-mail list
  (every role could read them there).
- Secrets show as dots only - their last two characters were shown.
- Sending codes from the enrolment page counts against the page's limit, and
  per destination; a code confirmed or proven is taken once even when two
  requests come together; confirming has a limit of its own.
- The same answer for a right password without a role as for a wrong one, and
  the same time for a name that is not there.
- An imported account whose password, role or state changes is signed out.
- IPv6 counted per /64 in the sign-in limits; another site's Origin refused.

**Load**
- The database connection has time limits (a statement 120 s, a wait for a
  row 10 s, a dropped line 30 s): one waiting statement held every sign-in.
- The Log, its search suggestions and the events read through a connection of
  their own: four searches of the whole log held RADIUS for 2-5 s and the
  health check failed - now ≤ 10 ms.
- Checking, the statistics and giving room back run on their own connection.
- The API closes a connection silent for a minute and takes 256 at most.
- A mail server answering byte by byte is given up after 4× its timeout; the
  outgoing-mail queue reads only the open mails every 10 s.
- At most one page waits for the other node's firewall, two for its test.

**RADIUS**
- An Accept never goes without an attribute it should carry: refused instead.
- A repeat of a request answered meanwhile gets the answer.
- That a NAS signs its requests is remembered in the database, per node
  (restarts, the other node); a new client must sign them unless let off.

**On the machine**
- Root (the command line, the installer) writes into the folders the otp
  account can write without following a link, through the open file.
- A token key that was never sealed is sealed at start and refused after.
- `$` in name checks let a newline through: `\Z`.

**Said plainly on the pages**
- The SMS gateway without HTTPS or without its certificate checked.
- Replication between the nodes without TLS checked (verify-full).

## 1.0.100 — 24 October 2026

- **Every click-through shows what it filters by.** A bar of the requests
  chart, a name, a reason, a client or an address in the overview, *Its
  requests* of a token or of a check: the Log opens with it written into
  the search box in the words it takes (`name:falco@x.cz`, `reason~"…"`,
  `from:10.1.2.3`), the result and the client in their filters, and the
  time picker set to the hour (or the window) clicked - not a window kept
  out of sight while the picker still said "last 24 hours". Each can be
  changed or cleared like anything typed.
- **Search and Clear beside every search box** - tokens, the Log, events,
  enrolment, the outgoing mail, and the restore of a backup: Search looks
  for what is typed and chosen (as Enter does), Clear empties the box and
  puts every filter of that list back (the time to the last 24 hours); it is
  lit while anything is filtered.
- **Restoring a backup, a token here already is decided one by one**: each
  has its own *keep the one here* / *replace it*, with *Keep every one
  here* and *Replace every one* for all of them; the line below says how
  many will be restored, how many replace the one here and how many are
  kept; replacing asks once more, naming them.
- The header says which node answered the page on every tab, not only on
  the overview.
- A locked backup asks for its passphrase when it is opened (and again,
  saying so, when the one typed does not open it).
- Search and Clear stand beside the search box with its suggestions, not
  wrapped under it.
- The restore's result and counts in Czech, with the right plural forms.

## 1.0.99 — 24 October 2026

- Settings → About: **what it runs on**, a column a node of the cluster -
  otp; Python, where it is, and its modules (psycopg2 with its libpq,
  PyMySQL, colorama); the OpenSSL and SQLite under it; the database server,
  pg_dump, mariadb-dump; nginx, php-fpm, the command line's PHP; the system,
  its kernel and architecture, systemd, OpenSSL, keepalived, iptables,
  firewalld. What is not the same on every node is marked. The other node's
  comes with its heartbeat (asked of the machine once an hour).
- And the pages' own PHP, as php-fpm runs it on the node that answered the
  page: its version, how it runs, OPcache, the web server, and every
  extension it has loaded with its version.

## 1.0.98 — 24 October 2026

What the review of 1.0.94 left open:

- **nginx no longer takes 4 GB from anybody on the admin networks.** A
  database put back and a new version go to `/admin/upload/` now, where
  nginx asks the daemon whether a full administrator is signed in
  (auth_request) before it reads a byte of the body; anybody else is
  answered at once, having sent 64 kB. Everything else on the admin page
  is held to 32 MB. Put into the nginx file that is there by install.sh
  (and every upgrade), where nginx has auth_request; nginx is asked first
  and the file left as it was if it does not take it - the pages then send
  the old way, as before.
- In a cluster, the time a RADIUS client was last heard from (written once
  a minute) no longer goes into the client's own row: logical replication
  sends a row whole, and that write on one node could put back a shared
  secret changed on the other at the same moment. It is kept per node now,
  and the pages show the latest of both.
- The enrolment pages: *Send it again* is there after the page is reloaded
  during the check of an address too - the address is the one the server
  keeps for that check.
- A directory server sending a damaged answer is said at once, not waited
  for until the whole timeout (up to 30 s a request).

## 1.0.97 — 24 October 2026

- **otp runs on the newest Python the distribution offers.** On RHEL,
  Rocky and AlmaLinux 9 the system's python3 is 3.9; install.sh (and every
  upgrade, from the pages too) now installs `python3.12` from AppStream
  with the database driver for it (`python3.12-psycopg2`, or
  `python3.12-PyMySQL`) and runs otp on it - faster (3.11 and 3.12 are
  some 25 % quicker than 3.9 at this kind of work), and supported by Red Hat
  for longer. Tried in order: 3.13, 3.12, 3.11, then the system's python3;
  a Python is taken only once it has shown it runs otp with the driver the
  database needs - otherwise the next one, and the old one stays.
- The choice is the link `/usr/local/lib/otp/python`: the service starts
  it, and the `otp` command is now a small script that starts otp.py on
  it (a link to otp.py ran it on whatever python3 was first in PATH). The
  root helpers (upgrades, the web side) stay on the system's python3.
  `--python PATH` picks one; `--system-python` keeps the system's.
- Checked on Python 3.9, 3.12 and 3.13: no deprecation warnings on 3.12;
  otp keeps running on 3.8 and newer.

## 1.0.96 — 24 October 2026

- **A whole backup of the tokens, and its restore.** Settings → Bringing
  tokens over: every token chosen - of every kind: the app, codes by
  e-mail, codes by SMS - as one file (`otp-tokens-NODE-DATE.json`) with its
  key, its recovery codes (used and not), how its codes come and where to,
  its language and mail form, its state, its note and owner. Chosen with the
  words of the token list, a state and a kind. Locked with a passphrase
  (scrypt, as the HA bundle) - or one made up on the page, shown once. A
  full administrator's, where keys may be shown; every backup written down.
- The restore reads it here or on another otp - which does not need this
  machine's sealing key: the backup is dropped where the .totp files are,
  the passphrase asked for if it is locked, and what it holds is shown -
  every token with its kind, where its codes go, its recovery codes left,
  its state and whether this server has one already - searched with the
  words of the token list, picked one by one or all shown, and restored,
  replacing the ones here or not.
- totpcgi's .totp files, and ZIPs of them, are read as before; the .totp
  export stays for totpcgi.
- **Mail straight to the recipients' servers with STARTTLS failed** on
  Python 3.9 (RHEL/Rocky/Alma 9): "server_hostname cannot be an empty
  string". The connection is made to the address looked up, and the
  Python 3.9 smtplib then had no name to check the certificate against -
  every receiving server offering STARTTLS (most do) was refused; the same
  through a relay given by its name. The name is set now. (Python 3.12+
  set it by itself, which is why it did not show everywhere.)
- The outgoing mail is searched with the words every list takes - fields
  offered as one types with what they hold (`to:`, `state:`, `kind:`,
  `name:`, `said~`, `tries:>2`, `node:`), `a,b`, `-not`, `*`, `~`,
  `(a OR b)` - the same search box as the tokens, the Log and the events.

## 1.0.95 — 24 October 2026

- **The outgoing mail.** Every mail goes through it - a token's QR code, a
  code to sign in with, a code to check an address. What the receiving side
  does not take at once - greylisting's "try again later" (451), a server
  away, a full mailbox - waits and is tried again by itself: after 1, 2, 5,
  10, 15 and 30 min, then every hour, for *Try a mail not delivered for*
  (24 h by default); a code to sign in with every minute while it is good.
  What the receiving side refuses for good (5xx) is shown as failed, not
  tried again.
- Settings → Outgoing mail: every mail with its state (waiting, being sent,
  sent, failed, given up), the tries, when the next one is, what the server
  said - and each try step by step. Counts by state, a filter and a search
  (`to:*@example.cz`, `state:waiting`, `kind:code`, `name:novak*`, or any
  word). A mail sent again now, or taken away - one, or every waiting /
  sent / failed one. A badge beside *Outgoing mail* says what waits or
  failed.
- In a cluster both nodes see one list (kept in the database they share,
  under keys of their own - no numbering two nodes could both give out). A
  mail is sent by the node it was made on; when that node is gone for
  5 min the other takes it over; either node's pages send one again or take
  it away.
- What a mail holds (a QR code, a key, a code) is sealed while it waits and
  thrown away once it went or was given up; the list keeps only who, what,
  when and what was said, for *Keep the list of mails sent for* (14 days).
- A token's mail not taken at once says so on the page: it waits and goes
  by itself. A code by mail greylisted is no longer "could not be sent":
  it arrives a minute later. The mail test on Settings → Mail still goes
  straight, to show every step.

## 1.0.94 — 24 October 2026

A review of the whole application, part by part. What was found and mended:

**Security**
- A token administrator could send somebody's sign-in codes elsewhere
  (changing where a mail or SMS token in use sends them): a full
  administrator's to do now, as replacing the token is. A token
  administrator could also take a token in use away and make it anew - the
  way round that same rule: taking away a token in use is a full
  administrator's, switching it off stays theirs.
- The enrolment pages: a token switched off or locked out by an
  administrator could be switched on again by its owner, "replacing" it with
  a code sent to it. Refused now at every step; a code is also sent to the
  old token only when the pages may replace tokens at all.
- A test made on the other node tried directory passwords without the limit
  a test on this node has.
- The code typed back on the enrolment pages: counted also for many requests
  at once.
- A code sent by mail or SMS is no longer taken once its token was taken
  away, made anew for the app or set to send elsewhere meanwhile.
- After a lockout ran out, one wrong code locked the token again for
  another 15 min - one guess a quarter kept its owner out. Counted from
  nothing again after the pause.
- Codes sent at once by several requests could pass the limit of codes per
  person: counted with a conditional write now.
- Mail: with "STARTTLS where offered", a server (or anybody on the way)
  offering no STARTTLS got the relay's password in plain text. Not sent
  without TLS now.
- install.sh wrote some of its files under /etc/otp through a path the otp
  account could swap for a link meanwhile (root writing over any file): it
  writes beside them and renames now.
- otp_web.py: an asking file the otp account made a link or a folder was
  never removed, and the helper was started again and again until systemd
  gave up on it (and with it TLS, VIP and firewall changes). The PostgreSQL
  log is checked again once opened.

**Reliability**
- A config.json that cannot be read (a typo in it) started the daemon on
  the built-in defaults - an empty SQLite of its own, every person refused,
  a node quietly out of its cluster. It stops now, saying why; a reload
  keeps the settings in effect.
- The database's TLS settings (db_tls, db_tls_ca) were left out of the test
  before a database setting is saved, of the cluster's bundle and of the
  move to another database.
- A rebuild from the other node that failed after emptying the tables put
  the node back in service with nothing in them; it stays in maintenance
  now until a rebuild goes through.
- A database password with "?" in it broke the replication subscriptions.
- Realms older than the switch for nested groups lost nested groups.
- The reload on SIGHUP (logrotate, every night) ran inside the signal
  handler, where it could lock up the main loop: done in the loop now. The
  daemon also notices a rotated otp.log by itself - logrotate's reload was
  refused to the otp account, and the lines went into a deleted file.
- Heartbeat and hourly work timed with a clock that cannot step back.
- The daily copy was lost when the database was away at that moment.
- The nodes picked the winner of a replication conflict by a comparison
  that followed the database's collation, and could pick differently.
- Restoring a copy could give the tables the other node's numbering for a
  moment; moving SQLite to PostgreSQL stopped on a NUL in an old row; new
  columns are pushed to the other node every hour, not once.
- IPv6 switched off on the machine with an IPv6 RADIUS address killed the
  daemon at start; said now, as a port in use is.
- `otp --tls-hsts 0` (any option given 0) started the daemon in the
  foreground.
- A file with secrets written over one already there kept its old mode;
  the HA bundle is created 0600 from its first byte; the sealing key is
  written whole before it appears.
- Mail settings with a line break in them are refused when saved.
- Changing anything of TLS on the pages dropped HSTS; a missing value is
  the two years nginx is shipped with.
- `--no-db-restart` is remembered for later upgrades (`--db-restart` allows
  it again); install.sh stops on PHP older than 8.0; the pip fallback works
  with RHEL 9's pip.
- Config import: the TLS settings and the web address are checked as the
  pages check them; an empty picture upload no longer deletes the logo.
- Pausing one direction of replication is refused when the request reached
  the other node than the page showed (behind a balancer).

**The pages**
- Settings: a certificate pasted for the SMS gateway disappeared from its
  box on coming back to the tab while the bar still counted it; a change
  made while a save was on its way could be lost; a certificate pending for
  a directory that is gone blocked every later save.
- The live lists (overview, requests, events) held back under the reader
  stayed stale until the next change; now drawn on the next tick.
- "No" on some questions closed the window behind them (throwing away a
  staged token, switching a token off, dropping a certificate request).
- The current code of a token showed an expired code when the next one did
  not come; the enrolment search ignored its time window; an upgrade
  package dropped twice was uploaded twice; the portal said "not in use"
  of a new app token while the old one went on working.

## 1.0.93 — 24 October 2026

- Tokens, finding one by where its codes go: a phone number is found
  however it is typed - 603 364 754, 603364754, +420 603 364 754, 00420…
  - the digits compared with the token's number, its country code in front
  or not. A mail address, or a part of it, is found too. Both in the plain
  search and next to other words of a search (`kind:sms 603364754`), where
  the address and the number were not looked in before; `to:603364754`
  finds the number that ends so, `to~364` one that holds it.
- The search box says it: "a name, a note, a mail address, a phone number".

## 1.0.92 — 24 October 2026

- The Teltonika gateway's certificate, read from it and imported, was still
  refused ("unable to get local issuer certificate"): a TRB sends only its
  own certificate, signed by an authority of its own ("ca") it never shows,
  and a certificate that is no root was not taken as one to trust. Every
  certificate imported for the gateway is now trusted by itself (a partial
  chain), and the strict checks meant for web servers are left out.
- After *Read it from the gateway*, a certificate whose signer the gateway
  did not send is said to be trusted as it is.

## 1.0.91 — 24 October 2026

- Making a token whose codes are sent: *Sent to* is filled in from the
  directory for the kind chosen - the mail address for e-mail, the mobile
  (or telephoneNumber) for SMS - as soon as the person is picked or their
  name is typed whole, and swapped when the kind is changed. It can always
  be changed; what is typed by hand stays. Under the box it says where the
  value came from, or that the directory has none for them.
- The enrolment pages say the same under the address or the number they
  fill in from the directory: that it can be changed.

## 1.0.90 — 24 October 2026

- The Test tab, a test made on the other node - the real cause at last:
  the other node looked for tests asked of it with a range of the key
  (`k >= 'radtest:ask:otp2:' AND k < 'radtest:ask:otp2;'`), and in a
  PostgreSQL made with the system's language collation (en_US.UTF-8,
  cs_CZ.UTF-8 - the usual on Rocky/RHEL) ':' and ';' are left out of the
  first comparison, so the range was always empty: the test sat in its
  database and was never taken. The first characters are now compared as
  they are (substr), whatever the collation. (1.0.87's message - "has the
  test in its database but did not take it" - is what showed it.)

## 1.0.89 — 24 October 2026

- The Teltonika gateway, *Check its certificate* on: the certificates it is
  checked against are imported right under it - the gateway's own one,
  read from it with *Read it from the gateway* (shown with its fingerprint
  first, trusted only with Save the changes), or the root and the chain of
  the authority that signed it, pasted or read from a file (PEM or DER).
  Each one is listed with whom it is, who signed it, until when it is good
  and its fingerprint, and taken out by itself. Kept in the database: the
  other node of a cluster has them too, and Export and import carries them.
- With certificates imported, only they are trusted; a gateway written as
  an address (192.168.1.1) is not checked for a name, one written as a name
  is. With none, the authorities of the machine, and the name.
- A certificate that does not pass says so and what to do, rather than a
  bare TLS error - and nothing is sent.

## 1.0.88 — 24 October 2026

- Settings → Codes by e-mail and SMS, drawn anew: in sections - *The
  codes* (how long, how many), *What they say* (language, a mail's form)
  and *SMS* - four even columns, each box the same width. What one way of
  sending needs (the Teltonika gateway, an HTTP gateway, a modem on this
  machine) sits together in a panel of its own under the choice, there
  only while that way is chosen - no longer a page of greyed-out boxes
  scattered among the others.

## 1.0.87 — 24 October 2026

- The Test tab, a test made on the other node: the request is written
  straight into that node's database and its answer read from there, not
  left to replication - when replication towards that node stood still or
  lagged, the test was never seen there and the page waited its 25 s in
  vain. Replication is used only when that database cannot be reached.
- When the other node still does not answer, the page says why: it took
  the test but did not finish it (a slow directory or RADIUS there), it has
  the test but did not take it (is otp running there, and which version),
  or its database could not be reached and replication is not running.

## 1.0.86 — 24 October 2026

- Settings: *Codes by e-mail and SMS* moved from *This installation* to
  the *Tokens* group, right under *The tokens*.

## 1.0.85 — 24 October 2026

- Tokens, the table: two new columns. **Codes** says how the codes come -
  the app, by e-mail or by SMS - and for a sent code where to (the address
  or the number). **Language** says the language of the codes and, for a
  mail token, whether the mail is HTML or plain text; what only follows the
  settings is shown muted.
- Tokens, finding: a new choice beside the state (every kind, the app,
  codes by e-mail, codes by SMS), and new words for the search -
  `kind:mail`, `to:*@example.cz`, `lang:en`, `mail:text`. The free search
  looks in the address or the number too. The line above the table counts
  the tokens of each kind once there is a sent one.
- The token's window fits the screen without scrolling: for a token whose
  codes are sent, the mail's form sits under the language in *Signing in*,
  and *Send a test* and *The app instead* share one row.

## 1.0.84 — 24 October 2026

- The Test tab, a test made on the other node: the code of a second window
  goes there with its State (it was left behind, and the answer refused).
  While it waits, the page says it is asking that node through the
  database, for up to 25 s.

## 1.0.83 — 24 October 2026

- Enrolling on the enrolment pages, the person chooses the language of the
  codes (and of the VPN's question), the language of the page offered, and
  for codes by e-mail whether the mail is HTML or plain text, the setting's
  choice offered. The mail that checks the address comes already in the
  language and the form chosen. An administrator changes both in the token's
  window, as before.

## 1.0.82 — 24 October 2026

- A token has a **language of its own**: the mail or SMS of its codes and the
  words of the VPN's second window are in it. Enrolling on the enrolment
  pages, a token takes the language of the page the person chose; an
  administrator changes it in the token's window (*Signing in → Language*),
  or leaves it to the setting.
- A mail with a code is **HTML or plain text**: Settings → Codes by e-mail
  and SMS → *A mail with a code is* (HTML, in the look of a token's mail, the
  plain text beside it - or plain text alone), and for one token in its
  window (*The mail is*).

## 1.0.81 — 24 October 2026

- SMS through a **Teltonika gateway** (TRB140, RUT… - RutOS), the box zigmon
  sends its texts through: Settings → Codes by e-mail and SMS → *How SMS is
  sent: a Teltonika gateway*. Its address, HTTPS (its own certificate taken
  unless checking is switched on), its user and password (sealed), and its
  interface - RutOS 7's own API (a login for a five-minute token, the modem
  asked once, `POST /api/messages/actions/send` with +420…) or the older
  Post/Get service (`/cgi-bin/sms_send` with 00420…). Sending only. As
  zigmon learned it: one message at a time with a short gap, tried again
  only where the request certainly never reached the box, and a box that
  took the message and did not answer in time is not "failed" - sending it
  again would be a second SMS. *Send a test SMS* works with it.
- *Without accents (one SMS, not two)*, on by default: a letter with an
  accent makes the whole SMS 70 characters a part; "kód" becomes "kod" and
  the code goes in one message - for every way of sending SMS.
- Fixed: since 1.0.76 the RADIUS lines for isemon (radius-detail) were not
  sent - "could not be written down: 11" in otp.log. The words of the codes
  (1.0.76) had taken the name the RADIUS packet types are kept under; the
  requests themselves were answered and written into the log as ever.
- `otp --radtest` finishes a second window: after an Access-Challenge it
  shows the words of it, asks for the code and sends it with the State, as
  the VPN client does. The Test tab does the same: a box for the code under
  the Access-Challenge, sent back with its State.

## 1.0.80 — 24 October 2026

- The enrolment pages, changing where the codes go: *Send me a code* is a
  button of full size beside the box the code goes into, said what it is for
  (the code proves the change is the person's own), and the box says "the
  code from the mail" / "from the SMS" rather than "a code from the old
  token". It no longer sits glued to *Go on*.

## 1.0.79 — 24 October 2026

- The mails of the codes (a sign-in code, an address checked on the
  enrolment pages, a test) look like a token's mail with its QR code: the
  blue band with the issuer and "VPN · Two-step sign-in", the white card,
  the greeting by the person's name, the code large in a grey box, how long
  it is good for, the warning in orange (or a note in blue), the footer -
  built of tables with the styles on each element, as Outlook shows them
  too. The plain text stays beside it for mail programs that show only that.

## 1.0.78 — 24 October 2026

- Mail → *Try it* sends two more samples, in the language picked beside: the
  mail of a sign-in code (a token whose codes come by e-mail) and the mail
  that checks an address on the enrolment pages - each with a code that
  opens nothing.

## 1.0.77 — 24 October 2026

- Active Directory: *Take old, weak certificates* on a directory - for
  domain controllers whose certificate has a 1024-bit key or a SHA-1
  signature, or that speak TLS 1.0 only ("EE certificate key too weak").
  OpenSSL's security level goes down for that directory alone; the
  certificate is still checked against its authority and the server's name
  (an old authority's certificate without the extensions Python 3.13
  insists on is taken too). The refusal now says which switch helps. The
  list of directories marks one that takes weak certificates. Command line:
  `--add-directory NAME --weak-certs on`.

## 1.0.76 — 24 October 2026

- **Codes by e-mail and SMS, and the VPN's second window** (RADIUS
  Challenge/Response, as Cisco Secure Client on ASA/FTD shows it). A realm
  says what people may choose - the app (as always), a code by e-mail, a
  code by SMS - and every kind works side by side; nothing changes for the
  app's tokens unless the realm is put in the new mode *the directory
  password; the code in a second window*.
  - A mail or SMS token holds where its codes go and recovery codes - no key
    anybody scans. Signing in: the directory password (and the groups) is
    checked, a code is sent, an Access-Challenge with a State and the words
    "Type the code sent to …" goes back; the code (or a recovery code) comes
    in the second request. Good for 300 s and once, 3 tries, at most 5 codes
    in 15 min per person, every wrong one counted towards the lockout; a
    wrong password sends nothing.
  - Kept in the database, so the answer may reach either node of a cluster;
    only a keyed hash of the code is kept. The other node's tables get the
    new columns at start, so a rolling upgrade does not stop replication.
  - The enrolment pages: who passes the realm's groups chooses a way; for
    e-mail and SMS the address or number from the directory is offered, a
    code proves it, and only then is the token made, with its recovery
    codes. Changing the address, the number or the way: the password and a
    code sent to the current one, or a recovery code.
  - SMS through a gateway's HTTP API (URL, GET/POST, JSON or form body,
    headers, a sealed key) or a GSM modem on the machine (a file into the
    spool of smstools3 / gammu-smsd). Settings → *Codes by e-mail and SMS*,
    with a test SMS.
  - Administration: the realm's *People may choose*; Make a token → *The
    codes come from*; a token's window with where its codes go, a test
    message, and *The app instead*; the log's *asked for the code*.
  - Command line: `--enroll NAME --by mail|sms --to ADDRESS`,
    `--add-realm … --methods totp,mail,sms`, `--mode challenge`.
  - [docs/codes-by-mail-and-sms.md](docs/codes-by-mail-and-sms.md).

## 1.0.75 — 24 October 2026

- High availability: the table of commands is folded away under *The
  commands*, as the balancers' guides are - opened when wanted.
- Seven more pictures for the sign-in, about the one-time passwords
  themselves: the authenticator app with its codes; how a code is made (the
  key and the time, HMAC, six digits - TOTP, RFC 6238); the six digits with
  the 30 seconds running down; the name, the password and the code; the VPN
  asking for the code; the codes in time with a step either side; recovery
  codes for when the phone is gone. In the pages' own colours, light and
  dark, moving slowly (and not at all with reduced motion).

## 1.0.74 — 24 October 2026

- High availability → *Looking after it from the command line* lists the web
  address's (VRRP) commands too: `--web-status`, `--vip-set` with
  `--vip-fqdn` / `--vip-vrid` / `--vip-iface`, `--vip on|off`, `--vip-move`,
  `--vip-return`, `--maintenance`, `--web-retry`, and keepalived's own
  `systemctl` / `journalctl` / `ip -br addr` for when the address does not
  come or does not move.
- A token's window, *The person*: the boxes of *Move to* and *Note* are the
  same width and their buttons too, so both lines end in one column.

## 1.0.73 — 24 October 2026

- Upgrade watched over the web address (VRRP): the page goes on by itself
  through every switch, there and back, with no F5. What stopped it:
  - one 401 for a moment (a node restarting, or one that has just got the
    address) made the PHP throw the session's cookie away and the page reload
    in the middle of the upgrade. Now the cookie stays, and the page asks
    whoami again (three times, two seconds apart) before it goes to the
    sign-in - a session really gone still does, within a few seconds;
  - in a tab in the background the next question was never asked again;
    now it waits and goes on when the tab is shown;
  - one answer that did not say "running" (from the node whose copy is a
    moment behind), or an error after one, ended the asking for good; now it
    asks every 3 s while it runs and for two minutes after, every 15 s
    otherwise, and an error is asked again, without a limit;
  - nginx's 502/503/504 while a node restarts count as "not reached";
  - the previous upgrade's plan, from a node a moment behind, is not drawn
    over the one running; answers to an older question are dropped.

- The picture on the sign-in waits for *Save the changes* as every other
  setting: a press on a picture, an upload, *Back to the default* and *Take
  my own picture away* only mark the change (the picture to come is outlined
  and tagged "after saving", the tab with a change has a dot), the save bar
  shows it, and nothing is changed before the save - *Put them back* drops it.
- Settings → The enrolment pages: the card of the sign-in's picture and the
  one under it have the same gap between them as every other card (the
  previews' hidden template stood between them and took it away).

## 1.0.72 — 24 October 2026

- The pictures of the two sign-ins are set apart: *The picture on the
  sign-in* has a tab for the enrolment pages and one for the administration,
  each with its own pick, its own picture of your own and its own *Back to
  the default* (the phone for the enrolment pages, RADIUS - the code - Active
  Directory for the administration, as each came; both can be picked for
  either). The switch "show it on the administration too" of 1.0.71 is gone:
  what it showed stays shown until the administration's own is picked. The
  exported configuration carries both (`art`, `logo`, `admin_art`,
  `admin_logo`); a file from 1.0.71 is read as it meant.

## 1.0.71 — 24 October 2026

- The picture on the sign-in can be picked: Settings → The enrolment pages →
  *The picture on the sign-in* shows five drawings with a preview (the
  phone as before, a 30-second clock, two keys for one door, the QR code and
  the app, a padlock with six digits), *No picture*, and a picture of your
  own (a logo: PNG, JPEG, GIF, WebP or SVG up to 512 KB; an SVG with a script,
  an event handler or a link out is turned away, and it is served with a
  policy that runs nothing). *Back to the one otp came with* returns the
  default at once; a picture of your own stays kept, to be picked again
  without uploading it, until *Take my own picture away*. It can be shown on
  the administration's sign-in too. All of it is kept in the database: both
  nodes of a cluster show the same picture, and it is in every backup and in
  the exported configuration (`logo`, `art`).
- Firewall: *Read it again* under the whole firewall works for the other node
  too - asked through the database, its root reads it and it is back on the
  page in a few seconds. A node also writes its whole firewall again every 10
  minutes, so one lost on the way (a rebuild, a restore) no longer leaves the
  other node's page with INPUT only.

## 1.0.70 — 23 October 2026

- Upgrade over the web address (VIP): the page no longer jumps back and forth
  when the address moves between the nodes during the upgrade. Each node's
  steps only go forward on the page (an answer from the other node that knows
  less does not undo what was already shown), the plan's state is worked out
  from the steps, *What root said last* keeps each node's own words with a
  switch between the nodes, and the "asking again" note has a line of its own
  so the table below no longer moves.

## 1.0.69 — 23 October 2026

- The upgrade's table keeps its columns where they are: they jumped about
  with every redraw as the bars and their words changed. "What install.sh
  said" stays open across the redraws.

## 1.0.68 — 23 October 2026

- Firewall: at the bottom, *The whole firewall* - each node's whole filter
  table as `iptables-save` shows it, every chain, OTP-IN and the jump to it
  marked (on firewalld, `firewall-cmd --list-all`). Root reads it after every
  change it makes and again on *Read it again*; the other node's is kept in
  the database, so either node's page shows both.

## 1.0.67 — 23 October 2026

- The upgrade on the pages shows how far it is: a bar for the whole and one
  for each node - waiting, taken out of service, install.sh by its sections
  (the one running is named under the bar), checking, done; red where it
  failed. The node being upgraded writes which section install.sh has
  reached, so the other node's page shows it too.
- Each node's own settings: also the RADIUS ports and the node's copies of
  the database (whether, when, how many); grouped; each node shows the value
  really in effect on it - its own (marked, with a way back to the
  cluster's), one from its config.json (marked), or the cluster's (dimmed);
  switches flipped in place; the cluster's value itself can be changed (it
  could not, in a cluster); the buttons stand one under the other.
- RADIUS: a changed port opens only that socket again - changing the
  authentication port had closed accounting for good (its port was taken
  again while the old reader still held it).
- install.sh --upgrade: the health check's rate limit was added a second time
  where the pages had put the access list in front of it; nginx refused that,
  and with it every other change the upgrade brings to the nginx file.

## 1.0.66 — 23 October 2026

- Behind the web address (VIP), an upgrade's progress stood still when the
  address moved to the other node, until the page was reloaded: an answer on
  its way was lost with the move and the page waited for it for good. Every
  question the pages ask now has a deadline (20 s, 150 s for changes; 8 s
  while an upgrade runs) - the browser then drops the dead connection, and
  the next question reaches whichever node holds the address. The upgrade
  and the rebuild of a node say "the web address is moving - asking again"
  and carry on by themselves.
- A copy's machine details say the database port in use (5432 / 3306)
  where config.json leaves it to the engine's default.

## 1.0.65 — 23 October 2026

- *Download* beside a kept copy (Settings → The database) now puts the key
  that opens its tokens - the `.key` beside it - inside the downloaded file,
  as *Download it* already did for a copy made at once: every copy taken
  from the pages is one file with everything in it. The file kept in
  `/var/lib/otp/backups/` itself is unchanged, its key beside it.

## 1.0.64 — 23 October 2026

- New guide: [docs/backup-and-recovery.md](docs/backup-and-recovery.md) -
  what there is to keep and where it is, copies against dumps, the key of the
  tokens, a backup plan (off the machine, the key apart, restore tests), and
  recovery step by step for one server and for a cluster: a wrong change,
  data deleted or damaged, a corrupt database, a node reverted to a snapshot
  or "lost", a split network, one node or both lost, the key lost, a failed
  upgrade, nobody able to sign in, a move to new hardware - and installing
  from nothing. Linked from the README and the runbook.

## 1.0.63 — 23 October 2026

- A copy of the database now carries the machine it was made on: its
  `config.json` (the database, the node's name, its place in a cluster -
  the database password left out), the host name and what was in use. It
  is shown before a copy is put back (on the pages and with
  `otp --restore FILE` without `--yes`) and by the new
  `otp --backup-info FILE`. Only to read: putting a copy back never writes
  `config.json`, which belongs to the machine.
- Operations guide: copies and dumps explained side by side - what each
  holds, where each goes back, and which to back up with.

## 1.0.62 — 23 October 2026

Export and import, copies and putting them back, and upgrades - looked at
end to end, on one server and in a cluster, on the pages and on the
command line.

**The configuration as one file - now all of it**
- The export held only the settings, clients, realms and directories. Now
  also: each node's own settings, the accounts of the pages (with their
  password hashes, with the secrets), the certificates and private keys of
  the pages and the web address, the web address, who may reach which page,
  the firewall and the mail server's authorities.
- Import puts all of that in. "Exactly the file" (`--replace`) also takes
  away what is not in the file and puts settings not in it back to their
  defaults; a setting put back to its default is in use at once. The
  account doing the import is never changed. A file of one machine put
  into a machine of another name gives it that machine's certificate.
- On the command line too: `otp --export-config FILE [--with-secrets]` and
  `otp --import-config FILE --yes [--replace]`; the pages take the command
  line's file and the other way round.
- A file with nothing to import says so.

**Copies of the database**
- Tested on SQLite and PostgreSQL, one server and a cluster, pages and command
  line: a copy, a dump, a downloaded copy and a kept copy put back give back
  everything - tokens, recovery codes, clients with their secrets,
  directories, accounts, certificates, firewall - on the same machine and on
  a new one; in a cluster the other node gets it all and replication goes on.
- On the command line a copy without a full administrator in it (one made
  on a server set up there alone) can be put back; it says how to make an
  account. The pages still refuse it.

**Upgrades from any version**
- Tested from every release 1.0.0 - 1.0.61 on SQLite and from releases across
  the range on MariaDB and PostgreSQL: tokens, recovery codes, clients and
  settings come through; copies made by any of them go back into this one.
- In a cluster, while one node is new and the other old, the other node's
  rows are taken as they come (the code step only goes up) - the newer
  guard of 1.0.60 had ignored what the old node changed in that window.
- Documented: operations (section 15) and upgrades.

## 1.0.61 — 23 October 2026

A fourth look for bugs: the PHP pages, nginx and install.sh, the pages'
scripts and their Czech, and what changed lately in the API - plus a fuzz of
every API call with odd values.

**Web pages and nginx**
- A few slow requests from anybody on the admin networks held every PHP
  worker for up to 15 minutes - the pages and the health check with them.
  nginx now takes a body whole before PHP is asked (an upgrade changes
  the installed otp.conf in place).
- `?+api=login` slipped past the sign-in limit: a parameter name of
  anything but letters, digits, _ and - is refused.
- `{}` sent from the page reached the daemon as `[]`.
- A backup the service cannot read (made by root) came down as a "200"
  with an error inside; now a clear refusal. A page closed mid-answer no
  longer writes a traceback.
- The daemon takes its port before it writes the key the pages use.
- install.sh: --admin-allow and the other lists are checked on the upgrade
  path too; a php-fpm pool changed by hand is kept beside the new one.

**Tokens**
- "Switch on" on a token that is not switched off no longer changes it; what
  was kept aside when it was switched off goes with a rename and away with a
  delete or a new enrolment.
- Switching off, on, unlocking, deleting and renaming wait for a confirm of
  the same name running at that moment.
- Recovery codes: one used on the other node at the same moment no longer
  shows as unused in the codes view, the export or after a rename; a rename
  counts the codes left correctly.
- Wrong codes for a waiting replacement no longer pause the token in use.
- "Last from" names the RADIUS client only where it was recorded.
- Ending a sign-in that is gone says so instead of writing "ended the
  sign-in of ?".

**Upgrades, cluster, backups**
- A node marked failed by the other while it waited comes back into
  service by itself; before marking, the other node's database is asked
  directly. Putting the same version in again no longer leaves a node in
  maintenance when it fails before anything was installed.
- The hourly numbering check no longer warns about the other node's rows
  being ahead (the usual thing) - it moves past them quietly.
- Copies take their name exclusively: the daemon and a root --backup in the
  same second no longer write the same file.
- Firewall ports: only ASCII digits.

**The pages**
- Log: past 20 000 rows the pager says "more than" and no false last page.
- A chart bar on a day the clocks change opens exactly that bar; the y-axis
  is as wide as its numbers.
- The time picker's ‹ › stay on whole months / weeks / days.
- A change made while settings were being saved is kept; a secret left as
  dots no longer sticks on the bar.
- Settings search finds Czech words.
- "Not in use while …" follows the choice.
- Firewall, certificates and the web address: a late refresh no longer
  overwrites a newer one.
- "Back in service" no longer leaves two windows; "End it" asks first;
  "Make it" and per-node Save once per press.
- About 50 more texts in Czech.

## 1.0.60 — 23 October 2026

A third look for bugs: the cluster's replication, the firewall and the web
address, and the LDAP and RADIUS protocols.

**Replication between two nodes**
- A row made on both nodes under the same name (one person enrolling on
  each, the same meta key, a first directory sign-in retried on the other
  node) stopped the replication for good on the duplicate. Now the same one
  of the two is kept on both nodes and replication goes on.
- A token changed on both nodes at once: each part keeps the newer change
  and both nodes end up the same - a token switched off is no longer
  switched back on by a sign-in on the other node, a lockout is no longer
  lost, a new key is not overwritten with the old one.
- Recovery codes: new ones made where the list was empty reached the other
  node and were then wiped on both - fixed; one code used on each node at
  the same moment no longer brings either back.
- Never two rebuilds at once (both nodes emptied), and the rebuild asked on
  the page is refused on the other node behind a balancer. Writes waiting
  while a rebuild started are refused properly. `--ha-join` stops the
  daemon while the rows come over.
- Each node checks every hour that its table numbering is ahead of the rows
  (after a restore on the other node).
- The disk test of the tuning page no longer writes a key both nodes share.
- Said in the documentation: within the replication's lag a TOTP code can
  be taken once on each node; send one person to one node where you can.

**Firewall and the web address**
- otp's chain lets in loopback, answers to this machine's own connections
  (LDAP, DNS, mail, replication) and IPv6 neighbour discovery before any
  rule: a DROP rule of yours broke sign-ins and the health check.
- The other node is let in on every port (its answers too).
- 2000 rules at most (200 RADIUS clients refused the whole request before);
  a range counts as two ports, a port with a newline is refused; the
  cluster's addresses come first in the allow lists.
- A failed apply on a machine with no rules before takes otp's chain out
  again; iptables' real message is shown.
- Each change is applied once, not twice.
- The default preferred node of the web address is the same on both nodes.
- "Who may reach the pages" checks your own address everywhere it can be
  set; a host name as the other node is resolved.
- PostgreSQL's log is read without following links, with its time zone.

**LDAP**
- Busy / unavailable / unreadable answers try the next domain controller
  instead of calling the password wrong; a server announcing its shutdown is
  left at once; a malformed answer fails at once.
- One search has a time limit as a whole; a sign-in's groups at most 20
  pages. Ranged memberOf is read.

**RADIUS**
- A Status-Server (or monitoring) no longer makes a client require a
  Message-Authenticator for every later request.
- The accounting port writes refused packets sparingly, and checks a
  Message-Authenticator where there is one.
- Empty attributes, Tunnel-Type values over 3 bytes and vendors with a
  different layout (WiMAX, USR, Lucent, Starent, MS-MPPE keys) are refused
  in the answer's lines instead of going out wrong.
- The test client refuses passwords over 128 bytes, checks the answer's
  length and Message-Authenticator.

## 1.0.59 — 23 October 2026

Errors under load, a fuzz of the RADIUS port and a second review of the
parts not looked at before (enrolment, mail, upgrade, rename, backups, CLI).

**Under load and with the database gone**
- The database unreachable: RADIUS requests go unanswered instead of being
  refused, so the VPN asks the other node (a refusal refused everybody
  until the database was back). The NAS's repeat is tried again.
- Log lines that can come thousands of times a second (database gone, a
  broken packet, a write-down that failed) are written once in a while
  with how many were left out - a 10 s database outage under load wrote
  50 MB of log. Housekeeping waits for the database without a traceback
  every 5 s.
- A User-Name with a NUL byte in it (fuzz) broke every such request and
  its write-down on PostgreSQL: NUL is now replaced before it reaches the
  database.
- Load on both nodes at once: the tokens stay the same on both.

**Enrolment and tokens**
- The enrolment page could bind a person to another person's token of the
  same bare name in a realm on a different directory: only names whose
  realm reads the same directory count now.
- Wrong codes while confirming a replacement no longer lock the token
  still in use; past the lockout count the new key is thrown away.
- Enrol, confirm, cancel and replace for one name go one at a time: a
  confirm landing on a key written meanwhile made an unproven key active.
- A pending token switched off and on waits for its code again instead of
  coming into use.
- The hourly fill of names no longer brings a deleted token back empty.
- A locked token's confirm says "locked out", not "rate limit".

**Upgrade, rename, backups**
- A node running the new version whose checks failed stays in
  maintenance instead of going back into service broken.
- A node that dies mid-upgrade is marked failed by the other after the
  timeout - the plan no longer runs for ever.
- install.sh from the pages has its own 20 min deadline (systemd 25,
  the daemon 30); a stopped helper says so.
- The opt→otp rename remembers each step as it is done: a half-done
  rename no longer leaves config.json with the old names.
- A copy put back without its key says loudly when its tokens do not open.
  The dump download reminds that the key is not in it.
- Copies are written under a temporary name and get a name of their own
  (two in one second overwrote each other); made by root, they belong to
  the service. The nightly dumps count as the latest copy.
- `--ha-resync` is root only; `--ha-join` throws away local tokens only
  with `--discard-local`; `--enroll` over a token in use and
  `--delete-token` ask (or take `--yes`).

**Mail, isemon, the rest**
- Going straight to the recipients' MX, TLS where offered no longer checks
  their certificate (a self-signed one failed every message); "required"
  still does. `mail_dns` is used even with dnspython installed. One 60 s
  deadline over all MX of a domain.
- A TCP isemon target that cannot be reached is left alone for 15 s - 5 min
  instead of holding every line 5 s (the queue filled and local files lost
  lines).
- The pages read the API port from /run/otp/api-port: changing api_port
  no longer breaks them.
- Overview day bars follow local midnight across summer time.
- The sign-in throttle map is tidied at most every 30 s and capped.

## 1.0.58 — 23 October 2026

- Tokens: beside the address a token was last used from, the RADIUS client
  it came through (the ASA, a test client…) - in the list, in the token's
  window and in the overview's "Used last". Kept from now on with every
  sign-in; for the ones before, the client whose address it is. Searchable
  as `client:ASA` (sign-ins from now on).

## 1.0.57 — 23 October 2026

A review of the whole application - security, bugs and speed - and what it
found, fixed. Also: the answer's lines written with help.

**The answer's lines, with help (Settings → Realms)**
- Ctrl+Space (or typing a name) lists what an Access-Accept can carry - the
  standard attributes and those of Cisco ASA/FTD, Cisco IOS/ISE, FortiGate,
  Palo Alto, Check Point, Juniper, Citrix NetScaler, F5, SonicWall, Aruba,
  MikroTik, Microsoft, pfSense, Zyxel - each with what it does, its vendor
  and number, and an example; after "=" the values of a numbered one (VLAN,
  IEEE-802, Administrative-User…). A product to narrow it to, with what that
  product reads (WatchGuard, Sophos, OpenVPN AS, Ivanti, UniFi, Horizon UAG
  too), ready-made lines (VLAN, an ASA group policy, a FortiGate group…),
  and every line checked as it is typed. The group lines have the same.
- About 70 vendor attributes can now be sent (Vendor-Specific); any other as
  `Vendor-<vendor>-Attr-<number> = value`. docs/reply-attributes.md lists
  them product by product.

**Security**
- Root's files could be written into through an IPv6 scope id
  (`fe80::1%…`), which Python keeps with any character in it: addresses are
  now plain addresses only, checked by the daemon and again by root, in the
  firewall rules, the page allow lists, the web address, RADIUS clients and
  certificate names.
- Root no longer trusts what it wrote last in the otp account's folder
  (status.json): every value it uses again is checked again.
- BlastRADIUS: an Access-Request with Proxy-State and no
  Message-Authenticator is refused (as FreeRADIUS's limit_proxy_state); "has
  sent one before" is remembered per address of a client, not per client.
- MS-CHAP, EAP, CHAP-Challenge and Tunnel-Password are never written into
  the log or sent to isemon.
- A realm's or a group's answer that cannot be built refuses the sign-in
  instead of letting in without the attributes that limit it; two accounts
  answering to one name are refused, not one of them taken by chance.
- A token locked out or paused is refused before its directory password is
  tried (no free AD password guessing).
- A token administrator can no longer replace a token in use (and receive
  its new key) or rename one: a full administrator's to do.
- Testing a code (Tokens) and the RADIUS test are counted per administrator,
  as sign-ins are; changing one's own password is counted too; a switched-off
  account is told "wrong name or password", like any other failure.
- Database and cluster settings can no longer be changed through
  Settings or an imported file (only by their own steps); a joining node's
  bundle and name are checked as settings are.
- Looking a person up in the directory needs a token administrator; the
  firewall page a token administrator too; reading PostgreSQL's log is an
  event; the admin allow list cannot be saved shutting out the one saving it.
- The RADIUS shared secret typed into the load balancer guide is not kept in
  the browser; a node name in a question is shown as text.
- Log lines cannot be faked through a user name (a new line continues
  indented).

**Bugs**
- LDAP: a domain controller that takes the connection and then says nothing
  no longer stops every sign-in - the next server is asked.
- A right code sent twice (a NAS asking again, or the other node) is refused
  but no longer counted as a wrong code towards the lockout.
- Two replicating nodes: a code or recovery code used on one could come back
  when the other wrote anything in the same token's row (PostgreSQL sends the
  whole row) - a trigger keeps the newer one.
- Settings and meta written on both nodes at once no longer stop replication
  on a duplicate key (one statement, not SELECT then INSERT).
- Rebuilding a node: nothing else writes meanwhile, the other node's
  subscription is made before this node writes again, and the numbering is
  put right whatever happens.
- The firewall: when anything fails half way, the rules and the files go
  back to what they were; firewalld refusing VRRP is said; files put back
  get their SELinux label.
- The web address's draft is taken from the server until something is
  changed (a later save no longer undid a move or turned the address off);
  edits made while saving are kept.
- A CA pasted for a directory goes to that directory, whichever is picked
  when saved.
- Lists: only the newest answer is drawn; they are not redrawn under
  somebody reading them; a page further back than 20 000 rows is said, not
  shown as page 200 again.
- The time picker: ‹ › by whole days, weeks, months; "yesterday" right
  around a change of summer time; a fixed start stays fixed.
- The overview's bars are on the local clock and there is no empty bar at
  the end.
- Signed out with changes not saved: said once, not "leave the page?" every
  five seconds.
- Smaller ones: a null setting no longer counts as changed; the refused
  setting is the right one; two job watchers, a second timer of the code
  tile, listeners left behind by every token window, "Make it again" pressed
  twice on the enrolment page.

**Speed**
- RADIUS: requests older than any NAS waits (15 s) are dropped after a
  stall instead of being worked through; a flood of made-up packets is
  written down once a minute, not row by row; past 10 000 refusals waiting
  out their delay, more are dropped rather than answered at once.
- PostgreSQL: TCP keepalives, so a connection lost in a failover is found in
  about 20 s; MariaDB: read/write timeouts.
- Search suggestions never group a whole log (30 days at most, never the
  event texts); the overview is kept 20 s; /healthz asks the database at
  most once a second; the event kinds are kept a minute; the enrolment tiles
  are one query.
- Forgetting old records and tidying go in batches with a breath between;
  tidying, directory names and the nightly copy run in threads of their
  own, so the heartbeat never waits for them; one node of two tidies.
- The pages ask for a pane only while it is in front and the tab is
  visible.

## 1.0.56 — 23 October 2026

- Every card of Settings saves through the bar at the bottom, as the
  settings themselves do - checked card by card:
  - High availability → the web address: its address, name, VRRP id, each
    node's interface, where it goes back to, and on/off (now a switch) are a
    draft until **Save the changes**; **Put them back** throws it away.
    Turning it off asks when saved (twice). *Move it here* stays a button:
    it is something done now, not a setting.
  - Active Directory and Mail → the certificate authority: pasted or read
    from a file, it is added on Save the changes (no Add it button).
  - The firewall (1.0.54) goes through the same: one bar for everything
    changed on the page, saved one after the other, stopping at the first
    that is refused.
  Lists edited in a window of their own (clients, realms, directories,
  accounts, a rule) and actions (backups, upgrades, replication) are as
  they were.
- The cluster's History can be cleared (asked twice): what the nodes wrote
  down by themselves is deleted; what was done by hand stays in Events and is
  no longer shown in the History.

## 1.0.55 — 23 October 2026

- The web address showed "holds it" on both nodes, with "On both nodes at
  once: they do not hear each other", though only one held it. Whether a
  node holds the address was asked by binding to it, and since 1.0.51 the
  web address turns net.ipv4.ip_nonlocal_bind on (so nginx can listen on
  it) - with that, the bind succeeds anywhere. It is now read from the
  kernel's own list of the machine's addresses (/proc/net/fib_trie,
  /proc/net/if_inet6). The cluster's History no longer says the address
  came to a node that never had it, and "it stays where it is" follows the
  node that really has it.

## 1.0.54 — 23 October 2026

- Firewall and access waits for the save bar, as the rest of Settings does:
  who may reach the pages, otp's firewall on or off, its rules turned on or
  off, the rules of your own (added, changed, moved, taken away) are a draft
  until **Save the changes**, and **Put them back** throws the draft away.
  A rule is checked by the daemon as soon as it is added or changed. Turning
  otp's firewall on or off still asks first when saved (off asks twice).
  One event says everything that was saved.

## 1.0.53 — 23 October 2026

- A time picker everywhere a list has a time window, as in isemon: the
  Overview (the chart and everything under it), the Log, Enrolment, Events
  (new there - all time by default) and the cluster's History.
  - Quick ranges: the last 15 minutes, hour, 6 and 24 hours, 3 days, week,
    month, 3 months, year (and all time where it makes sense).
  - By the calendar: today, yesterday, this week, last week, this month,
    last month.
  - The last N minutes, hours, days or weeks, typed in.
  - From - to by date and time (to empty: up to now).
  - ‹ and › move the window back and forth by its own length.
  - Each list remembers its window in the browser.
- The Overview's names, reasons, clients and places open the Log on the
  same window as the Overview.
- The API takes the window as `from` and `to` (seconds since 1970) on
  /api/events, /api/enrolment and /api/ha/history, and `since`/`until` on
  /api/dashboard and /api/activity.

## 1.0.52 — 23 October 2026

- Settings → Firewall and access, new:
  - **Who may reach the pages** - the enrolment pages, the administration and
    the health check (/healthz) each for everybody or only from the networks
    given (IPv4 and IPv6). nginx says it page by page (the allow lists of
    otp.conf, the web address's server with them); the other node, the web
    address and the machine itself are always let in.
  - **The firewall** (iptables and ip6tables): turned on, otp keeps a chain
    of its own, OTP-IN, first in INPUT on every node, and in
    /etc/sysconfig/iptables and ip6tables between marks of its own, so it is
    there after a reboot (the file is checked with iptables-restore --test
    before it is written; the rest of it, comments included, is left as it
    was). Turned off, the chain and its jump go and nothing else changes.
  - What otp's functions need is let in by itself and changes with them:
    HTTP/HTTPS (to the networks of the page lists), RADIUS only from the
    RADIUS clients set up, SSH, ICMP/ICMPv6, DHCPv6, and inside the cluster
    always the other node (PostgreSQL replication, its pages) and VRRP once
    the web address is on. The optional ones can be turned off one by one.
  - Rules of your own: accept, drop or reject; TCP, UDP, ICMP, VRRP or any;
    a port, a range or several; from an address or a network; IPv4, IPv6 or
    both; for all nodes or one; in an order of your own, looked at right
    after the other node of the cluster (which nothing can shut out) and
    before the rest of otp's.
  - Each node's state (in place, waiting, failed with root's words, with
    Try again) and the rest of its firewall, read only, IPv4 and IPv6.
  - firewalld running: otp leaves the firewall to it and says what to do.
- docs/firewall.md: the same, and how to do it by hand.
- Settings → High availability → The load balancer: a guide for each kind,
  folded until opened - HAProxy, nginx (with RADIUS over UDP), Apache, F5
  BIG-IP, Citrix NetScaler, keepalived + LVS, Cisco ASA, FortiGate, and how
  to check it. Filled in with this cluster's real node names, addresses,
  RADIUS ports and name, marked in colour, and with what is typed in above
  them (the balancer's address, the name, TLS ended or passed through, the
  health check, the shared secret - which only goes into the text); each
  block has Copy. Whether the nodes already trust the balancer's
  X-Forwarded-For is said, with the command when they do not.
- Replication's errors: the count in the table is a button - what PostgreSQL
  said about it, from its own log (root reads only the lines about logical
  replication), each with a sentence on what it usually means and what to
  do; errors and warnings or everything about replication. **Clear them**
  counts from then on (PostgreSQL's own count goes on).
- **History** (High availability, top): what happened to the cluster, day by
  day - the web address coming and going, a node's health, a node stopping
  and answering again, maintenance, replication paused, stopped, running
  again, new errors, a slot about to be lost - written by the nodes as they
  see it - and what was done by hand, filtered by kind.
- The web address: **where it goes back to** - always back to a node chosen
  (as before; the default is the first node), or **it stays where it is**:
  after a failover it does not come back by itself, only when the node that
  holds it fails or it is moved by hand. On the command line:
  `otp --vip-return NODE|stay`.
- Anything that destroys something is asked twice: the button in the popup
  turns into "Really? This cannot be taken back" with the button again.
  Switching a token off, throwing a new token or an uploaded package away
  now ask first too.

## 1.0.51 — 23 October 2026

- The web address's own certificate is answered on its IP address too, and
  to a client that sends no name - not only for its name. nginx listens on
  the address on both nodes (net.ipv4.ip_nonlocal_bind), so the node that
  takes the address over answers on it at once.
- DH parameters the node has made for itself serve the web address as well
  when the same are chosen: made once, not twice.
- The certificate cards stand level: each says under its name which
  certificate it is, the badge always top right.
- The web address's card shows, node by node, whether its certificate is in
  place, and how far root is when it is still being put in.

## 1.0.50 — 23 October 2026

- The buttons of a certificate's card are all the same size, two by two;
  *Download* and *Stop managing…* are buttons of the same size as the
  others, not two small icons.
- What root is doing on a node shows as a bar with a percentage on its card:
  the steps done, and while DH parameters are made, the time gone against
  the time it usually takes (2048 bits seconds, 4096 bits up to ten minutes).
- DH parameters are made before nginx's file is read, so an upgrade that
  runs while they are being made is never written over with an older copy
  of the file.
- Nothing in the settings menu or on the buttons is cut short any more: an
  open menu wraps a long name; the certificate buttons are named shorter
  (Upload, Request (CSR), Self-signed, TLS settings, Download, Let go) and wrap if they must.
- The box for pasting PEM is much bigger and shows the usual order in it:
  the certificate, the intermediates, the root, the key (any order is taken).
- The web address's card says what it is: the certificate of the cluster's
  VIP, answered on that address whichever node holds it.

## 1.0.49 — 23 October 2026

- The web address (VIP) is set, watched and moved on *Settings → High
  availability*, beside the nodes and the replication; *Settings →
  Certificates and TLS* keeps the certificates (the web address's own
  among them).
- *How it speaks TLS* made clearer: the four choices as tiles that say what
  each means and who can connect, the ciphers each uses shown on demand,
  the protocols of your own as switches, HSTS as one row of choices.

## 1.0.48 — 23 October 2026

- A node renamed (node_name) carries over, at its next start, everything
  kept under its old name: its own settings, its maintenance, its
  certificate and TLS settings, its place in the web address; the old name
  leaves the list of nodes. A rename made before this version: once
  `otp --ha-renamed OLD` on that node.
- docs/operations.md: how to rename a node, and that *What to call this
  installation* is the cluster's name, not a node's.

## 1.0.47 — 23 October 2026

Certificates and TLS
- *Settings → Certificates and the web address*: a card per node and one for
  the web address - the certificate, who issued it, until when (a bar that
  turns orange three weeks before), its names, key, chain and root, whether
  the chain leads to the root, the TLS settings, and whether it is in place.
- Upload a certificate as PEM files (certificate, key, chain, root - any
  order, or all in one) or as PFX / PKCS#12, with a password or without
  (old PFX files too, and keys with a passphrase); or make the request (CSR)
  here - the key stays here - and upload only what the authority sends
  back; or make a self-signed one. The certificates are sorted by
  themselves and the chain checked against the root.
- TLS per node and for the web address: Standard, Mozilla intermediate,
  Mozilla modern or custom protocols and ciphers; DH parameters (RFC 7919
  groups, or made on the node); the server choosing the cipher; HSTS.
- Root puts it in through a new helper (otp_web.py, otp-web.path): every
  value checked, nginx asked before it is reloaded and every file put back
  when it says no.
- Command line: otp --web-status, --tls-import, --tls-preset, --tls-dh,
  --tls-hsts, --tls-for.

The web address (VIP)
- In a cluster, one more address for the pages, on one node at a time,
  held by keepalived (installed by itself). It leaves a node that goes into
  maintenance, is upgraded or rebuilt, whose own /healthz (nginx, PHP, the
  daemon, the database) fails, whose RADIUS stops listening, or that is gone;
  and returns to the node it is meant to be on once that is well. Moved by
  hand on the pages (*Move it here*) or with otp --vip-move; on and off with
  otp --vip. Its own name and certificate (nginx answers it by SNI). RADIUS
  stays active/active on the nodes' own addresses.
- With it off, a load balancer of your own works as before.
- keepalived's check is put in /usr/libexec/keepalived, where SELinux lets
  keepalived run it.

Health checks
- /healthz?check=radius also says whether RADIUS listens (for a balancer of
  UDP 1812/1813); /healthz?check=all also whether replication runs (for
  monitoring).

The cluster on the command line
- otp --ha-compare: every table counted on both nodes, side by side.
- otp --ha-standalone: leave the cluster and go on alone keeping everything -
  replication and its slots taken away, the other node forgotten,
  config.json a single server's again.
- otp --ha-forget NAME: a node off the list.
- otp --ha-resync stops otp on the node while it is rebuilt (its heartbeat met
  the rows coming over) and makes a copy of what was there first.
- otp --ha-status: errors counted earlier no longer mark a running direction
  as failed.

Documents (docs/)
- operations.md - the runbook: a fresh install, PostgreSQL 16 on AlmaLinux 9,
  moving from SQLite, building the cluster, every-day checks, upgrades,
  OS updates, a node down for a while, a split network, a node lost for good,
  "lost" replication, leaving the cluster, changing an address, copies,
  back to SQLite, the key, a lost password, troubleshooting.
- tls-and-vip.md - certificates, TLS, the web address, and what to open in
  firewalld, iptables and nftables.
- load-balancers.md - HAProxy, nginx (and nginx Plus), Apache, F5 BIG-IP,
  Citrix NetScaler, keepalived/LVS, Cisco ASA, with health checks that look
  at the whole node.

Other
- install.sh keeps its copies of nginx's file in /etc/nginx/otp-backups (the
  last ten), no longer beside it in conf.d.

## 1.0.46 — 23 October 2026

- A click on a recovery code that is still free copies it to the
  clipboard, and so does a click on the key beside the QR code (without
  its spaces) - in the administration and on the enrolment pages. The tile
  flashes green and a message says what was copied.

## 1.0.45 — 23 October 2026

- High availability: every line of the Log (requests and checks of a code),
  of the events and of the enrolment pages says which node wrote it - a
  *Node* column in a cluster, in the details of a request or a check, and
  the field `node:` in the search box (`node:otp2`). Lines written before
  this version have none.
- Test: in a cluster the test can be made on any node that answers (*On
  the node*). It is asked through the database both nodes open, the
  password sealed with the key both have, and answered by that node as if
  asked on its own pages; the answer says where it was made.
- Upgrading a cluster: the new column has to be on a node before the other
  sends it rows that carry it. Upgraded from the pages that is so by itself
  (the other node goes first); by hand, upgrade the node that is not
  answering the pages first - until both are, replication waits and then
  goes on by itself.

## 1.0.44 — 23 October 2026

A review of the whole application for bugs; what it found, put right.

Security
- Enrolment pages: somebody with only the directory password could get a
  second token for the same person by signing in under another spelling
  (DOMAIN\\name, another realm on the same directory, other letters' case).
  The token the person has already is the one the session is about now.
- The sign-in limit per name counts the person, not the spelling: DOMAIN\\ro,
  ro@anything and Ro are one name.
- *Code now* needs "show the key of a token" switched on, as the key itself
  does, and every look is written down by the server whatever the page
  says (once per five minutes per person and token).
- Upgrades from the pages: root's helper works on the upgrade folder through
  one descriptor opened once, so the otp account cannot swap the folder for
  a link between two of root's steps; a FIFO put in a file's place no longer
  holds it up; a package's headers are counted as they are read, not all
  read first. install.sh makes the folders inside /var/lib/otp as the otp
  account (root's install -d followed a link there). Release keys a new
  version no longer ships are no longer trusted.
- MariaDB: names are compared byte for byte, as SQLite and PostgreSQL
  compare them; novák@x.cz and novak@x.cz were one token, and one person's
  token was written over the other's. Existing tables are changed once.
- A wrong code on the confirm page counts toward the lockout, not only the
  short pause.
- The replication password never reaches PostgreSQL's log: the other node's
  database is tried first, and a subscription that would fail is not sent.

RADIUS and the directory
- Proxy-State is sent back in every answer (RFC 2865): behind a RADIUS
  proxy every answer was thrown away.
- Status-Server on the accounting port is answered (RFC 5997).
- An answer too long for a packet (too many reply attributes) is a logged
  refusal instead of no answer at all.
- A directory given as [IPv6]:port works.
- A connection to a domain controller that drops during a sign-in is "could
  not be reached", and the next one is asked - not "wrong password".
- Directories reloaded no longer vanish for a moment under a request.
- Wrong codes are counted in the database itself, so two nodes do not lose
  each other's counts.

The database, upgrades, high availability
- Putting back the oldest kept copy works; the safety copy made first
  rotated that very copy away.
- Putting a copy back keeps this machine's maintenance, heartbeats, upgrades
  and jobs (and, in a cluster, the other node's).
- In a cluster a copy sealed with another key is refused before anything is
  replaced.
- A cancelled upgrade finishes the node that had begun: one that drained
  goes back into service, one that installs is checked.
- A node waits for the other to be alive and in service before it leaves
  for its upgrade - never both out at once.
- A node whose install.sh does not finish in 10 minutes is marked failed,
  not done.
- *Forget the package* removes its pieces from the database (it removed
  none), and a new package removes every older one's.
- Rebuilding a node from the other: nothing of its own is written while the
  rows come over (it answers nothing meanwhile), so the copy no longer stops
  on a duplicate key.
- A daily backup set as 3:30 runs (only 03:30 did).
- The disk speed probe measures a real write.
- install.sh --upgrade: a machine installed without the pages is upgraded
  without them; a failed upgrade starts the daemon again and brings the node
  back into service; it never moves the machine's PHP to Remi by itself; a
  retry keeps the first copy of the nginx configuration. --uninstall waits
  for an upgrade going on and says what it leaves (certificate, firewall).

The pages
- A popup over a popup that opened nothing (Back in service, a failed
  request) froze the page; it cannot now.
- *Code now* stops asking once its window is closed.
- *Make new ones* (recovery codes), *Check it* and *Look a name up* are
  shown only to who may use them.
- Saving a client before its realms were read no longer clears the realms
  it may use.
- A role the server refused is not left showing in Accounts.
- The Test tab names an answer that is neither accept nor reject as it is.
- Directory buttons and long buttons wrap at phone width.
- A few untranslated texts translated.

The API and the command line
- Imports check every realm's directory before saving anything, and what
  was saved is in use even when something after it was refused.
- A field of the wrong kind is a 400 with a reason, not a 500.
- Renaming a token follows the same rule for names as a new token.
- /api/portal/me says nothing once the enrolment pages are switched off.
- otp --set-role needs --role and keeps the last full administrator;
  otp --passwd ends the account's sign-ins; otp --restore takes every kind
  of copy, makes a safety copy and uses the key that came with it; bare
  otp shows the status again; --delete-token removes what was kept beside
  the token; --scratch is written down; --tokens --limit is honoured;
  ordinary mistakes are one line, not a trace.

## 1.0.43 — 23 October 2026

- High availability: on a node that is one of two already, *Making it two*
  no longer warns that PostgreSQL is on this machine (127.0.0.1) - with
  replication each node has its own and the other never opens it. The
  check says so in green, and the steps are folded away behind *Show how
  it was made*.

## 1.0.42 — 23 October 2026

- *Try a code*: the marked answer takes the place of the line under the
  row at the same height, so the token window does not grow and gets no
  scroll bar after a try.

## 1.0.41 — 23 October 2026

- *Code now* keeps its size: the tile is as big with the code shown as
  before it, and the other tiles beside it do not move.
- Shown, a click on *Code now* copies the code (without the space) to the
  clipboard; the tile flashes green and a message says so.
- *Try a code* marks its answer: a green "✓ RIGHT" or a red "✗ WRONG"
  label with the reason, and the code box goes green or red until it is
  typed in again.

## 1.0.40 — 23 October 2026

- The token window has a tile *Code now*: pressed, it shows the code the
  phone shows at this moment, with a ring counting down its seconds, and
  goes on to the next code by itself. A full administrator only; every look
  is written in the events.

## 1.0.39 — 23 October 2026

- The buttons at the end of a row in Tokens, the Log and the other lists are
  a cell of the row like any other, as in Settings: no colour or place of
  their own. A table wider than its card scrolls sideways.

## 1.0.38 — 23 October 2026

**Small things on the pages.**
- The database card's window shows what the database holds as a table: what
  each table is, its name, its rows and its room with a bar, biggest first;
  and the copies with their size, when they were made and whether the key is
  beside them.
- *Open Upgrades* (and every card's button to its settings) opens that very
  page of Settings, not whichever one was open last.

## 1.0.37 — 23 October 2026

**The program is called otp - everywhere.**
- Until now it was installed as "opt". From this version on everything is
  otp: the service `otp.service` (`systemctl status otp`), the command `otp`,
  `/usr/local/lib/otp/otp.py`, `/var/lib/otp`, `/etc/otp/config.json`,
  `/var/log/otp/otp.log`, `/var/www/otp`, the accounts `otp`, `otp-web` and
  `otp-www`, nginx's `/etc/nginx/conf.d/otp.conf`, the php-fpm pool, the
  logrotate and polkit files, the SQLite file `otp.db`, the copies and dumps
  (`otp-…`), the package `otp-X.Y.Z.tar.gz`.
- `install.sh --upgrade` from an opt installation renames all of it once,
  keeping every setting, token, account and log: the accounts are renamed
  (so every file keeps its owner), the folders moved, nginx's file kept with
  its host name and allow lists, the certificate kept.
- The databases too: a PostgreSQL or MariaDB on the same machine has its
  database and account opt renamed otp (pg_hba.conf with them). One on
  another machine keeps its names, written into config.json. Replicated, the
  publication, the subscriptions and the slots become `otp_pub` and
  `otp_from_N` on both nodes without stopping or losing a row - whichever
  node is upgraded first, the second finishes it.
- Copies and dumps made under the old name are still listed and put back.
  Nothing else answers to "opt" any more.

**Upgrades from the pages, one node at a time.**
- *Settings → Upgrades*: send the released `.tar.gz` and press *Upgrade*.
  One server is put in and restarted; a cluster is upgraded node by node -
  each taken out of service, upgraded, checked (its database, RADIUS, the
  replicated tables read again) and brought back before the next begins. A
  failure stops it there with what `install.sh` said; *Stop it* leaves the
  rest as they are. `otp --upgrade-status`, `otp --upgrade-cancel`.
- Nothing is installed by the service itself: root does it, through
  `otp-upgrade.path` and `otp-upgrade.service`, after checking the package
  again from a copy of its own. Every release is now **signed** (`MANIFEST`,
  `MANIFEST.sig`, Ed25519): a package changed or signed by a key the server
  does not know is refused, as is one older than what runs.
- The command line works as it always has. This version has to go in on the
  command line once - that installs the units and the release key.
- docs/upgrades.md: both ways, and the operating system too.

**Maintenance.**
- A node in maintenance answers no RADIUS request and its `/healthz` says 503,
  so the VPN and the load balancer use the other one; its pages go on
  working. *Settings → Upgrades*, the Overview, or `otp --maintenance on|off|status`.
- `install.sh --upgrade` takes the node out of service while it works and
  puts it back once the new version answers.

**A cluster: each node's own settings.**
- The address RADIUS listens on, the API port, the mail HELO name, the isemon
  host name and the debug switches are now kept per node (*Settings → High
  availability → Each node's own settings*); before, one node's address was
  given to the other too. Everything else is the cluster's, as before.

**The Overview.**
- The four cards open what they count, as isemon's do: who was let in, why
  people were refused, the tokens (locked out, used last), isemon.
- Four more: this server (version, uptime, RADIUS, problems), high
  availability (nodes, replication), the database (size, the last copy, the
  key) and maintenance and upgrades - each opening its details.

**Moving between databases.**
- After a move, making a copy or a dump was refused for ever: the copy made
  at the start of the move held the move as "going on", and the new database
  kept showing it. Such notes are no longer carried over, and a job whose
  process has gone is taken as ended.
- After *Set it up*, the steps after it did not find the password it had just
  made ("no password supplied").
- The database's address can no longer be saved with the save bar: saved,
  the next restart opened a database nothing had been carried into. The four
  steps are the only way.
- *Start using it* refuses a database that holds an older copy (left by an
  earlier move): empty it and carry everything across first.

**Smaller.**
- `systemctl status otp` works: the unit has the alias `otp.service`.
- Fact tiles wrap long words and addresses instead of running over their
  border.

## 1.0.36 — 23 October 2026

A second detailed pass over the whole program - the server, the pages, the
enrolment pages, PHP and the installer - and what it found.

**RADIUS.**
- On a server listening on `::`, answers to IPv4 clients go back to the
  address the request came from (`::ffff:a.b.c.d`); they were lost.
- A delayed refusal (*Wait before a refusal*) is waited out by one thread for
  all of them, not in a worker: a flood of wrong codes no longer ties the
  workers up sleeping. A delayed answer is not kept as the answer to a repeat.
- A client's allowed realms may have names with spaces, and follow a realm
  that is renamed or taken away.

**Tokens.**
- A wrong code for a token deleted at that moment no longer writes an empty
  token back under its name; switching off, notes, clock drift and *Forget
  them* refuse a name with no token instead of making one.
- Making a token again, or importing one over it, ends a lockout; an import
  also drops a waiting replacement.
- A confirmed replacement no longer shows the old key's last use.
- A new QR code keeps the token's note.
- A `.totp` file must hold a key of at least 80 bits; a file of rubbish was
  imported as a token. A counter (HOTP) file is refused.
- Export with *Steps of clock drift* 0 writes `WINDOW_SIZE 1`.
- `otp --restore` and a configuration read again seal restored tokens to their
  names; `otp --unlock` says so when there is no such token; `otp --check`
  shows each realm's way of signing in.

**The database and the directory.**
- TLS to MariaDB/MySQL checks the certificate when asked to; the dump and
  restore tools use the same TLS settings. A server address may be IPv6.
- A connection lost in the middle of a restore is not quietly reopened
  half-way through the transaction.
- A directory connection used again no longer fails at once on a deadline
  left over from the last question; every page of a search has its own.
- An unreachable directory is asked about a signed-in administrator again in
  a minute, not on every click.
- An error answered to somebody signed in no longer keeps their session alive.

**The administration pages.**
- *Move to* → *No* goes back to the token window.
- *Try* results are green or red; *Try sign-in* keeps its boxes after a
  failure, so a typo can be put right.
- *Print* prints the popup alone, black on white - not the page under it
  eight times.
- A bar of the overview chart shows that hour from the server: right count,
  and every page of it.
- The group finder of a realm empties after an error, so groups of another
  directory cannot be added.
- The mail test is held back only by unsaved mail settings.
- The buttons at the end of a row stay in sight in a narrow window; on a
  phone the pager no longer covers the rows and the tabs stay on one line.
- Every settings page has an icon of its own.
- Czech: some two hundred more answers, events and errors translated; plurals
  right; "Odebrat … away" and "realm je gone" gone.

**The enrolment pages.**
- A code that is not 6-8 digits is said so before it is sent; the reason a
  code was wrong is translated.
- nginx's own answers (too many attempts, server down) are said in words.
- The page's title, the disabled-token text and the hints are translated;
  the key breaks only between its groups on a phone.

**PHP, the installer, the documents.**
- The php2shell check asks php-fpm itself, not the command-line PHP, and reads
  the changelog whole (a `| grep -q` under pipefail could miss the CVE and
  move a fixed PHP to Remi). On Debian the pool goes to the php-fpm that is
  installed, not to the first folder by name.
- php-fpm is reloaded only when otp's pool or the guard changed - other sites
  on the machine are left alone.
- Installing again keeps the nginx file (`--rewrite-nginx` writes it afresh).
- `--dry-run --import-legacy` changes nothing; a copy that broke off is not
  imported. `--uninstall` also removes the polkit rule.
- `/healthz` says when the pages cannot read the API token; a download after
  signing out goes back to the sign-in.
- High availability: how the balancer must pass the client's address
  (`option forwardfor` or the PROXY protocol); with plain `mode tcp` every
  sign-in limit was shared by everybody.

## 1.0.35 — 23 October 2026

**The offer under a box low on the screen is seen.**
- A box near the bottom of the screen - *Move to* in a token's window -
  opens its list of people upwards, as it was meant to. It was pushed below
  the edge of the screen instead, leaving a sliver nobody could see, so the
  list seemed never to come.

## 1.0.34 — 23 October 2026

**Move to offers people as Make a token does.**
- Typing part of a name in a token's *Move to* offers the people of every
  realm's directory, with their full name, mail and whether they have a
  token - as *Make a token* does. It offered nobody: it asked for the realm
  by what comes after the @, and the directories are asked by the realm's
  name. The same slip hid the people in any box once a whole @domain was
  typed after a name.

## 1.0.33 — 23 October 2026

A security review of the whole program (the RADIUS server and the code
check; the pages, the API and PHP; the database, the directory, mail, high
availability and files), load tests, and what they found.

**Signing in to the administration from the directory.**
- With no group given a role, nobody from the directory gets in. Before,
  anybody in the directory could then read every log, token and account.
- A directory administrator is asked about again every ten minutes: switched
  off there, or out of every group with a role, and every sign-in of theirs
  ends; a role that changed changes. Changing the role groups or the
  directory signs everybody from the directory out.
- A password changed or set ends the other sign-ins of that account.
- An unknown name takes as long to refuse as a known one.

**RADIUS.**
- The order is now realm, directory (the account, in use, its groups), the
  password, and the code last. Somebody without the password can no longer
  guess codes or lock a token out; a code is used up only by a request that
  would be let in. In "password then code" realms one wrong attempt counts
  once (the probes that find where the password ends counted three times and
  paused the person after one typo), and one password costs the directory
  one try.
- A client can be limited to the realms it may use (Clients → Realms it may
  use). Without it the name typed chose the realm - and with it how strictly
  the person was checked: user@wifi at the VPN, password alone.
- A realm written with a dot at the end is the same realm; a name with
  nothing before its @ is refused.
- Lockout: after 10 wrong codes in a row, however slowly, a token takes no
  code for 15 minutes (Settings → The tokens). The short pause alone let a
  patient guesser try thousands of codes a day. *Forget them* ends it.
- A refusal goes back without its reason (Settings → RADIUS → Say why in a
  refusal): the VPN could show strangers whether a name has a token, or that
  the code was right and the password not.
- Message-Authenticator: a client that has sent one must go on sending one;
  one of the wrong length is wrong, not missing; answers carry it first.
- The answer goes out before anything is written down: a slow database
  delays the log, not the person, and no longer leaves a request let in
  without its answer. A refusal's delay waits on a timer, not in a worker.
- Junk from anywhere is counted, not written down a row each, and summed up
  once a minute; unknown addresses at most 30 rows a minute.
- The duplicate cache has a hard limit and no longer rebuilds itself.
- Only digits 0-9 are a code (Arabic-Indic digits left a request unanswered
  and unwritten); recovery codes work also when as long as phone codes.
- A realm's reply may carry only reply attributes.
- Two thread races (the client list, the unknown-address table) are gone.

**Tokens.**
- New recovery codes for somebody else follow the rule for showing a key: a
  full administrator, where showing keys is allowed, written down as a
  warning. A token administrator could get working codes for anybody.
- Confirming a new token is throttled like a sign-in, and done one at a time.
- A replacement with a longer period no longer refuses every code after it.
- Every token's sealed key, recovery codes and waiting replacement are tied
  to its name: copied into another person's row in the database, they no
  longer open. Existing tokens are sealed again at the first start (20 000
  in about 4 seconds), and after a restore.

**The pages and the API.**
- `?api=lo%67in` no longer slips past nginx's count of sign-ins; the count
  in the daemon is taken before the password is checked (thirty at once got
  thirty tries, now five) and also per name.
- Details such as a domain controller's name or a bind DN go only to
  somebody signed in; an error inside goes to the log, not to the page.
- A read-only account no longer sees the last characters of secrets.
- The enrolment pages switched off sign out whoever is on them; a wrong
  password or code when replacing a token no longer signs the page out.
- The link in a token's mail is built from the address the pages were
  reached by, not taken from the page.
- An open page signs out after the idle time even while it refreshes itself.
- Events for throwing away a waiting replacement, a note changed, a sign-in
  ended (whose), and the enrolment page's cancel.
- The first password file of the installer is deleted once that password is
  changed.
- Search-as-you-type for numbers (recovery codes) no longer breaks on
  PostgreSQL.

**The database, mail, the directory.**
- Database name, account and host are checked: a name like
  `--result-file=…` was an option to mariadb-dump; control characters in a
  password could add lines to its option file.
- Database TLS: Settings → The database → Encryption (require, verify-ca,
  verify-full and the authority's file), also for the link to the other node.
- A restore is all or nothing: one that broke off half-way left the tokens
  empty.
- A connection lost is retried only for reads, or where nothing was sent: a
  write retried could have used a code twice, then refused it as used.
- Plain searches treat % and _ as themselves; very deep NOT/brackets refused.
- The key that seals the secrets is read once and kept, made with O_EXCL,
  and never made anew where the database already holds secrets sealed with
  a missing one.
- The directory: one deadline for a whole answer, and an answer that does
  not read is a directory error, not a crash.
- Mail straight to the recipients: answers to its DNS questions only from
  the server asked and for the question asked, within one deadline; an
  answer that does not read fails cleanly. TLS to the recipients' servers can
  be required (Settings → Mail).

**Speed.**
- New indexes: the events by kind, the log by packet and by client, the
  sign-ins by kind (the enrolment tab 38 → 0.7 ms, the kinds offered 98 →
  0.2 ms). The overview's chart is counted by the database (1.3 s for a
  month before). Old rows are deleted 5 000 at a time. A client's last-seen
  time is written once a minute, not on every packet; the last address of a
  token in one statement. The API takes 256 connections waiting at once (20
  pages asking at the same moment lost one).
- Measured on one machine (SQLite, 20 000 tokens, 50 clients, 30 realms):
  RADIUS about 630 sign-ins a second with 50 clients at once, p99 104 ms, no
  answer lost; with 30 % wrong codes 580/s; 1 000 enrolments at 40 at once
  beside 10 000 sign-ins, no error, sign-ins p99 230 ms.

**Import.** A ZIP of .totp files can be dropped on *Bringing tokens over* -
a totpcgi folder zipped, or another otp's export (read in memory, with
limits on size and number; names inside are never used as paths).

**The pages.** *Your account* is wider.

**Known and left as it is, for now.**
- Replicated high availability (two databases) cannot make a code strictly
  one-time across both nodes while they are apart; shared mode (one
  database) can. Wrong codes are also counted per node there.
- A group named by its name alone (VPN_USERS) matches any group of that name
  anywhere under the base: pick groups from the directory (whole DN).
- Two realms both naming tokens without the realm share the tokens of
  people of the same name.
- MySQL 8 is not tested (MariaDB is); an account locked in Active Directory
  is refused by its password in password realms, not in code-only realms.

## 1.0.32 — 23 October 2026

**A token replaced on the enrolment pages could not be confirmed when the
settings had changed since it was made.**
- Every token keeps its own digits, period and hash: imported totpcgi tokens
  (SHA-1, 6 digits, 30 s) go on working beside tokens made later with other
  settings - that was always so. But a replacement waiting beside an old
  token was made with today's settings and checked with the old token's:
  an imported SHA-1 six-digit token replaced while the settings said
  SHA-512 and eight digits could never be confirmed. The waiting key now
  keeps its own shape, is confirmed with it, and the token takes it on once
  confirmed. *Show* on the waiting key shows it in its own shape too.
- Checked end to end: an imported SHA-1/6 token signs in, a new token is
  SHA-512/8, the old one replaced is confirmed with an 8-digit SHA-512 code
  and is SHA-512/8 from then on.

**What the hash and the length do, said where they are set.**
- *The hash*, *Digits in a code* and *A code lasts* now say that they are for
  tokens made from now on, and that Microsoft Authenticator and Google
  Authenticator on Android ignore SHA-256/SHA-512 (and Microsoft
  Authenticator eight digits) - their codes would be refused.

## 1.0.31 — 23 October 2026

**The step numbers in a token's mail are pictures.**
- Outlook's own circles (1.0.30) put the digit at the bottom edge, cut in
  half. Each number is now a small picture of the circle with its digit -
  drawn sharp for high-resolution screens, sent inside the mail like the QR
  code (about 2 KB each) - so it looks the same in Outlook, on the web and
  on a phone. With pictures blocked, the number itself is shown instead.

## 1.0.30 — 23 October 2026

**Round step numbers in Outlook as well.**
- Outlook on Windows draws mail with Word, which knows no rounded corners,
  so the numbered steps were squares there. In Outlook they are now drawn
  as VML circles - Outlook's own shapes - and every other mail program gets
  the same circles as before from CSS.
- The blue band at the top is one solid colour in Outlook too: its lighter
  stripes above and below the title are gone.

## 1.0.29 — 23 October 2026

**A token's mail that looks right in Outlook too.**
- Laid out in tables with sizes as attributes, which is all Outlook (it draws
  mail with Word) understands: the numbered steps are round badges beside
  their words instead of a sliver of blue, the QR code sits in a frame, the
  key is one line in a grey box, and the recovery codes are each in a box
  of their own, five to a row - they ran together into one long number.
- The account and the name under the QR code are plain text, not links
  that Outlook made of every name@domain, and are never broken in two.
- The plain-text copy of the mail is unchanged.

## 1.0.28 — 23 October 2026

**The steps of a sending folded away.**
- After making a token with its mail, and after *Send by mail* in a token's
  window, only the line saying how it went is shown - *Sent by mail to …*
  or why not. A click on it (or Enter) unfolds the steps: the MX records,
  the addresses, the server reached, TLS, what the server answered.
  *Settings → Mail → Try it*, which is there for the steps, still shows them.

## 1.0.27 — 23 October 2026

**A token's mail sent again.**
- *The person → By mail → Send by mail* in a token's window: the same
  choices as when it is made - the address, the recovery codes (the ones
  not used yet), Czech or English - and the steps of the sending.
- The address is remembered: wherever the token's mail went last time
  (when it was made, or sent again) is filled in, also when it was not the
  one in the directory; the row says where and when. It goes with the token
  when the token moves to another realm; given to somebody else, it does not.
- The key leaves the machine as when it is shown, so the same rule: a full
  administrator, with showing keys allowed. Every sending is a warning event.

**Where a mail went once it left.**
- *Handed the message over* now says what the receiving server answered -
  `250 2.0.0 Ok: queued as 4Xy…` - after making a token as well as when it
  failed, and the event keeps it: that id is what the receiving side's log
  (an IronPort's message tracking, say) is searched by when a mail never
  turns up although it left.
- *Settings → Mail → Try it* can send *a sample token mail* - the real
  layout, picture and codes, with a made-up key that opens nothing - next to
  the short message: a filter that lets a line of text through can still
  stop a mail with a QR code in it.

## 1.0.26 — 23 October 2026

**An upgrade leaves a good PHP alone.**
- `install.sh` (and `--upgrade`) no longer installs PHP again, switches its
  stream or restarts php-fpm when the PHP there already has the php2shell
  fix: it says so and goes on. Nothing pins a version - newer builds and
  streams come with the system's own `dnf upgrade` / `apt upgrade`.
- A PHP that is there but not fixed only has its own packages upgraded, on
  the stream it is on. Before, the stream was reset to `php:8.3` - which
  would have taken a machine already on `php:8.4` back down.
- A machine with no PHP gets `php:8.3` (`--php-stream`) only when no stream
  is enabled yet.

## 1.0.25 — 23 October 2026

**A popup closes only when told to.**
- A click beside a popup - on the darkened page, or on the window under a
  popup over it - no longer closes it; a stray click used to throw away a
  half-filled form. It closes with its own buttons (Save, Close, No, Back…),
  its ×, or Escape.

## 1.0.24 — 23 October 2026

**The window underneath stays still.**
- With a popup open over a token's window, the window underneath no longer
  jumps: its foot (the history, the Log, *Take the token away*, *Close*)
  lost its layout while it was underneath, wrapped onto two lines and gave
  the cards a scroll bar. Its look no longer depends on being on top.

## 1.0.23 — 23 October 2026

**Mail straight to the recipients: their servers' addresses too.**
- With *DNS servers for the recipients' domains* (`mail_dns`) set, the
  address of each recipient's mail server (A and AAAA, a CNAME followed) is
  asked of those servers as well, not only its MX record - before, only the
  MX went there and the address still came from the system's resolver.
  The connection goes to that address; the certificate is still checked
  against the server's name.
- With `mail_dns` empty, the address comes from the system's resolver
  (/etc/hosts, nsswitch) as before; only the MX question - which the system
  has no call for - is otp's own, sent to the servers in /etc/resolv.conf.
- Nothing else uses `mail_dns`: Active Directory, the SMTP relay, isemon,
  the database and the other node are looked up by the system as always.
- The step says what the address is and who gave it.

## 1.0.22 — 23 October 2026

**Mail straight to the recipients finds their mail servers.**
- The MX lookup asks with EDNS0, takes a cut-short answer again over TCP,
  follows a CNAME and knows a null MX. A DNS server that refuses or fails
  (SERVFAIL) is no longer taken for "this domain has no MX" - which sent
  the mail to the domain's own address (merit.cz:25) and timed out. It goes
  on to the next DNS server, and if none can answer it says which and why.
- The step says which DNS server gave the MX records.
- New setting *DNS servers for the recipients' domains* (`mail_dns`) for a
  machine whose own resolver will not answer; empty means /etc/resolv.conf.
  dnspython is used when it is installed.

**A window over a window.**
- In a token's window, *Show* (QR code and key, recovery codes), *In the
  directory*, the history, *New QR code*, new recovery codes, *Export .totp*
  and *Take the token away* open over it; closing them goes back to the
  token, drawn afresh where something changed. Esc closes only the top one.

**Passwords as isemon shows them.**
- Every password and secret box in the administration - the settings, the
  directory's account, a client's secret, accounts, the database, the Test
  tab, high availability - shows dots and its last two characters, both a
  kept one and one being typed. The sign-in pages keep the browser's own
  password box, so password managers still fill them.

**A person picked stays picked.**
- Once somebody is picked from the offer (or a box comes filled in), the
  offer does not pop up again when the box is clicked or focused - only
  once something is typed or deleted.

## 1.0.21 — 23 October 2026

**A token's window on one screen.**
- Four cards of exactly the same size, two by two: the phone, signing in,
  the recovery codes, the person. Their rows are lower, *Move to* and the
  note sit on one line each.
- When it was made, by whom, last used and from where sit beside the name
  instead of under it.
- The history, *Everything in the Log* and *Take the token away* are in the
  window's foot beside *Close* - no card of their own, and no scrolling on
  an ordinary screen.

## 1.0.20 — 23 October 2026

**Mail: a token's QR code sent to the person it is for.**
- *Settings → Mail*: through your mail server (STARTTLS 587, SMTPS 465, or
  none for a relay inside your network) with no sign-in, the best the server
  offers, PLAIN, LOGIN, CRAM-MD5 or XOAUTH2 (Microsoft 365, Google) - or
  straight to each recipient's domain by its MX record, with no server at
  all. The password is kept sealed with the tokens' key.
- The server's certificate is checked; a private authority is imported the
  same way as for Active Directory (paste or a .crt/.pem/.cer file, one or a
  chain, each listed with its whole fingerprint and removable on its own).
- *Try it* sends a short mail by the same road and shows every step:
  connection, TLS, sign-in, hand-over.

**Make a token: find the person, send it by mail.**
- *For* offers the people of the realms' directories as one types; picked,
  their mail address is read from the directory into *To* (it can be
  changed).
- *Send it by mail*: the QR code, the key, how to set the phone up, and -
  if ticked - the recovery codes, in Czech or English, as a tidy HTML mail
  with a plain-text copy. Every mail sent is in the events.
- The owner's full name is read from the directory as soon as the token is
  made - no need to press *Names from the directory* afterwards.

**Tokens out as .totp files.**
- *Settings → Export and import*: every token, or the ones a search picks
  (`realm:example.cz`, `name:novak*`, a state), as totpcgi .totp files in
  one ZIP - for totpcgi or another otp. A single token from its window:
  *For another server → Export .totp*. Full administrators only, with
  showing keys allowed, and each export is in the events as a warning.

**The pages made over.**
- One height for every box and button, one grid for the tiles, the token's
  window rebuilt as cards of actions, the settings laid on one grid so every
  name, box and explanation on a row starts at the same height.
- The list of suggestions floats above windows instead of being cut off
  inside them with its own scroll bars.
- Czech for everything new and for the titles still left in English.

## 1.0.19 — 23 October 2026

**Every search box offers its fields and values as one types (as isemon).**
- Tokens, the Log, Enrolment and Events read `field:value` besides plain
  words: `result:reject client:ASA`, `name:novak*`, `-state:active`,
  `realm:dpmo.cz,corpnet.cz`, `ms:>500`, `reason~ldap`, `from:10.1.0.0/16`,
  `(client:ASA OR client:localhost)`, `NOT …`. A name the list does not have
  is a word, so `10.1.2.3:1812` is searched as before.
- Under the box, as one types: the list's fields with what each means and an
  example; after `field:` what that field holds, busiest first, narrowed by
  what is typed. ↑ ↓ choose, Tab or Enter take, Esc closes. A search that
  cannot be read says why under the box. `GET /api/suggest` behind it.

**People and realms offered as one types.**
- *Make a token*, the token's *Move to*, *Look a name up* and the Test tab:
  type part of a name and the people of the realm's directory are offered,
  with their full name, mail, whether they are switched off and whether
  they have a token already; after an @ the realms are offered.

**A token can be given to another person, not only moved to another realm.**
- *Move to* takes any name; given to somebody else, the owner's name is read
  again from the directory. Key, recovery codes and history go with it.

**The person card, as isemon's.**
- The directory card (Accounts, a token's *In the directory*) and *Your
  account*: initials, name, principal name, tags (active / switched off /
  locked out / expires, role, realm, token), where the account lives as
  steps (domain › OU › person) with the DN, and the groups - the ones that
  make an administrator or let into a realm first, as cards saying so, the
  rest as chips (and N more).

**Fixes**
- The administration sign-in page said "the database will not open" to
  anyone not on the server itself, though it opened and signing in worked.
- Tiles never break a value in the middle of a word; a value too long ends
  in an ellipsis with the whole under the pointer.

## 1.0.18 — 22 October 2026

- Settings → Accounts: every row has the same buttons in the same places -
  the role first, then the directory lookup, the password, switching off,
  removing, the columns. A button that does not apply to an account (the
  directory for a local one, the password for a directory one) is there,
  dimmed, and says why; the invisible gaps that stood in for them made the
  rows look broken.

## 1.0.17 — 22 October 2026

**Long lists keep their search and their pager in place (as isemon).**

- Tokens, the Log, Enrolment and Events: the card is a column of heading,
  note, filters, the rows and the pager; only the rows scroll, the table's
  heading stays stuck to the top of them, and the search box and the pager
  never leave the window. A note longer than two lines is cut, and opens
  with a press on it. The daemon's own log under the events stays reachable.
  On a window too short or too narrow to frame, the page scrolls as one.

## 1.0.16 — 22 October 2026

**A tab for the enrolment pages: who came and what they did.**

- *Enrolment*, between Test and Events: every step a person took on the
  enrolment pages, newest first - signed in, made a token, confirmed it with
  a code, replaced an old one, could not sign in (and why), may not enrol
  (not in the groups). Six tiles count them for the chosen window (24 hours,
  a week, a month, all time); the list is searched by name or address and
  narrowed by step. A click on a row opens the person's token.
- `GET /api/enrolment` behind it (`q`, `step`, `since`, `limit`, `offset`).

## 1.0.15 — 22 October 2026

**A review of the whole program: security, bugs, the pages.**

Security - the daemon:
- A token an administrator switched off could be switched back on by its
  owner on the enrolment pages: confirming a code did not look at the state.
  Only a token that waits (new, or with a replacement staged) is confirmed
  now, and confirming never moves `last_step` back, so a code already used
  stays used.
- A test of a code in the Test tab ("dry") counted nothing and logged
  nothing: a token administrator could try codes without limit. Dry checks
  are logged (`test-dry`) and wrong ones count towards the pause.
- Recovery codes were kept as a plain SHA-256 of the code: a copy of the
  database without its key could be brute-forced offline in a minute. They
  are now keyed with the sealing key (HMAC); old rows are read and rewritten
  on their next use.
- The admin sign-in no longer says whether the name exists in the
  directory, or that the account there is locked or expired (that stays in
  the events).
- An account marked "must change the password" could call every endpoint;
  it may now only change the password, ask who it is, or sign out.
- A Reply-Message with non-ASCII characters longer than 253 bytes made the
  RADIUS server throw instead of answering and the request was never logged.
- `--trusted-proxy` wrote the real_ip block into the port-80 server, not the
  HTTPS one: behind a load balancer the sign-in pause was keyed on the
  balancer's address.
- HA: database passwords no longer pass on psql's command line nor reach
  PostgreSQL's log; an error text with a connection string is scrubbed
  before it is stored. The peer has to be one address (not a range); IPv6
  peers get /128. The `pg_hba.conf` line is prepended, so no earlier reject
  line wins.
- The per-name lock table and the "unknown client" table could grow without
  bound under a flood of made-up names and addresses.
- `--radtest` no longer prints the password.

Security - the pages:
- A restore upload (up to 4 GB) was read into a temp file before anyone was
  identified; now a full administrator's sign-in is checked first.
- The sign-in rate limit in nginx could be bypassed with a doubled or
  percent-encoded `api` parameter.
- `/healthz` is rate-limited; the pre-sign-in page tells its operator
  details (php-fpm user, token path, "no account yet") only from localhost;
  PHP errors are never displayed into a response.

The pages:
- Fields side by side in a popup started on different lines (the labels
  of a row were staggered); the tuning popup's memory field as well.
- Switching tabs with unsaved settings threw them away.
- The name of a switch setting did not flip it when clicked.
- Names with an apostrophe or an ampersand showed `&#39;` / `&amp;` in
  popup titles.
- Settings search: results are styled and say when nothing is found.
- Export and the Test tab are hidden from roles that may not use them.
- "Add it" under the certificate authority came back on a timer, so a slow
  import could be sent twice.
- The job progress is asked every five seconds when its pane is left (was
  every second, for ever).
- Escape over the column menu closed the popup under it too.
- Column layouts from a file are checked (no absurd widths, no junk).
- Shared secrets, bind passwords, first passwords and the HA passphrase
  are typed unseen; every popup label is linked to its box.
- Edit/person/lock buttons no longer turn red on hover; only the destructive
  ones do. Empty tables say "Nothing here". Several Czech texts that were
  still in English (the DB tooltips, HA buttons, token verdicts in the log,
  disk words in the tuning popup, the isemon rule note); `<this>` in the
  isemon hint was shown as `&lt;this&gt;`.
- The realm list no longer wraps its name, suffix and directory; the
  replication table's numbers have room; the import pane's checkbox is dark.
- The sign-in page of the administration shows the version and the language
  switch, as the enrolment pages do.
- The HA pane describes building and looking after the cluster with the
  exact commands, step by step, and has a table of every `--ha-*` command
  and when to use it. The intro follows the mode (replicated or shared).
- Sign-ins that sat untouched longer than allowed were still listed under
  "Signed in now"; they are tidied.
- About a third of the stylesheet was rules carried over from isemon for
  things these pages never draw; they are gone, as is a block that was in
  the file twice.

## 1.0.14 — 22 October 2026

**High availability, replicated: each node its own PostgreSQL, both answering**
- see docs/high-availability.md.

- `otp --ha-setup --ha-peer ADDRESS` now builds the replicated layout by
  default: logical replication both ways (publication `otp_pub`, subscriptions
  with `origin = none`, so nothing goes round in circles), odd ids on the first
  node and even on the second, `max_slot_wal_keep_size = 16GB`. The shared
  layout of 1.0.13 is `--ha-setup --ha-shared`.
- `otp --ha-join FILE` on the second node installs PostgreSQL if it is missing,
  copies every row from the first node and sets both directions up. The same
  command rejoins a reinstalled node.
- A node that was down catches up by itself. A node that was away longer than
  what is kept for it is rebuilt from the live one: `otp --ha-resync`, or
  *Rebuild this node from the other…* (a safety copy is made first).
- Watching and stepping in, on the pages (*Settings → High availability →
  Replication*) and on the command line: status of each direction (running,
  last heard from, waiting to go over, errors), `--ha-pause [both|in|out]`,
  `--ha-resume`, `--ha-stop`, `--ha-resync`, *Read the tables again*.
- Per-node things stay per node: the tuning record, the disk sizes, a job's
  progress, the nightly dump. The settings serial is a time and node mark, so
  both nodes' changes are seen.
- A new PostgreSQL database is created as UTF8 and every connection speaks
  UTF8 (an SQL_ASCII database failed on names with diacritics).

**Names from the directory after an import**
- Tokens brought in from another system get their owner's name from the
  directory, the same way as tokens enrolled here: right after the import, then
  every hour for any still without a name (100 at a time; a directory that does
  not answer is skipped for that round).
- A *Names from the directory* button on the Tokens tab does it at once for every
  token without a name; `otp --fill-names` on the command line.

**Settings → Active Directory → The certificate authority**
- The SHA-256 fingerprint is shown whole (two lines of 16 bytes) instead of
  cut short; a click selects it.

## 1.0.13 — 22 October 2026

**High availability: two servers, both answering (active/active), over one
PostgreSQL** - see docs/high-availability.md.

- Anything may go to either node, round robin and without stickiness: the
  "Edit the columns" switch is now kept with the sign-in in the database (it
  was in one daemon's memory), a job's progress is in the database too, and
  every setting changed on one node is read by the other within five seconds.
- A code - or a recovery code - is used up with one conditional UPDATE: two
  nodes asked for the same code at the same moment cannot both accept it.
- The nightly dump is claimed by one node.
- Each node writes a heartbeat; *Settings → High availability* lists the nodes
  (address, version, RADIUS, when last heard from), and the header says which
  node answered the page when there are two.
- The wizard: `otp --ha-setup --ha-peer ADDRESS` on the first node (opens a
  local PostgreSQL to the second node - listen_addresses, pg_hba.conf,
  firewalld - and writes the bundle), `otp --ha-join FILE` on the second; or
  *Make the bundle…* and *Join a cluster…* on the pages. The bundle carries
  the database's address and password and the key that opens the tokens,
  locked with a passphrase (scrypt + HMAC-SHA256) shown once.
  `otp --ha-status` lists the nodes.
- `GET /healthz` for the load balancer: 200 "ok NODE" while the node and its
  database answer, 503 when not.
- `otp --trusted-proxy CIDR`: nginx takes the client's address from
  X-Forwarded-For when it comes from the load balancer.
- `node_name` in config.json: this node's name (Settings → High availability).
- `install.sh --upgrade` now brings an existing nginx configuration up to the
  version (the 4 GB body for putting a database back, which 1.0.10 needed, and
  /healthz), keeping its allow lists and a copy of what it was.
- A token window's history, cleaner popups: a grid of two fields no longer has
  the second one pushed down.

## 1.0.12 — 22 October 2026

- **Several certificate authorities per directory.** A directory whose
  domain controllers come from several domains or authorities keeps a chain
  for each: *Add it* adds what is pasted or read from a file (a whole chain at
  once, and a certificate already kept is not added twice) instead of
  replacing it; every certificate is listed - who it is, who signed it, valid
  from and until (coloured as it nears its end), its SHA-256 fingerprint - and
  each has its own bin. *Take them all away* empties it.
- **A token's window is wide and needs no scrolling**: four cards side by
  side - the phone (with *Try a code* under it), the recovery codes, signing
  in (with *Take it away* under it) and the person (directory, realm, note) -
  and the history behind its button below them.

## 1.0.11 — 22 October 2026

**The whole interface gone over.**

- A token's window: the buttons of each card are one under another, all the
  same size; *Try a code* and *Note* take the whole width; the history (the
  checks of a code and the requests) is no longer drawn under everything but
  behind **The history** - a popup of its own with the way back - and
  **Everything in the Log** opens the Log searched for that name.
- **A token can be moved to another realm** (*The person → Realm → Move it*):
  its name changes to name@realm (or the bare name), with the same key, the
  same history and its recovery codes made again under the new name.
- Settings whose choices are long (*Who may enrol a token*, *Token names are
  kept*) are two columns wide, so the choice is not cut off.
- Fields in popups have room between them; the group searches are wide enough
  for their hint; the certificate authority's *Load a file…* has the upload
  icon and *Import* the save one; the phone on the enrolment page shows its
  code inside the screen.
- Realms: "default - also without @" and how a name is looked up are in the
  page's language; "/var/log/remote/<host>/" reads "HOST"; About says the
  engine by its name.
- Czech: the database pane, the reasons of the token engine (*Not a valid
  token*, *Scratch-token used*…), "From"/"Since" as *Odkud*/*Od kdy*, the new
  events.
- The database's restart: the tuning popup has **Restart the server…** itself
  when something waits for PostgreSQL's next start, and where it may not, says
  why (another machine, no single postgresql service, or install.sh's rule
  missing).
- The installer installs the database client only for the engine in the
  config file: `--with-db both` no longer puts the MariaDB client on a machine
  that runs on PostgreSQL.
- Events of copies and dumps read better ("made a PostgreSQL dump (every
  night): …").

## 1.0.10 — 22 October 2026

**Settings → The database, rebuilt to be isemon's.**

- **The dumps it keeps** (new): every night the database in use is dumped by
  its engine's own program - `pg_dump` (custom format, `.pgc`),
  `mariadb-dump` (`.sql.gz`), SQLite's own backup (`.db`) - into
  `/var/lib/otp/dumps`, with the key that opens the tokens beside each one.
  Where the program is missing, a portable copy is made instead and the card
  says what to install. *Make one now*, *Download one*, and per dump
  *Download*, *Restore* and *Delete*; *Put a dump back* takes one from
  elsewhere. A dump goes back only into the engine it came off.
- **Copies**: the same list for the portable copies (any engine), with
  *Download*, *Restore* and *Delete*, plus *Download it* (a copy made now,
  with the key inside it) and *Put a copy back* (drop a file). Everything put
  back is read and shown first - what it is, how many tokens, accounts and
  full administrators - and refused if it is not otp's, is a dump of another
  engine or has no full administrator. A copy of what is replaced is always
  made first. The file goes up as the request body itself (never multipart,
  php2shell), a lump at a time, up to 4 GB.
- **Which one it is**: the facts as isemon shows them, whether each driver is
  installed; *Try it*, *Set it up…*, *Carry everything across…*, *Empty it…*,
  *Start using it…* each in its own popup with what will happen.
- **The disk it is on** (new): free space, how fast the database grows (noted
  daily, the slope of the last fortnight), days left, the files it is made of
  (`otp.db`, `-wal`, `-shm`, the copies, the dumps); a warning when the
  server's own cache is smaller than the database.
- **The database server's own settings**: the popup shows the server, the
  machine (memory, free memory, processors), how the disk was judged - a
  virtual machine's disk always says it spins, so the time a small write takes
  decides, as on isemon - and per setting *Now / For this machine / Takes /
  Why*. Memory settings within a tenth are the same, so it no longer asks to
  change shared_buffers back and forth. What was tuned and when, and what is
  waiting for the server's next start, is said on the card.
- **Restart the server…**: PostgreSQL on this machine restarted from the page
  for the settings waiting for its start, refused when the memory free would
  not hold the new shared_buffers or huge pages are on, then waited for. The
  installer puts in a polkit rule that lets the `otp` account restart
  `postgresql*.service` and nothing else (`--no-db-restart` takes it away).
- **Erase the collected data** (new): the RADIUS requests, the checks of a
  code and the event log, each with its count, ticked and erased as a job
  with a copy made first and the disk given back afterwards. Tokens, accounts
  and settings are not in the list at all.
- The installer installs the database clients (`postgresql`, `mariadb`) with
  `--with-db`, for the dumps.

## 1.0.9 — 22 October 2026

**The columns of every table, laid out by whoever is looking - exactly as on isemon.**

- Every table in the administration (tokens, the log, events, realms,
  clients, accounts, sign-ins, groups, the database…) can be laid out per
  account: drag the edge of a heading to size a column (its width is shown
  in a pill at the foot of the window, twice on the edge puts that table's
  widths back), drag the heading itself to move the column, and the right
  button on a heading or a row opens the menu: hide this column, bring a
  hidden one back (a tick by each column), add an empty column to the left
  or right for room, take an empty one away, put this table back as it comes.
- Only while **Edit the columns** is switched on - under your name at the
  top right, or on Settings → Accounts. The switch is held by the daemon for
  that one sign-in: signing out, the sign-in running out or a restart of the
  service turn it off. Off, the layout is drawn just the same and nothing can
  move it; a change sent with it off is refused (409) and the page says so.
- The layout is kept with the account in the database (`accounts.cols`),
  not in the browser, so it follows you to any machine; widths are kept as
  shares of the table so it always fits its card. Laid out before the
  browser paints, so a table is never seen in its old order first.
- **Put my columns back as they come** (under your name and on Accounts).
  A full admin can put anybody's back: the new *Columns* column on Accounts
  says how many tables each person has laid out, and the button beside it
  resets them (logged as an event).
- **Your settings in a file**: *Export my settings* saves your column layout
  and language as `otp-settings-<you>-<date>.json` (kind
  `otp-user-settings`); *Import settings…* shows whose file it is, where and
  when it was saved and what it holds before replacing yours. isemon's own
  settings file is read too. Never a password, a role or anything else about
  the account.
- New API: `POST /api/auth/columns` (`{edit}`, `{cols}`, `{reset}`),
  `GET|POST /api/auth/settings`; `/api/users` action `reset_cols`;
  `whoami` carries `cols` and `cols_edit`.

**Who may enrol a token: the groups found and picked.**

- Settings → The enrolment pages → *Groups that may enrol* has a
  **Find and pick the groups** button: the same directory group search as
  for realms and administrators, with *May enrol* beside each group to put
  it in or take it out, the chosen ones shown as chips. It looks in the
  directory of the enrolment pages' realm (or the default realm) first.

## 1.0.8 — 22 October 2026

**Security: the groups of a realm are now always checked.**

- A realm whose *By* was "not looked up anywhere" skipped the directory
  entirely - its groups, a switched-off account - and let anybody with a right
  code in. A realm with a directory now always asks it: the way is chosen by
  the form of the name (with an @ by userPrincipalName, without it by
  sAMAccountName) when none is set. A realm that names groups and has no
  directory refuses everybody, saying so.
- **Enrolment** checks the realm's groups always: nobody enrols a token the VPN
  would refuse. *Who may enrol* can only narrow that further.
- Every refusal says why, with names: `account does not pass LDAP group
  filter(s): novak@example.cz is in none of VPN_USERS, VPN_ADMINS`, and on the
  enrolment pages the same goes into the log and the events.
- Groups inside groups (nested) count everywhere a group is asked about - the
  realms, enrolment, the administrators' roles - with Active Directory's
  in-chain rule; a realm can switch it off.
- A request that could not be decided because of an error inside gets a
  refusal with the reason, never silence.

**The default realm** (Settings → Realms): names written without a realm
belong to it - `novak` is `novak@example.cz` - on the enrolment pages and in
RADIUS requests from a client that adds no realm of its own; `novak@example.cz`
works as well, and every other realm still needs its @domain. The realm list
marks it.

**One log**: *Requests* and *Codes* are one tab, *Log* - every RADIUS request
with what the token said about its code, and every code checked anywhere else
(the enrolment pages, a test, the command line), filtered by kind, time,
result and client. A log is not edited from the pages any more: old lines go
by themselves after the days set under Settings → The database, which is also
where they can be cleared (*Forget records older than…*, or every line).

**Tokens**

- The token window is large and in sections: *The phone* (show the QR code and
  key, a new QR code with a new key, the waiting one), *Recovery codes* (show
  them - which are free and which were used, and when - or make new ones),
  *Signing in* (switch off, forget the wrong codes, clock drift), *Try a code*,
  *The person* (what the directory says, the note), *Take it away*.
- Recovery codes are kept sealed beside their hashes, so a full administrator
  can show them again; a used one stays, struck through, with when it was
  used. Tokens made before 1.0.8 have only the hashes: make new ones to have
  them shown. Every look is an event; *Administrators may show a token's QR
  code and key* switches it off.

**The pages**

- A pencil for every Edit, everywhere.
- *In the directory* beside every token and every account signed in from the
  directory: who it is, whether it is switched off or has run out, the DN, its
  groups (nested ones too).
- Active Directory: each directory a card - its servers as chips, how it is
  reached, its certificate, the base, the reading account - and its editor in
  two sections. The certificate authority as tiles, *Good until* coloured as
  it nears its end, the paste box behind *Import another…* once one is there.
- The realm editor in sections: what it takes, looking the person up, the
  groups that let in, the answer.
- The overview's lists keep their words whole - the name or the reason on its
  own line, the bar, the count and when under it - and the chart counts in
  whole numbers.
- The save bar shows only on a page with settings to save.

Upgrading: unpack 1.0.8 and run `./install.sh --upgrade`. Check *By* of every
realm afterwards: what was "not looked up anywhere" now looks the name up.

## 1.0.7 — 22 October 2026

- **Aligned.** A row with buttons at its end is centred top to bottom, so the
  name, its tags and its buttons stand on one line. In Accounts every row's
  buttons stand in the same columns - an account signed in from the directory,
  which has no password here to set, keeps an empty place where the lock is -
  and the role choice has one width in every row. A setting as wide as the
  page (the groups of the roles, the help text) has its (i) at its right edge
  like every other.

Upgrading: unpack 1.0.7 and run `./install.sh --upgrade`.

## 1.0.6 — 22 October 2026

- **No browser dialogs anywhere.** *Look a name up* (Active Directory) and
  *Set a new password* (Accounts) asked through the browser's own prompt box;
  both are now the pages' own popup, like everything else - the password asked
  twice and checked for length before it is sent. Nothing on the pages uses
  prompt, alert or confirm any more.

Upgrading: unpack 1.0.6 and run `./install.sh --upgrade`.

## 1.0.5 — 22 October 2026

The administration pages, gone through as a whole.

- **The tables no longer draw their buttons over the columns before them.**
  The cell holding a row's buttons was made a flex box, which takes it out of
  the table: in Active Directory the Base and the account were covered, in
  Accounts the role. Long names (servers, DNs) wrap in their own column.
- **Every row has its Edit and its Delete**: tokens (open it, take it away),
  clients, realms, directories (a gear to change it, a bin to take it away),
  the checks of a code and the RADIUS requests (see below).
- **Codes**: a line opens what it was (when, right or not, what was said, how,
  from where, which request) with *Its token*, *Its requests* and *Forget this
  line*; a bin on every line; *Forget these…* takes out every line the filters
  match. The same on **Requests**. Full administrators only, and every
  forgetting is written down as an event; what went to isemon stays there.
- **A name without a token** opens with *Make a token* and its history,
  instead of a window saying only that there is none.
- **A token's QR code and key can be shown again** by a full administrator
  (*Show the QR code and key*, and *Show the waiting one* for a replacement
  not yet confirmed) - after a warning, and every look written down. The
  setting *Administrators may show a token's QR code and key* (Settings → The
  tokens) switches it off.
- **A wrong code when confirming a new token says why**: the phone's clock is
  off by so many seconds, or the code is not from this token at all - usually
  an older entry of the same name in the application.
- **Signing administrators in against Active Directory, as isemon does it**
  (Settings → Accounts): *The groups, and what each one may do* - *Find the
  groups* (all, or those whose name holds what is typed), the list searchable
  and paged, and *Full admin* / *Token admin* / *Read only* beside every
  group, lit where it holds the role; *Try a sign-in…* asks the directory as a
  real sign-in would and shows the role and the groups, signing nobody in.
  Names may be typed as `novak`, `novak@example.cz` or `EXAMPLE\novak`. With
  no group given a role at all, anybody in the directory may read (isemon's
  rule); naming one closes that.
- **The same group list in the realm editor**: *Find the groups*, search, and
  *Lets in* beside every group, in place of a prompt that added every match.
- **The certificate authority of a directory, as isemon's**: its own card
  under Active Directory - what is imported (who it is, who signed it, from
  and until when), paste it or *Read a file…* (.pem, .crt, and a .cer in DER
  as Windows exports it), *Import it*, *Take it away*. It is checked for being
  a certificate before it is stored.
- **The database page, as isemon's**:
  - *Which one it is*: *Try it* (the address in the editor, unsaved), *Set it
    up…* (makes the database and the account on MariaDB or PostgreSQL with an
    administrator of that server used once and kept nowhere; a password made
    and shown once), *Carry everything across…* (a copy first, then every
    row, with a progress bar), *Empty it…* (only ever the other one), *Start
    using it…* (writes the address and starts the daemon again on it).
  - *What is in it*: rows and size of every table, the room free inside,
    *Make a copy now*, *Check it* (integrity check / CHECK TABLE / every table
    read), *Optimise it* (fresh statistics), *Apply what is kept, now*,
    *Forget records older than…*, *Give the disk back* (VACUUM / OPTIMIZE
    TABLE / VACUUM FULL).
  - *The database server's own settings* (MariaDB, PostgreSQL): what the
    machine has, the settings worked out for it beside what is there now, put
    in with ALTER SYSTEM or SET GLOBAL (the ones that need a restart said so,
    and for MariaDB the lines for `/etc/my.cnf.d/`), and *Put back as it was*.
- Copying into another database is batched: a transaction per thousand rows
  rather than one per row.
- A link to `#settings/dir` (or Back in the browser) opens that page.

Upgrading: unpack 1.0.5 and run `./install.sh --upgrade`.

## 1.0.4 — 22 October 2026

The command line, and the enrolment page.

- **`otp` (or `otp`) with nothing after it, typed at a terminal, says what it
  is doing** - the same as `--status` - instead of starting a second daemon
  that failed on the port the running one holds. The daemon itself is now
  `otp --daemon`; `otp.service` starts it so (under systemd, or anything else
  that is not a terminal, a bare `otp` is still the daemon).
- **Only one daemon at a time**: a second one stops at once and says which one
  is running (`/var/lib/otp/otp.lock`). And the RADIUS sockets no longer set
  SO_REUSEADDR, which on UDP let a second process bind the very same port
  and take half the packets.
- A daemon started by hand as root becomes the account `otp`, as the rest of
  the command line already did.
- **Colour as in isemon**: colorama when it is installed (the installer puts
  `python3-colorama` in place, or takes it from pip), the same escape
  sequences written by hand when it is not. `--help` is isemon's: two
  columns, the options green, their values yellow, the headings cyan, and
  THINGS PEOPLE ACTUALLY TYPE at the end. `NO_COLOR=1` and `--no-color` turn
  it off; a pipe gets none.
- **`--check` checks more than `--status` shows**: the key of the tokens, the
  age of the latest copy, PHP and php2shell, every client, every realm and
  whether its directory exists, every domain controller step by step, and
  where isemon's lines go.
- **The enrolment page** is headed *One-time passwords* (*Jednorázová hesla*)
  unless `portal_title` says otherwise - it said *Google Authenticator*. It
  links to the administration pages at the bottom, and while no realm with a
  directory is set up it says that nobody can enrol yet and that
  administrators sign in at `/admin/` - instead of "the name or the password
  is not right" to the administrator who has just installed it.

- The daemon's answers on the pages ("the directory cannot be reached just now" and
  the rest) are in Czech as well, not half-translated.

Upgrading: unpack 1.0.4 and run `./install.sh --upgrade` - it puts the new
`otp.service` in place, with `--daemon`.

## 1.0.3 — 22 October 2026

- **`otp` works as well as `otp`.** The installer links the command under both
  names, `/usr/local/bin/otp` and `/usr/local/bin/otp` — `otp --status`,
  `otp --log`, `otp --radtest falco 135830`. A different `otp` already on the
  machine is left alone, with a warning. `--uninstall` takes the link away.

Upgrading: unpack 1.0.3 and run `./install.sh --upgrade`.

## 1.0.2 — 22 October 2026

The installer.

- With firewalld not running, the firewall step was skipped without a word.
  It now says so, and what has to be let through by whatever filters the
  machine instead: TCP 443 (and 80), UDP 1812 and 1813 from the VPN
  concentrators.
- `--radius-from 127.0.0.1` (or `::1`) no longer becomes a firewalld rule:
  the machine's own packets never meet the firewall.

Upgrading from 1.0.0 or 1.0.1: unpack 1.0.2 and run `./install.sh --upgrade`.
The daemon, the pages and the database are unchanged; the version number on
them moves to 1.0.2.

## 1.0.1 — 22 October 2026

The installer.

- **It ended without a word at "PHP, and php2shell" on a machine that never
  had PHP.** `dnf module list --enabled php` exits 1 when no PHP stream is
  enabled, and under `set -euo pipefail` that ended the script. Its output is
  now taken first and read afterwards; PHP goes onto `php:8.3` as intended.
- The same kind of trap in two more places that had not been reached yet:
  the check for FreeRADIUS holding UDP 1812, and the list of PHP packages on
  Debian / Ubuntu.
- Nothing ends silently any more: whatever stops the installer prints
  `ERROR: line N: "command" ended with X`.

Upgrading from 1.0.0: unpack 1.0.1 and run `./install.sh` again (or
`./install.sh --upgrade` where 1.0.0 finished installing). The daemon, the
pages and the database are the same as in 1.0.0.

## 1.0.0 — 22 October 2026

The first version: the RADIUS server, TOTP, the QR codes, Active Directory,
realms and groups, the enrolment and administration pages, isemon's syslog
lines, SQLite / MariaDB / PostgreSQL, the import of a totpcgi + FreeRADIUS
server, the installer with PHP fixed against php2shell, Czech.
