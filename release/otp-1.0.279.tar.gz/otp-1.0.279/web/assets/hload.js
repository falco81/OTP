/* How busy the server is, in the header of the page (from ai 1.0.72-1.0.76).
   Plain JavaScript, no library. Needs the few helpers of helpers.js ($, el, clear,
   noI18n, bytes, api, prefs, savePrefs, LIVE, toast, oops) - or your own of the same names.

   Start it:     hloadLoop();          (polls every 3 s while the page is shown)
   The header:   <div class="hload" id="hload" hidden aria-live="off"></div>
   My account:   hloadPickers(host)    (the two rows of cards to choose the looks)
*/
/* How busy the server is, beside running (1.0.72): every 3 s while the page
   is shown and live, nothing while it is hidden; the daemon reads /proc only
   when asked. CPU, memory, the disks, the network. */
var HLOAD = {timer: null, busy: false};
function hloadRate(n) {
  if (n === null || n === undefined) return '–';
  if (n < 1024) return Math.round(n) + ' B/s';
  if (n < 1024 * 1024) return (n / 1024).toFixed(n < 10240 ? 1 : 0) + ' kB/s';
  return (n / 1048576).toFixed(n < 10485760 ? 1 : 0) + ' MB/s';
}
/* Four looks to choose from (1.0.72): pills with a bar, one plain line,
   small graphs of the last two minutes, rings. */
var HLOAD_KEEP = 40;
/* the server's readings [{at, cpu, mem, disk, net}] as the four lines of the graphs */
function hloadHistOf(list) {
  var h = {cpu: [], mem: [], disk: [], net: []};
  (list || []).forEach(function (x) { ['cpu', 'mem', 'disk', 'net'].forEach(function (k) { h[k].push(x[k] || 0); }); });
  return h;
}
/* The graphs drawn by time (1.0.253): each node's readings, one a second from its daemon's
   sampler, placed by when they were read - not one after the other. The line is moved on by
   one CSS animation for each graph (the browser's own, nothing redrawn by a timer); new
   readings are put at their places only when they come. It is drawn a little behind now -
   the newest readings wait beyond the right edge until their time - so it never jumps.
   Two nodes, two clocks: each node's readings against its own clock as they came. */
var HL_SPAN = 120;                  /* seconds across a graph */
/* how old the right edge is: the pace + the asking; the other node's readings come up to 5 s (its row)
   + 5 s (this node reading it) + 2 s (the page asking) late - 10 s was not always enough, and its
   graph grew by jumps at the edge (1.0.258) */
var HL_LAG = {here: 3.5, peer: 14};
var HL_T0 = Date.now() / 1000;      /* when the animations of this page began */
var HL_RUN_S = 86400;
HLOAD.series = {};                  /* node ('' this one) -> [{at, cpu, mem, disk, net}] */
HLOAD.off = {};                     /* node -> its clock minus this browser's, as last seen */
HLOAD.tops = {};
function hlAdd(node, list) {
  var have = HLOAD.series[node] || (HLOAD.series[node] = []);
  var last = have.length ? have[have.length - 1].at : 0;
  /* that node's clock was stepped back (1.0.255): its newest reading well before the last one
     here - the series starts again (and its clock's distance with it), or nothing would ever be
     newer than the last and the graph stayed blank */
  var newest = 0;
  (list || []).forEach(function (x) { if (x && typeof x.at === 'number' && x.at > newest) newest = x.at; });
  if (last && newest && newest < last - 5) {
    have = HLOAD.series[node] = [];
    last = 0;
    delete HLOAD.off[node];
  }
  (list || []).forEach(function (x) {
    if (!x || typeof x.at !== 'number' || x.at <= last) return;
    have.push({at: x.at, cpu: x.cpu || 0, mem: x.mem || 0, disk: (x.disk_rd || 0) + (x.disk_wr || 0),
               net: (x.net_rx || 0) + (x.net_tx || 0)});
    last = x.at;
  });
  if (have.length) {
    /* how far that node's clock is from this one: the freshest a reading has ever come
       (a later one that came slowly does not move the graph back) */
    var seen = have[have.length - 1].at - Date.now() / 1000;
    var was = HLOAD.off[node];
    HLOAD.off[node] = was === undefined || seen > was ? seen : was + (seen - was) * 0.02;
  }
  while (have.length && have[0].at < have[have.length - 1].at - HL_SPAN - 10) have.shift();
}
function hlLast(node) { var h = HLOAD.series[node] || []; return h.length ? h[h.length - 1].at : 0; }
/* the top of a graph of rates: the most of the two minutes, eased so it does not jump */
function hlTop(node, k) {
  var key = node + '/' + k, h = HLOAD.series[node] || [], most = 1024;
  for (var i = 0; i < h.length; i++) if (h[i][k] > most) most = h[i][k];
  var was = HLOAD.tops[key];
  var top = !was ? most : (most > was ? was + (most - was) * 0.35 : was + (most - was) * 0.06);
  HLOAD.tops[key] = top;
  return top;
}
function hlScale(k, max) {
  var sc = el('span', 'hp-scale muted small', k === 'cpu' || k === 'mem' ? '100 %' : hloadRate(max));
  if (HLOAD.ctx !== null && HLOAD.ctx !== undefined && k !== 'cpu' && k !== 'mem') {
    sc.classList.add('hl-live-scale'); sc.dataset.k = k; sc.dataset.node = HLOAD.ctx;
  }
  return noI18n(sc);
}
function hlLiveSvg(k, w, h, grid, area, cls) {
  var svg = '<svg class="hl-live ' + (w === 56 ? 'hl-spark ' : '') + (cls || '') + '" data-gk="' + k + '" data-gnode="'
    + String(HLOAD.ctx).replace(/[&"<>]/g, '') + '" data-w="' + w + '" data-h="' + h + '" viewBox="0 0 ' + w + ' ' + h
    + '" width="' + (w === 56 ? w : '100%') + '" height="' + h + '" preserveAspectRatio="none" aria-hidden="true">';
  if (grid) [0.25, 0.5, 0.75].forEach(function (g) { svg += '<line x1="0" x2="' + w + '" y1="' + h * g + '" y2="' + h * g + '" class="hp-grid" vector-effect="non-scaling-stroke"/>'; });
  svg += '<g class="hl-run">';
  if (area) svg += '<path class="hl-fill" d="" fill="currentColor" opacity=".16"/>';
  svg += '<path class="hl-line" d="" fill="none" stroke="currentColor" stroke-width="' + (w === 56 ? 1.4 : 1.6)
    + '" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>';
  return svg + '</g></svg>';
}
/* The readings put at their places - when they come or a graph is drawn, never by a timer. */
function hlPaint() {
  var now = Date.now() / 1000, tops = {};
  document.querySelectorAll('svg.hl-live').forEach(function (svg) {
    var node = svg.getAttribute('data-gnode') || '', k = svg.getAttribute('data-gk');
    var w = +svg.getAttribute('data-w'), h = +svg.getAttribute('data-h'), list = HLOAD.series[node] || [];
    /* One time for every node of a cluster (1.0.257): the same lag for all - a moment stands at
       the same place in both graphs (this node's right edge was 3.5 s old, the other's 10 s, and
       its graph ran 6.5 s behind); each node's readings by its own clock, as before. */
    var many = !!(HLOAD.others && HLOAD.others.length);
    var pps = w / HL_SPAN, lag = many ? HL_LAG.peer : (node ? HL_LAG.peer : HL_LAG.here);
    var off = HLOAD.off[node] || 0;
    var key = node + '/' + k;
    var top = (k === 'cpu' || k === 'mem') ? 100 : (tops[key] || (tops[key] = hlTop(node, k)));
    var area = !!svg.querySelector('.hl-fill'), segs = [], seg = null, prev = null;
    for (var i = 0; i < list.length; i++) {
      var at = list[i].at - off;
      if (now - at > HL_SPAN + lag + 10) continue;
      /* where it is in the moving group: at the right edge `lag` seconds after it was read */
      var x = w + lag * pps + (at - HL_T0) * pps;
      var y = h - 1 - (h - (area ? 3 : 2)) * Math.min(1, (list[i][k] || 0) / top);
      /* a time nobody looked (or the node did not answer) stays empty, not a straight line */
      if (!seg || at - prev > 5) segs.push(seg = []);
      seg.push([x, y]);
      prev = at;
    }
    var xy = function (q) { return q[0].toFixed(1) + ',' + q[1].toFixed(1); };
    var line = segs.map(function (g) { return 'M' + g.map(xy).join('L'); }).join('');
    var fill = segs.map(function (g) {
      return 'M' + g[0][0].toFixed(1) + ',' + h + 'L' + g.map(xy).join('L') + 'L' + g[g.length - 1][0].toFixed(1) + ',' + h + 'Z';
    }).join('');
    var pl = svg.querySelector('.hl-line'), pg = svg.querySelector('.hl-fill'), run = svg.querySelector('.hl-run');
    if (pl) pl.setAttribute('d', line);
    if (pg) pg.setAttribute('d', fill);
    if (run && !run._on) {
      /* one animation: left at the graph's own speed, begun as if with the page */
      run._on = true;
      run.style.setProperty('--hl-run', (-pps * HL_RUN_S).toFixed(1) + 'px');
      run.style.animationDuration = HL_RUN_S + 's';
      run.style.animationDelay = (-(now - HL_T0)).toFixed(3) + 's';
    }
  });
  document.querySelectorAll('.hl-live-scale').forEach(function (sc) {
    var key = (sc.dataset.node || '') + '/' + sc.dataset.k;
    if (tops[key]) sc.textContent = hloadRate(tops[key]);
  });
}
function hloadSpark(vals, max, cls, keep, k) {
  var w = 56, h = 18, n = vals.length;
  keep = keep || HLOAD_KEEP;
  if (k && HLOAD.ctx !== null && HLOAD.ctx !== undefined) return hlLiveSvg(k, w, h, false, false, cls);
  var svg = '<svg class="hl-spark ' + (cls || '') + '" viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h + '" preserveAspectRatio="none" aria-hidden="true">';
  if (n > 1) {
    var top = Math.max(max || 0, 1);
    var pts = vals.map(function (v, i) { return (i * w / (keep - 1)).toFixed(1) + ',' + (h - 1 - (h - 2) * Math.min(1, (v || 0) / top)).toFixed(1); });
    svg += '<polyline points="' + pts.join(' ') + '" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>';
  }
  return svg + '</svg>';
}
function hlVal(v) {
  var s = noI18n(el('span', 'hl-v'));
  if (v.indexOf('<span') === 0) s.innerHTML = v; else s.textContent = v;
  return s;
}
/* How wide a bar is (1.0.253, plexmon 2.7.2): exactly what it says - nothing at 0 %, at least
   a hairline for anything that rounds to 1 % or more. */
function hlWidth(pct) {
  pct = Number(pct) || 0;
  if (pct < 0.5) return 0;
  return Math.max(1, Math.min(100, pct));
}
function hloadRing(pct) {
  var r = 7, c = 2 * Math.PI * r, p = hlWidth(pct);
  return '<svg class="hl-ring" viewBox="0 0 18 18" width="18" height="18" aria-hidden="true"><circle cx="9" cy="9" r="' + r + '" class="hl-ring-bg"/>'
    + '<circle cx="9" cy="9" r="' + r + '" class="hl-ring-fg" stroke-dasharray="' + (c * p / 100).toFixed(1) + ' ' + c.toFixed(1) + '" transform="rotate(-90 9 9)"/></svg>';
}
function hloadChips(host, d, hist, look, preview, peer, keep) {
  var mp = d.mem_total ? 100 * d.mem_used / d.mem_total : null;
  var tips = {
    cpu: 'The processor, busy over the last ' + (d.over_s || 3) + ' s, all ' + d.cores + ' core(s) together' + (d.load ? ' · load ' + d.load.join(' / ') : ''),
    mem: 'Memory in use (without what the kernel keeps as cache and gives back)' + (d.swap_used ? ' · swap in use ' + bytes(d.swap_used) : ''),
    disk: 'The disks: read ↓ and written ↑, every disk together',
    net: 'The network cards: down ↓ (in) and up ↑ (out), every card together - not the loopback nor the bridges of containers'
  };
  var cpuV = d.late ? '–' : d.cpu === undefined ? '…' : Math.round(d.cpu) + ' %';
  var memV = d.mem_total ? bytes(d.mem_used) + ' / ' + bytes(d.mem_total) : '–';
  // fixed places for each number, so nothing beside them moves as they change (1.0.73)
  var two = function (a, b) { return '<span class="hl-r">↓' + hloadRate(a) + '</span><span class="hl-r">↑' + hloadRate(b) + '</span>'; };
  var diskV = two(d.disk_rd, d.disk_wr);
  var netV = two(d.net_rx, d.net_tx);
  var heat = function (c, pct) { if (pct === null || pct === undefined) return; c.classList.toggle('hot', pct >= 90); c.classList.toggle('warm', pct >= 70 && pct < 90); };
  if (look === 'line') {
    var line = el('span', 'hl-line');
    [['CPU', cpuV, 'cpu', d.cpu], ['RAM', memV, 'mem', mp], ['Disk', diskV, 'disk'], ['Net', netV, 'net']].forEach(function (x, i) {
      if (i) line.appendChild(el('span', 'hl-sep', '·'));
      var part = el('span', 'hl-part hl-' + x[2]);
      part.appendChild(el('span', 'hl-k', x[0]));
      part.appendChild(hlVal(x[1]));
      heat(part, x[3]);
      if (hpStyle() === 'off') part.title = tips[x[2]];
      part.dataset.k = x[2];
      /* a preview (My account) sits inside a button of its own: nothing in it to tab to (1.0.255) */
      if (!preview) { part.tabIndex = 0; part.setAttribute('role', 'button'); }
      if (peer) part.dataset.node = peer;
      if (!preview) hloadPanelHooks(part, x[2]);
      line.appendChild(part);
    });
    host.appendChild(line);
  } else {
    [['CPU', cpuV, 'cpu', d.cpu, 100], ['RAM', memV, 'mem', mp, 100], ['Disk', diskV, 'disk', null, null], ['Net', netV, 'net', null, null]].forEach(function (x) {
      var c = el('span', 'hl hl-' + x[2]);
      c.title = tips[x[2]];
      if (look === 'rings' && x[3] !== null && x[3] !== undefined) {
        var ring = el('span', 'hl-ringbox'); ring.innerHTML = hloadRing(x[3]); c.appendChild(ring);
      }
      c.appendChild(el('span', 'hl-k', x[0]));
      c.appendChild(hlVal(x[1]));
      if (look === 'pills' && x[3] !== null && x[3] !== undefined) {
        var bar = el('span', 'hl-bar'), fill = el('span', '');
        fill.style.width = hlWidth(x[3]) + '%';
        bar.appendChild(fill); c.appendChild(bar);
      }
      if (look === 'graphs') {
        var g = el('span', 'hl-g');
        var vals = hist[x[2]], max = x[4] || Math.max.apply(null, vals.concat([1024]));
        g.innerHTML = hloadSpark(vals, max, '', keep, x[2]);
        c.appendChild(g);
      }
      heat(c, x[3]);
      c.dataset.k = x[2];
      if (!preview) { c.tabIndex = 0; c.setAttribute('role', 'button'); }
      if (hpStyle() !== 'off') c.removeAttribute('title');
      if (peer) c.dataset.node = peer;
      if (!preview) hloadPanelHooks(c, x[2]);
      host.appendChild(c);
    });
  }
}
function hloadDraw(d, into, asLook) {
  /* into/asLook: a preview of a look drawn elsewhere (My account), from the
     sample numbers; it touches nothing of the real header (1.0.75) */
  var preview = !!into;
  var host = into || $('hload');
  if (!host) return;
  /* the animations run HL_RUN_S once (1.0.255): a page open for a day begins them again from
     now - every live graph is drawn anew below (and the panel's with it), so all move together */
  if (!preview && Date.now() / 1000 - HL_T0 > HL_RUN_S - 600) HL_T0 = Date.now() / 1000;
  /* the chip that has the keyboard's focus keeps it across the redraw (1.0.255) */
  var act = !preview && document.activeElement && host.contains(document.activeElement) ? document.activeElement : null;
  var focusK = act && act.dataset ? act.dataset.k : null, focusNode = act && act.dataset ? act.dataset.node || '' : '';
  var hist;
  var mp = d.mem_total ? 100 * d.mem_used / d.mem_total : null;
  if (preview) hist = hpSample().hist;
  else {
    HLOAD.last = d;
    hist = {cpu: [], mem: [], disk: [], net: []};     /* the live graphs read HLOAD.series */
  }
  var look = asLook || HLOAD.look || 'graphs';
  /* In a cluster (1.0.253) a group for each node, with its name; alone, the chips as they were.
     The groups one under the other (1.0.257), a row each, as acme draws them. */
  var others = preview ? [] : (HLOAD.others || []);
  host.className = 'hload look-' + look + (preview ? ' hl-preview' : '') + (others.length ? ' hl-cluster' : '');
  clear(host);
  var was = HLOAD.ctx;
  HLOAD.ctx = preview ? null : '';
  if (!others.length) { hloadChips(host, d, hist, look, preview, '', HLOAD_KEEP); }
  else {
    [{node: HLOAD.node || '', d: d, hist: hist, keep: HLOAD_KEEP}].concat(others.map(function (o) {
      /* its last numbers kept while it is late (1.0.257), dimmed; none ever heard: a dash */
      return {node: o.node, d: o.now ? o.now : {late: true}, hist: hist, keep: HLOAD_KEEP, late: o.late || !o.now, error: o.error};
    })).forEach(function (g, i) {
      HLOAD.ctx = i ? g.node : '';
      var box = el('span', 'hl-node' + (i ? ' hl-peer' : ' hl-here') + (g.late ? ' hl-late' : ''));
      var name = noI18n(el('span', 'hl-name', g.node));
      name.title = i ? (g.late ? 'The other node ' + g.node + ' does not answer' + (g.error ? ': ' + g.error : '') : 'The other node: ' + g.node)
                     : 'This node, the one this page is on: ' + g.node;
      box.appendChild(name);
      hloadChips(box, g.d, g.hist, look, preview, i ? g.node : '', g.keep);
      host.appendChild(box);
    });
  }
  HLOAD.ctx = was;
  host.hidden = false;
  if (focusK) { var back = hloadChipOf(focusK, focusNode); if (back) back.focus({preventScroll: true}); }
  if (!preview && HLOAD.open) hloadPanelDraw();
  if (!preview) hlPaint();
}
/* Sample numbers for the previews in My account: a server with sensors, so
   every part shows (1.0.75). */
function hpSample() {
  if (HLOAD.sample) return HLOAD.sample;
  var h = {cpu: [], mem: [], disk: [], net: []};
  for (var i = 0; i < HLOAD_KEEP; i++) {
    h.cpu.push(48 + 28 * Math.sin(i / 4)); h.mem.push(30 + i * 0.15);
    h.disk.push((1 + Math.sin(i / 4 + 1)) * 9e7); h.net.push((1 + Math.sin(i / 4 + 2)) * 7e6);
  }
  var cores = [[96, 3900, 71], [12, 1200, 48], [88, 3800, 69], [4, 800, 46], [61, 3400, 62], [9, 1100, 47], [100, 4100, 84], [22, 2000, 51]]
    .map(function (c, n) { return {n: n, busy: c[0], mhz: c[1], temp: c[2]}; });
  HLOAD.sample = {hist: h,
    last: {cpu: 49, mem_used: 9.8e9, mem_total: 33.5e9, disk_rd: 190e6, disk_wr: 48e6, net_rx: 12.6e6, net_tx: 1.5e6, cores: 8, load: [3.92, 3.1, 2.71], over_s: 3},
    detail: {cores: cores, model: 'AMD Ryzen 7 5800X 8-Core Processor', temps: {cpu: [['Tctl', 73]], cores: {}, other: []},
      disks: [{name: 'nvme0n1', size: 1e12, model: 'Samsung SSD 980 PRO', rd: 190e6, wr: 48e6, util: 38, temp: 44},
              {name: 'sda', size: 4e12, model: 'WDC WD40EFRX', rd: 2.2e6, wr: 0, util: 3, temp: 36}],
      filesystems: [{mount: '/', kind: 'ext4', total: 984e9, used: 212e9}, {mount: '/srv', kind: 'xfs', total: 3.6e12, used: 3.1e12}],
      nics: [{name: 'eno1', state: 'up', speed: 1000, rx: 12.6e6, tx: 1.5e6, rx_all: 812e9, tx_all: 96e9}],
      top_cpu: [{name: 'node', pid: 1201, cpu: 187}, {name: 'claude', pid: 1302, cpu: 96}, {name: 'postgres', pid: 812, cpu: 41}],
      top_mem: [{name: 'node', pid: 1201, rss: 2.1e9}, {name: 'claude', pid: 1302, rss: 1.4e9}],
      uptime: 1051200, mem: {total: 33.5e9, available: 21.6e9, cached: 6.1e9, buffers: 0.3e9, swap_total: 8.6e9, swap_free: 8.6e9, shared: 120e6}, procs: 312}};
  return HLOAD.sample;
}
/* A picker as the terminal colours: a card for each choice with what it
   really looks like, drawn by the same code from the sample numbers. */
function hlPicker(choices, now, draw, pick) {
  var box = el('div', 'pal-pick hl-pick' + (draw === hlPreviewPanel ? ' hl-pick-p' : ''));
  choices.forEach(function (n) {
    var b = el('button', 'pal-card hl-card' + (n[0] === now ? ' on' : ''));
    b.type = 'button';
    b.dataset.v = n[0];
    var sw = el('div', 'pal-sw hl-sw');
    draw(sw, n[0]);
    b.appendChild(sw);
    b.appendChild(el('span', 'pal-name', n[1]));
    b.onclick = function () {
      box.querySelectorAll('.pal-card').forEach(function (x) { x.classList.toggle('on', x === b); });
      pick(n[0]);
    };
    box.appendChild(b);
  });
  return box;
}
function hlPreviewLook(sw, look) {
  if (look === 'off') { sw.appendChild(el('span', 'muted small hl-none', 'nothing in the header')); return; }
  var inner = el('div', 'hl-scale');
  var host = el('div', 'hload');
  inner.appendChild(host);
  hloadDraw(hpSample().last, host, look);
  sw.appendChild(inner);
}
function hlPreviewPanel(sw, st) {
  if (st === 'off') {
    var t = el('div', 'hl-tipbox');
    t.appendChild(el('span', 'hl-tipchip', 'CPU 49 %'));
    t.appendChild(el('span', 'hl-tip small', 'The processor, busy over the last 3 s, all 8 core(s) together'));
    sw.appendChild(t);
    return;
  }
  var smp = hpSample(), keep = [HLOAD.last, HLOAD.detail, HLOAD.hist, HLOAD.open];
  HLOAD.last = smp.last; HLOAD.detail = smp.detail; HLOAD.hist = smp.hist; HLOAD.open = 'cpu';
  var p = el('div', 'hl-panel hp-' + st + ' hl-prevpanel');
  p.style.width = (st === 'wide' ? 1180 : (st === 'table' ? 420 : 470)) + 'px';
  try {
    if (st === 'table') hpTable(p, 'cpu'); else if (st === 'map') hpMap(p, 'cpu'); else if (st === 'wide') hpWide(p); else hpTiles(p, 'cpu');
  } finally { HLOAD.last = keep[0]; HLOAD.detail = keep[1]; HLOAD.hist = keep[2]; HLOAD.open = keep[3]; }
  var inner = el('div', 'hl-scale hl-scale-p' + (st === 'wide' ? ' wide' : ''));
  inner.appendChild(p);
  sw.appendChild(inner);
}
/* The panel of one chip (1.0.73): pointed at (or tapped on an iPad), what is
   behind the number - each core with its frequency and temperature, the
   disks and the filesystems, the cards, the processes taking most, and the
   last two minutes larger. Read from the daemon only while it is open. */
function hloadPanelHooks(c, k) {
  c.onmouseenter = function () { if (matchMedia('(hover: hover)').matches) hloadPanelOpen(k, c); };
  c.onmouseleave = function () { if (matchMedia('(hover: hover)').matches) hloadPanelSoon(); };
  c.onclick = function (e) {
    e.stopPropagation();
    if (HLOAD.open === k && HLOAD.openNode === (c.dataset.node || '')) hloadPanelClose(); else hloadPanelOpen(k, c);
  };
  c.onkeydown = function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); c.onclick(e); } if (e.key === 'Escape') hloadPanelClose(); };
}
function hloadPanelOpen(k, chip) {
  clearTimeout(HLOAD.shut);
  if (hpStyle() === 'off') return;
  HLOAD.open = k;
  HLOAD.chip = k;
  HLOAD.openNode = (chip && chip.dataset.node) || '';
  var p = $('hload-panel');
  if (!p) {
    p = el('div', 'hl-panel');
    p.id = 'hload-panel';
    p.onmouseenter = function () { clearTimeout(HLOAD.shut); };
    p.onmouseleave = function () { if (matchMedia('(hover: hover)').matches) hloadPanelSoon(); };
    p.onclick = function (e) { e.stopPropagation(); };
    document.body.appendChild(p);
    document.addEventListener('click', function () { if (HLOAD.open) hloadPanelClose(); });
    window.addEventListener('resize', function () { if (HLOAD.open) hloadPanelPlace(); });
  }
  p.hidden = false;
  hloadPanelDraw();
  hloadPanelPlace(chip);
  if (HLOAD.openNode || !HLOAD.detail || Date.now() - (HLOAD.detailAt || 0) > 2500) hloadTick(true);
}
function hloadPanelSoon() { clearTimeout(HLOAD.shut); HLOAD.shut = setTimeout(hloadPanelClose, 350); }
function hloadPanelClose() {
  HLOAD.open = null;
  var p = $('hload-panel');
  if (p) p.hidden = true;
  document.querySelectorAll('#hload .hl-open').forEach(function (c) { c.classList.remove('hl-open'); });
}
function hloadPanelPlace(chip) {
  var p = $('hload-panel');
  chip = chip || hloadChipOf(HLOAD.chip, HLOAD.openNode);
  if (!p || !chip) return;
  var r = chip.getBoundingClientRect(), st = hpStyle();
  var w = Math.min(st === 'wide' ? 1180 : (st === 'table' ? 420 : 470), window.innerWidth - 16);
  var left = r.left;
  if (st === 'wide') { var hr = $('hload').getBoundingClientRect(); left = hr.left; r = {bottom: hr.bottom, left: hr.left}; }
  p.style.width = w + 'px';
  p.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, left)) + 'px';
  p.style.top = Math.round(r.bottom + 6) + 'px';
  p.style.maxHeight = Math.max(200, window.innerHeight - r.bottom - 20) + 'px';
}
function hlBar(pct, cls) {
  var b = el('span', 'hp-bar ' + (cls || ''));
  var f = el('span', '');
  f.style.width = hlWidth(pct) + '%';
  if (pct >= 90) b.classList.add('hot'); else if (pct >= 70) b.classList.add('warm');
  b.appendChild(f);
  return b;
}
function hlTemp(t) {
  if (t === null || t === undefined) return null;
  return el('span', 'hp-temp' + (t >= 85 ? ' hot' : (t >= 70 ? ' warm' : '')), Math.round(t) + ' °C');
}
function hlUp(sec) {
  sec = Math.round(sec || 0);
  var d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60);
  return (d ? d + ' d ' : '') + (d || h ? h + ' h ' : '') + m + ' min';
}
/* Four ways to show the details (1.0.74), chosen in My account: tiles, a
   table (as htop, good for many cores), a map of the cores with rings, or one
   wide panel with all four at once. */
var HP_STYLES = [['tiles', 'tiles - a card for each core'], ['table', 'a table - a row for each core (as htop)'],
                 ['map', 'a map of the cores with rings'], ['wide', 'one wide panel with everything at once'],
                 ['off', 'no details - only a short tip']];
function hpStyle() { var v = prefs().hpanel; return HP_STYLES.some(function (x) { return x[0] === v; }) ? v : 'tiles'; }
/* the chip of a part (cpu, mem...) of a node ('' this one) */
function hloadChipOf(k, node) {
  var all = document.querySelectorAll('#hload [data-k="' + k + '"]');
  for (var i = 0; i < all.length; i++) if ((all[i].dataset.node || '') === (node || '')) return all[i];
  return null;
}
function hloadPanelDraw() {
  var p = $('hload-panel'), k = HLOAD.open;
  if (!p || !k) return;
  var st = hpStyle(), node = HLOAD.openNode || '';
  /* the same panel drawn anew every tick keeps where it was scrolled to (1.0.255) */
  var key = k + '/' + node + '/' + st, top = p._key === key ? p.scrollTop : 0;
  clear(p);
  document.querySelectorAll('#hload [data-k]').forEach(function (c) {
    c.classList.toggle('hl-open', (c.dataset.node || '') === node && (st !== 'wide' ? c.dataset.k === k : true));
  });
  var o = node ? (HLOAD.others || []).filter(function (x) { return x.node === node; })[0] || {} : null;
  var keep = [HLOAD.last, HLOAD.detail, HLOAD.ctx];
  if (o) { HLOAD.last = o.now || {late: true}; HLOAD.detail = o.detail || null; }
  HLOAD.ctx = node;
  p.className = 'hl-panel hp-' + st;
  try {
    /* the other node's own details once it sends them (1.0.258), in the style picked */
    if (o && !(o.detail && !o.late)) { p.className = 'hl-panel hp-tiles'; hpPeer(p, k, node, o); }
    else {
      hpStyleDraw(p, k, st);
      /* whose they are: the other node's name over its own details */
      if (o) p.insertBefore(noI18n(el('div', 'hp-node muted small', node)), p.firstChild);
    }
  } finally { HLOAD.last = keep[0]; HLOAD.detail = keep[1]; HLOAD.ctx = keep[2]; }
  p._key = key;
  p.scrollTop = top;
  hlPaint();
}
function hpStyleDraw(p, k, st) {
  if (st === 'table') hpTable(p, k);
  else if (st === 'map') hpMap(p, k);
  else if (st === 'wide') hpWide(p);
  else hpTiles(p, k);
}
var HP_TITLE = {cpu: 'The processor', mem: 'Memory', disk: 'The disks', net: 'The network'};
function hpMax(k) {
  if (HLOAD.ctx !== null && HLOAD.ctx !== undefined) return (k === 'cpu' || k === 'mem') ? 100 : hlTop(HLOAD.ctx, k);
  var vals = (HLOAD.hist || {})[k] || [];
  return (k === 'cpu' || k === 'mem') ? 100 : Math.max.apply(null, vals.concat([1024]));
}
/* a filled graph of the last two minutes, as wide as its box */
function hpArea(k, h, grid) {
  var vals = (HLOAD.hist || {})[k] || [], w = 400, top = Math.max(hpMax(k), 1);
  var box = el('div', 'hp-area hl-' + k);
  if (HLOAD.ctx !== null && HLOAD.ctx !== undefined) { box.innerHTML = hlLiveSvg(k, w, h, grid, true); return box; }
  var svg = '<svg viewBox="0 0 ' + w + ' ' + h + '" width="100%" height="' + h + '" preserveAspectRatio="none" aria-hidden="true">';
  if (grid) [0.25, 0.5, 0.75].forEach(function (g) { svg += '<line x1="0" x2="' + w + '" y1="' + h * g + '" y2="' + h * g + '" class="hp-grid" vector-effect="non-scaling-stroke"/>'; });
  if (vals.length > 1) {
    var pts = vals.map(function (v, i) { return (i * w / (HLOAD_KEEP - 1)).toFixed(1) + ',' + (h - 1 - (h - 3) * Math.min(1, (v || 0) / top)).toFixed(1); });
    var last = ((vals.length - 1) * w / (HLOAD_KEEP - 1)).toFixed(1);
    svg += '<polygon points="0,' + h + ' ' + pts.join(' ') + ' ' + last + ',' + h + '" fill="currentColor" opacity=".16"/>';
    svg += '<polyline points="' + pts.join(' ') + '" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>';
  }
  box.innerHTML = svg + '</svg>';
  return box;
}
function hpRing(pct, label, cls, size) {
  size = size || 78;
  var r = size / 2 - 7, c = 2 * Math.PI * r, v = hlWidth(pct);
  var col = cls || (v >= 90 ? 'hot' : (v >= 70 ? 'warm' : ''));
  var box = el('span', 'hp-ring ' + col);
  box.innerHTML = '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '" aria-hidden="true">'
    + '<circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" class="hp-ring-bg"/>'
    + '<circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" class="hp-ring-fg" stroke-dasharray="' + (c * v / 100).toFixed(1) + ' ' + c.toFixed(1) + '" transform="rotate(-90 ' + size / 2 + ' ' + size / 2 + ')"/></svg>';
  box.appendChild(noI18n(el('span', 'hp-ring-v', label)));
  return box;
}
function hpTempCls(t) { return t >= 85 ? 'hot' : (t >= 70 ? 'warm' : 'ok'); }
function hpSec(p, title) { var s = el('div', 'hp-sec'); if (title) s.appendChild(el('div', 'hp-h', title)); p.appendChild(s); return s; }
function hpTd(tr, v, cls) { var td = el('td', cls || ''); if (v && v.nodeType) td.appendChild(v); else if (v !== null && v !== undefined) td.appendChild(noI18n(el('span', '', String(v)))); tr.appendChild(td); return td; }
function hpGHz(m) { return m ? (m >= 1000 ? (m / 1000).toFixed(1) + ' GHz' : m + ' MHz') : ''; }
function hpPct(v) { return v === null || v === undefined ? '…' : Math.round(v) + ' %'; }
function hpCpuTemp(x) { var t = ((x.temps || {}).cpu || [])[0]; return t ? t[1] : null; }
function hpNoTemp(host, x) {
  var tps = x.temps || {};
  if (!(tps.cpu || []).length && !Object.keys(tps.cores || {}).length)
    host.appendChild(el('p', 'muted small', 'No temperature: this machine has no sensors the kernel reads (a virtual machine has none).'));
}
function hpWait(p) { p.appendChild(el('p', 'muted small', 'reading…')); }
/* the same rows for memory and the network in every style but the tiles */
function hpMemRows(host, x) {
  var m = x.mem || {}, used = (m.total || 0) - (m.available || 0);
  var t = el('table', 'hp-t hp-kvt');
  [['In use', bytes(used)], ['Free for programs', bytes(m.available || 0)], ['Cache (given back when needed)', bytes((m.cached || 0) + (m.buffers || 0))],
   ['Shared', bytes(m.shared || 0)], ['Swap', m.swap_total ? bytes(m.swap_total - (m.swap_free || 0)) + ' / ' + bytes(m.swap_total) : null], ['Altogether', bytes(m.total || 0)]].forEach(function (r) {
    var tr = el('tr', ''); hpTd(tr, el('span', 'muted', r[0])); hpTd(tr, r[1] === null ? el('span', 'muted', 'none') : r[1], 'num'); t.appendChild(tr);
  });
  host.appendChild(t);
}
function hpProcs(host, list, what) {
  /* A bar is the real share (1.0.253, plexmon 2.7.2): of one core for the processor (of the
     busiest when one takes more than a core), of the memory in use for memory - not of the
     busiest process, which gave a process at 0 % a third of the width. */
  var t = el('table', 'hp-t'), top = 100;
  var memAll = (HLOAD.last && (HLOAD.last.mem_used || HLOAD.last.mem_total)) || 0;
  list.forEach(function (q) { if (what === 'cpu') top = Math.max(top, q.cpu || 0); });
  list.slice(0, 5).forEach(function (q) {
    var tr = el('tr', ''), v = what === 'cpu' ? q.cpu : q.rss;
    var share = what === 'cpu' ? 100 * (v || 0) / top : (memAll ? 100 * (v || 0) / memAll : 0);
    hpTd(tr, q.name, 'mono hp-name'); hpTd(tr, hlBar(share, 'hp-info'), 'hp-barc');
    hpTd(tr, what === 'cpu' ? Math.round(v) + ' %' : bytes(v), 'num');
    t.appendChild(tr);
  });
  host.appendChild(t);
  if (!list.length) host.appendChild(el('p', 'muted small', 'nothing busy just now'));
}
function hpNicRows(host, x) {
  var t = el('table', 'hp-t');
  (x.nics || []).forEach(function (n) {
    var tr = el('tr', '');
    hpTd(tr, el('b', 'mono', n.name)); hpTd(tr, (n.state || '') + (n.speed ? ' · ' + (n.speed >= 1000 ? n.speed / 1000 + ' Gb/s' : n.speed + ' Mb/s') : ''), 'muted small');
    hpTd(tr, '↓' + hloadRate(n.rx) + ' ↑' + hloadRate(n.tx), 'num'); t.appendChild(tr);
    var tr2 = el('tr', 'hp-sub'); hpTd(tr2, ''); hpTd(tr2, noI18n(el('span', 'muted small', '↓' + bytes(n.rx_all) + ' ↑' + bytes(n.tx_all))), 'hp-span2');
    tr2.lastChild.colSpan = 2; t.appendChild(tr2);
  });
  host.appendChild(t);
  if (!(x.nics || []).length) host.appendChild(el('p', 'muted small', 'no card'));
}
function hpDisks(x) { return (x.disks || []).filter(function (dk) { return dk.size > 64 * 1048576; }); }
function hpHead(p, k, extra) {
  var head = el('div', 'hp-head');
  head.appendChild(el('b', '', HP_TITLE[k]));
  if (extra) head.appendChild(extra);
  p.appendChild(head);
}
/* B - the table */
function hpTable(p, k) {
  var d = HLOAD.last || {}, x = HLOAD.detail;
  var sum = {cpu: hpPct(d.cpu), mem: d.mem_total ? bytes(d.mem_used) + ' / ' + bytes(d.mem_total) : '',
             disk: '↓' + hloadRate(d.disk_rd) + ' ↑' + hloadRate(d.disk_wr), net: '↓' + hloadRate(d.net_rx) + ' ↑' + hloadRate(d.net_tx)}[k];
  var ex = el('span', 'muted small');
  ex.appendChild(noI18n(el('b', 'hp-sum', sum)));
  if (k === 'cpu' && x) { ex.appendChild(noI18n(el('span', '', ' · load ' + (d.load || []).join(' / ')))); var ct = hpCpuTemp(x); if (ct !== null) { ex.appendChild(noI18n(el('span', '', ' · '))); ex.appendChild(hlTemp(ct)); } }
  hpHead(p, k, ex);
  p.appendChild(hpArea(k, 38));
  if (!x) return hpWait(p);
  if (k === 'cpu') {
    var t = el('table', 'hp-t hp-cores-t');
    (x.cores || []).forEach(function (c) {
      var tr = el('tr', '');
      hpTd(tr, 'cpu' + c.n, 'mono muted'); hpTd(tr, hlBar(c.busy), 'hp-barc'); hpTd(tr, hpPct(c.busy), 'num');
      hpTd(tr, hpGHz(c.mhz), 'num muted'); hpTd(tr, hlTemp(c.temp), 'num'); t.appendChild(tr);
    });
    p.appendChild(t);
    hpNoTemp(p, x);
    hpProcs(hpSec(p, 'Taking most of the processor'), x.top_cpu || [], 'cpu');
  } else if (k === 'mem') {
    hpMemRows(hpSec(p, ''), x);
    hpProcs(hpSec(p, 'Taking most memory'), x.top_mem || [], 'mem');
  } else if (k === 'disk') {
    var td = el('table', 'hp-t'), hr = el('tr', 'hp-th');
    ['disk', 'read', 'written', 'busy', '°C'].forEach(function (h, i) { hpTd(hr, el('span', '', h), i ? 'num' : ''); });
    td.appendChild(hr);
    hpDisks(x).forEach(function (dk) {
      var tr = el('tr', '');
      hpTd(tr, dk.name, 'mono'); hpTd(tr, hloadRate(dk.rd), 'num'); hpTd(tr, hloadRate(dk.wr), 'num'); hpTd(tr, hpPct(dk.util), 'num'); hpTd(tr, hlTemp(dk.temp), 'num');
      td.appendChild(tr);
    });
    p.appendChild(td);
    var s2 = hpSec(p, 'Filesystems'), tf = el('table', 'hp-t');
    (x.filesystems || []).forEach(function (f) {
      var pct = f.total ? 100 * f.used / f.total : 0, tr = el('tr', '');
      hpTd(tr, f.mount, 'mono hp-name'); hpTd(tr, hlBar(pct), 'hp-barc'); hpTd(tr, bytes(f.used) + ' / ' + bytes(f.total), 'num muted small'); hpTd(tr, Math.round(pct) + ' %', 'num');
      tf.appendChild(tr);
    });
    s2.appendChild(tf);
  } else hpNicRows(hpSec(p, ''), x);
}
/* C - the map of the cores and rings */
function hpMap(p, k) {
  var d = HLOAD.last || {}, x = HLOAD.detail;
  var top = el('div', 'hp-top');
  var info = el('div', 'hp-info-col');
  info.appendChild(el('b', '', HP_TITLE[k]));
  if (k === 'cpu') {
    top.appendChild(hpRing(d.cpu, hpPct(d.cpu)));
    var ct = x ? hpCpuTemp(x) : null;
    if (ct !== null) top.appendChild(hpRing(ct, Math.round(ct) + '°', hpTempCls(ct) === 'ok' ? '' : hpTempCls(ct)));
    if (x) {
      if (x.model) info.appendChild(noI18n(el('div', 'muted small', x.model)));
      info.appendChild(noI18n(el('div', 'muted small', 'load ' + (d.load || []).join(' / ') + ' · ' + hlUp(x.uptime))));
    }
  } else if (k === 'mem') {
    var mp = d.mem_total ? 100 * d.mem_used / d.mem_total : 0;
    top.appendChild(hpRing(mp, Math.round(mp) + ' %'));
    info.appendChild(noI18n(el('div', 'muted small', d.mem_total ? bytes(d.mem_used) + ' / ' + bytes(d.mem_total) : '')));
  } else {
    var a = k === 'disk' ? [d.disk_rd, d.disk_wr] : [d.net_rx, d.net_tx];
    info.appendChild(noI18n(el('div', 'hp-big', '↓' + hloadRate(a[0]) + '  ↑' + hloadRate(a[1]))));
  }
  top.appendChild(info);
  p.appendChild(top);
  p.appendChild(hpArea(k, 60, true));
  if (!x) return hpWait(p);
  if (k === 'cpu') {
    var s = hpSec(p, 'Map of the cores (colour = how busy, number = temperature)');
    var g = el('div', 'hp-heat');
    (x.cores || []).forEach(function (c) {
      var b = el('div', 'hp-cell'), v = c.busy || 0;
      b.style.background = 'hsl(' + Math.round(120 - 1.2 * v) + ',62%,' + Math.round(20 + v * 0.17) + '%)';
      b.appendChild(noI18n(el('span', 'hp-cell-n', String(c.n))));
      b.appendChild(noI18n(el('b', '', c.busy === null || c.busy === undefined ? '…' : Math.round(v) + '%')));
      b.appendChild(noI18n(el('span', 'hp-cell-t', c.temp !== null && c.temp !== undefined ? Math.round(c.temp) + '°' : hpGHz(c.mhz))));
      b.title = 'CPU ' + c.n + ' · ' + hpGHz(c.mhz);
      g.appendChild(b);
    });
    s.appendChild(g);
    hpNoTemp(s, x);
    var s3 = hpSec(p, 'Taking most of the processor'), w = el('div', 'hp-pills');
    (x.top_cpu || []).slice(0, 6).forEach(function (q) { var c = el('span', 'hp-pill'); c.appendChild(noI18n(el('span', 'mono', q.name))); c.appendChild(noI18n(el('b', '', Math.round(q.cpu) + ' %'))); w.appendChild(c); });
    s3.appendChild(w);
  } else if (k === 'mem') {
    hpMemRows(hpSec(p, ''), x);
    hpProcs(hpSec(p, 'Taking most memory'), x.top_mem || [], 'mem');
  } else if (k === 'disk') {
    var cards = el('div', 'hp-cards');
    hpDisks(x).forEach(function (dk) {
      var c = el('div', 'hp-card'), t = el('div', 'hp-card-top');
      t.appendChild(noI18n(el('b', 'mono', dk.name)));
      if (dk.temp !== null && dk.temp !== undefined) t.appendChild(hlTemp(dk.temp));
      c.appendChild(t);
      c.appendChild(noI18n(el('div', 'muted small hp-ell', bytes(dk.size) + (dk.model ? ' · ' + dk.model : ''))));
      c.appendChild(noI18n(el('div', 'hp-big', hpPct(dk.util))));
      c.appendChild(hlBar(dk.util));
      c.appendChild(noI18n(el('div', 'muted small', '↓' + hloadRate(dk.rd) + ' ↑' + hloadRate(dk.wr))));
      cards.appendChild(c);
    });
    p.appendChild(cards);
    var s2 = hpSec(p, 'Filesystems'), rings = el('div', 'hp-rings');
    (x.filesystems || []).forEach(function (f) {
      var pct = f.total ? 100 * f.used / f.total : 0, one = el('div', 'hp-fsring');
      one.appendChild(hpRing(pct, Math.round(pct) + '%', null, 64));
      one.appendChild(noI18n(el('div', 'mono hp-ell', f.mount)));
      one.appendChild(noI18n(el('div', 'muted small', bytes(f.used) + ' / ' + bytes(f.total))));
      rings.appendChild(one);
    });
    s2.appendChild(rings);
  } else {
    var nc = el('div', 'hp-cards');
    (x.nics || []).forEach(function (n) {
      var c = el('div', 'hp-card'), t = el('div', 'hp-card-top');
      t.appendChild(noI18n(el('b', 'mono', n.name)));
      t.appendChild(noI18n(el('span', 'muted small', (n.state || '') + (n.speed ? ' · ' + (n.speed >= 1000 ? n.speed / 1000 + ' Gb/s' : n.speed + ' Mb/s') : ''))));
      c.appendChild(t);
      c.appendChild(noI18n(el('div', 'hp-big', '↓' + hloadRate(n.rx))));
      c.appendChild(noI18n(el('div', 'hp-big', '↑' + hloadRate(n.tx))));
      c.appendChild(noI18n(el('div', 'muted small', '↓' + bytes(n.rx_all) + ' ↑' + bytes(n.tx_all))));
      nc.appendChild(c);
    });
    p.appendChild(nc);
    if (!(x.nics || []).length) p.appendChild(el('p', 'muted small', 'no card'));
  }
}
/* D - one wide panel, the four side by side */
function hpWide(p) {
  var d = HLOAD.last || {}, x = HLOAD.detail;
  var grid = el('div', 'hp-wide-grid');
  ['cpu', 'mem', 'disk', 'net'].forEach(function (k) {
    var col = el('div', 'hp-col' + (k === HLOAD.open ? ' hp-col-on' : ''));
    var head = el('div', 'hp-head');
    head.appendChild(el('b', '', HP_TITLE[k]));
    var sum = {cpu: hpPct(d.cpu), mem: d.mem_total ? bytes(d.mem_used) + ' / ' + bytes(d.mem_total) : '',
               disk: '↓' + hloadRate(d.disk_rd) + ' ↑' + hloadRate(d.disk_wr), net: '↓' + hloadRate(d.net_rx) + ' ↑' + hloadRate(d.net_tx)}[k];
    var ex = el('span', 'small');
    ex.appendChild(noI18n(el('span', 'hp-sum', sum)));
    if (k === 'cpu' && x) { var ct = hpCpuTemp(x); if (ct !== null) { ex.appendChild(noI18n(el('span', '', ' '))); ex.appendChild(hlTemp(ct)); } }
    head.appendChild(ex);
    col.appendChild(head);
    col.appendChild(hpArea(k, 34));
    if (!x) { hpWait(col); grid.appendChild(col); return; }
    if (k === 'cpu') {
      var t = el('table', 'hp-t');
      (x.cores || []).forEach(function (c) {
        var tr = el('tr', '');
        hpTd(tr, 'cpu' + c.n, 'mono muted'); hpTd(tr, hlBar(c.busy), 'hp-barc'); hpTd(tr, hpPct(c.busy), 'num'); hpTd(tr, hlTemp(c.temp), 'num');
        t.appendChild(tr);
      });
      col.appendChild(t);
      if (x.model) col.appendChild(noI18n(el('div', 'muted small hp-ell', x.model)));
      col.appendChild(noI18n(el('div', 'muted small', 'load ' + (d.load || []).join(' / ') + ' · ' + hlUp(x.uptime))));
    } else if (k === 'mem') {
      hpMemRows(col, x);
      hpProcs(hpSec(col, 'Taking most memory'), (x.top_mem || []).slice(0, 4), 'mem');
    } else if (k === 'disk') {
      var td = el('table', 'hp-t');
      hpDisks(x).forEach(function (dk) {
        var tr = el('tr', '');
        hpTd(tr, dk.name, 'mono hp-name'); hpTd(tr, hlBar(dk.util), 'hp-barc'); hpTd(tr, hpPct(dk.util), 'num'); hpTd(tr, hlTemp(dk.temp), 'num');
        td.appendChild(tr);
        var tr2 = el('tr', 'hp-sub'); hpTd(tr2, ''); hpTd(tr2, noI18n(el('span', 'muted small', '↓' + hloadRate(dk.rd) + ' ↑' + hloadRate(dk.wr))));
        tr2.lastChild.colSpan = 3; td.appendChild(tr2);
      });
      col.appendChild(td);
      var s2 = hpSec(col, 'Filesystems'), tf = el('table', 'hp-t');
      (x.filesystems || []).forEach(function (f) {
        var pct = f.total ? 100 * f.used / f.total : 0, tr = el('tr', '');
        hpTd(tr, f.mount, 'mono hp-name'); hpTd(tr, hlBar(pct), 'hp-barc'); hpTd(tr, Math.round(pct) + ' %', 'num'); tf.appendChild(tr);
      });
      s2.appendChild(tf);
    } else {
      var tn = el('table', 'hp-t');
      (x.nics || []).forEach(function (n) {
        var tr = el('tr', '');
        hpTd(tr, el('b', 'mono', n.name), 'hp-name');
        hpTd(tr, (n.state || '') + (n.speed ? ' · ' + (n.speed >= 1000 ? n.speed / 1000 + ' Gb/s' : n.speed + ' Mb/s') : ''), 'num muted small');
        tn.appendChild(tr);
        var tr2 = el('tr', 'hp-sub'); hpTd(tr2, noI18n(el('span', '', '↓' + hloadRate(n.rx) + ' ↑' + hloadRate(n.tx)))); tr2.lastChild.colSpan = 2; tn.appendChild(tr2);
        var tr3 = el('tr', 'hp-sub'); hpTd(tr3, noI18n(el('span', 'muted small', '↓' + bytes(n.rx_all) + ' ↑' + bytes(n.tx_all)))); tr3.lastChild.colSpan = 2; tn.appendChild(tr3);
      });
      col.appendChild(tn);
      if (!(x.nics || []).length) col.appendChild(el('p', 'muted small', 'no card'));
    }
    grid.appendChild(col);
  });
  p.appendChild(grid);
  if (x) {
    var s = hpSec(p, 'Taking most of the processor'), w = el('div', 'hp-pills');
    (x.top_cpu || []).slice(0, 8).forEach(function (q) { var c = el('span', 'hp-pill'); c.appendChild(noI18n(el('span', 'mono', q.name))); c.appendChild(noI18n(el('b', '', Math.round(q.cpu) + ' %'))); w.appendChild(c); });
    s.appendChild(w);
  }
}
/* The other node's panel (1.0.253): its numbers and its last two minutes, as its row in the
   database brings them every 5 s - each core, the disks and the processes are read on that
   node only, on its own pages. */
function hpPeer(p, k, node, o) {
  var d = o.now || {};
  var head = el('div', 'hp-head');
  head.appendChild(el('b', '', HP_TITLE[k]));
  head.appendChild(noI18n(el('span', 'hp-scale muted small', node)));
  p.appendChild(head);
  var big = el('div', 'hp-graph hl-' + k);
  big.innerHTML = hlLiveSvg(k, 400, 54, false, true);
  p.appendChild(big);
  p.appendChild(el('div', 'hp-span muted small', 'the last two minutes'));
  var s = hpSec(p, '');
  var kv = function (a, b) { var r = el('div', 'hp-row hp-kv'); r.appendChild(el('span', 'muted', a)); r.appendChild(noI18n(el('b', '', b))); s.appendChild(r); };
  if (o.late || !o.now) kv('Now', 'no answer');
  else if (k === 'cpu') { kv('Now', hpPct(d.cpu)); if (d.load) kv('load', d.load.join(' / ')); kv('cores', String(d.cores || '')); }
  else if (k === 'mem') { kv('In use', d.mem_total ? bytes(d.mem_used) + ' / ' + bytes(d.mem_total) : '–'); if (d.swap_used) kv('Swap', bytes(d.swap_used)); }
  else if (k === 'disk') { kv('read', hloadRate(d.disk_rd)); kv('written', hloadRate(d.disk_wr)); }
  /* its own words (1.0.255): 'down' alone is a service down elsewhere on the pages */
  else { kv('received ↓', hloadRate(d.net_rx)); kv('sent ↑', hloadRate(d.net_tx)); }
  p.appendChild(el('p', 'muted small', 'Each core, the disks and the processes of this node are shown on its own pages.'));
}
/* A - the tiles */
function hpTiles(p, k) {
  var d = HLOAD.last || {}, x = HLOAD.detail;
  var head = el('div', 'hp-head');
  head.appendChild(el('b', '', {cpu: 'The processor', mem: 'Memory', disk: 'The disks', net: 'The network'}[k]));
  var big = el('div', 'hp-graph');
  var vals = (HLOAD.hist || {})[k] || [];
  var max = (k === 'cpu' || k === 'mem') ? 100 : Math.max.apply(null, vals.concat([1024]));
  big.innerHTML = HLOAD.ctx !== null && HLOAD.ctx !== undefined ? hlLiveSvg(k, 400, 54, false, true)
    : hloadSpark(vals, max).replace('width="56" height="18"', 'width="100%" height="54"');
  big.classList.add('hl-' + k);
  var scale = hlScale(k, max);
  head.appendChild(scale);
  p.appendChild(head);
  p.appendChild(big);
  p.appendChild(el('div', 'hp-span muted small', 'the last two minutes'));
  var sec = function (title) { var s = el('div', 'hp-sec'); if (title) s.appendChild(el('div', 'hp-h', title)); p.appendChild(s); return s; };
  var row = function (host, cells) { var r = el('div', 'hp-row'); cells.forEach(function (c) { if (c === null || c === undefined) { r.appendChild(el('span', '')); return; } r.appendChild(c.nodeType ? c : noI18n(el('span', '', String(c)))); }); host.appendChild(r); return r; };
  if (!x) { p.appendChild(el('p', 'muted small', 'reading…')); return; }
  var tps = x.temps || {};
  if (k === 'cpu') {
    var s1 = sec('');
    row(s1, [el('span', 'muted', 'Now'), noI18n(el('b', '', d.cpu === undefined ? '…' : Math.round(d.cpu) + ' %')), el('span', 'muted', 'load'), noI18n(el('span', '', (d.load || []).join(' / ')))]).classList.add('hp-kv');
    if (x.model) row(s1, [noI18n(el('span', 'hp-wide muted small', x.model))]);
    row(s1, [el('span', 'muted', 'Up for'), noI18n(el('span', '', hlUp(x.uptime))), el('span', 'muted', 'processes'), noI18n(el('span', '', String(x.procs || '')))]).classList.add('hp-kv');
    (tps.cpu || []).forEach(function (t) { row(s1, [noI18n(el('span', 'muted', t[0])), hlTemp(t[1])]).classList.add('hp-kv'); });
    var s2 = sec('Each core');
    var grid = el('div', 'hp-cores');
    (x.cores || []).forEach(function (c) {
      var one = el('div', 'hp-core');
      var top = el('div', 'hp-core-top');
      top.appendChild(noI18n(el('b', '', 'CPU ' + c.n)));
      top.appendChild(noI18n(el('span', '', c.busy === null || c.busy === undefined ? '…' : Math.round(c.busy) + ' %')));
      one.appendChild(top);
      one.appendChild(hlBar(c.busy));
      var bot = el('div', 'hp-core-bot muted small');
      bot.appendChild(noI18n(el('span', '', c.mhz ? (c.mhz >= 1000 ? (c.mhz / 1000).toFixed(1) + ' GHz' : c.mhz + ' MHz') : '')));
      var t = hlTemp(c.temp);
      if (t) bot.appendChild(t);
      one.appendChild(bot);
      grid.appendChild(one);
    });
    s2.appendChild(grid);
    if (!(tps.cpu || []).length && !Object.keys(tps.cores || {}).length) s2.appendChild(el('p', 'muted small', 'No temperature: this machine has no sensors the kernel reads (a virtual machine has none).'));
    var s3 = sec('Taking most of the processor');
    (x.top_cpu || []).slice(0, 5).forEach(function (q) { row(s3, [noI18n(el('span', 'mono', q.name)), noI18n(el('span', 'muted small', 'pid ' + q.pid)), noI18n(el('span', 'num', Math.round(q.cpu) + ' %'))]); });
    if (!(x.top_cpu || []).length) s3.appendChild(el('p', 'muted small', 'nothing busy just now'));
  } else if (k === 'mem') {
    var m = x.mem || {}, used = (m.total || 0) - (m.available || 0);
    var s1m = sec('');
    s1m.appendChild(hlBar(m.total ? 100 * used / m.total : 0));
    [['In use', used], ['Free for programs', m.available], ['Cache (given back when needed)', (m.cached || 0) + (m.buffers || 0)], ['Shared', m.shared], ['Altogether', m.total]].forEach(function (r) {
      row(s1m, [el('span', 'muted', r[0]), noI18n(el('span', 'num', bytes(r[1] || 0)))]).classList.add('hp-kv2');
    });
    if (m.swap_total) {
      var su = m.swap_total - (m.swap_free || 0);
      row(s1m, [el('span', 'muted', 'Swap'), noI18n(el('span', 'num', bytes(su) + ' / ' + bytes(m.swap_total)))]).classList.add('hp-kv2');
    } else row(s1m, [el('span', 'muted', 'Swap'), el('span', 'num muted', 'none')]).classList.add('hp-kv2');
    var s2m = sec('Taking most memory');
    (x.top_mem || []).slice(0, 5).forEach(function (q) { row(s2m, [noI18n(el('span', 'mono', q.name)), noI18n(el('span', 'muted small', 'pid ' + q.pid)), noI18n(el('span', 'num', bytes(q.rss)))]); });
  } else if (k === 'disk') {
    var s1d = sec('Each disk');
    (x.disks || []).filter(function (dk) { return dk.size > 64 * 1048576; }).forEach(function (dk) {
      var r = row(s1d, [noI18n(el('b', 'mono', dk.name)), noI18n(el('span', 'muted small', bytes(dk.size) + (dk.model ? ' · ' + dk.model : ''))),
        noI18n(el('span', 'num', '↓' + hloadRate(dk.rd) + ' ↑' + hloadRate(dk.wr))), hlTemp(dk.temp)]);
      r.classList.add('hp-disk');
      var u = el('div', 'hp-util');
      u.appendChild(el('span', 'muted small', 'busy'));
      u.appendChild(hlBar(dk.util));
      u.appendChild(noI18n(el('span', 'small num', dk.util === undefined ? '…' : Math.round(dk.util) + ' %')));
      s1d.appendChild(u);
    });
    var s2d = sec('Filesystems');
    (x.filesystems || []).forEach(function (f) {
      var pct = f.total ? 100 * f.used / f.total : 0;
      var r = row(s2d, [noI18n(el('span', 'mono', f.mount)), noI18n(el('span', 'muted small', f.kind)), noI18n(el('span', 'num', bytes(f.used) + ' / ' + bytes(f.total)))]);
      r.classList.add('hp-fs');
      var b = el('div', 'hp-util');
      b.appendChild(hlBar(pct));
      b.appendChild(noI18n(el('span', 'small num', Math.round(pct) + ' %')));
      s2d.appendChild(b);
    });
  } else {
    var s1n = sec('Each card');
    (x.nics || []).forEach(function (n) {
      row(s1n, [noI18n(el('b', 'mono', n.name)), noI18n(el('span', 'muted small', (n.state || '') + (n.speed ? ' · ' + (n.speed >= 1000 ? n.speed / 1000 + ' Gb/s' : n.speed + ' Mb/s') : ''))),
        noI18n(el('span', 'num', '↓' + hloadRate(n.rx) + ' ↑' + hloadRate(n.tx)))]).classList.add('hp-nic');
      row(s1n, [el('span', ''), noI18n(el('span', 'muted small', 'since start ↓' + bytes(n.rx_all) + ' ↑' + bytes(n.tx_all)))]).classList.add('hp-nic2');
    });
    if (!(x.nics || []).length) s1n.appendChild(el('p', 'muted small', 'no card'));
  }
  var oth = tps.other || [];
  if (k === 'cpu' && oth.length) {
    var s4 = sec('Other sensors');
    oth.forEach(function (t) { row(s4, [noI18n(el('span', 'muted', t[0])), hlTemp(t[1])]).classList.add('hp-kv'); });
  }
}
/* otp's own (1.0.253): the looks kept with the account (ME.prefs, POST prefs); LIVE is
   admin.js's switch of the page; the meter only for a full administrator, and only while
   Settings - About has it on (STATUS.perf_meter). */
function prefs() { return (typeof ME === 'object' && ME && ME.prefs) || {}; }
function savePrefs(change) {
  return api('prefs', change).then(function (d) {
    if (typeof ME === 'object' && ME) ME.prefs = (d && d.prefs) || ME.prefs;
    return ME && ME.prefs;
  });
}
function hloadAllowed() {
  return typeof STATUS === 'object' && STATUS && !!STATUS.perf_meter
    && typeof ME === 'object' && ME && ME.role === 'fulladmin';
}
function hloadLive() { return typeof LIVE === 'boolean' ? LIVE : !(LIVE && LIVE.on === false); }
function hloadOff() {
  hloadPanelClose();
  HLOAD.others = null; HLOAD.last = null; HLOAD.had = false; HLOAD.series = {}; HLOAD.off = {}; HLOAD.tops = {};
  var h = $('hload');
  if (h) { h.hidden = true; clear(h); }
}
function hloadTick(now) {
  if (!$('hload')) return;
  if (!hloadAllowed()) { if (!$('hload').hidden || HLOAD.had) hloadOff(); return; }
  if ((HLOAD.busy && !now) || !hloadLive()) return;
  /* In a tab behind others (1.0.258) the page goes on asking, every 30 s and drawing nothing, and
     says so (keep): the daemons go on reading, and back in front the graphs have no hole. The
     browser lets a page in the background ask once a minute only - the daemon keeps it 75 s. */
  var hidden = !!document.hidden;
  if (hidden && Date.now() - (HLOAD.hiddenAsked || 0) < 30000) return;
  if (hidden) HLOAD.hiddenAsked = Date.now();
  HLOAD.look = prefs().hload || 'graphs';
  if (HLOAD.look === 'off') { hloadPanelClose(); $('hload').hidden = true; return; }
  HLOAD.busy = true;
  /* only what is newer than what the page has of each node; nothing at the first look after the
     page is loaded (F5) - then the daemon gives its last two and a half minutes */
  var since = Object.keys(HLOAD.series).filter(function (n) { return hlLast(n); })
    .map(function (n) { return encodeURIComponent((n || HLOAD.node || '') + ':' + hlLast(n)); }).join(',');
  var q = 'load' + (since ? '&since=' + since : '');
  if (hidden) q += '&keep=75';
  else if (HLOAD.open && !HLOAD.openNode) q += '&detail=1';
  /* the other node's panel open: its cores, disks and processes asked of it (1.0.258) */
  else if (HLOAD.open && HLOAD.openNode) q += '&detail_node=' + encodeURIComponent(HLOAD.openNode);
  api(q).then(function (d) {
    if (!hloadAllowed() || !d || !d.now) return;
    HLOAD.node = d.node || '';
    hlAdd('', d.hist);
    (d.others || []).forEach(function (o) { hlAdd(o.node, o.hist); });
    HLOAD.had = true;
    HLOAD.others = d.others || null;
    if (d.detail) { HLOAD.detail = d.detail; HLOAD.detailAt = Date.now(); }
    if (document.hidden) { HLOAD.last = d.now; return; }     /* nothing drawn behind other tabs */
    hloadDraw(d.now);
  }).catch(function (e) {
    /* switched off meanwhile (404) - the next status says so too */
    if (e && /switched off/.test(String(e.message || ''))) hloadOff();
  }).then(function () { HLOAD.busy = false; });
}
function hloadLoop() {
  if (!$('hload')) return;
  clearInterval(HLOAD.timer);
  hloadTick();
  HLOAD.timer = setInterval(hloadTick, 2000);
}
document.addEventListener('visibilitychange', function () { if (!document.hidden) hloadTick(); });

/* The two pickers of My account (1.0.75): cards drawn by the same code from sample numbers. */
function hloadPickers(lsec) {
  if (!$('hload') || !hloadAllowed()) return;
  var HL_LOOKS = [['graphs', 'with a graph of the last two minutes'], ['pills', 'pills with a bar'], ['line', 'one plain line'],
                  ['rings', 'with rings'], ['off', 'not shown']];
  var g3 = el('div', 'hl-pickers');
  g3.appendChild(el('div', 'hl-pick-h', 'The load of the server in the header (CPU, RAM, the disks, the network)'));
  g3.appendChild(hlPicker(HL_LOOKS, prefs().hload || 'graphs', hlPreviewLook, function (v) {
    savePrefs({hload: v}).then(function () {
      HLOAD.look = v;
      if (v === 'off') { hloadPanelClose(); $('hload').hidden = true; } else if (HLOAD.last) hloadDraw(HLOAD.last); else hloadTick();
      toast('kept', 'good');
    }).catch(oops);
  }));
  /* and how its details look when a number is pointed at (1.0.74) */
  g3.appendChild(el('div', 'hl-pick-h', 'Its details, when a number is pointed at (or tapped)'));
  g3.appendChild(hlPicker(HP_STYLES, hpStyle(), hlPreviewPanel, function (v) {
    savePrefs({hpanel: v}).then(function () {
      if (v === 'off') hloadPanelClose(); else if (HLOAD.open) { hloadPanelDraw(); hloadPanelPlace(); }
      if (HLOAD.last) hloadDraw(HLOAD.last);
      toast('kept', 'good');
    }).catch(oops);
  }));
  lsec.appendChild(g3);
}
