<?php
/**
 * admin/index.php — the administration pages of otp.
 *
 * isemon's dashboard, for a token server: the same header, the same tabs, the
 * same settings down a rail at the left edge, the same popups. It collects
 * nothing itself and decides nothing: every word comes from the otp daemon
 * over its API on localhost, and the daemon decides whether whoever is signed
 * in may have it.
 */
declare(strict_types=1);

define('OTP_COOKIE', 'otp_session');
define('OTP_COOKIE_PATH', '/admin/');
require_once dirname(__DIR__) . '/otp-page.php';
require_once dirname(__DIR__) . '/otp-api.php';
require_once dirname(__DIR__) . '/otp-art.php';

/* nginx's question before it takes a big body (1.0.98, auth_request): is a
   full administrator signed in? Nothing else is answered here. */
if (($_SERVER['OTP_AUTH_ONLY'] ?? '') === '1') {
    $who = otp_whoami();
    /* One who must change the password first is not let send 4 GB to be refused (1.0.208). */
    http_response_code(is_array($who) && ($who['role'] ?? '') === 'fulladmin'
                       && empty($who['must_change']) ? 204 : 403);
    exit;
}

/* The certificate's own port (1.0.275): nginx there asks the browser for a client certificate and
   sends only ?api=cert-login and ?api=cert-check here, with the certificate it got
   (SSL_CLIENT_CERT, set by nginx - never a header of the browser's). Nothing else is answered on
   that port; every answer goes back to the pages on 443. */
if (($_SERVER['OTP_CERT_PORT'] ?? '') === '1') {
    otp_cert_port();
    exit;
}

function otp_cert_back(string $said = ''): void
{
    $host = preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
    if (!preg_match('/^([A-Za-z0-9.-]{1,253}|\[[0-9A-Fa-f:.]{2,45}\])\z/', $host)) {
        $host = (string) ($_SERVER['SERVER_NAME'] ?? 'localhost');
    }
    /* Why not, in a cookie of this site for two minutes (1.0.278) - not as words in the address:
       a link of anybody's put any text on this sign-in page as a refusal, and stopped the
       certificate being tried by itself in that tab. The address says only that one is there. */
    if ($said !== '') {
        setcookie('otp_certsaid', substr($said, 0, 300), ['expires' => time() + 120, 'path' => OTP_COOKIE_PATH,
                                                         'secure' => true, 'httponly' => true, 'samesite' => 'Lax']);
    }
    $to = 'https://' . $host . '/admin/' . ($said !== '' ? '?certsaid=1' : '');
    header('Cache-Control: no-store');
    header('Location: ' . $to, true, 303);
    exit;
}

function otp_cert_port(): void
{
    $what = (string) ($_GET['api'] ?? '');
    if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !in_array($what, ['cert-login', 'cert-check', 'cert-alive'], true)) {
        http_response_code(404);
        exit;
    }
    if ($what === 'cert-alive') {
        /* The card watched (1.0.285): the signed-in page loads a picture from here every few seconds - a
           new connection, whose handshake only the card can sign. Whatever certificate came (none: the
           card is out) goes to the daemon with the session's cookie; the answer is a picture 1 pixel wide
           (the card is there), 2 wide (it is out, the session waits) or none - 403 (the session is over).
           No session, no question asked. A picture: no CORS, nothing for another site to read. */
        header('Cache-Control: no-store');
        $pem = ($_SERVER['OTP_CERT_FAIL'] ?? '') === '1' ? '' : rawurldecode((string) ($_SERVER['SSL_CLIENT_CERT'] ?? ''));
        if (strlen($pem) > 20000) {
            $pem = '';
        }
        /* 1.0.286: 3 wide - no cookie came with the check (the page then says so on 443, where its cookie
           does come); 4 wide - this browser cannot be checked (its checks never once found the card): it is
           not watched. */
        $gifs = [1 => 'R0lGODlhAQABAIEAAAAAAP///wAAAAAAACH5BAEAAAAALAAAAAABAAEAAAgEAAEEBAA7',
                 2 => 'R0lGODlhAgABAIEAAAAAAP///wAAAAAAACH5BAEAAAAALAAAAAACAAEAAAgFAAEACAgAOw==',
                 3 => 'R0lGODlhAwABAIEAAAAAAP///wAAAAAAACH5BAEAAAAALAAAAAADAAEAAAgFAAEIDAgAOw==',
                 4 => 'R0lGODlhBAABAIEAAAAAAP///wAAAAAAACH5BAEAAAAALAAAAAAEAAEAAAgGAAEIBBAQADs=',
                 /* 1.0.288: 5 wide - the sign-in ended just now for its card, 6 - for another card: the page
                    says why and tries nothing by itself (a 403 left it without a word). */
                 5 => 'R0lGODlhBQABAIEAAAAAAP///wAAAAAAACH5BAEAAAAALAAAAAAFAAEAAAgGAAEIFBgQADs=',
                 6 => 'R0lGODlhBgABAIEAAAAAAP///wAAAAAAACH5BAEAAAAALAAAAAAGAAEAAAgGAAEIHBgQADs='];
        $wide = 0;
        if (otp_session() !== '') {
            $k = preg_replace('/[^0-9a-f]/', '', substr((string) ($_GET['k'] ?? ''), 0, 64));
            [$status, $body] = otp_call('/api/auth/card', 'POST', ['cert' => $pem, 'k' => $k], 10.0);
            $d = $status === 200 ? json_decode((string) $body, true) : null;
            if (is_array($d) && empty($d['gone'])) {
                $wide = !empty($d['unable']) ? 4 : (!empty($d['alive']) ? 1 : 2);
            } elseif (is_array($d) && !empty($d['watched'])) {
                $wide = ($d['why'] ?? '') === 'other' ? 6 : 5;
            }
        } else {
            $wide = 3;
        }
        if ($wide > 0) {
            header('Content-Type: image/gif');
            echo base64_decode($gifs[$wide]);
            exit;
        }
        http_response_code(403);
        exit;
    }
    $pem = rawurldecode((string) ($_SERVER['SSL_CLIENT_CERT'] ?? ''));
    if (($_SERVER['OTP_CERT_FAIL'] ?? '') === '1') {
        /* nginx refused the certificate itself (495): run out, not for a client, cut short. */
        $why = preg_replace('/^FAILED:/', '', (string) ($_SERVER['SSL_CLIENT_VERIFY'] ?? ''));
        $why = preg_replace('/[^\x20-\x7e]/', '', $why);
        $why = $why !== '' ? $why : 'the browser\'s certificate could not be read';
        if ($what === 'cert-check') {
            header('Content-Type: text/plain; charset=utf-8');
            echo 'would not sign in: the certificate is not taken: ' . $why;
            exit;
        }
        otp_cert_back('the certificate is not taken: ' . $why);
    }
    if ($what === 'cert-login') {
        /* Started from the sign-in page of this browser (the nonce of its cookie): a link of
           somebody else's cannot sign anybody in. Used once. */
        $n = (string) ($_GET['n'] ?? '');
        $c = (string) ($_COOKIE['otp_certn'] ?? '');
        setcookie('otp_certn', '', ['expires' => time() - 3600, 'path' => OTP_COOKIE_PATH,
                                    'secure' => true, 'httponly' => true, 'samesite' => 'Strict']);
        if ($n === '' || $c === '' || !preg_match('/^[0-9a-f]{32}\z/', $n) || !hash_equals($c, $n)) {
            otp_cert_back('the sign-in with a certificate was not started from this browser\'s sign-in page - try again');
        }
        if ($pem === '') {
            otp_cert_back('no certificate was sent - none chosen, or the browser has none from the authorities put in here');
        }
        [$status, $body] = otp_call('/api/auth/cert', 'POST', ['cert' => $pem], 30.0);
        $data = json_decode((string) $body, true);
        if ($status === 200 && is_array($data) && !empty($data['token'])) {
            otp_set_session((string) $data['token']);
            otp_cert_back();
        }
        otp_cert_back(is_array($data) && !empty($data['error']) ? (string) $data['error']
                      : ($status === 0 ? 'the daemon is not answering' : 'refused'));
    }
    /* cert-check: who the certificate would sign in, for a signed-in administrator - nothing opened. */
    [$status, $body] = otp_call('/api/certlogin', 'POST', ['action' => 'check', 'cert' => $pem], 30.0);
    $d = json_decode((string) $body, true);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    $h = fn($x) => htmlspecialchars((string) $x, ENT_QUOTES, 'UTF-8');
    $ok = is_array($d) && !empty($d['ok']);
    $line = !is_array($d) ? 'the daemon is not answering'
        : ($status !== 200 ? ($d['error'] ?? 'refused')
        : ($ok ? 'would sign in ' . ($d['upn'] ?? '') . ' as ' . ($d['role'] ?? '') . (!empty($d['mfa']) ? ', then the second step' : '')
               : 'would not sign in' . (!empty($d['upn']) ? ' ' . $d['upn'] : '') . ': ' . ($d['said'] ?? '')));
    $rows = '';
    foreach (['subject' => 'Subject', 'issuer' => 'Issuer', 'serial' => 'Serial', 'not_after' => 'Valid to', 'sid' => 'SID'] as $k => $l) {
        if (is_array($d) && !empty($d[$k])) {
            $rows .= '<tr><td>' . $h($l) . '</td><td><code>' . $h($d[$k]) . '</code></td></tr>';
        }
    }
    $host = preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>otp - your certificate</title><style nonce="' . $h($GLOBALS['nonce'] ?? '') . '">body{font-family:system-ui,sans-serif;background:#0d1117;color:#e6e9ef;margin:0;padding:32px}'
        . '.box{max-width:720px;margin:0 auto;background:#161b22;border:1px solid #262c37;border-radius:14px;padding:24px}'
        . '.ok{color:#3fb950}.bad{color:#f85149}td{padding:4px 12px 4px 0;vertical-align:top;color:#8b94a3}code{color:#e6e9ef;word-break:break-all}'
        . 'a{color:#58a6ff}</style></head><body><div class="box"><h2>Your certificate</h2><p class="' . ($ok ? 'ok' : 'bad') . '" id="said">'
        . $h($line) . '</p><table>' . $rows . '</table><p><a href="https://' . $h($host) . '/admin/#settings/people">Back to the pages</a></p></div></body></html>';
}

if (isset($_GET['api'])) {
    $what = (string) $_GET['api'];
    $post = $_SERVER['REQUEST_METHOD'] === 'POST';
    /* acme push (docs/acme-push-protocol.md): an acme putting its certificates on
       these pages - Settings → Certificates and TLS → Certificates from acme. No
       sign-in: the daemon checks acme's signature over the body as it came, so the
       body (as base64) and the X-Acme-Push-* headers go to it untouched, in its JSON. */
    if (preg_match('/^acme-push-(hello|pair|inventory|install)$/', $what, $push)) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $op = $push[1];
        if (($op === 'hello') === $post) {
            http_response_code(405);
            echo json_encode(['ok' => false, 'code' => 'bad_request',
                              'error' => $op === 'hello' ? 'hello is a GET' : 'a POST, signed']);
            exit;
        }
        $payload = null;
        if ($post) {
            $raw = (string) file_get_contents('php://input', false, null, 0, 1048577);
            if (strlen($raw) > 1048576) {
                http_response_code(413);
                echo json_encode(['ok' => false, 'code' => 'too_big', 'error' => 'that is more than a certificate']);
                exit;
            }
            $signed = [];
            foreach (['Version', 'Key', 'Time', 'Nonce', 'Signature'] as $h) {
                /* Printable ASCII only (1.0.217): a byte that is not UTF-8 made the relay's JSON
                   fail, and the answer was another request's error. The protocol's values are ASCII. */
                $signed[$h] = substr(preg_replace('/[^\x20-\x7e]/', '',
                    (string) ($_SERVER['HTTP_X_ACME_PUSH_' . strtoupper($h)] ?? '')), 0, 300);
            }
            $payload = ['body' => base64_encode($raw), 'headers' => $signed];
        }
        [$status, $body] = otp_call('/api/acme-push/' . $op, $post ? 'POST' : 'GET', $payload, 60.0);
        http_response_code($status ?: 503);
        echo $status ? $body : json_encode(['ok' => false, 'code' => 'down',
                                            'error' => 'the daemon is not answering']);
        exit;
    }
    if ($what === 'lang' && !$post) {
        otp_serve_lang();
    }
    if ($what === 'software' && !$post) {
        /* What every node runs on (1.0.99) - and of the pages, what this
           PHP itself is: php-fpm's, not the command line's. */
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        [$status, $body] = otp_call('/api/software', 'GET', null, 20.0);
        $data = json_decode((string) $body, true);
        if ($status !== 200 || !is_array($data)) {
            http_response_code($status ?: 503);
            echo $body ?: json_encode(['ok' => false, 'error' => 'the daemon is not answering']);
            exit;
        }
        $ext = [];
        foreach (get_loaded_extensions() as $e) {
            $v = phpversion($e);
            $ext[$e] = ($v === false || $v === PHP_VERSION) ? '' : (string) $v;
        }
        ksort($ext, SORT_NATURAL | SORT_FLAG_CASE);
        $data['pages'] = [
            'php' => PHP_VERSION, 'sapi' => PHP_SAPI, 'extensions' => $ext,
            'opcache' => function_exists('opcache_get_status') && is_array(@opcache_get_status(false))
                && !empty(@opcache_get_status(false)['opcache_enabled']),
            'server' => (string) ($_SERVER['SERVER_SOFTWARE'] ?? ''),
            'os' => PHP_OS_FAMILY,
        ];
        echo json_encode($data);
        exit;
    }
    if ($what === 'logo' && !$post) {
        otp_serve_logo();
    }
    if ($what === 'upgrade-state' && !$post) {
        /* How far an upgrade of this node is (1.0.299), without the daemon: the pages ask this
           while it restarts - and whether it answers again, and the version of these files. */
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        [$hs] = otp_call('/api/health', 'GET', null, 3.0);
        echo json_encode(['ok' => true, 'upgrading' => otp_upgrading(otp_session() !== ''),
                          'pages' => OTP_VERSION, 'api' => $hs === 200],
                         JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }
    if ($post) {
        otp_guard_post();
    }
    if ($what === 'login' && $post) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $sent = sent_body();
        [$status, $body] = otp_call('/api/auth/login', 'POST', [
            'name'     => (string) ($sent['name'] ?? ''),
            'password' => (string) ($sent['password'] ?? ''),
        ], 30.0);
        if ($status === 0) {
            http_response_code(503);
            echo json_encode(['ok' => false, 'error' =>
                'the daemon is not answering — is otp.service running?']);
            exit;
        }
        $data = json_decode($body, true);
        if ($status === 200 && is_array($data) && !empty($data['token'])) {
            otp_set_session((string) $data['token']);
            unset($data['token']);
            echo json_encode($data);
            exit;
        }
        http_response_code($status === 200 ? 400 : $status);
        echo json_encode(is_array($data) ? $data : ['ok' => false, 'error' => 'sign-in failed']);
        exit;
    }
    if (($what === 'kerberos-login' || $what === 'kerberos-check') && $post) {
        /* Signing in with Windows (1.0.274): the browser's Kerberos ticket, from
           "Authorization: Negotiate", handed to the daemon - which checks it, refuses
           NTLM, and opens the sign-in (the second step still to give, when it is on).
           Without a ticket: 401 and "WWW-Authenticate: Negotiate", which makes a
           browser that may send one send it at once. */
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $login = $what === 'kerberos-login';
        if ($login) {
            $hl = otp_get('/api/health', 5.0);
            if (!is_array($hl) || empty($hl['kerberos'])) {
                http_response_code(404);
                echo json_encode(['ok' => false, 'error' => 'signing in with Kerberos is off']);
                exit;
            }
        }
        $auth = (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? ''));
        /* NTLM is never taken (1.0.277): offered bare - a browser outside the domain, or a name and
           password typed into the browser's own window - it is refused here at once, with 403 and no new
           challenge, so the browser does not ask again. Never passed on, never looked into. */
        if (preg_match('/^\s*(NTLM|Basic|Digest)\b/i', $auth, $other)) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'code' => 'ntlm', 'error' => strtoupper($other[1]) === 'NTLM'
                ? 'the browser offered NTLM, which is never taken here - only Kerberos'
                : 'the browser offered ' . $other[1] . ', which is never taken here - only Kerberos']);
            exit;
        }
        /* A quantifier of PCRE goes to 65535 at most: the length is checked apart. */
        if (strlen($auth) > 140000
            || !preg_match('/^Negotiate\s+([A-Za-z0-9+\/]{8,}={0,2})\s*\z/i', $auth, $neg)) {
            http_response_code(401);
            header('WWW-Authenticate: Negotiate');
            echo json_encode(['ok' => false, 'code' => 'no_ticket', 'error' =>
                'the browser sent no Kerberos ticket - is this computer in the domain, and is this '
                . 'name among the browser\'s intranet sites?']);
            exit;
        }
        [$status, $body] = $login
            ? otp_call('/api/auth/kerberos', 'POST', ['token' => $neg[1]], 30.0)
            : otp_call('/api/kerberos', 'POST', ['action' => 'check', 'token' => $neg[1]], 30.0);
        if ($status === 0) {
            http_response_code(503);
            echo json_encode(['ok' => false, 'error' =>
                'the daemon is not answering — is otp.service running?']);
            exit;
        }
        $data = json_decode($body, true);
        if ($login && $status === 200 && is_array($data) && !empty($data['token'])) {
            otp_set_session((string) $data['token']);
            unset($data['token']);
            echo json_encode($data);
            exit;
        }
        /* Refused: 403, never 401 again - a 401 with Negotiate would have the browser try
           once more, or offer NTLM, or ask for a password in a window of its own. */
        http_response_code($status === 401 ? 403 : $status);
        echo is_array($data) ? json_encode($data) : json_encode(['ok' => false, 'error' => 'refused']);
        exit;
    }
    if ($what === 'cert-nonce' && $post) {
        /* The start of a sign-in with a certificate (1.0.275): a nonce in a cookie of this browser,
           and the address of the certificate's port to go to with it. */
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $hl = otp_get('/api/health', 5.0);
        if (!is_array($hl) || empty($hl['cert'])) {
            http_response_code(404);
            echo json_encode(['ok' => false, 'error' => 'signing in with a certificate is off']);
            exit;
        }
        $n = bin2hex(random_bytes(16));
        setcookie('otp_certn', $n, ['expires' => time() + 300, 'path' => OTP_COOKIE_PATH,
                                    'secure' => true, 'httponly' => true, 'samesite' => 'Strict']);
        $host = preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
        if (!preg_match('/^([A-Za-z0-9.-]{1,253}|\[[0-9A-Fa-f:.]{2,45}\])\z/', $host)) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => 'open the pages by their name']);
            exit;
        }
        echo json_encode(['ok' => true, 'url' => 'https://' . $host . ':' . (int) ($hl['cert_port'] ?? 8443)
                          . '/admin/?api=cert-login&n=' . $n]);
        exit;
    }
    if ($what === 'mfa' && $post) {
        /* The second step given (1.0.149): the daemon ends the sign-in the
           password opened and hands a new one - its cookie set here, the
           token never shown to the page. */
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        [$status, $body] = otp_call('/api/auth/mfa', 'POST', sent_json(), 90.0);
        if ($status === 0) {
            http_response_code(503);
            echo json_encode(['ok' => false, 'error' =>
                'the daemon is not answering — is otp.service running?']);
            exit;
        }
        $data = json_decode($body, true);
        if (is_array($data) && !empty($data['token'])) {
            if ($status === 200) {
                otp_set_session((string) $data['token']);
            }
            unset($data['token']);
            $body = json_encode($data);
        }
        http_response_code($status);
        echo $body;
        exit;
    }
    if ($what === 'upgrade-package' && $post) {
        /* A new version of otp (1.0.37): the .tar.gz itself is the body, as a
           database being put back is. A full administrator only, asked before
           a byte is read; the daemon checks its signature, and root checks it
           again before putting it in. */
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $who = otp_whoami();
        if (!is_array($who) || ($who['role'] ?? '') !== 'fulladmin' || !empty($who['must_change'])) {
            http_response_code(401);
            echo json_encode(['ok' => false, 'error' => is_array($who)
                ? 'only a full administrator may send a new version'
                : 'not signed in']);
            exit;
        }
        [$tmp, $why] = otp_take_body(64 * 1024 * 1024);
        if ($tmp === null) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $why]);
            exit;
        }
        try {
            [$status, $body] = otp_send_file('/api/upgrade/package', $tmp);
        } finally {
            @unlink($tmp);
        }
        if ($status === 0) {
            http_response_code(503);
            echo json_encode(['ok' => false, 'error' =>
                'the daemon is not answering — is otp.service running?']);
            exit;
        }
        http_response_code($status);
        echo $body;
        exit;
    }
    if ($what === 'db-restore' && $post) {
        /* A database somebody is putting back: the file itself is the body,
           written down a lump at a time as it arrives and going on to the
           daemon from there - never held in memory, never a multipart form. */
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        /* Who is sending it is asked first, before a byte of the body is read:
           the daemon would refuse it at the end anyway, but up to four
           gigabytes would have been written to disk by then on anybody's
           say-so. Only a full administrator may put a database back. */
        $who = otp_whoami();
        if (!is_array($who) || ($who['role'] ?? '') !== 'fulladmin' || !empty($who['must_change'])) {
            http_response_code(401);
            echo json_encode(['ok' => false, 'error' => is_array($who)
                ? 'only a full administrator may put a database back'
                : 'not signed in']);
            exit;
        }
        [$tmp, $why] = otp_take_body(4 * 1024 * 1024 * 1024);
        if ($tmp === null) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $why]);
            exit;
        }
        $ask = '/api/db/restore' . (isset($_GET['check']) ? '?check=1' : '');
        try {
            [$status, $body] = otp_send_file($ask, $tmp);
        } finally {
            @unlink($tmp);
        }
        if ($status === 0) {
            http_response_code(503);
            echo json_encode(['ok' => false, 'error' =>
                'the daemon is not answering — is otp.service running?']);
            exit;
        }
        http_response_code($status);
        echo $body;
        exit;
    }
    if ($what === 'rbackup-upload' && $post) {
        /* A backup file being put back (1.0.109): as a database above - the
           file the body, written down as it comes, only a full administrator. */
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        $who = otp_whoami();
        if (!is_array($who) || ($who['role'] ?? '') !== 'fulladmin' || !empty($who['must_change'])) {
            http_response_code(401);
            echo json_encode(['ok' => false, 'error' => 'only a full administrator may put a backup back']);
            exit;
        }
        [$tmp, $why] = otp_take_body(4 * 1024 * 1024 * 1024);   // as nginx and the pool take (1.0.139)
        if ($tmp === null) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $why]);
            exit;
        }
        try {
            [$status, $body] = otp_send_file('/api/rbackup/upload', $tmp);
        } finally {
            @unlink($tmp);
        }
        if ($status === 0) {
            http_response_code(503);
            echo json_encode(['ok' => false, 'error' => 'the daemon is not answering — is otp.service running?']);
            exit;
        }
        http_response_code($status);
        echo $body;
        exit;
    }
    if ($what === 'rbackup-download' && !$post) {
        /* A backup made now - or one fetched from a destination - a lump at a
           time to the browser. Only an id and a file name are passed on. */
        $id = preg_replace('/[^a-f0-9]/', '', (string) ($_GET['id'] ?? ''));
        $name = preg_replace('/[^A-Za-z0-9._-]/', '', (string) ($_GET['name'] ?? ''));
        $bits = [];
        if ($id !== '' && $name !== '') { $bits[] = 'id=' . $id; $bits[] = 'name=' . rawurlencode($name); }
        [$status, $body] = otp_pipe('/api/rbackup/download' . ($bits ? '?' . implode('&', $bits) : ''), $name, 1800.0);
        if ($status === 401) {
            header('Location: /admin/');
            exit;
        }
        if ($status !== 200) {
            http_response_code($status ?: 503);
            header('Content-Type: application/json');
            echo $body ?: json_encode(['ok' => false, 'error' => 'the daemon is not answering']);
        }
        exit;
    }
    if ($what === 'db-download' && !$post) {
        /* A copy or a dump as a file to save, from the daemon to the browser a
           lump at a time. Only a name and which folder are passed on - never a
           path: the daemon holds both folders. */
        $name = preg_replace('/[^A-Za-z0-9._-]/', '', (string) ($_GET['name'] ?? ''));
        $kind = ($_GET['kind'] ?? '') === 'dump' ? 'dump' : '';
        $ticket = preg_replace('/[^a-f0-9]/', '', (string) ($_GET['ticket'] ?? ''));
        $bits = [];
        if ($ticket !== '') { $bits[] = 'ticket=' . $ticket; }
        if ($name !== '') { $bits[] = 'name=' . rawurlencode($name); }
        if ($kind !== '') { $bits[] = 'kind=dump'; }
        $ask = '/api/db/download' . ($bits ? '?' . implode('&', $bits) : '');
        [$status, $body] = otp_pipe($ask, $name);
        if ($status === 401) {
            // Signed out meanwhile: back to the sign-in, not a page of JSON (1.0.36).
            header('Location: /admin/');
            exit;
        }
        if ($status !== 200) {
            http_response_code($status ?: 503);
            header('Content-Type: application/json');
            echo $body ?: json_encode(['ok' => false, 'error' => 'the daemon is not answering']);
        }
        exit;
    }
    if ($what === 'logout' && $post) {
        otp_call('/api/auth/logout', 'POST', [], 10.0);
        otp_clear_session();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => true]);
        exit;
    }
    /* Reads apart from writes, so a GET can never reach a road that changes
       something, whatever is typed in the address bar. */
    $reads = [
        'status' => '/api/status', 'dashboard' => '/api/dashboard', 'radius' => '/api/radius',
        'radius-row' => '/api/radius/row', 'otp' => '/api/otp', 'tokens' => '/api/tokens',
        'activity' => '/api/activity',
        'token' => '/api/token', 'clients' => '/api/clients', 'realms' => '/api/realms',
        'directories' => '/api/directories', 'settings' => '/api/settings',
        'users' => '/api/users', 'sessions' => '/api/sessions', 'events' => '/api/events',
        'enrolment' => '/api/enrolment', 'suggest' => '/api/suggest', 'mail' => '/api/mail',
        'log' => '/api/log', 'db' => '/api/db', 'whoami' => '/api/auth/whoami',
        'export' => '/api/export', 'my-settings' => '/api/auth/settings', 'ha' => '/api/ha',
        'upgrade' => '/api/upgrade', 'web' => '/api/web',
        'firewall' => '/api/firewall', 'ha-history' => '/api/ha/history',
        'art' => '/api/portal/art', 'mailq' => '/api/mailq', 'texts' => '/api/texts', 'mailq-one' => '/api/mailq/one', 'software' => '/api/software',
        'rbackup' => '/api/rbackup', 'lockouts' => '/api/lockouts', 'net' => '/api/net', 'power' => '/api/power', 'ntp' => '/api/ntp', 'clock' => '/api/clock',
        'console-login' => '/api/console-login',
        'selinux' => '/api/selinux',
        'portal-sso' => '/api/portal-sso',
        'mfa' => '/api/auth/mfa', 'passkeys' => '/api/auth/passkeys',
        'sshkeys' => '/api/sshkeys', 'osroots' => '/api/osroots', 'osusers' => '/api/osusers', 'settings-nodes' => '/api/settings/nodes', 'osup' => '/api/osup', 'alerts' => '/api/alerts', 'sshd' => '/api/sshd', 'hisec' => '/api/hisec', 'acme' => '/api/acme', 'siem' => '/api/siem', 'isemon' => '/api/isemon', 'proxy' => '/api/proxy', 'logs' => '/api/logs',
        'dbtls' => '/api/dbtls', 'metrics' => '/api/metrics', 'snmp' => '/api/snmp', 'snmpfile' => '/api/snmpfile',
        'acme-push' => '/api/acme-push',
        'split' => '/api/split',
        'load' => '/api/load',
        'after' => '/api/after',
        'kerberos' => '/api/kerberos',
        'certlogin' => '/api/certlogin',
        'db-agent' => '/api/db-agent',
    ];
    $writes = [
        'token' => '/api/token', 'token-import' => '/api/token/import', 'tokens-backup' => '/api/tokens/backup', 'tokens-export' => '/api/tokens/export',
        'clients' => '/api/clients', 'realms' => '/api/realms',
        'directories' => '/api/directories', 'radtest' => '/api/radtest',
        'settings' => '/api/settings', 'isemon' => '/api/isemon', 'users' => '/api/users',
        'sessions' => '/api/sessions', 'db' => '/api/db', 'import' => '/api/import',
        'password' => '/api/auth/password', 'prefs' => '/api/auth/prefs',
        'columns' => '/api/auth/columns', 'my-settings' => '/api/auth/settings',
        'ha' => '/api/ha', 'mail' => '/api/mail', 'upgrade' => '/api/upgrade', 'web' => '/api/web', 'firewall' => '/api/firewall',
        'art' => '/api/portal/art', 'mailq' => '/api/mailq', 'texts' => '/api/texts',
        'rbackup' => '/api/rbackup', 'lockouts' => '/api/lockouts', 'trial' => '/api/trial', 'net' => '/api/net', 'power' => '/api/power', 'ntp' => '/api/ntp', 'clock' => '/api/clock',
        'console-login' => '/api/console-login',
        'selinux' => '/api/selinux',
        'portal-sso' => '/api/portal-sso',
        'mfa' => '/api/auth/mfa', 'passkeys' => '/api/auth/passkeys',
        'sshkeys' => '/api/sshkeys', 'osroots' => '/api/osroots', 'osusers' => '/api/osusers', 'settings-nodes' => '/api/settings/nodes', 'osup' => '/api/osup', 'alerts' => '/api/alerts', 'sshd' => '/api/sshd', 'hisec' => '/api/hisec', 'acme' => '/api/acme', 'siem' => '/api/siem', 'proxy' => '/api/proxy', 'logs' => '/api/logs',
        'dbtls' => '/api/dbtls', 'metrics' => '/api/metrics', 'snmp' => '/api/snmp',
        'acme-push' => '/api/acme-push',
        'split' => '/api/split',
        'after' => '/api/after',
        'kerberos' => '/api/kerberos',
        'certlogin' => '/api/certlogin',
        'card-gone' => '/api/auth/cardgone',
        'db-agent' => '/api/db-agent',
    ];
    if ($post) {
        if (!isset($writes[$what])) {
            http_response_code(404);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'unknown endpoint']);
            exit;
        }
        // the database server's agent (1.0.289): a restart through it waits up to 240 s
        otp_relay($writes[$what], 'POST', sent_json(), $what === 'db-agent' ? 300.0 : 90.0);
        exit;
    }
    if (!isset($reads[$what])) {
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'unknown endpoint']);
        exit;
    }
    $query = $_GET;
    unset($query['api']);
    /* The status with this node's upgrade file in it, when there is one (1.0.299): the band
       appears at once, before anything restarts - and an upgrade by hand (no plan) too. */
    $alter = null;
    if ($what === 'status' && otp_upgrading(true) !== null) {
        $alter = static function (object $d): object {
            $d->upgrade_file = otp_upgrading(true);
            return $d;
        };
    }
    otp_relay($reads[$what] . ($query ? '?' . http_build_query($query) : ''), 'GET', null, 60.0, $alter);
    exit;
}

/* ---- the page ------------------------------------------------------------ */
$me      = otp_whoami();
/* Signed in with the password, the second step still to give (1.0.125): the
   sign-in page, asking for it - nothing of the pages yet. */
$mfa     = (is_array($me) && !empty($me['mfa'])) ? (string) $me['mfa'] : '';
if ($mfa !== '') { $me = null; }
/* The card watched (1.0.285): its check is a picture from the certificate's port, which this page's
   policy lets in by that one address - only for a sign-in that is watched, sent again before anything of
   the page is. The name is the one this page was reached by (as the picture's). */
if (is_array($me) && is_array($me['card'] ?? null)) {
    $cwp = (int) ($me['card']['port'] ?? 0);
    $cwh = preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
    if ($cwp >= 1025 && $cwp <= 65535) {
        otp_csp($nonce, preg_match('/^[A-Za-z0-9.-]{1,253}\z/', $cwh) ? 'https://' . $cwh . ':' . $cwp : 'https:');
    } else {
        $me['card'] = null;
    }
}
$health  = otp_get('/api/health', 5.0);
$alive   = is_array($health);
/* This node being upgraded (1.0.299): the sign-in page says so itself, from the file, and loads
   again when the daemon is back - not "the daemon is not answering". */
$upg     = $me ? null : otp_upgrading(otp_session() !== '');
$upg_run = is_array($upg) && $upg['state'] === 'running';
$token_there = file_exists(OTP_TOKEN);
$token_ok    = otp_token() !== null;
$web_user    = function_exists('posix_getpwuid') && function_exists('posix_geteuid')
    ? (posix_getpwuid(posix_geteuid())['name'] ?? '?') : '?';
/* What the sign-in page says when something is wrong is for the operator at
   the console: which account the pages run as, where the token is, whether
   any account exists yet. From anywhere but this machine the page says only
   that the daemon is not answering - and the lines that would have named the
   rest never get a chance to. */
if (!$me && !otp_local()) {
    $token_there = false;
    if (!$token_ok || empty($health['database']['ok']) || empty($health['users'])) {
        $alive = false;
    }
    /* Reduced to what the markup tests, all of it saying "fine": anything
       that is not fine has already turned this into "not answering" above.
       (1.0.19: only the language was kept, and the page then read the
       missing database as one that will not open.) */
    $keep = ['lang' => (string) ($health['lang'] ?? 'cs'), 'database' => ['ok' => true],
             'users' => 1];
    /* 1.0.277: the ways of signing in are what a browser from anywhere needs to draw the
       page (they were dropped here, so Windows and a certificate were offered only to a
       browser on this machine, and "no password at all" left a remote one nothing to press).
       Only yes/no - the same /api/health says to anybody. */
    foreach (['kerberos', 'kerberos_auto', 'cert', 'cert_auto'] as $k) {
        if (is_array($health) && array_key_exists($k, $health)) $keep[$k] = !empty($health[$k]);
    }
    if (is_array($health) && array_key_exists('password', $health)) $keep['password'] = $health['password'] !== false;
    $health = $keep;
}
/* The certificate's port said why not (1.0.278): read once, from its cookie. */
$certsaid = '';
if (isset($_GET['certsaid']) && isset($_COOKIE['otp_certsaid'])) {
    $certsaid = substr((string) $_COOKIE['otp_certsaid'], 0, 300);
    setcookie('otp_certsaid', '', ['expires' => time() - 3600, 'path' => OTP_COOKIE_PATH,
                                   'secure' => true, 'httponly' => true, 'samesite' => 'Lax']);
}
$initial = $me ? (otp_get('/api/status', 8.0) ?: null) : null;
/* The sign-in's picture, when it is to be shown here too (1.0.71). */
$art_info = $me ? null : otp_get('/api/portal/info', 3.0);
$art_here = $me ? '' : otp_art_for(is_array($art_info) ? ($art_info['admin_art'] ?? null) : null, 'admin', 'otp');
$host    = (string) ($_SERVER['HTTP_HOST'] ?? php_uname('n'));
$site    = (string) ($initial['site'] ?? '');
$title   = $site !== '' ? $site . ' · OTP' : 'otp';
$lang    = otp_lang_pick($me, (string) ($health['lang'] ?? 'cs'));
// Listed is enough (1.0.265): the whole pack was read and decoded on every page drawn.
$load    = $lang !== 'en' && isset(otp_langs()[$lang]);
if ($me && ($_COOKIE['otp_lang'] ?? '') !== $lang) {
    setcookie('otp_lang', $lang, ['expires' => time() + 365 * 86400, 'path' => '/',
              'secure' => otp_https(), 'httponly' => false, 'samesite' => 'Strict']);
}
?>
<!doctype html>
<html lang="<?= h($lang) ?>" class="app-shell-root<?= $load ? ' i18n-wait' : '' ?>">
<head>
<?php otp_head($title, $lang, $load, $nonce, '/', $site !== '' ? $site : 'otp'); ?>
<link rel="stylesheet" nonce="<?= h($nonce) ?>" href="/assets/hload.css?v=<?= h(OTP_VERSION) ?>">
</head>
<body class="app-shell fold-words<?= $me ? ' framed' : '' ?>">
<div class="wrap">

<?php if (!$me): ?>
<div class="signin">
  <div class="signbox">
    <?= $art_here ?>
    <div class="card">
    <h1 data-no-i18n><?= h($title) ?></h1>
    <p class="lede">The one-time password server on <span data-no-i18n><?= h($host) ?></span>. Sign in to go on.</p>
    <?php if (!$token_ok && $token_there): ?>
      <div class="offline">
        The daemon is running, but this page may not read what it wrote.<br><br>
        <span class="mono"><?= h(OTP_TOKEN) ?></span> exists and is not readable by
        <span class="mono"><?= h($web_user) ?></span>, which is what this page runs as.
        On the server:<br>
        <span class="mono">usermod -a -G otp-web <?= h($web_user) ?></span><br>
        <span class="mono">systemctl restart php-fpm nginx</span>
      </div>
    <?php endif; ?>
    <?php if ($upg_run):
        $upg_pc = $upg['parts'] > 0 ? (int) round(100 * max(0, $upg['part'] - 1) / $upg['parts']) : 3; ?>
      <div class="upband-in" id="upband-in" data-alive="<?= $alive ? '1' : '' ?>">
        <b><?= $upg['downgrade'] ? 'otp is being taken back to' : 'otp is being upgraded to' ?> <span data-no-i18n><?= h($upg['version']) ?></span></b>
        <div class="up-bar"><span id="upband-in-bar" style="width:<?= $upg_pc ?>%"></span></div>
        <div class="small muted"><span id="upband-in-words"><?= h($upg['words']) ?></span><?php if ($upg['parts'] > 0): ?> · <span id="upband-in-step" data-no-i18n><?= h($upg['part'] . ' / ' . $upg['parts']) ?></span><?php endif; ?></div>
        <div class="small">otp.service and these pages restart once - this page loads again by itself when they are back.</div>
      </div>
    <?php elseif (is_array($upg) && $upg['state'] === 'failed'): ?>
      <div class="offline">The upgrade to otp <span data-no-i18n><?= h($upg['version']) ?></span> failed<?= $upg['said'] !== '' ? ': <span data-no-i18n>' . h($upg['said']) . '</span>' : '' ?></div>
    <?php endif; ?>
    <?php if ($token_ok || !$token_there): ?>
    <?php if ($upg_run): ?>
    <?php elseif (!$alive): ?>
      <div class="offline">The daemon is not answering. Nobody can sign in until
        <span class="mono">otp.service</span> is running:<br>
        <span class="mono">systemctl status otp</span> ·
        <span class="mono">journalctl -u otp -n 50</span></div>
    <?php elseif (empty($health['database']['ok'])): ?>
      <div class="offline">The daemon is running, but its database will not open. On the
        server: <span class="mono">otp --check</span> · <span class="mono">journalctl -u otp -n 50</span></div>
    <?php elseif (empty($health['users'])): ?>
      <div class="offline">There is no account on this machine yet. Make one on the server:<br>
        <span class="mono">otp --add-user yourname --role fulladmin</span></div>
    <?php endif; ?>
    <?php endif; ?>
    <div id="mfa-box" data-stage="<?= h($mfa) ?>" hidden></div>
    <?php $pw_off = is_array($health) && array_key_exists('password', $health) && $health['password'] === false
                    && (!empty($health['kerberos']) || !empty($health['cert'])); ?>
    <form id="signin-form" autocomplete="on"<?= ($mfa !== '' || $pw_off) ? ' hidden' : '' ?>>
      <input type="text" id="in-name" name="username" placeholder="name" autocomplete="username"
             autocapitalize="none" spellcheck="false" required>
      <input type="password" id="in-pass" name="password" placeholder="password"
             autocomplete="current-password" required>
      <button class="btn primary cmd" type="submit" id="in-go"><svg
        viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor"
        stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"
        ><path d="M10 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4"/><path d="M14 12h7"/><path
        d="M18 9l3 3-3 3"/></svg><span>Sign in</span></button>
      <div class="said" id="in-said"></div>
    </form>
    <?php if (!empty($health['kerberos']) || !empty($health['cert'])): ?>
    <div id="krb-box" class="krb-box"<?= $mfa !== '' ? ' hidden' : '' ?> data-certsaid="<?= h($certsaid) ?>"
         data-auto="<?= (!empty($health['kerberos_auto']) || ($pw_off && !empty($health['kerberos']))) ? '1' : '' ?>"
         data-cert-auto="<?= (!empty($health['cert_auto']) || ($pw_off && !empty($health['cert']) && empty($health['kerberos']))) ? '1' : '' ?>">
      <?php if ($pw_off): ?>
      <p class="muted small krb-only"><?= !empty($health['cert']) && empty($health['kerberos'])
        ? 'Signing in here is with a certificate only - no password.'
        : (!empty($health['cert']) ? 'Signing in here is with Windows or a certificate only - no password.'
        : 'Signing in here is with Windows only - no password.') ?></p>
      <?php else: ?>
      <div class="krb-or"><span>or</span></div>
      <?php endif; ?>
      <?php if (!empty($health['kerberos'])): ?>
      <button class="btn cmd" type="button" id="krb-go"><svg viewBox="0 0 24 24" width="17" height="17"
        fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"
        aria-hidden="true"><rect x="3" y="3" width="8" height="8"/><rect x="13" y="3" width="8" height="8"/><rect
        x="3" y="13" width="8" height="8"/><rect x="13" y="13" width="8" height="8"/></svg><span>Sign in with Windows</span></button>
      <?php endif; ?>
      <?php if (!empty($health['cert'])): ?>
      <button class="btn cmd" type="button" id="cert-go"><svg viewBox="0 0 24 24" width="17" height="17"
        fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"
        aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="12" r="2.2"/><path
        d="M14 10h4M14 14h3"/></svg><span>Sign in with a certificate</span></button>
      <?php endif; ?>
      <div class="said" id="krb-said"></div>
    </div>
    <?php endif; ?>
    <div style="margin-top:14px;display:flex;justify-content:space-between;align-items:center">
      <span class="muted small">otp <?= h(OTP_VERSION) ?></span>
      <span class="langpick" id="langpick"></span>
    </div>
    </div>
  </div>
</div>
</div>
<script nonce="<?= h($nonce) ?>" src="/assets/core.js?v=<?= h(OTP_VERSION) ?>"></script>
<script nonce="<?= h($nonce) ?>">
/* This node being upgraded (1.0.299): asked every 2 s how far it is; loaded again once the daemon
   answers after having been away, or the upgrade has ended. */
(function () {
  var box = document.getElementById('upband-in');
  if (!box) return;
  var down = box.getAttribute('data-alive') !== '1', gone = 0;
  function ask() {
    fetch('?api=upgrade-state', {credentials: 'same-origin', cache: 'no-store'}).then(function (r) { return r.json(); }).then(function (d) {
      gone = 0;
      var u = d && d.upgrading;
      if (u && u.state === 'running') {
        var w = document.getElementById('upband-in-words'), s = document.getElementById('upband-in-step'), b = document.getElementById('upband-in-bar');
        if (w && u.words) w.textContent = (typeof i18nText === 'function' && i18nText(u.words)) || u.words;
        if (s && u.parts) s.textContent = u.part + ' / ' + u.parts;
        if (b && u.parts) b.style.width = Math.round(100 * Math.max(0, u.part - 1) / u.parts) + '%';
      }
      if (!d.api) { down = true; return; }
      if (down || !u || u.state !== 'running') { location.reload(); return; }
    }).catch(function () { down = true; gone++; }).then(function () { setTimeout(ask, 2000); });
  }
  setTimeout(ask, 2000);
}());
(function () {
  var form = $('signin-form'), said = $('in-said'), go = $('in-go');
  /* The language, chosen before signing in - as on the enrolment pages (1.0.15). */
  var host = $('langpick');
  if (host && window.OTP_LANGS && window.OTP_LANGS.length > 1) {
    window.OTP_LANGS.forEach(function (l) {
      var b = el('button', l.code === window.OTP_LANG ? 'on' : '', l.code.toUpperCase());
      b.type = 'button';
      b.setAttribute('data-no-i18n', '');
      b.title = l.name;
      b.onclick = function () {
        document.cookie = 'otp_lang=' + encodeURIComponent(l.code) + '; path=/; max-age=31536000; '
          + 'samesite=strict' + (location.protocol === 'https:' ? '; secure' : '');
        location.reload();
      };
      host.appendChild(b);
    });
  }
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    said.className = 'said';
    said.textContent = '';
    go.disabled = true;
    var words = go.querySelector('span');
    words.textContent = 'Signing in…';
    api('login', {name: $('in-name').value, password: $('in-pass').value}).then(function (d) {
      if (d && d.mfa) { form.hidden = true; mfaStep(); return; }
      said.className = 'said good';
      said.textContent = 'Welcome back.';
      location.reload();
    }).catch(function (e) {
      said.className = 'said bad';
      said.textContent = String(e.message || e);
      go.disabled = false;
      words.textContent = 'Sign in';
      $('in-pass').value = '';
      $('in-pass').focus();
    });
  });
  /* Signing in with Windows - Kerberos (1.0.274): the browser hands its ticket on the 401 of
     ?api=kerberos-login. Never NTLM. The second step after it, when it is on, as after a
     password. Tried by itself only when so set, once per tab, and never after signing out. */
  var kb = $('krb-box');
  /* A certificate (1.0.275): a nonce in this browser's cookie, then the certificate's own port -
     the browser asks which certificate (and the card's PIN); the answer comes back here. */
  /* Tried once in a tab (1.0.277): after a refusal or Sign out it is not started by itself again. */
  function certGo() {
      var b = $('cert-go'), ksaid = $('krb-said');
      try { sessionStorage.setItem('otp.cert.tried', '1'); } catch (e) { }
      b.disabled = true; ksaid.className = 'said'; ksaid.textContent = '';
      b.querySelector('span').textContent = 'Asking for your certificate…';
      api('cert-nonce', {}).then(function (d) { location.href = d.url; }).catch(function (e) {
        b.disabled = false; b.querySelector('span').textContent = 'Sign in with a certificate';
        ksaid.className = 'said bad'; ksaid.textContent = String(e.message || e);
      });
  }
  if ($('cert-go')) $('cert-go').onclick = certGo;
  var certRefused = false;
  try {
    var cs = new URLSearchParams(location.search).get('certsaid') !== null && $('krb-box')
             ? ($('krb-box').getAttribute('data-certsaid') || '') : '';
    if (new URLSearchParams(location.search).get('certsaid') !== null && !cs) history.replaceState(null, '', location.pathname);
    if (cs) { certRefused = true; try { sessionStorage.setItem('otp.cert.tried', '1'); } catch (e) { } }
    if (cs && $('krb-said')) {
      $('krb-said').className = 'said bad';
      $('krb-said').textContent = cs;
      history.replaceState(null, '', location.pathname);
    }
  } catch (e) { }
  /* A browser with no Windows ticket (1.0.277) - outside the domain, or its window of name and password
     cancelled, or NTLM offered: remembered in it for 30 days, and Windows is not tried by itself there
     meanwhile; the button stays, and a sign-in with Windows forgets it. A computer in the domain signs in
     silently and is never marked. */
  var KRB_NONE = 'otp.krb.none', KRB_NONE_MS = 30 * 86400000;
  function krbNoneRecent() {
    try { var t = +localStorage.getItem(KRB_NONE) || 0; return t > 0 && Date.now() - t < KRB_NONE_MS; } catch (e) { return false; }
  }
  function krbNone(mark) {
    try { if (mark) localStorage.setItem(KRB_NONE, String(Date.now())); else localStorage.removeItem(KRB_NONE); } catch (e) { }
  }
  function krbTry(auto) {
    var kgo = $('krb-go'), ksaid = $('krb-said'), kw = kgo.querySelector('span');
    kgo.disabled = true; ksaid.className = 'said'; ksaid.textContent = '';
    kw.textContent = 'Signing in with Windows…';
    try { sessionStorage.setItem('otp.krb.tried', '1'); } catch (e) { }
    return api('kerberos-login', {}).then(function (d) {
      krbNone(false);
      if (d && d.mfa) { form.hidden = true; kb.hidden = true; mfaStep(); return; }
      ksaid.className = 'said good'; ksaid.textContent = 'Welcome back.';
      location.reload();
    }).catch(function (e) {
      kgo.disabled = false; kw.textContent = 'Sign in with Windows';
      var noTicket = !!(e && e.data && (e.data.code === 'no_ticket' || e.data.code === 'ntlm'
                        || (e.data.code === 'kerberos' && /NTLM/.test(String(e.message || e.data.error || '')))));
      if (auto && noTicket) {
        krbNone(true);
        /* No ticket at all - a computer outside the domain (1.0.277): the certificate, when it is tried by
           itself too; a refusal with a reason is said and nothing else starts. */
        if (certAuto) { certGo(); return; }
        if (!form.hidden) return;                                     /* not in the domain: the form only */
      }
      ksaid.className = 'said bad'; ksaid.textContent = String(e.message || e);
    });
  }
  if (kb && $('krb-go')) {
    $('krb-go').onclick = function () { krbTry(false); };
  }
  var krbAuto = false;
  try {
    krbAuto = !!(kb && $('krb-go') && !kb.hidden && kb.dataset.auto === '1' && !$('mfa-box').dataset.stage
                 && !sessionStorage.getItem('otp.krb.tried') && !sessionStorage.getItem('otp.krb.out') && !krbNoneRecent());
  } catch (e) { krbAuto = false; }
  var certAuto = false;
  try {
    certAuto = !!(kb && $('cert-go') && !kb.hidden && kb.dataset.certAuto === '1' && !$('mfa-box').dataset.stage
                  && !certRefused && !sessionStorage.getItem('otp.cert.tried') && !sessionStorage.getItem('otp.krb.out'));
  } catch (e) { certAuto = false; }
  /* Signed out because of the card (1.0.285): said once, by a word of this tab's own - never a text of
     the address - and nothing tried by itself (otp.krb.out), so the browser's certificate chooser does
     not open again on its own. */
  try {
    var cw = sessionStorage.getItem('otp.card.out');
    if (cw) {
      sessionStorage.removeItem('otp.card.out');
      var cws = $('krb-said') || $('in-said');
      if (cws) {
        cws.className = 'said bad';
        cws.textContent = cw === 'late' ? 'Signed out: the card you signed in with was not put back in time.'
          : cw === 'other' ? 'Signed out: another card than the one you signed in with was offered.'
          : 'Signed out: the card you signed in with was taken out.';
      }
    }
  } catch (e) { }
  if ($('mfa-box').dataset.stage) mfaStep();
  else if (krbAuto) krbTry(true);
  else if (certAuto) certGo();
  else if (!form.hidden) $('in-name').focus();
}());
</script>
</body>
</html>
<?php exit; endif; ?>

<header>
  <h1 data-no-i18n><?= h($site ?: 'otp') ?> <span class="host"><?= h($host) ?></span></h1>
  <span id="state-pill" class="pill unknown"><span class="dot"></span><span>…</span></span>
  <div class="hload" id="hload" hidden aria-live="off"></div>
  <div class="spacer"></div>
  <div class="btnrow">
    <button type="button" class="btn small mebtn" id="me-btn" data-icon="person"
            title="The account you are signed in as: what it may do, its password, the language of these pages, the columns of the tables and your settings in a file."><span class="me-name" data-no-i18n><?= h($me['name']) ?></span></button>
    <button class="btn small" id="signout" data-icon="out">Sign out</button>
  </div>
  <div class="updated" id="updated" title="Click to pause or resume the live updates">
    <b>live</b><br><span id="updated-at">…</span></div>
</header>

<div id="upband" class="upband" hidden aria-live="polite"></div>
<div id="offline" class="offline" hidden></div>
<div id="phpsafety" class="offline" hidden></div>
<div id="problems" class="offline warnish" hidden></div>
<div id="trials" class="trials" hidden></div>

<div class="tabs" role="tablist">
  <button role="tab" aria-selected="true" data-tab="overview" data-icon="chart"
          title="The shape of the day: who was let in, who was refused and why, which clients asked.">Overview</button>
  <button role="tab" aria-selected="false" data-tab="tokens" data-icon="token"
          title="Everybody who has a token: when it was made, when it was last used, how many recovery codes are left. Click a row to look after one.">Tokens<span class="count" id="tabn-tokens"></span></button>
  <button role="tab" aria-selected="false" data-tab="requests" data-icon="list"
          title="Every RADIUS request with what the token said about its code, and every code checked anywhere else - the enrolment pages, a test. Click a row for every attribute and every step of the decision.">Log<span class="count" id="tabn-requests"></span></button>
  <button role="tab" aria-selected="false" data-tab="test" data-icon="play" class="token-admin"
          title="Ask this server the way the VPN does, and see every step of the answer - what radtest does, from here.">Test</button>
  <button role="tab" aria-selected="false" data-tab="enrolment" data-icon="people"
          title="Who came to the enrolment pages and what they did there: signed in, made a token, confirmed it, replaced it - or was turned away.">Enrolment</button>
  <button role="tab" aria-selected="false" data-tab="events" data-icon="history"
          title="Every token made or taken away, every change of a setting, every sign-in - and the daemon’s own log.">Events</button>
  <button role="tab" aria-selected="false" data-tab="settings" data-icon="gear"
          title="The RADIUS server, its clients, the realms, Active Directory, the tokens, the enrolment pages, isemon, the accounts and the database.">Settings<span class="count after-n" id="tabn-settings"></span></button>
</div>

<!-- ===================== Overview ===================== -->
<section class="panel" id="tab-overview">
  <div class="grid top">
    <div class="card metric ok" id="card-accept"><div class="label">Let in, last 24 h</div>
      <div class="value" id="m-accept">–</div><div class="sub" id="m-accept-sub">&nbsp;</div></div>
    <div class="card metric crit" id="card-reject"><div class="label">Refused, last 24 h</div>
      <div class="value" id="m-reject">–</div><div class="sub" id="m-reject-sub">&nbsp;</div></div>
    <div class="card metric info" id="card-tokens"><div class="label">Tokens</div>
      <div class="value" id="m-tokens">–</div><div class="sub" id="m-tokens-sub">&nbsp;</div></div>
    <div class="card metric warn" id="card-isemon"><div class="label">isemon</div>
      <div class="value" id="m-isemon">–</div><div class="sub" id="m-isemon-sub">&nbsp;</div></div>
  </div>
  <div class="grid top" style="margin-top:14px">
    <div class="card metric ok" id="card-server"><div class="label">This server</div>
      <div class="value" id="m-server">–</div><div class="sub" id="m-server-sub">&nbsp;</div></div>
    <div class="card metric info" id="card-cluster"><div class="label">High availability</div>
      <div class="value" id="m-cluster">–</div><div class="sub" id="m-cluster-sub">&nbsp;</div></div>
    <div class="card metric info" id="card-db"><div class="label">The database</div>
      <div class="value" id="m-db">–</div><div class="sub" id="m-db-sub">&nbsp;</div></div>
    <div class="card metric ok" id="card-maint"><div class="label">Maintenance and upgrades</div>
      <div class="value" id="m-maint">–</div><div class="sub" id="m-maint-sub">&nbsp;</div></div>
  </div>
  <div class="card full" style="margin-top:14px">
    <h2>Requests
      <span class="right">
        <select id="ov-hours" title="How far back the chart and the cards under it look.">
          <option value="6">last 6 hours</option>
          <option value="24" selected>last 24 hours</option>
          <option value="72">last 3 days</option>
          <option value="168">last week</option>
          <option value="720">last month</option>
        </select>
      </span></h2>
    <p class="note">Every Access-Request, as one line of time: green let in, red refused or not
      answered. Press a bar to open that hour.</p>
    <div class="chart" id="ov-chart"><div class="empty">…</div><div class="tip"></div></div>
    <div class="legend">
      <span><i style="background:#3fb950"></i>let in</span>
      <span><i style="background:#f85149"></i>refused</span>
    </div>
  </div>
  <div class="grid halves" style="margin-top:14px">
    <div class="card facet"><h2>Refused the most</h2><div id="ov-names"></div></div>
    <div class="card facet"><h2>Why they were refused</h2><div id="ov-reasons"></div></div>
    <div class="card facet"><h2>Who asks</h2><div id="ov-clients"></div></div>
    <div class="card facet"><h2>From where</h2><div id="ov-places"></div></div>
  </div>
</section>

<!-- ===================== Tokens ===================== -->
<section class="panel" id="tab-tokens" hidden>
  <div class="card full" data-hold>
    <h2>Tokens <span class="right" id="tk-said"></span></h2>
    <p class="note">Everybody who has a token. Click a row to switch one off, give new recovery
      codes, test a code or take it away. A token is made by its owner on the enrolment pages,
      or here.</p>
    <div class="filterbar btnrow filters">
      <input type="search" id="tk-q" placeholder="a name, a note, a mail address, a phone number…" style="flex:1;min-width:200px">
      <select id="tk-state">
        <option value="">every state</option>
        <option value="active">in use</option>
        <option value="pending">waiting for a code</option>
        <option value="disabled">switched off</option>
      </select>
      <select id="tk-kind">
        <option value="">every kind</option>
        <option value="totp">the app</option>
        <option value="mail">codes by e-mail</option>
        <option value="sms">codes by SMS</option>
      </select>
      <select id="tk-per"><option>50</option><option selected>100</option><option>500</option></select>
      <button class="btn cmd token-admin" id="tk-names" data-icon="person"
              title="Every token without its owner's name is given it from the directory of its realm - as an enrolment on the enrolment pages does. Tokens brought over from totpcgi get theirs by themselves, in the background, after the import and every hour.">Names from the directory</button>
      <button class="btn cmd primary token-admin" id="tk-add" data-icon="add"
              title="Make a token for somebody and show its QR code here, to scan off this screen or to hand over.">Make a token</button>
    </div>
    <div id="tk-table" class="scroll rowsonly"></div>
    <div class="pager" id="tk-pager"></div>
  </div>
</section>

<!-- ===================== The log ===================== -->
<section class="panel" id="tab-requests" hidden>
  <div class="card full" data-hold>
    <h2>The log <span class="right" id="rq-said"></span></h2>
    <p class="note">One log of everything: every RADIUS request this server was asked, with what
      the token said about its code, and every code checked anywhere else - on the enrolment
      pages, in a test, on the command line. Newest first. Click a row for every attribute that
      came, the answer, and each step of the decision. Old lines go by themselves after the days
      under Settings - The database, which is also where they can be cleared.</p>
    <div class="btnrow filters">
      <input type="search" id="rq-q" placeholder="a name, an address, a reason…" style="flex:1;min-width:200px">
      <select id="rq-kind">
        <option value="">RADIUS and codes</option><option value="radius">RADIUS requests only</option>
        <option value="codes">codes outside RADIUS only</option>
      </select>
      <select id="rq-hours">
        <option value="1">last hour</option><option value="24" selected>last 24 hours</option>
        <option value="168">last week</option><option value="720">last month</option>
        <option value="8760">last year</option>
      </select>
      <select id="rq-result">
        <option value="">everything</option><option value="access">sign-ins only</option>
        <option value="accept">let in / right</option><option value="reject">refused / wrong</option>
        <option value="drop">not answered</option><option value="acct">accounting</option>
      </select>
      <select id="rq-client"><option value="">every client</option></select>
      <select id="rq-per"><option>50</option><option selected>100</option><option>500</option></select>
    </div>
    <div id="rq-table" class="scroll rowsonly"></div>
    <div class="pager" id="rq-pager"></div>
  </div>
</section>

<!-- ===================== Test ===================== -->
<section class="panel" id="tab-test" hidden>
  <div class="grid halves">
    <div class="card">
      <h2>Ask it as the VPN does</h2>
      <p class="note">What <span class="mono">radtest falco 135830 otp.example.local 1812
        testing123</span> asks, sent from this machine to this server as a real RADIUS packet,
        with the shared secret of the client for 127.0.0.1. A right code is used up by it, as
        it would be by the VPN.</p>
      <div class="formgrid">
        <div class="set-item"><label>Name</label><input type="text" id="rt-user" autocomplete="off" spellcheck="false"></div>
        <div class="set-item"><label>Password</label><input type="password" id="rt-pass" autocomplete="new-password" spellcheck="false" class="mono"></div>
        <div class="set-item"><label>How</label>
          <select id="rt-how">
            <option value="udp">a RADIUS packet to 127.0.0.1</option>
            <option value="direct">straight into the decision, as from a client</option>
          </select></div>
        <div class="set-item" id="rt-client-item" hidden><label>As the client</label><select id="rt-client"></select></div>
        <div class="set-item" id="rt-node-item" hidden><label>On the node</label><select id="rt-node"></select></div>
      </div>
      <div class="btnrow" style="margin-top:14px">
        <button class="btn cmd primary" id="rt-go" data-icon="play">Ask</button>
      </div>
      <p class="muted small" style="margin-top:10px">From the server itself, the same:
        <span class="mono">otp --radtest NAME CODE</span>, and with FreeRADIUS's own client:
        <span class="mono">radtest NAME CODE 127.0.0.1 0 SECRET</span>.</p>
    </div>
    <div class="card"><h2>The answer</h2><div id="rt-out"><p class="muted">Nothing asked yet.</p></div></div>
  </div>
</section>

<!-- ===================== Events ===================== -->
<section class="panel" id="tab-enrolment" hidden>
  <div class="card full" data-hold>
    <h2>Who enrolled <span class="right" id="en-said"></span></h2>
    <p class="note">Everything that happened on the enrolment pages, person by person: who
      signed in, who made a token, who confirmed it with a code, who replaced an old one - and
      who was turned away, and why. Click a row to open the person's token.</p>
    <div class="facts" id="en-tiles"></div>
    <div class="btnrow filters">
      <input type="search" id="en-q" placeholder="a name, an address…" style="flex:1;min-width:200px">
      <select id="en-step">
        <option value="">every step</option>
        <option value="signed_in">signed in</option>
        <option value="enrolled">made a token</option>
        <option value="confirmed">confirmed it</option>
        <option value="replacing">replaced it</option>
        <option value="stopped">stopped replacing</option>
        <option value="refused">could not sign in</option>
        <option value="not_allowed">may not enrol</option>
      </select>
      <select id="en-since">
        <option value="86400">last 24 hours</option><option value="604800" selected>last week</option>
        <option value="2592000">last month</option><option value="0">all time</option>
      </select>
    </div>
    <div id="en-table" class="scroll rowsonly"></div>
    <div class="pager" id="en-pager"></div>
  </div>
</section>

<section class="panel" id="tab-events" hidden>
  <div class="card full" data-hold>
    <h2>What this daemon has done</h2>
    <p class="note">Every token made, replaced or taken away, every change of a setting, every
      sign-in. Kept in the database, so it survives a restart.</p>
    <div class="btnrow filters">
      <input type="search" id="ev-q" placeholder="anything in an event…" style="flex:1;min-width:200px">
      <select id="ev-kind"><option value="">everything</option></select>
      <span id="ev-time" title="How far back the events go."></span>
    </div>
    <div id="ev-table" class="scroll rowsonly"></div>
    <div class="pager" id="ev-pager"></div>
  </div>
  <div class="card full fulladmin-only aside">
    <h2>The daemon's own log</h2>
    <p class="note">The tail of <span class="mono">/var/log/otp/otp.log</span>. Switch on
      <i>debug</i> in Settings → About to have it say every step of every request.</p>
    <div class="btnrow"><button class="btn cmd" id="log-read" data-icon="log">Read it</button>
      <select id="log-lines"><option>200</option><option selected>600</option><option>2000</option></select></div>
    <pre class="lines" id="log-out" style="margin-top:12px" hidden></pre>
  </div>
</section>

<!-- ===================== Settings ===================== -->
<section class="panel" id="tab-settings" hidden>
<div class="ctl-layout">
  <nav class="ctl-nav" id="ctl-nav" aria-label="Settings sections">
    <div class="ctl-navtop">
      <button type="button" class="ctl-pin" id="ctl-pin" aria-pressed="false" aria-label="Keep this menu open"></button>
      <div class="ctl-find-wrap">
        <input type="search" id="ctl-find" placeholder="Find a setting…" autocomplete="off" aria-label="Find a setting">
        <div class="ctl-found" id="ctl-found" hidden></div>
      </div>
    </div>
    <div class="ctl-group">RADIUS</div>
    <button type="button" data-pane="radius" data-icon="router" title="Where the RADIUS server listens, what it answers and how.">The RADIUS server</button>
    <button type="button" data-pane="guard" data-icon="shield" title="Somebody guessing codes or names from one place: counted, and blocked for a while; changes of the network and the firewall that go back by themselves unless kept.">Sign-in protection</button>
    <button type="button" data-pane="clients" data-icon="net" title="The VPN concentrators and anything else that may ask: their addresses, their shared secrets, the realm added to their names.">Clients</button>
    <button type="button" data-pane="realms" data-icon="globe" title="What a name after its @ means: which directory it is looked up in, which groups let it in, what the password is and what goes back in the answer.">Realms</button>
    <button type="button" data-pane="dir" data-icon="key" title="The Active Directory servers the realms and the sign-ins ask: how they are reached, as whom, and a check that says which step failed.">Active Directory</button>
    <div class="ctl-group">Tokens</div>
    <button type="button" data-pane="tokens" data-icon="token" title="How long a code is, how long it lasts, how much clock drift is forgiven, how many wrong codes before a pause, recovery codes.">The tokens</button>
    <button type="button" data-pane="codes" data-icon="phone" title="Codes sent after the password, by e-mail or SMS: how long they last, how many, and the SMS gateway.">Codes by e-mail and SMS</button>
    <button type="button" data-pane="texts" data-icon="edit" title="Every word people get from this server - the mails, the SMS, what the VPN asks - in Czech and in English, edited as they will look.">Message texts</button>
    <button type="button" data-pane="portal" data-icon="people" title="The pages where people enrol their own token: who may, what they see, what they have to prove.">The enrolment pages</button>
    <button type="button" data-pane="import" data-icon="upload" title="Bring the tokens of a totpcgi server over: its .totp files, read here, nobody has to enrol again.">Bringing tokens over</button>
    <div class="ctl-group">Mail</div>
    <button type="button" data-pane="mail" data-icon="mail" title="How a token's QR code reaches its owner by mail: a mail server, or straight to theirs.">Mail</button>
    <button type="button" data-pane="mailq" data-icon="list" title="Every mail sent - a token's QR code, a code to sign in with - and what became of it: sent, waiting for another try (greylisting, a server away), failed. Sent again or taken away by hand.">Outgoing mail <span class="nav-badge" id="mq-badge" hidden></span></button>
    <div class="ctl-group">Access</div>
    <button type="button" data-pane="people" data-icon="person" title="Who may open these pages, what each of them may do, and who is signed in right now.">Accounts</button>
    <button type="button" class="fulladmin-only" data-pane="hisec" data-icon="shield" title="Every way of doing something less safely switched off - and what stands against it now.">High security</button>
    <button type="button" class="fulladmin-only" data-pane="selinux" data-icon="shield" title="What SELinux refuses on each node, what otp needs of it, what is put right here - and the steps to enforcing.">SELinux</button>
    <button type="button" data-pane="web" data-icon="lock" title="The certificates of the nodes and of the cluster's VIP address, and how TLS is spoken.">Certificates and TLS</button>
    <button type="button" class="fulladmin-only" data-pane="acme" data-icon="lock" title="The certificates ordered from Let's Encrypt (or another ACME CA) and renewed by themselves.">Automatic certificates</button>
    <button type="button" data-pane="fw" data-icon="wall" title="Who may reach the enrolment pages, the administration and the health check; and the machine's firewall (iptables, IPv4 and IPv6) - what otp's functions need opens by itself.">Firewall and access</button>
    <button type="button" class="fulladmin-only" data-pane="sshd" data-icon="shield" title="How the SSH server lets people in - root, passwords, the port - and the notice shown before and after signing in.">SSH server and notices</button>
    <button type="button" class="fulladmin-only" data-pane="sshkeys" data-icon="key" title="The keys that may sign in to each node over SSH - as root or as a user who may sign in there: made here, added or taken away.">SSH keys</button>
    <button type="button" class="fulladmin-only" data-pane="osusers" data-icon="people" title="The users of each node's own system: root shown, the others made, given a password or sudo, locked or taken away - on every node or on one.">Local users</button>
    <div class="ctl-group">Server</div>
    <button type="button" class="fulladmin-only" data-pane="network" data-icon="net" title="Each node's address, gateway, DNS servers, host name and IPv6 - put in by the node itself, a cluster kept whole.">Network</button>
    <button type="button" class="fulladmin-only" data-pane="proxy" data-icon="globe" title="An HTTP proxy, for what you switch on: the new versions, the system updates, ACME, the SMS gateway.">Proxy</button>
    <button type="button" class="fulladmin-only" data-pane="time" data-icon="clock" title="The clock of each node: chrony, its time servers, how far off it is - codes from the app are worked out from it.">Time</button>
    <button type="button" data-pane="ha" data-icon="ethernet" title="Two servers, both answering: the nodes, and the wizard that makes the second one.">High availability</button>
    <button type="button" class="fulladmin-only" data-pane="power" data-icon="power" title="Restart or switch off this node, the other, or both - the VIP address moved out of the way first.">Restart and power off</button>
    <button type="button" class="fulladmin-only" data-pane="logs" data-icon="chart" title="Each node's disks, and how much the system journal and otp's own logs may take.">Disks and logs</button>
    <div class="ctl-group">Data</div>
    <button type="button" data-pane="db" data-icon="db" title="Which database everything lives in, how big it is, copies of it, and how long things are kept.">The database</button>
    <button type="button" data-pane="backup" data-icon="archive" title="Backups of everything to another machine - FTP, FTPS, SFTP, SCP, SMB or a folder - locked with a password, on a schedule, and putting one back.">Backups</button>
    <button type="button" data-pane="carry" data-icon="download" title="Everything that makes this installation what it is, as one file to carry to another machine.">Export and import</button>
    <div class="ctl-group">Monitoring and updates</div>
    <button type="button" class="fulladmin-only" data-pane="alerts" data-icon="bell" title="A mail when something is wrong, and a report of the week by mail.">Alerts and reports</button>
    <button type="button" class="fulladmin-only" data-pane="monitor" data-icon="pulse" title="Prometheus asks each node for its metrics.">Monitoring</button>
    <button type="button" data-pane="isemon" data-icon="pulse" title="Sending every check of a code and every RADIUS packet to isemon, in the shape isemon already reads.">isemon</button>
    <button type="button" class="fulladmin-only" data-pane="siem" data-icon="log" title="Every event and every sign-in to a syslog server or a SIEM - UDP, TCP or TLS; JSON, CEF or RFC 5424.">Syslog and SIEM</button>
    <button type="button" class="fulladmin-only" data-pane="osup" data-icon="download" title="The operating system's packages updated, one node at a time, the VIP address moved out of the way first; a restart offered when one is needed.">System updates</button>
    <button type="button" class="fulladmin-only" data-pane="upgrade" data-icon="up" title="A new version, put in from here; nodes in and out of service.">Upgrades<b class="count rail-n" id="after-badge"></b></button>
    <button type="button" data-pane="about" data-icon="info" title="Version, what is running, the language, the debug log.">About</button>
  </nav>

  <div class="ctl-main">
  <div class="card full" id="readonly-note" hidden>
    <h2>You may look, but not change</h2>
    <p class="note" style="margin:0">This account may not change the settings. A full administrator can change that under <i>Accounts</i>.</p>
  </div>

  <div class="ctl-pane" id="pane-radius">
    <div class="ctl-head"><h2 class="ctl-title">The RADIUS server</h2>
      <p class="ctl-lede">otp answers RADIUS itself - no FreeRADIUS - on the ports below. A request
        from an address that is not one of the clients is never answered.</p></div>
    <div class="card full"><div id="sect-radius"></div></div>
  </div>

  <div class="ctl-pane" id="pane-guard" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Sign-in protection</h2>
      <p class="ctl-lede">Guessing from one place held back - wrong passwords, wrong codes,
        names nobody has.</p></div>
    <div class="card full"><div id="sect-guard"></div></div>
    <div class="card full fulladmin-only" id="dp-card"><h2>Wrong directory passwords - each directory</h2>
      <p class="note">Each directory with a cap of its own, or as the setting above. <b>Read the
        domain's policy</b> asks the domain itself - through the directory's own connection - how it
        locks accounts and what it asks of passwords, and recommends a cap below its lockout. Nothing
        changes until <b>Save the changes</b> below.</p>
      <div id="dp-list"></div></div>
    <div class="card full fulladmin-only" id="gd-card"><h2>Counted and blocked now <span class="right" id="gd-tools"></span></h2>
      <p class="note">The places the VPN's requests come from with refusals still counted, and the
        tokens locked by wrong codes - how close each is to its limit, and how long a block still
        runs. Type a name or an address to see only those; Clear lets them in again at once.</p>
      <div class="btnrow" style="margin-bottom:10px"><input type="search" id="gd-find" class="mono" placeholder="a name or an address" autocomplete="off" style="max-width:320px"></div>
      <div id="gd-table"></div></div>
  </div>

  <div class="ctl-pane" id="pane-clients" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Clients</h2>
      <p class="ctl-lede">Everything that may ask: a VPN concentrator, a load balancer, this machine
        for testing. A client is an address or a range, a shared secret, and - where its names
        come without one - the realm added to them, which is what FreeRADIUS's hints file did.</p></div>
    <div class="card full">
      <div class="btnrow" style="margin-bottom:12px"><button class="btn cmd primary admin-only" id="cl-add" data-icon="add">Add a client</button></div>
      <div id="cl-table"></div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-realms" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Realms</h2>
      <p class="ctl-lede">A realm is what comes after the @. It says where the person is looked up,
        which groups let them in, whether the password is the code alone or their directory
        password followed by it, and what goes back to the VPN - a Class, a group policy - for
        everybody, or for the members of one group.</p></div>
    <div class="card full">
      <div class="btnrow" style="margin-bottom:12px"><button class="btn cmd primary admin-only" id="rl-add" data-icon="add">Add a realm</button></div>
      <div id="rl-table"></div>
    </div>
    <div class="card full"><div id="sect-realms"></div></div>
  </div>

  <div class="ctl-pane" id="pane-dir" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Active Directory</h2>
      <p class="ctl-lede">The directories the realms look people up in and the enrolment pages sign
        people in against. Read only: nothing is ever written to a directory, and the reading
        account needs no right beyond reading.</p></div>
    <div class="card full">
      <div class="btnrow" style="margin-bottom:12px"><button class="btn cmd primary admin-only" id="ad-add" data-icon="add">Add a directory</button></div>
      <div id="ad-table"></div>
    </div>
    <div class="card full" id="ca-card" hidden>
      <h2>The certificate authority <span class="right muted small" id="ca-when"></span></h2>
      <p class="note">Needed only when the directory is reached over TLS (LDAPS or StartTLS) and the domain controllers' certificates were signed by your own authority. Several can be kept for one directory - a chain for each domain or authority its controllers come from: paste one (or a whole chain), or read it from the .crt / .pem / .cer file, and press Save the changes below. Each is listed and can be taken out by itself.</p>
      <div id="ca-pick"></div>
      <div id="ca-state"></div>
      <textarea id="ca-pem" rows="6" class="mono admin-only" style="width:100%;margin-top:10px"
                placeholder="-----BEGIN CERTIFICATE-----&#10;MIID...&#10;-----END CERTIFICATE-----"></textarea>
      <div class="btnrow admin-only" style="margin-top:10px">
        <button class="btn cmd primary" id="ca-save" data-icon="save"
                title="Read the certificate and keep it. It is checked for being a certificate at all before it is stored, and what it is gets shown above.">Add it</button>
        <button class="btn cmd" id="ca-file" data-icon="upload"
                title="Pick a .crt or .pem file instead of pasting it.">Read a file…</button>
        <button class="btn cmd danger" id="ca-drop" data-icon="trash"
                title="Take every certificate kept for this directory away. The domain controllers' certificates then have to be signed by one this machine already trusts.">Take them all away</button>
        <input type="file" id="ca-input" accept=".pem,.crt,.cer,.txt" hidden>
      </div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-tokens" hidden>
    <div class="ctl-head"><h2 class="ctl-title">The tokens</h2>
      <p class="ctl-lede">How codes are made and checked. A token keeps what it was made with:
        a change here is for the tokens made after it.</p></div>
    <div class="card full"><div id="sect-tokens"></div></div>
  </div>

  <div class="ctl-pane" id="pane-portal" hidden>
    <div class="ctl-head"><h2 class="ctl-title">The enrolment pages</h2>
      <p class="ctl-lede">Where people make their own token: <span class="mono" id="portal-url">/</span>
        on this server. They sign in with their directory password, scan the QR code, keep the
        recovery codes and prove it worked with a code.</p></div>
    <template id="art-gallery"><?php foreach (OTP_ARTS as $a): ?><div data-art="<?= h($a) ?>" data-words="<?= h(OTP_ART_WORDS[$a]) ?>"><?= otp_art_svg($a) ?></div><?php endforeach; ?></template>
    <div class="card full" id="art-card">
      <h2>The picture on the sign-in</h2>
      <div class="seg" id="art-slot" style="margin:4px 0 10px">
        <button type="button" data-slot="portal">The enrolment pages</button>
        <button type="button" data-slot="admin">The administration</button>
      </div>
      <p class="note" id="art-note-portal">Shown above the sign-in of the enrolment pages, where people make their token.</p>
      <p class="note" id="art-note-admin" hidden>Shown above the sign-in of these administration pages.</p>
      <p class="note small muted">Pick one of these, or a picture of your own (a logo: PNG, JPEG,
        GIF, WebP or SVG, at most 512 KB) - each sign-in its own. It is kept in the database: both
        nodes of a cluster show the same one, and it is in every backup and in the exported
        configuration. A picture of your own stays kept when you pick another one.</p>
      <div class="art-grid" id="art-grid"></div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd small fulladmin-only" id="art-upload" data-icon="upload">Upload a picture of your own</button>
        <button class="btn cmd small fulladmin-only" id="art-reset" data-icon="undo">Back to the default</button>
        <button class="btn cmd small fulladmin-only" id="art-forget" data-icon="trash" hidden>Take my own picture away</button>
      </div>
      <input type="file" id="art-file" accept="image/png,image/jpeg,image/gif,image/webp,image/svg+xml,.svg" hidden>
      <p class="note small" id="art-said"></p>
    </div>
    <div class="card full"><div id="sect-portal"></div></div>
    <div class="card full" id="sso-card">
      <h2>Signed in by a load balancer or WAF (SSO)</h2>
      <p class="note">The enrolment pages published through a NetScaler, an F5 or another
        balancer that signs people in against the directory first: they then come in signed in,
        without a second password. Off, the pages are as until now.</p>
      <div id="sect-portalsso"></div>
      <div id="sso-host"></div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-import" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Bringing tokens over</h2>
      <p class="ctl-lede">A backup of every token - of every kind: the app, codes by e-mail, codes by SMS - and its restore, all of them or the ones picked; and the files of a totpcgi server (<code>/etc/totpcgi/totp/novak@example.cz.totp</code>), read so that everybody keeps the token they have: the same key, the same recovery codes, the same clock drift.</p></div>
    <div class="card full fulladmin-only">
      <h2>Restoring, or bringing over</h2>
      <p class="note">A backup made below (<code>otp-tokens-….json</code>, locked with a passphrase or not): you see what is in it and pick what is restored. Or the <code>.totp</code> files of totpcgi, or a ZIP of them. The whole old server at once - its clients, the realm its hints file added, the directory and the groups of its handler, its settings and every token - is one command on this machine: <code>otp --import-legacy /path/to/old/root</code>.</p>
      <div class="drop" id="imp-drop"><span>Drop a backup (.json), the .totp files or a ZIP of them here - or press to pick them</span></div>
      <input type="file" id="imp-files" multiple accept=".totp,.zip,.json" hidden>
      <div class="btnrow" style="margin-top:12px">
        <label class="check small" style="margin-top:10px"><input type="checkbox" id="imp-replace"><span>replace a token that is here already</span></label>
      </div>
      <div id="imp-out" style="margin-top:12px"></div>
    </div>
    <div class="card full fulladmin-only">
      <h2>Backing up, or taking tokens away</h2>
      <p class="note">A whole backup holds every token chosen as it is: its key, its recovery codes,
        how its codes come and where to, its language and its state - read back here or on another
        otp, whose own sealing key it does not need. Lock it with a passphrase: every key in it
        signs its owner in. Or the tokens of the app as .totp files in a ZIP, for totpcgi. Needs
        <i>Settings → Tokens → Administrators may show a token's QR code and key</i>; every
        backup is written down in the events.</p>
      <div class="btnrow filters">
        <input type="search" id="exp-q" placeholder="which ones - empty: all (realm:example.cz, name:novak*, kind:mail…)" style="flex:1;min-width:280px">
        <select id="exp-state">
          <option value="">every state</option><option value="active">in use</option>
          <option value="pending">waiting for a code</option><option value="disabled">switched off</option>
        </select>
        <select id="exp-kind">
          <option value="">every kind</option><option value="totp">the app</option>
          <option value="mail">codes by e-mail</option><option value="sms">codes by SMS</option>
        </select>
      </div>
      <div class="btnrow filters" style="margin-top:10px">
        <select id="exp-format">
          <option value="backup">a whole backup (.json) - every kind</option>
          <option value="totp">.totp files in a ZIP - the app's tokens, for totpcgi</option>
        </select>
        <select id="exp-lock" title="Locked: the passphrase opens it - a ZIP with 7-Zip, WinRAR or PeaZip (AES-256), a backup with otp. Not locked: whoever has the file can sign in as any of the tokens in it.">
          <option value="lock">locked with a passphrase</option>
          <option value="open">not locked</option>
        </select>
        <input type="password" id="exp-pass" autocomplete="new-password" placeholder="a passphrase to lock it with (8 characters at least)" style="flex:1;min-width:260px">
        <button class="btn cmd" id="exp-gen" data-icon="key" title="Make one up - it is shown once, keep it">Make one up</button>
        <button class="btn cmd primary" id="exp-go" data-icon="download">Download</button>
      </div>
      <div id="exp-said" class="small" style="margin-top:8px"></div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-alerts" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Alerts and reports</h2>
      <p class="ctl-lede">A mail when something is wrong - a node or the replication, a backup, a certificate,
        a disk, the clock, the directory, the SMS gateway - and again when it is over; and a report of the
        week (or the day, or the month) with the sign-ins, who was refused and why, and everything else.
        One node of a cluster looks at both and sends them. Both are off until switched on below.</p></div>
    <div id="al-host"></div>
    <div class="card full"><h2>Settings</h2><div id="sect-alerts"></div></div>
    <div id="al-log"></div>
  </div>
  <div class="ctl-pane" id="pane-hisec" hidden>
    <div class="ctl-head"><h2 class="ctl-title">High security</h2>
      <p class="ctl-lede">Every way of doing something less safely switched off, on every node: plain LDAP,
        unencrypted mail, syslog and backups, certificates not checked, weak TLS, SSH with passwords, the
        administration open to everybody, exports not locked. It is switched on only once nothing below stands
        against it; while it is on, all of that is refused wherever it is changed and greyed out on the pages.</p></div>
    <div id="hs-host"></div>
    <div class="card full"><h2>Settings</h2><div id="sect-hisec"></div></div>
  </div>
  <div class="ctl-pane" id="pane-selinux" hidden>
    <div class="ctl-head"><h2 class="ctl-title">SELinux</h2>
      <p class="ctl-lede">What SELinux refuses on each node when it is enforcing, and what otp needs of it: its own
        module (otp_server), the labels of its files, the booleans that let the pages ask the daemon and SSH ask
        for the code, the ports of sshd and PostgreSQL. Looked at every half hour; what is put right and the
        steps - made ready and permissive, enforcing, permissive again - are done by each node's root only when
        asked here or with <span class="mono">sudo otp --selinux</span>.</p></div>
    <div id="se-host"></div>
  </div>
  <div class="ctl-pane" id="pane-acme" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Automatic certificates</h2>
      <p class="ctl-lede">The certificate of the VIP address - and, where asked, each node's own - ordered from Let's
        Encrypt or another ACME CA and renewed by itself well before it runs out. The CA checks the name by asking
        it on port 80 (HTTP-01), or by a record in DNS (DNS-01) for servers it cannot see from the internet. In a
        cluster the answer is kept in the database, so whichever node has the VIP address gives it.</p></div>
    <div id="ac-host"></div>
    <div class="card full"><h2>Settings</h2><div id="sect-acme"></div></div>
  </div>
  <div class="ctl-pane" id="pane-siem" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Syslog and SIEM</h2>
      <p class="ctl-lede">Every event and every sign-in - who, from where, let in or refused and why - to a
        syslog server or a SIEM (Graylog, Splunk, Elastic, Wazuh, QRadar, Sentinel), as RFC 5424 syslog over
        UDP, TCP or TLS. Each node sends its own, as it happens, from a thread of its own: a sign-in never
        waits for it. Off until switched on.</p></div>
    <div id="si-host"></div>
    <div class="card full"><h2>Settings</h2><div id="sect-siem"></div></div>
  </div>
  <div class="ctl-pane" id="pane-monitor" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Monitoring</h2>
      <p class="ctl-lede">Prometheus asks each node for its metrics at <code>https://NODE/metrics</code>:
        RADIUS, the tokens, the database, the cluster and its replication, the certificates, the mail,
        isemon and syslog, the alerts open now. And SNMPv3: each node answers it itself, and sends traps when
        something is wrong.</p></div>
    <div class="card full"><h2>Settings</h2><div id="sect-monitor"></div></div>
    <div id="snmp-host"></div>
    <div id="mon-host"></div>
  </div>
  <div class="ctl-pane" id="pane-proxy" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Proxy</h2>
      <p class="ctl-lede">Where the servers may reach the web only through an HTTP proxy - on every node. Off
        by default, and switched on it is used only for what is switched on below: the new versions of otp, the
        system updates, ACME and its DNS APIs, the SMS gateway; all of them off, nowhere. RADIUS, mail, Active
        Directory, the database, syslog, isemon, the backups, the other node and the VIP address's check never go
        through it.</p></div>
    <div class="card full"><h2>Settings</h2><div id="sect-proxy"></div></div>
    <div id="px-host"></div>
  </div>
  <div class="ctl-pane" id="pane-logs" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Disks and logs</h2>
      <p class="ctl-lede">How full each node's disks are, and how much the system journal and otp's own logs
        may take - put in on every node by the node itself, again whenever it is changed here.</p></div>
    <div id="lg-host"></div>
    <div class="card full"><h2>Settings</h2><div id="sect-logs"></div></div>
  </div>
  <div class="ctl-pane" id="pane-isemon" hidden>
    <div class="ctl-head"><h2 class="ctl-title">isemon</h2>
      <p class="ctl-lede">Every check of a code goes to isemon as a <span class="mono">totp.cgi</span>
        line and every RADIUS packet as a <span class="mono">radius-detail</span> line - exactly
        what a totpcgi token server and its FreeRADIUS send it - so isemon reads this server with
        what it already has.</p></div>
    <div id="isemon-state"></div>
    <div class="card full fulladmin-only" id="isemon-tls-card" hidden>
      <h2>Encrypted sending (TLS)</h2>
      <p class="note">The lines to isemon over TLS on 6514/tcp, isemon's certificate checked - from
        every node. Where isemon has no certificate, otp's own authority makes one for it, given
        away once in a locked file with the rsyslog configuration that takes it; with mutual TLS
        each node shows isemon a certificate of its own, so isemon takes lines from otp's nodes
        only.</p>
      <div id="isemon-tls"></div>
    </div>
    <div class="card full"><h2>Settings</h2><div id="sect-isemon"></div></div>
    <div class="card full" id="isemon-guide"></div>
  </div>

  <div class="ctl-pane" id="pane-people" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Accounts</h2>
      <p class="ctl-lede">Who may open these pages. <b>full admin</b> may change everything;
        <b>token admin</b> may look at everything and look after people's tokens; <b>read only</b>
        may look and change nothing.</p></div>
    <div class="card full">
      <h2>Accounts <span class="right"><button class="btn cmd small primary admin-only" id="us-add" data-icon="add">Make an account</button></span></h2>
      <div id="us-table"></div>
    </div>
    <div class="card full fulladmin-only"><h2>Signed in now</h2><div id="se-table"></div></div>
    <div class="card full fulladmin-only" id="lo-card"><h2>Locked out <span class="right" id="lo-tools"></span></h2>
      <p class="note">Addresses and names with wrong attempts still counted, codes sent to a person, and tokens
        locked by wrong codes - at the limit they are locked out until the time runs out. Clear one, or all of them,
        and they may try again at once.</p>
      <div id="lo-table"></div></div>
    <div class="card full" id="cols-card">
      <h2>Columns of the tables <span class="right" id="cols-count"></span></h2>
      <p class="note">Every table on these pages can be laid out the way you read it. Press
        your name at the top right and switch on <b>Edit the columns</b>; then drag the edge of
        a column's heading to make it wider or narrower, and drag the heading itself to move
        the column. The right button on a heading hides a column, brings a hidden one back or
        adds an empty one for room. Twice on an edge puts that table's widths back. Each change
        is kept with your account the moment you let go, not in this browser, and comes back
        wherever you sign in; nobody else's tables change. The switch is for this sign-in
        only: signing out, the sign-in running out or the service restarting turn it off
        again, and the columns stay as you left them.</p>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd" id="cols-edit-go" data-icon="edit"
                title="The same switch as under your name: on for this sign-in only.">Edit the columns</button>
        <button class="btn cmd" id="cols-reset" data-icon="undo"
                title="Every table back as it comes: the widths and the order of the columns you set, on every page. Nobody else's are touched.">Put my columns back as they come</button>
        <button class="btn cmd" id="cols-export" data-icon="download"
                title="How you have set these pages up for yourself, saved as a JSON file.">Export my settings</button>
        <button class="btn cmd" id="cols-import" data-icon="upload"
                title="Read a file saved by Export my settings - here or on another machine running otp.">Import settings…</button>
      </div>
    </div>
    <div class="card full"><div id="sect-people"></div></div>
    <div class="card full" id="krb-card">
      <h2>Signing in with Windows (Kerberos)</h2>
      <p class="note">A browser on a computer in the domain signs its person in to these pages without a
        password: it sends a Kerberos ticket for the name it opened, checked here against the keytab of that
        name. Only accounts of the directory chosen above get in, with the role of their groups - and the second
        step, when it is on, is asked after it just the same. NTLM is never taken. Off, nothing of it is
        offered.</p>
      <div id="sect-kerberos"></div>
      <div id="krb-host"></div>
    </div>
    <div class="card full" id="cert-card">
      <h2>Signing in with a certificate</h2>
      <p class="note">A certificate of the domain's authority - on a smart card, a YubiKey or in the computer -
        signs its person in to these pages without a password. nginx asks for it on a port of its own, never on
        443: nobody else is ever asked for a certificate. Checked here: the chain to an authority put in below,
        its dates, a key usage for signing in, not revoked (CRL), and the UPN in it looked up in the directory set
        above - the role of its groups. The second step, when it is on, is asked after it just the same.
        Off, nothing of it is offered.</p>
      <div id="sect-certlogin"></div>
      <div id="cert-host"></div>
    </div>
    <div class="card full" id="signin-card">
      <h2>The sign-in page</h2>
      <p class="note">What the sign-in page offers, with Windows and a certificate side by side: each is a button
        under the name and password, or is tried by itself when the page opens. Both tried by itself: Windows
        first - silently - and the certificate only when this computer has no Windows ticket (a computer outside
        the domain with a smart card). A refusal of either stops there and says why; the form stays unless there
        is no password at all. After Sign out nothing is tried by itself again in that tab. The same on every node
        of a cluster and on the VIP address.</p>
      <div id="sect-signin"></div>
      <div id="signin-host"></div>
    </div>
    <div class="card full">
      <h2>The groups, and what each one may do</h2>
      <p class="note">Choose the directory in Sign administrators in against the directory above, then press Find the groups and pick them out of the directory rather than typing a distinguished name by hand — that is how a role ends up pointing at a group that does not exist, and nobody finds out until the first person cannot sign in.</p>
      <div class="btnrow admin-only" style="align-items:center">
        <input type="search" id="ag-like" style="min-width:340px;max-width:420px" placeholder="part of a group's name (empty: all)"
               autocomplete="off">
        <button class="btn cmd primary" id="ag-find" data-icon="search"
                title="Ask the directory what groups there are. Nothing is changed; it only reads.">Find the groups</button>
        <button class="btn cmd" id="ag-try" data-icon="person"
                title="Try one person's sign-in from here, so you find out it works before you sign out.">Try a sign-in…</button>
      </div>
      <div id="ag-groups" style="margin-top:14px"></div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-db" hidden>
    <div class="ctl-head"><h2 class="ctl-title">The database</h2>
      <p class="ctl-lede">One database holds everything: the tokens, the RADIUS requests, the
        checks of a code, the settings and the accounts. It is a file on this machine unless you
        say otherwise. The keys of the tokens are sealed with a key kept beside it, in the state
        folder - and every copy and every dump is kept with that key beside it.</p></div>
    <div class="card full"><div id="sect-db"></div></div>

    <div class="card full" id="db-tls-card" hidden>
      <h2>Encryption to the database server</h2>
      <p class="note">This daemon’s own connection to its database - on every node, moved over
        on the live database without stopping anything: tried apart first, then switched, and
        put back at once if the first statement on the new one does not go.</p>
      <div id="db-tls"></div>
    </div>

    <div class="card full" id="db-dump-card">
      <h2>The dumps it keeps <span class="right" id="db-dump-now"></span></h2>
      <p class="note">Every night at the time above, the database in use is dumped
        <b>by its own engine's own program</b> — <code>pg_dump</code> on PostgreSQL,
        <code>mariadb-dump</code> on MariaDB, and on the file SQLite's own backup, which is
        the file. It is a fraction of the size of the database, and it is the format the
        server's own tools read, so it can be put back by somebody who has never heard of
        this program.</p>
      <p class="note">A dump goes back into <b>the engine it came off</b>. What goes back
        into any of the three is a copy, which the card below makes — that is what carries an
        installation from the file to a server and back.</p>
      <div id="db-dump-says"></div>
      <div class="btnrow admin-only" style="margin-top:12px">
        <button class="btn cmd" id="db-dump-make" data-icon="save"
                title="Dump the database now, with the engine's own program, rather than waiting for tonight. It is kept with the others and counts as one of them.">Make one now</button>
        <button class="btn cmd" id="db-dump-get" data-icon="down"
                title="Dump the database now and save it to the machine you are sitting at. Nothing is kept here.">Download one</button>
      </div>
      <div id="db-dumps" style="margin-top:18px"></div>
      <div class="admin-only" id="db-dump-upload" style="margin-top:18px">
        <h4>Put a dump back</h4>
        <p class="note">A dump from somewhere else — one downloaded from here, or a file
          copied off the dumps folder. It replaces everything: every token, every request,
          every setting and every account. Nothing happens until it has been read, checked and
          shown to you.</p>
        <div class="drop" id="dump-drop">
          <input type="file" id="dump-file" accept=".pgc,.gz,.sql,.db,application/octet-stream" hidden>
          <span id="dump-drop-says">Drop a dump here, or press to choose one</span>
        </div>
        <div id="dump-upload-what" hidden></div>
        <div class="btnrow" style="margin-top:10px">
          <button class="btn cmd danger" id="dump-restore" data-icon="undo" disabled>Restore from this file</button>
        </div>
      </div>
    </div>

    <div class="card full" id="db-engine-card">
      <h2>Which one it is <span class="right" id="db-engine-now"></span></h2>
      <p class="note">This installation keeps everything in one database: the file on this machine
        (SQLite), PostgreSQL or MariaDB. Moving to another one is done by the wizard below, step by
        step - which kind, its address, reaching it (and setting it up when it is not there yet),
        what will happen - and then all of it: a copy of what is here first, every table carried
        across and counted, and the daemon started again on the new one. What is here now is never
        changed by it, so going back is the same wizard the other way. Where it is kept is the only
        thing written into <b id="db-engine-file">the config file</b>.</p>
      <div id="db-engine-says"></div>
      <p class="note warn" id="db-wizard-cluster" hidden>This node is one of a cluster: its database
        is the cluster's, and it is not moved from here - make this node one alone first
        (Settings → High availability), then move it, then build the cluster again from it.</p>
      <div class="btnrow admin-only" style="margin-top:12px">
        <button class="btn cmd primary" id="db-wizard" data-icon="db"
                title="Step by step to another database, with Back and Next: nothing is done until the last step.">Move to another database…</button>
      </div>
      <details class="db-by-hand">
        <summary class="small muted">Step by step by hand, as before</summary>
        <div class="btnrow admin-only" style="margin-top:10px">
          <button class="btn cmd" id="db-engine-test" data-icon="check"
                  title="Reach that server with the address above, exactly as the daemon would, and say what answered. Nothing is saved and nothing is written.">Try it</button>
          <button class="btn cmd" id="db-engine-setup" data-icon="key"
                  title="Make the database and the account on that server, and give that account rights on that one database and no other, with a password made here and shown once. The first time it asks for an administrator on the server, uses it for this one connection and stores it nowhere. Afterwards it needs none: it opens the database and puts its tables right, which is worth doing after every upgrade.">Set it up…</button>
          <button class="btn cmd" id="db-engine-move" data-icon="save"
                  title="Copy everything that is here into that database: every token, every request, every setting and every account. What is here is left exactly as it is.">Carry everything across…</button>
          <button class="btn cmd danger" id="db-engine-empty" data-icon="forget"
                  title="Throw away what is in the OTHER database, so that a move can be tried again. Never the one in use.">Empty it…</button>
          <button class="btn cmd" id="db-engine-use" data-icon="power"
                  title="Start using it. This writes the address into the config file and restarts the daemon; nothing in either database is touched, and coming back is the same four steps the other way.">Start using it…</button>
        </div>
        <p class="btnhelp">These take the address from the settings above. The wizard asks for its own.</p>
      </details>
    </div>

    <div class="card full">
      <h2>The disk it is on</h2>
      <p class="note">How much room there is where this database's files live, how fast it is
        growing, and how long one will hold the other. Measured, not guessed: the size is
        noted once a day and what is shown is the slope of the last fortnight. On a database
        server the database is not on this machine at all — what is here then is the copies
        and the dumps, and the line below says so.</p>
      <div id="db-disk"></div>
    </div>

    <div class="card full" id="db-tune-card">
      <h2>The database server’s own settings</h2>
      <p class="note">A database server is installed with settings for a machine of any size,
        which is to say for a small one: PostgreSQL keeps 128 MB of the database in memory, and
        MariaDB likewise, on a machine of 32 GB. This reads what the machine the server runs on
        has — its memory, its processors, its disk — works the settings out for it, shows them
        beside what is there now, and puts them in when you say so.</p>
      <p class="note">Changing them takes an account that may: this program’s own where it has
        that right, otherwise an administrator on that server, asked for in the popup, used for
        that one request and stored nowhere — not in the settings, not in the database, not in
        any log.</p>
      <div id="db-tune-says"></div>
      <div class="btnrow admin-only" style="margin-top:12px">
        <button class="btn cmd primary" id="db-tune" data-icon="gear"
                title="Read what the machine the database server runs on has, work its settings out for it and show them beside what is there now. Nothing is changed until you say so.">Tune it for this machine…</button>
        <button class="btn cmd" id="db-tune-restart" data-icon="power" hidden
                title="Restart PostgreSQL for the settings that take effect only at its start.">Restart the server…</button>
        <button class="btn cmd" id="db-tune-undo" data-icon="undo" hidden
                title="Put every setting this page changed back to what it was before.">Put back as it was…</button>
      </div>
    </div>

    <div class="card full">
      <h2>What is in it <span class="right" id="db-size"></span></h2>
      <p class="note">A copy is consistent even while the daemon is writing to it, and it is
        written as a portable file whatever this is running on — so a copy made on MariaDB or
        PostgreSQL goes back into either of those, or into the file on this machine.</p>
      <p class="btnhelp">These are <b>every row in each table</b>, which is not the number on
        the tabs above: those count what the page they belong to is showing.</p>
      <div id="db-counts"></div>
      <div class="going wide" id="db-going" hidden>
        <div class="bar"><span id="db-going-fill"></span></div>
        <div class="says" id="db-going-says"></div>
      </div>
      <div class="btnrow" style="margin-top:12px">
        <button class="btn cmd admin-only" id="db-backup" data-icon="save"
                title="Copy the database as it is into the backups folder on this machine, now, rather than waiting for tonight.">Make a copy now</button>
        <button class="btn cmd admin-only" id="db-download" data-icon="down"
                title="Make a copy now and save it to the machine you are sitting at, with the key that opens the tokens inside it. Nothing is kept here.">Download it</button>
        <button class="btn cmd admin-only" id="db-check" data-icon="check"
                title="Ask the database to read itself through and say whether anything in it is broken - SQLite's integrity check, MariaDB's CHECK TABLE, and on PostgreSQL every table read through. It only reads; on a large one it takes a while.">Check it</button>
        <button class="btn cmd admin-only" id="db-tidy" data-icon="broom"
                title="Throws away exactly what the &quot;keep for&quot; numbers above already say is too old — the RADIUS requests, the checks of a code and the events, each by its own number of days. It happens by itself every hour; this is the same thing, now. Lowering one of those numbers deletes nothing by itself: this is what does it.">Apply what is kept, now</button>
        <button class="btn cmd danger admin-only" id="db-prune" data-icon="forget"
                title="Forgets the RADIUS requests and the checks of a code older than an age you choose here, whatever the &quot;keep for&quot; numbers say. Only those two kinds of record: the tokens, the accounts and the settings are not touched.">Forget records older than…</button>
        <button class="btn cmd admin-only" id="db-optimize" data-icon="db"
                title="Gives the space back to the DISK. Deleting rows frees room inside the database and the engine reuses it; nothing hands it back to the operating system until the whole thing is rebuilt. All three do that the same way — SQLite's VACUUM, MariaDB's OPTIMIZE TABLE, PostgreSQL's VACUUM FULL — and all three hold the table shut while they do it and need room for a second copy of the biggest one. Worth doing after throwing a lot away, and not otherwise.">Give the disk back</button>
      </div>
      <div id="db-backups" style="margin-top:18px"></div>
      <div class="admin-only" id="db-upload" style="margin-top:18px">
        <h4>Put a copy back</h4>
        <p class="note">A database from somewhere else — one downloaded from here, or a file
          copied off the backups folder. It replaces everything: every token, every request,
          every setting and every account. Nothing happens until it has been read, checked
          and shown to you.</p>
        <div class="drop" id="db-drop">
          <input type="file" id="db-file" accept=".gz,.db,.sqlite,.sqlite3,application/octet-stream" hidden>
          <span id="db-drop-says">Drop a database file here, or press to choose one</span>
        </div>
        <div id="db-upload-what" hidden></div>
        <div class="btnrow" style="margin-top:10px">
          <button class="btn cmd danger" id="db-restore" data-icon="undo" disabled>Restore from this file</button>
        </div>
      </div>
    </div>

    <div class="card full">
      <h2>Erase the collected data <span class="right" id="erase-size"></span></h2>
      <p class="note">What is recorded of what happened can be thrown away without anybody
        losing anything they need: nobody has to enrol again and nothing stops working. Choose
        what goes; nothing is erased that you have not ticked.</p>
      <p class="note"><b>The tokens, the accounts, the clients, the realms, the directories and
        every setting are never touched by this.</b> They are not options you could tick by
        mistake: they are not in the list at all.</p>
      <div id="erase-list" class="erase-list"></div>
      <div class="btnrow admin-only" style="margin-top:14px;align-items:center">
        <button class="btn cmd danger" id="erase-go" data-icon="forget"
                title="Erase everything ticked above. It cannot be undone — but a copy of the database is made just before it, and it can be restored.">Erase what is ticked…</button>
        <label class="check small" id="erase-tidy-wrap">
          <input type="checkbox" id="erase-tidy" checked
                 title="Rebuild the database afterwards so the space actually goes back to the disk. None of the three give room back by themselves when rows are deleted — it is reused inside instead.">
          <span>rebuild it afterwards, to give the disk back</span>
        </label>
      </div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-codes" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Codes by e-mail and SMS</h2>
      <p class="ctl-lede">Instead of the app, a realm may offer a code sent after the directory
        password (Realms → People may choose). The VPN sends the password alone; this server
        checks it and the groups, sends a code and answers with an Access-Challenge - Cisco Secure
        Client (ASA, FTD) and others show a second window for the code. E-mail goes the way set
        under Mail; SMS through a gateway or a modem set up here.</p></div>
    <div class="card full"><div id="sect-codes"></div></div>
    <div class="card full">
      <h2>Try an SMS <span class="right muted small" id="sms-said"></span></h2>
      <p class="note">Sends a short message with a code that opens nothing, the way a sign-in code
        would go, and shows what the gateway answered. Save the changes first.</p>
      <div class="btnrow admin-only filters">
        <input type="tel" id="sms-to" placeholder="+420 603 123 456" style="flex:1;min-width:240px">
        <button class="btn cmd" id="sms-try" data-icon="phone">Send a test SMS</button>
      </div>
    </div>
    <div class="card full">
      <h2>On the VPN</h2>
      <p class="note">Cisco ASA: <code>aaa-server OTP protocol radius</code>, the server with
        <code>timeout 15</code>, and the tunnel group's <code>authentication-server-group OTP</code>.
        Leave <code>password-management</code> off on the tunnel group: with it the ASA asks with
        MS-CHAPv2, and a code can only travel as PAP. FTD (FMC): a RADIUS Server Group with the
        timeout 15 s, the connection profile's AAA - authentication only - with that group.
        The second window needs nothing on the clients.</p>
    </div>
  </div>

  <div class="ctl-pane" id="pane-mail" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Mail</h2>
      <p class="ctl-lede">A token's QR code - and its recovery codes, where wanted - can be sent to
        the person it is for when it is made. The mail leaves through your mail server (SMTP), or
        straight to the server of the recipient's domain with no relay at all.</p></div>
    <div class="card full"><div id="sect-mail"></div></div>
    <div class="card full">
      <h2>Try it <span class="right muted small" id="mail-said"></span></h2>
      <p class="note">Sends a short message - or a sample of a token's mail, with a made-up key - the
        way a token's mail would go, and shows every step: the server reached, TLS, signing in, the
        message handed over and what the server said. Save the changes first.</p>
      <div class="btnrow admin-only filters">
        <input type="email" id="mail-to" placeholder="somebody@example.cz" style="flex:1;min-width:240px">
        <select id="mail-test-kind"><option value="short">a short message</option><option value="token">a sample token mail</option><option value="code">a sample sign-in code (e-mail codes)</option><option value="verify">a sample address check (enrolment)</option></select>
        <select id="mail-test-lang"><option value="cs">Čeština</option><option value="en">English</option></select>
        <select id="mail-test-via" title="With mail sent straight to the recipient's server: this once, every step shown here - or through the outgoing mail, as codes go: tried now, and tried again by itself while the other side does not take it yet (greylisting)." hidden><option value="queue">through the outgoing mail</option><option value="straight">straight, this once (to see every step)</option></select>
        <button class="btn cmd primary" id="mail-test" data-icon="mail">Send a test</button>
      </div>
      <div id="mail-steps"></div>
    </div>
    <div class="card full">
      <h2>The certificate authority <span class="right muted small" id="mca-when"></span></h2>
      <p class="note">Needed only when the mail server's certificate was signed by an authority of your own that this machine does not already trust. Paste one (or a whole chain), or read it from the .crt / .pem / .cer file, and press Save the changes below. Each is listed and can be taken out by itself.</p>
      <div id="mca-state"></div>
      <textarea id="mca-pem" rows="5" class="mono admin-only" style="width:100%;margin-top:10px"
                placeholder="-----BEGIN CERTIFICATE-----&#10;MIID...&#10;-----END CERTIFICATE-----"></textarea>
      <div class="btnrow admin-only" style="margin-top:10px">
        <button class="btn cmd primary" id="mca-save" data-icon="save">Add it</button>
        <button class="btn cmd" id="mca-file" data-icon="upload">Read a file…</button>
        <button class="btn cmd danger" id="mca-drop" data-icon="trash">Take them all away</button>
        <input type="file" id="mca-input" accept=".pem,.crt,.cer,.txt" hidden>
      </div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-network" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Network</h2>
      <p class="ctl-lede">Each node's address, gateway, DNS servers, host name and - switched on - IPv6.
        A change is put in by the node itself: in a cluster the other node is told the new address
        first, the VIP address moves away, the network is set and the node restarts; back up, it
        checks its address, replication and the link between the databases, and comes back into service.</p></div>
    <div id="net-host"></div>
    <div class="card full fulladmin-only"><h2>Taken back unless kept</h2><div id="sect-network"></div></div>
  </div>
  <div class="ctl-pane" id="pane-time" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Time</h2>
      <p class="ctl-lede">A code from the app is worked out from the clock: a node whose clock is off by
        more than a few seconds refuses codes that are right. Each node keeps its clock with chrony; here
        is how far off each one is, which servers it follows, and the time servers set for the whole cluster.</p></div>
    <div id="ntp-host"></div>
    <div class="card full" id="clock-card" hidden>
      <h2>The clocks of the nodes <span class="right" id="clock-state"></span></h2>
      <p class="note">A node whose clock is off refuses codes that are right - and answers, so the VPN does not
        ask the other node. Its heartbeat, its pauses and lockouts are off with it; a node that cannot reach the
        directory refuses every password the same way. Here each node measures itself against the time servers
        and the other node, and what is done about it is chosen.</p>
      <div id="clock-guard"></div>
    </div>
  </div>
  <div class="ctl-pane" id="pane-power" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Restart and power off</h2>
      <p class="ctl-lede">This node, the other or both, restarted or switched off from here. In a cluster the
        VIP address moves to the other node first; restarted one after the other, the service never stops.
        The page follows each node down and up again.</p></div>
    <div id="pw-host"></div>
    <div class="card full fulladmin-only"><h2>On a schedule</h2><div id="sect-power"></div></div>
  </div>
  <div class="ctl-pane" id="pane-osup" hidden>
    <div class="ctl-head"><h2 class="ctl-title">System updates</h2>
      <p class="ctl-lede">The operating system's packages, updated by dnf (or apt) on each node. In a cluster one
        node at a time: each is out of service while it is updated - the VIP address moves to the other,
        which answers RADIUS meanwhile - and back in service before the next one starts. A restart an update
        needs is offered when it is done, or made by itself, one node after the other.</p></div>
    <div id="ou-host"></div>
    <div class="card full fulladmin-only"><h2>On a schedule</h2><div id="sect-osup"></div></div>
  </div>
  <div class="ctl-pane" id="pane-sshd" hidden>
    <div class="ctl-head"><h2 class="ctl-title">SSH server and notices</h2>
      <p class="ctl-lede">How each node's SSH server lets people in - root with a key or a password, the port,
        who may sign in - and the notice shown before signing in over SSH, at the console and after signing in.
        Put in by each node's root helper as a file of otp's own beside the system's, checked by sshd before it
        is used, and on trial: unless it is kept in time, each node puts back what it had by itself.</p></div>
    <div id="sd-host"></div>
    <div class="card full"><h2>otp’s gate for SSH</h2><div id="sect-sshd"></div></div>
  </div>
  <div class="ctl-pane" id="pane-sshkeys" hidden>
    <div class="ctl-head"><h2 class="ctl-title">SSH keys</h2>
      <p class="ctl-lede">The keys that may sign in to each node over SSH - as root (the lines of
        /root/.ssh/authorized_keys, only shown here: put on and taken away by root on the node itself) or as
        any user who may sign in there (their own ~/.ssh/authorized_keys, written as they are), read from
        every node. A key made here for a user is shown once, to be kept by you, and kept nowhere on the
        server; one of your own is put on by its public half - on every node or on one. Every change is
        written into Events.</p></div>
    <div id="sk-host"></div>
  </div>
  <div class="ctl-pane" id="pane-osusers" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Local users</h2>
      <p class="ctl-lede">The users of each node's own system - who may sign in to the machine itself, over SSH
        or at its console; not the accounts of these pages. root is shown and never changed here; the others
        (UID 1000 and up) are made, given a password or sudo, locked or taken away on every node at once or on
        one, by each node's root helper. A password typed here goes to the nodes as its hash only and is kept
        nowhere. Every change is written into Events.</p></div>
    <div id="osu-host"></div>
  </div>
  <div class="ctl-pane" id="pane-backup" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Backups</h2>
      <p class="ctl-lede">A backup is everything: the whole database (tokens, clients, realms,
        accounts, every setting, the certificates, the VIP address, the firewall, the texts, the
        logs), the key that opens the tokens and this machine's config.json - with RESTORE.md, the
        exact steps to bring it all back on a machine installed from nothing, one server or a
        cluster. Locked with the password below; sent to every destination switched on - a
        folder, FTP, FTPS, SFTP, SCP or a Windows/Samba share. Each node of a cluster sends its own.</p></div>
    <div id="rb-top"></div>
    <div class="card full" id="rb-tried-card" hidden><h2>Backups tried <span class="right" id="rb-tried-tools"></span></h2><div id="rb-tried"></div></div>
    <div class="card full"><h2>When, how many, and the password</h2><div id="sect-backup"></div></div>
    <div class="card full"><h2>Where they go <span class="right" id="rb-add-host"></span></h2>
      <div id="rb-targets"></div></div>
    <div class="card full"><h2>What was sent <span class="right" id="rb-runs-tools"></span></h2><div id="rb-runs"></div></div>
  </div>
  <div class="ctl-pane" id="pane-texts" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Message texts</h2>
      <p class="ctl-lede">What people get from this server - the mails, the SMS and the VPN's second window, in Czech and English. Click into a text to write; the blue parts are filled in when it is sent.</p></div>
    <div id="tx-root"></div>
  </div>

  <div class="ctl-pane" id="pane-mailq" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Outgoing mail</h2>
      <p class="ctl-lede">Every mail this server sends - a token's QR code, a code to sign in with, a
        code to check an address - goes through here. What the receiving side does not take at
        once (greylisting's "try again later", a server away, a full mailbox) waits and is tried
        again by itself; what it refuses for good is shown as failed. Both nodes of a cluster see
        the same list: a mail is sent by the node it was made on, or by the other when that one
        is gone. What a mail held is never kept once it went.</p></div>
    <div class="card full held mq-held">
      <div class="mq-chips" id="mq-chips"></div>
      <div class="btnrow filters" style="margin-top:12px">
        <input type="search" id="mq-q" placeholder="an address, a name, what the server said… (to:*@example.cz, state:waiting, kind:code…)" style="flex:1;min-width:260px">
        <select id="mq-state">
          <option value="">every state</option>
          <option value="open">waiting or failed</option>
          <option value="waiting">waiting for another try</option>
          <option value="sending">being sent</option>
          <option value="sent">sent</option>
          <option value="failed">failed</option>
          <option value="expired">given up</option>
        </select>
        <button class="btn cmd tokadmin-only" id="mq-retry-all" data-icon="refresh">Send every waiting one now</button>
        <button class="btn cmd tokadmin-only" id="mq-drop-sent" data-icon="trash">Clear the sent ones</button>
        <button class="btn cmd danger tokadmin-only" id="mq-drop-failed" data-icon="trash">Clear the failed ones</button>
      </div>
      <div id="mq-said" class="muted small" style="margin:8px 0 0"></div>
      <div id="mq-table" class="scroll rowsonly" style="margin-top:10px"></div>
      <div id="mq-pager" class="pager"></div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-ha" hidden>
    <div class="ctl-head"><h2 class="ctl-title">High availability
        <button type="button" class="btn cmd small ha-hist-btn" id="ha-history" data-icon="history"
                title="What happened to the cluster: the VIP address moving, a node stopping and coming back, replication stopping, errors - and what was done by hand.">History</button></h2>
      <p class="ctl-lede" id="ha-lede-shared">Two servers, both answering - active/active. Both open the same
        PostgreSQL and keep nothing that matters anywhere else, so a load balancer may send any
        request to either, round robin and without stickiness: a sign-in, an enrolment half done
        on one and finished on the other, a RADIUS packet. Every change made on one is on the
        other within five seconds.</p>
      <p class="ctl-lede" id="ha-lede-replicated" hidden>Two servers, both answering (active/active). Each has its own PostgreSQL and the two replicate to each other both ways, so a load balancer may send any request to either one, round robin and with no stickiness - a sign-in, a token enrolment started on one and finished on the other, a RADIUS packet. Either node goes on alone while the other is away and catches up when it is back.</p></div>
    <div class="card full">
      <h2>The nodes <span class="right" id="ha-said"></span></h2>
      <p class="note">Each node writes into the database every fifteen seconds that it is
        there. One not heard from for three of those is shown as gone; one taken away for good
        can be taken off the list.</p>
      <div id="ha-nodes"></div>
    </div>
    <div class="card full" id="ha-own-card" hidden>
      <h2>Each node's own settings</h2>
      <p class="note">Everything else in Settings is the cluster's and goes to every node. These
        belong to one machine: the address and ports RADIUS listens on, the port the pages ask
        the daemon on, the name it greets mail servers with and the name isemon files it under,
        its own copies of the database (whether, when, how many - each node keeps them on its own
        disk), and the debug switches. Each node shows the value in effect on it: its own,
        marked, or the cluster's, dimmed.</p>
      <p class="note">The machine itself - its addresses, IPv6, gateway, DNS and host name - is
        set per node in Settings → Network; turning IPv6 on there makes RADIUS listen on
        <code>::</code> (IPv4 and IPv6) by itself. Its clock is in Settings → Time.</p>
      <div id="ha-own"></div>
    </div>
    <div class="card full" id="ha-rep-card" hidden>
      <h2>Replication <span class="right" id="ha-rep-said"></span></h2>
      <p class="note">Each node has its own PostgreSQL and goes on alone when the other is away.
        What one writes goes to the other within a moment; what a node misses while it is away
        waits for it on the other (up to 16 GB of it) and comes over by itself when it is back.
        A node that was away longer than that, or was reinstalled, is rebuilt from the other.</p>
      <div id="ha-rep"></div>
      <div class="going wide" id="ha-going" hidden>
        <div class="bar"><span id="ha-going-fill"></span></div>
        <div class="says" id="ha-going-says"></div>
      </div>
      <div class="btnrow admin-only" style="margin-top:12px">
        <button class="btn cmd" id="ha-pause" data-icon="power"
                title="Both directions stop for now. What is written meanwhile waits on each node for the other, up to 16 GB, and goes over when it is resumed.">Pause it…</button>
        <button class="btn cmd primary" id="ha-resume" data-icon="play"
                title="Both directions go on from where they stopped.">Resume it</button>
        <button class="btn cmd" id="ha-errors" data-icon="flag"
                title="What the errors were, from PostgreSQL's own log - and clearing them once dealt with.">The errors…</button>
        <button class="btn cmd" id="ha-refresh" data-icon="refresh"
                title="Read the list of tables the other node publishes again - after an upgrade that added one.">Read the tables again</button>
        <button class="btn cmd danger" id="ha-resync" data-icon="db"
                title="Rebuild THIS node from the other: its tables emptied and every row copied over, both directions made afresh. A copy of what is here is made first.">Rebuild this node from the other…</button>
        <button class="btn cmd danger" id="ha-stop" data-icon="cancel"
                title="Replication off for good: each node goes on alone with what it has, and they drift apart.">Switch it off…</button>
      </div>
    </div>
    <div class="card full" id="ha-addr-card" hidden>
      <h2>The addresses of the two nodes <span class="right" id="ha-addr-said"></span></h2>
      <p class="note">Replication reaches the other node by its address, kept in three places on
        each node: config.json, its subscription and the line of pg_hba.conf that lets the other
        in. When an address changes, tell it here - on the node whose address did <b>not</b>
        change: it puts its side right and tells the other node, which does its part by itself.
        Names of the nodes are changed under Each node's own settings; the whole guide is
        docs/renaming-and-readdressing.md.</p>
      <div id="ha-addr"></div>
    </div>
    <div class="card full" id="ha-vip-card">
      <h2>The VIP address</h2>
      <p class="note">An address for the pages that is on one node at a time - active and
        standby - held by keepalived. It leaves a node by itself when the node goes into
        maintenance, is upgraded or rebuilt, or when its pages stop answering their own
        /healthz (nginx, PHP, the daemon, the database) or RADIUS stops listening; and when
        the node is gone altogether. It comes back to the node it is meant to be on once
        that is well again. With it off, a load balancer of your own works as before
        (docs/load-balancers.md).</p>
      <div id="web-vip"></div>
    </div>
    <div class="card full" id="ha-split-card" hidden>
      <h2>When the nodes lose each other <span class="right" id="ha-split-state"></span></h2>
      <p class="note">Two nodes that cannot reach each other each take the other for gone and go on alone
        (split brain): a code may then be let in on both halves, the wrong tries are counted on each half
        apart, and what is changed on each half goes its own way. Without a third machine it cannot be
        ruled out - but which node goes on, and what holds meanwhile, is chosen here. Each node watches
        the other’s database every two seconds.</p>
      <div id="ha-split"></div>
    </div>
    <div class="card full"><div id="sect-ha"></div></div>
    <div class="card full" id="ha-make">
      <h2>Making it two, step by step</h2>
      <div id="ha-checks"></div>
      <div class="btnrow" id="ha-make-open" hidden><button class="btn cmd" id="ha-make-btn" data-icon="eye">Show how it was made</button></div>
      <div id="ha-make-body">
      <p class="note">Everything below is done on the command line, as root, because it changes PostgreSQL's own configuration and restarts it. The pages show the result and look after it afterwards. In the examples the first node is <code>otp1</code> at <code>192.0.2.11</code> and the second <code>otp2</code> at <code>192.0.2.12</code>; put your own names and addresses in.</p>
      <ol class="ha-steps">
        <li><p><b>On this node, the first one.</b> Its database has to be PostgreSQL 16 or later on this machine (<i>Settings → The database</i> moves it there if it is not yet). Then:</p>
          <pre class="ha-cmd" data-no-i18n>otp --ha-setup --ha-peer 192.0.2.12 --node-name otp1</pre>
          <p>It switches PostgreSQL to logical replication and restarts it (after asking), lets the second node in (pg_hba.conf, the firewall), publishes every table, numbers this node's rows odd - the second's will be even - and writes the bundle to <code>/root/otp-join-otp1.json</code>, printing its passphrase once. Write the passphrase down.</p>
          <p>For one PostgreSQL both nodes open instead (a server of its own, or a cluster's address) add <code>--ha-shared</code>, and <code>--ha-db-host ADDRESS</code> when the server is elsewhere.</p></li>
        <li><p><b>The bundle</b> carries what the second node needs and nothing else: the database's account and password, and the key that opens the tokens - locked with the passphrase. Carry the file over on its own (scp, a USB stick) and tell the passphrase some other way. A fresh one, for a node to be rebuilt later:</p>
          <pre class="ha-cmd" data-no-i18n>otp --ha-bundle /root/otp-join-otp1.json</pre>
          <div class="btnrow admin-only">
            <button class="btn cmd primary" id="ha-bundle" data-icon="key">Make the bundle…</button>
          </div></li>
        <li><p><b>On the second node</b>, as root: install the same version of otp, fetch the bundle and join:</p>
          <pre class="ha-cmd" data-no-i18n>./install.sh --with-db postgres --yes
scp root@192.0.2.11:/root/otp-join-otp1.json /root/
otp --ha-join /root/otp-join-otp1.json --node-name otp2</pre>
          <p>It installs PostgreSQL there if it is missing, prepares it the same way, copies every row from this node and sets both directions up. From then on sign in to either node with the same accounts. A node joining one shared PostgreSQL can instead use <b>Join a cluster…</b> on its own pages.</p>
          <div class="btnrow admin-only">
            <button class="btn cmd" id="ha-join" data-icon="net">Join a cluster…</button>
          </div></li>
        <li><p><b>On both nodes</b>, give the load balancer's address, so that the allow lists, the sign-in pause and every log see the real client and not the balancer:</p>
          <pre class="ha-cmd" data-no-i18n>otp --trusted-proxy 192.0.2.10/32</pre></li>
        <li><p><b>Check it</b> on either node - both nodes and both directions of the replication should be listed as running:</p>
          <pre class="ha-cmd" data-no-i18n>otp --ha-status</pre>
          <p>The same is on this page, above. Then set the load balancer up: see below.</p></li>
      </ol>
      </div>
    </div>
    <div class="card full">
      <h2>Looking after it from the command line</h2>
      <p class="note">Each of these has its button above; the command does the same thing from a shell on the node, as root, and works when the pages do not.</p>
      <!-- Folded away until asked for (1.0.75), as the balancers' guides. -->
      <details class="lb-guide ha-cli-fold" id="ha-cli-fold">
        <summary><b>The commands</b><span class="tag dim">replication · the VIP address (VRRP) · maintenance</span></summary>
        <div class="ha-cli-in">
      <table class="plain ha-cli">
        <thead><tr><th>Command</th><th>What it does</th></tr></thead>
        <tbody>
          <tr><td data-no-i18n>otp --ha-status</td>
            <td>The nodes, when each was last heard from, and both directions of the replication: running or not, how much is waiting to go over, any error.</td></tr>
          <tr><td data-no-i18n>otp --ha-pause<br>otp --ha-pause in<br>otp --ha-pause out</td>
            <td>Stop sending for now - both directions, or only what comes in or goes out. Both nodes keep answering from their own database. What is written meanwhile waits (up to 16 GB) and goes over after resuming.</td></tr>
          <tr><td data-no-i18n>otp --ha-resume<br>otp --ha-resume in<br>otp --ha-resume out</td>
            <td>Carry on from where it stopped.</td></tr>
          <tr><td data-no-i18n>otp --ha-resync</td>
            <td>Rebuild <b>this</b> node from the other: a copy of this node's database is made, its tables are emptied, every row is copied over and both directions are set up afresh. For a node that was away longer than what is kept for it (the status says <i>lost - rebuild the other node</i>), or one whose database is in doubt. Always run it on the node that was away, never on the one that kept working.</td></tr>
          <tr><td data-no-i18n>otp --ha-bundle FILE<br>otp --ha-join FILE --node-name NAME</td>
            <td>A node reinstalled from scratch: a new bundle on the live node, then install otp on the new machine and join with it, exactly as the second node did the first time. It takes the same place as the node it replaces.</td></tr>
          <tr><td data-no-i18n>otp --ha-stop</td>
            <td>Replication off for good: both subscriptions and their slots are removed, each node goes on alone with what it has, and from then on they drift apart. Putting them together again is a rebuild of one from the other (<code>--ha-resync</code>).</td></tr>
          <tr><td data-no-i18n>./install.sh</td>
            <td>An upgrade: run it on one node, then on the other. Both nodes have to run the same version - the list of nodes above shows a mismatch. Replication goes on through it.</td></tr>
          <tr><td data-no-i18n>otp --ha-stop<br>…<br>otp --ha-resync</td>
            <td>Putting a dump back is refused while replication runs. Switch it off, restore the dump on one node, then rebuild the <b>other</b> node from it with <code>--ha-resync</code> run there.</td></tr>
          <tr><td data-no-i18n>otp --trusted-proxy CIDR</td>
            <td>The load balancer's address, on both nodes: nginx then takes the client's own address from X-Forwarded-For sent by that one address.</td></tr>
          <tr class="ha-cli-group"><td colspan="2">The VIP address (VRRP)</td></tr>
          <tr><td data-no-i18n>otp --web-status</td>
            <td>Where the VIP address is now and how each node sees it (VRRP: master or backup), its settings, and the certificates of the nodes and of the address. <code>--json</code> for a script.</td></tr>
          <tr><td data-no-i18n>otp --vip-set 192.0.2.10/24 --vip-fqdn NAME<br>&nbsp;&nbsp;[--vip-vrid N] [--vip-iface NODE=IFACE]</td>
            <td>The address itself: with its prefix, its host name, the VRRP id (1-255, default 51; another id for every cluster on the same network) and on each node the interface it goes on (default: the one with the node's own address). Run on one node; the other takes it within a few seconds.</td></tr>
          <tr><td data-no-i18n>otp --vip on<br>otp --vip off</td>
            <td>The VIP address on or off: root writes keepalived's configuration and starts it, or stops it and takes the address away - on both nodes.</td></tr>
          <tr><td data-no-i18n>otp --vip-move NODE</td>
            <td>Move the address to that node now, by hand - it goes once the node is healthy (its pages answer, RADIUS listens, not in maintenance).</td></tr>
          <tr><td data-no-i18n>otp --vip-return NODE<br>otp --vip-return stay</td>
            <td>Where it goes after a failure is over: always back to that node, or <i>stay</i> - it stays where it is until that node fails or it is moved by hand.</td></tr>
          <tr><td data-no-i18n>otp --maintenance on|off|status [--node NAME]</td>
            <td>A node out of service and back: RADIUS is not answered, its /healthz says 503 - and the VIP address leaves it for the other node by itself.</td></tr>
          <tr><td data-no-i18n>otp --web-retry</td>
            <td>This node asks root again for what failed (keepalived's configuration, a certificate for nginx, the firewall).</td></tr>
          <tr><td data-no-i18n>systemctl status keepalived<br>journalctl -u keepalived -n 50<br>ip -br addr</td>
            <td>On the node itself, when the address does not come or does not move: whether keepalived runs, what it said (each change between MASTER and BACKUP is a line), and on which interface the address is. VRRP is IP protocol 112 between the two nodes - the firewall lets it in from the other node by itself.</td></tr>
        </tbody>
      </table>
        </div>
      </details>
      <p class="note">A short outage - a reboot, a network cut, hours or days - needs nothing: the live node keeps what the other misses, and the node catches up by itself when it is back. A code used on one node is known to the other a moment later; a code tried on both nodes in that same moment, or on both halves of a split network, can be accepted twice - so a 30-second code may, rarely, pass twice. Change settings on one node at a time.</p>
    </div>
    <div class="card full">
      <h2>The load balancer</h2>
      <div id="ha-lb"></div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-carry" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Export and import</h2>
      <p class="ctl-lede">The whole configuration as one file: the settings (each node's own
        too), the RADIUS clients, the realms, the directories, the accounts of these pages, the
        certificates of the pages and the VIP address, the VIP address, who may reach which page,
        the firewall and the mail server's authorities. The tokens are not in it: they move with a
        copy of the database and its key. On the command line: otp --export-config FILE
        [--with-secrets] and otp --import-config FILE --yes.</p></div>
    <div class="card full">
      <div class="btnrow">
        <button class="btn cmd admin-only" id="ex-plain" data-icon="download">Export</button>
        <button class="btn cmd danger admin-only" id="ex-whole" data-icon="key">Export with the secrets</button>
        <button class="btn cmd admin-only" id="ex-load" data-icon="upload">Import a file…</button>
        <input type="file" id="ex-file" accept=".json" hidden>
      </div>
    </div>
  </div>

  <div class="ctl-pane" id="pane-web" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Certificates and TLS</h2>
      <p class="ctl-lede">How the pages and the administration speak HTTPS: on each node,
        and on the cluster's VIP address (Settings → High availability) - the certificate
        with its chain, the protocols, the ciphers.</p></div>
    <div class="card full">
      <h2>Certificates</h2>
      <p class="note">One for each node's own name and one for the VIP address's. A
        certificate is sent as PEM files (the certificate, its key, the chain, the root - in
        any order, or all in one file) or as a PFX / PKCS#12 file, with its password or
        without; or the request is made here and only what the authority sends back is
        uploaded. Root puts it in nginx and asks nginx before reloading it.</p>
      <div id="web-certs" class="cert-grid"></div>
    </div>
    <div class="card full" id="web-push-card">
      <h2>Certificates from acme <span class="right" id="web-push-state"></span></h2>
      <p class="note">acme, the certificate manager, can give this server its certificate and renew it
        by itself (acme push). Paired once with a code shown here, acme signs every request with its key and
        sends the certificate's private key sealed for this server alone; the certificate is kept exactly where
        an upload above keeps it, and the Automatic certificates leave it alone from then on. Off until switched
        on; acme's address must be among those that may reach these pages.</p>
      <div id="web-push"></div>
    </div>
    <!-- The system's trusted roots (1.0.265): certificate authorities of one's own put into the
         trust of the operating system of every node, beside the distribution's list. -->
    <div class="card full" id="osr-card">
      <h2>Trusted roots of the system</h2>
      <p class="note">Certificate authorities of your own - your company's root, an intermediate -
        trusted by the operating system of every node as a whole: curl, dnf, LDAPS to a domain
        controller, SMTP, syslog over TLS, otp's own connections - every program that uses the
        system's trust. The distribution's own list stays as it is and keeps coming with the
        system's updates; these are added beside it, the way the system itself takes local
        additions (update-ca-trust on RHEL, AlmaLinux and Rocky, update-ca-certificates on Debian
        and Ubuntu), and stay there through those updates.</p>
      <div id="osr-host"></div>
    </div>

  </div>
  <div class="ctl-pane" id="pane-fw" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Firewall and access</h2>
      <p class="ctl-lede">Who may reach which pages, and the machine's own firewall: what otp's
        functions need is let in by itself (a RADIUS client added, the cluster made, the web
        address turned on), and you add whatever else you want - for IPv4 and IPv6. Inside
        the cluster everything is always let in.</p></div>
    <div class="card full">
      <h2>Who may reach the pages</h2>
      <p class="note">The enrolment pages, the administration and the health check share
        ports 80 and 443, so who sees which is said by nginx, page by page; the firewall
        below opens the ports only to these networks. The other node and the VIP address
        are always let in, and so is the machine itself.</p>
      <div id="fw-access"></div>
    </div>
    <div class="card full">
      <div class="fw-top"><div><h2>The firewall (iptables / ip6tables)</h2>
        <p class="note" id="fw-lede"></p></div>
        <div id="fw-master"></div></div>
      <div id="fw-nodes" class="fw-nodes"></div>
      <div id="fw-body"></div>
    </div>
    <div class="card full fulladmin-only"><h2>Settings</h2><div id="sect-fw"></div></div>
  </div>
  <div class="ctl-pane" id="pane-upgrade" hidden>
    <div class="ctl-head"><h2 class="ctl-title">Upgrades and maintenance</h2>
      <p class="ctl-lede">A new version put in from here: send the package, and the nodes are
        upgraded one at a time - each taken out of service first, so the VPN and the load
        balancer go to the other, and brought back only once it answers again. The command
        line (install.sh --upgrade) works as it always has.</p></div>
    <!-- What an update cannot do itself (1.0.258): counted beside Upgrades in the menu, said in
         the alerts and the console until it is done; the first card of the pane. -->
    <div class="card full fulladmin-only after-card" id="after-card">
      <h2>To be done by hand</h2>
      <p class="note">What otp cannot do itself and somebody has to - a step a new version needs on
        the command line, what the installer left to you (SELinux, the firewall, a package). Kept
        here, counted beside Upgrades in the menu, said in the alerts and in the console until it is
        done. One that can be checked goes by itself once it is so.</p>
      <div id="after-bands"></div>
      <div id="after-lately"></div>
    </div>
    <div class="card full">
      <h2>The nodes</h2>
      <p class="note">A node in maintenance answers no RADIUS request and its /healthz says
        503, so the VPN and the load balancer leave it alone; these pages go on working.
        With a single server, maintenance means nobody can sign in to the VPN.</p>
      <div id="up-nodes"></div>
    </div>
    <div class="card full admin-only" id="up-web-card">
      <h2>From the web</h2>
      <p class="note">Where new versions are published - the address below - is looked at once a
        day. A newer otp found there is offered here, and put in with one click: fetched, its
        signature checked like a package sent by hand, then the nodes upgraded one at a time.
        Nothing is put in by itself.</p>
      <div id="up-web"></div>
      <div id="sect-upgrade"></div>
    </div>
    <div class="card full admin-only">
      <h2>A new version</h2>
      <p class="note">The .tar.gz of a new otp, as it was released. It is checked before
        anything else: it must be signed by a release key this server trusts, every file in
        it must be the one signed, and it must not be older than what runs here. Root checks
        it all again before it is put in.</p>
      <div class="drop" id="up-drop">
        <input type="file" id="up-file" accept=".gz,.tgz,application/gzip,application/octet-stream" hidden>
        <span id="up-drop-says">Drop the otp-X.Y.Z.tar.gz here, or press to choose it</span>
      </div>
      <div id="up-pkg"></div>
      <div class="btnrow" style="margin-top:10px">
        <button class="btn cmd primary" id="up-start" data-icon="play" disabled>Upgrade</button>
        <button class="btn cmd" id="up-forget" data-icon="trash" hidden>Forget the package</button>
      </div>
      <div id="up-ready"></div>
    </div>
    <div class="card full admin-only" id="up-down-card" hidden>
      <h2>Going back to an older version</h2>
      <p class="note">Only to a version that is safe: one that reads what the newer versions
        wrote into the database the same, and has every security fix that matters - each version
        says how far back it may go, and the highest of what ran on this database and was
        installed on this machine counts. The database is not put back nor changed: its tables
        stay as they are and the older version runs on them, so it does not matter how big it
        is. The package is checked like an upgrade's, and against this database's tables, before
        anything is put in; then the nodes go back one at a time, as in an upgrade.</p>
      <div id="up-down"></div>
    </div>
    <div class="card full" id="up-plan-card" hidden>
      <h2>The upgrade</h2>
      <div id="up-plan"></div>
      <p class="note small" id="up-retry" style="min-height:1.4em;margin:6px 0 0"></p>
      <div class="btnrow" style="margin-top:10px">
        <button class="btn cmd danger admin-only" id="up-cancel" data-icon="cancel" hidden>Stop it</button>
      </div>
    </div>
    <div class="card full">
      <h2>What root said last <span class="mono small muted" id="up-log-node" data-no-i18n></span></h2>
      <p class="note"><span>The output of install.sh, the last time this node was upgraded from these pages.</span>
        <span class="mono" data-no-i18n>/var/lib/otp/upgrade/last.log</span></p>
      <!-- Folded until asked for (1.0.196): a long log pushed the rest down. -->
      <details class="fold" id="up-log-fold">
        <summary>the output</summary>
        <div class="seg" id="up-log-nodes" hidden style="margin:10px 0"></div>
        <pre class="lines" id="up-log">–</pre>
      </details>
    </div>
    <div class="card full">
      <h2>On the command line</h2>
      <p class="note">The same, by hand, on each node in turn, as root:</p>
      <pre class="lines">otp --maintenance on --why "upgrade"     # out of service
tar xzf otp-X.Y.Z.tar.gz && cd otp-X.Y.Z
./install.sh --upgrade                     # takes it out and back by itself as well
otp --maintenance off                      # back in service (if it was put out by hand)
otp --upgrade-status                       # an upgrade started on these pages</pre>
    </div>
  </div>

  <div class="ctl-pane" id="pane-about" hidden>
    <div class="ctl-head"><h2 class="ctl-title">About</h2></div>
    <div class="card full"><div id="about-state"></div></div>
    <div class="card full"><div id="sect-about"></div></div>
  </div>

  <div class="card full" id="rest-card" hidden><div id="sect-rest"></div></div>

  <div class="save-bar admin-only" id="save-bar">
    <button class="btn cmd primary" id="set-save" data-icon="save"
            title="Save the changed settings into the database. They take effect the moment they are saved - nothing restarts.">Save the changes</button>
    <button class="btn cmd" id="set-reset" data-icon="undo"
            title="Throw away the changes on this page and read the settings back from the daemon as they are.">Put them back</button>
    <span class="muted small" id="set-said"></span>
  </div>
  </div>
</div>
</section>

</div><!-- /wrap -->

<div class="modal" id="modal" hidden>
  <div class="box" id="modal-box">
    <div class="head"><h3 id="modal-title">…</h3>
      <button class="xbtn" id="modal-x" data-icon="close" aria-label="Close"></button></div>
    <div class="body" id="modal-body"></div>
    <div class="foot" id="modal-foot"></div>
  </div>
</div>
<div class="toast" id="toast"></div>
<script nonce="<?= h($nonce) ?>">
var ME = <?= json_encode($me, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
/* Only Windows (1.0.274): no field for a password anywhere on these pages. */
var PW_OFF = <?= (is_array($health) && array_key_exists('password', $health) && $health['password'] === false) ? 'true' : 'false' ?>;
var STATUS = <?= $initial ? json_encode($initial, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) : 'null' ?>;
var PHP_SAFETY = <?= ($me['role'] ?? '') === 'fulladmin' ? json_encode(otp_php_safety(), JSON_HEX_TAG | JSON_HEX_AMP) : 'null' ?>;
</script>
<script nonce="<?= h($nonce) ?>" src="/assets/core.js?v=<?= h(OTP_VERSION) ?>"></script>
<script nonce="<?= h($nonce) ?>" src="/assets/cols.js?v=<?= h(OTP_VERSION) ?>"></script>
<script nonce="<?= h($nonce) ?>" src="/assets/hload.js?v=<?= h(OTP_VERSION) ?>"></script>
<script nonce="<?= h($nonce) ?>" src="/assets/admin.js?v=<?= h(OTP_VERSION) ?>"></script>
</body>
</html>
